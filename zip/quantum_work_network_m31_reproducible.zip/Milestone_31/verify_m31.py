"""Replay the M31 holdout trials with M30's independent physics and causality audit."""

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime
from itertools import product
import json
import math
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent
M30 = REPO / "Milestone_30"
ORIGINS = tuple(f"V{number:02}" for number in range(1, 9))
POLICIES = ("RP", "P3+IA")
MODE_FOLDERS = {"rk4": "stages", "exact": "exact_online"}
REUSE_FILES = ("equivalent_policy.json", "equivalent_anchor.json", "ablation_reuse.json",
               "archived_wait_tail.json")

os.environ["OPENBLAS_NUM_THREADS"] = "1"
sys.path.insert(0, str(M30))
import verify_m30 as a30

from verify_m27 import State, np, physical_state, read_rows, sha256, state_sha256


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def verify_freeze(root):
    frozen_path = root / "freeze.json"
    frozen = read_json(frozen_path)
    required = {"Milestone_30/PROTOCOL_M30.md", "Milestone_30/m30_control.py"}
    if not required <= frozen["upstream_files"].keys():
        raise ValueError("The freeze must bind the M30 protocol and controller")
    files = {
        root / "PROTOCOL_M31.md": frozen["protocol_sha256"],
        root / "HOLDOUT_RECIPES_M31.json": frozen["recipe_sha256"],
        **{REPO / name: digest for name, digest in frozen["upstream_files"].items()},
    }
    for path, digest in files.items():
        if sha256(path) != digest:
            raise ValueError(f"Frozen input changed: {path}")
    return frozen, sha256(frozen_path)


def seed_registry(root, frozen, freeze_digest):
    folder = root / "holdout"
    registry_path = folder / "sources.csv"
    manifest = read_json(folder / "manifest.json")
    if (manifest["freeze_sha256"] != freeze_digest
            or manifest["input_registry_sha256"] != sha256(registry_path)
            or datetime.fromisoformat(manifest["registered_at"]) < datetime.fromisoformat(frozen["registered_at"])):
        raise ValueError("Held-out registration does not match the frozen protocol")
    records = read_rows(registry_path)
    seed = {}
    for row in records:
        origin = row["origin"]
        path = folder / "densities" / f"{origin}.npz"
        if origin in seed or origin not in ORIGINS or (folder / row["archive_file"]).resolve() != path.resolve():
            raise ValueError(f"Invalid holdout source registration: {origin}")
        source_time = float(row["source_time"])
        digest = sha256(path)
        if (digest != row["archive_sha256"] or digest != manifest["input_archives"][origin]
                or not math.isfinite(source_time) or float(row["preparation_elapsed"]) < 0
                or any(row[name] != frozen[name] for name in ("protocol_sha256", "recipe_sha256"))):
            raise ValueError(f"Holdout archive provenance mismatch: {path}")
        fingerprints = {label: row[f"{label}_sha256"] for label in a30.RESOLUTIONS}
        with np.load(path, allow_pickle=False) as archive:
            if (int(archive["tick"].item()) != 0 or json.loads(str(archive["records"].item())) != []
                    or source_time != float(archive["source_time"].item())):
                raise ValueError(f"Holdout must begin at elapsed zero with no control history: {path}")
            for label, fingerprint in fingerprints.items():
                matrix = archive[label]
                physical_state(State(matrix, source_time), f"{origin}/{label}")
                if state_sha256(matrix) != fingerprint:
                    raise ValueError(f"Holdout density fingerprint mismatch: {origin}/{label}")
        seed[origin] = (path, source_time, fingerprints, digest)
    if set(seed) != set(ORIGINS):
        raise ValueError(f"Missing registered holdout states: {sorted(set(ORIGINS) - seed.keys())}")
    return seed


def audit_source_hashes():
    files = [Path(__file__), M30 / "verify_m30.py"]
    files.extend(REPO / f"Milestone_{number}" / f"verify_m{number}.py" for number in range(25, 30))
    files.append(Path(sys.modules["m21_observables"].__file__).resolve())
    return {path.relative_to(REPO).as_posix(): sha256(path) for path in files}


def branch_inputs(key, folders, seed, mode):
    _, _, policy, _ = key
    files = []
    for cap, folder in folders.items():
        checkpoint = folder / "checkpoint.npz"
        if not checkpoint.is_file():
            raise ValueError(f"Missing M31 saved branch: {folder}")
        if any((folder / filename).exists() for filename in REUSE_FILES):
            raise ValueError(f"M31 holdout trajectories must be run directly: {folder}")
        expected = (*key, mode)
        summary, = read_rows(folder / "m30_checkpoints.csv")
        observed = tuple(summary[name] for name in ("group", "origin", "policy", "precision", "propagation"))
        if observed != expected:
            raise ValueError(f"Wrong M31 checkpoint branch identity at {folder}")
        with np.load(checkpoint, allow_pickle=False) as saved:
            if (saved["propagation"].item() != mode or saved["policy"].item() != policy
                    or float(saved["source_time"].item()) != seed[1] or int(saved["tick"].item()) != cap):
                raise ValueError(f"Wrong M31 checkpoint provenance at {folder}")
        files.extend(path for path in sorted(folder.iterdir()) if path == checkpoint or path.suffix == ".csv")
    return (key, folders, *seed[:3], mode == "exact", False, False), files


def audit(root, workers, modes, origins, cache, available_only):
    frozen, freeze_digest = verify_freeze(ROOT)
    sources = seed_registry(root, frozen, freeze_digest)
    audit_hashes = audit_source_hashes()
    sentinels = a30.control_sentinels()
    jobs, completed, order = {}, {}, {}
    omitted = []
    for mode in modes:
        levels = a30.RESOLUTIONS if mode == "rk4" else ("coarse",)
        order[mode] = []
        for origin, policy, precision in product(origins, POLICIES, levels):
            key = ("holdout", origin, policy, precision)
            folders = a30.branch_folders(root / MODE_FOLDERS[mode], key, a30.BOUNDARIES)
            if available_only and any(not (folder / "checkpoint.npz").is_file()
                                      for folder in folders.values()):
                omitted.append("/".join((mode, *key)))
                continue
            order[mode].append(key)
            arguments, files = branch_inputs(key, folders, sources[origin], mode)
            metadata = {
                "freeze_sha256": freeze_digest,
                "audit_source_sha256": audit_hashes,
                "python_version": sys.version.split()[0],
                "numpy_version": np.__version__,
                "initial_archive_sha256": sources[origin][3],
                "artifacts": {path.relative_to(root).as_posix(): sha256(path) for path in files},
            }
            path = cache / mode / f"{origin}_{policy}_{precision}.json"
            identifier = mode, key
            if path.is_file():
                prior = read_json(path)
                if prior["metadata"] == metadata:
                    completed[identifier] = prior["audit"]
                    continue
            jobs[identifier] = arguments, path, metadata

    total = len(jobs) + len(completed)
    if not total:
        raise ValueError("No registered holdout branches have completed all three boundaries")
    print(f"Independent replay: {len(jobs)} to audit, {len(completed)} cached, {len(omitted)} incomplete", flush=True)

    def record(identifier, result):
        _, path, metadata = jobs[identifier]
        a30.write_json(path, {"metadata": metadata, "audit": result})
        completed[identifier] = result
        if len(completed) % 8 == 0 or len(completed) == total:
            print(f"Independent replay: {len(completed)}/{total} selected branches verified", flush=True)

    if workers == 1:
        for identifier, (arguments, _, _) in jobs.items():
            record(identifier, a30.audit_branch(*arguments))
    elif jobs:
        failures = []
        with ProcessPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(a30.audit_branch, *arguments): identifier
                       for identifier, (arguments, _, _) in jobs.items()}
            for future in as_completed(futures):
                identifier = futures[future]
                try:
                    record(identifier, future.result())
                except Exception as error:
                    failures.append((identifier, error))
        if failures:
            raise RuntimeError(f"Independent holdout replay failed at {[key for key, _ in failures]}") from failures[0][1]

    report = {
        "freeze_sha256": freeze_digest,
        "protocol_sha256": frozen["protocol_sha256"],
        "audit_source_sha256": audit_hashes,
        "registered_boundaries": [tick / 1000 for tick in a30.BOUNDARIES],
        "initial_archives_sha256": {origin: sources[origin][3] for origin in origins},
        "control_adapter_sentinels": {name: sentinels[name] for name in POLICIES},
        "omitted_incomplete_branches": omitted,
    }
    for mode, keys in order.items():
        branches = {"/".join(key): completed[mode, key] for key in keys}
        if not branches:
            report[mode] = {"totals": {"branches": 0}, "branches": {}}
            continue
        totals = a30.a28.totals_for(branches.values())
        for field in ("decision_observations", "observed_scalars", "forced_limits",
                      "max_waits", "pending_prefix_samples_reproduced"):
            totals[field] = sum(row[field] for row in branches.values())
        totals["max_pending_projection_error"] = max(row["max_pending_projection_error"]
                                                     for row in branches.values())
        report[mode] = {"totals": totals, "branches": branches}
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--cache", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--modes", choices=MODE_FOLDERS, nargs="+", default=tuple(MODE_FOLDERS))
    parser.add_argument("--origins", choices=ORIGINS, nargs="+", default=ORIGINS)
    parser.add_argument("--available-only", action="store_true", help="Audit only fully saved branches")
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("--workers must be at least 1")
    modes = tuple(dict.fromkeys(args.modes))
    origins = tuple(dict.fromkeys(args.origins))
    complete = set(modes) == set(MODE_FOLDERS) and set(origins) == set(ORIGINS) and not args.available_only
    if not complete and args.output is None:
        parser.error("Use --output for a selected subset of the independent audit")
    root = args.root.resolve()
    output = args.output or root / "results" / "audit_independent.json"
    cache = args.cache or root / "audit_cache"
    result = audit(root, args.workers, modes, origins, cache, args.available_only)
    a30.write_json(output, result)
    print(f"Published {sum(result[mode]['totals']['branches'] for mode in modes)} audited branches at {output}")


if __name__ == "__main__":
    main()
