# M31 再現手順

M30のP3+IAとRPを、M30で使わなかったV01〜V08の初期密度で比較する。[正式報告書](MILESTONE_31_HELDOUT_CONTROL_VALIDATION_REPORT.md) [事前固定プロトコル](PROTOCOL_M31.md) [準備レシピ](HOLDOUT_RECIPES_M31.json) [固定ファイルのハッシュ](freeze.json)

## 実行

リポジトリのルートでWindows PowerShellを使用。Python 3.14.10、NumPy 2.5.5、Matplotlib 3.10.9。M23〜M30の元コードと、M24・M26の起点登録簿が指すM23の保存密度、M28のアンカー、M29のU01〜U06の準備密度が必要。

```powershell
py -3.14 -m pip install 'numpy==2.5.5' 'matplotlib==3.10.9'
$m31Redo = Join-Path (Get-Location) 'Milestone_31/redo'
py -3.14 -B Milestone_31/prepare_m31.py --output $m31Redo
py -3.14 -B Milestone_31/run_m31.py --output $m31Redo --workers 6
py -3.14 -B Milestone_31/analyze_m31.py --root $m31Redo
py -3.14 -B Milestone_31/verify_m31.py --root $m31Redo --workers 6
```

`run_m31.py` は初期密度の登録を確認し、各枝の0から評価する。保存済みの枝を別方式へ流用する処理はない。同一枝の保存境界が一致すれば続行できる。`verify_m31.py` は独立計算で台帳と保存密度を照合し、入力と出力のハッシュが一致する監査結果を再実行時に使用する。

## 成果物

| 場所 | 内容 |
| --- | --- |
| `holdout/` | 初期密度のペア、準備操作、物理量、過去の登録密度および新規状態間の距離、来歴とハッシュ |
| `stages/holdout/`、`exact_online/holdout/` | 粗・半刻みRK4と厳密オンラインの各枝。経過150・300・540の密度、操作と観測の台帳 |
| `results/m31_paired_endpoints.csv`、`results/m31_group_metrics.csv` | 経過540のRPとの差、個別90%・全体95%の判定、観測・演算負担 |
| `results/m31_timeline.csv`、`results/m31_work_events.csv` | 共通時計の仕事と操作単位の会計 |
| `results/m31_numerical_comparison.csv`、`results/m31_policy_divergences.csv` | 数値方式間の時計と終点差、同一初期状態からRPとP3+IAの操作が初めて分かれる試行 |
| `results/audit_independent.json` | 物理量、観測、会計、保存境界の独立照合 |
| `results/audit_historical_fingerprints.json` | M25〜M30の公開試行台帳と新規初期密度の完全一致の有無を調べたハッシュ照合 |
| `figures/` | 終点と判定幅、粗刻みの全仕事軌道 |

仕事はモデルのエネルギー単位。回収を正とする正味仕事は、受動化による回収から切断・再接続で系に加えた符号付き仕事を引く。待機や停止が途中でも、指定時刻までに実行済みの操作をその時刻の収支に入れる。`propagation=exact, precision=coarse` の `coarse` は準備密度を指す。
