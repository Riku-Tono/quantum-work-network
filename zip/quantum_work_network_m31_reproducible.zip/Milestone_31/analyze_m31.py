"""Summarize the fixed M30 rule's out-of-sample performance in M31."""

import argparse
from collections import defaultdict
import json
import math
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / "Milestone_30"))

from analyze_m30 import TOL, information_design, read_branch, retention, table


ORIGINS = tuple(f"V{i:02}" for i in range(1, 9))
FAMILY = dict(zip(ORIGINS, ("reachable",) * 4 + ("product",) * 4, strict=True))
POLICIES = ("RP", "P3+IA")
LANES = (
    ("rk4", "coarse", "stages"),
    ("rk4", "half", "stages"),
    ("exact", "coarse", "exact_online"),
)
COSTS = (
    "reconnect_real_scalars_completed_trials", "reconnect_control_observation_points_completed_trials",
    "connected_observation_points_completed_trials", "amplitude_evaluations", "angle_evaluations",
    "threshold_abs_initial", "forced_attempts", "forced_short_deadline_attempts", "forced_net_work",
)
PHYSICAL_FIELDS = ("start_tick", "reconnect_tick", "end_tick", "accepted")
DECISION_FIELDS = (*PHYSICAL_FIELDS, "forecast_decision_tick", "reconnect_reason", "stop_reason")


def sign(value):
    return (value > 0) - (value < 0)


def add_retention(baseline, candidate):
    reference = baseline["net_work"]
    for row in (baseline, candidate):
        work = row["net_work"]
        ratio, passed = retention(work, reference, 0.90)
        row.update(rp_work=reference, rp_delta=work - reference, rp_retention=ratio, state90=passed,
                   state90_minimum_work=0.90 * reference if reference > TOL else reference - TOL,
                   work_sign=sign(work), same_sign_as_rp=sign(work) == sign(reference))


def paired_endpoints(endpoints):
    by_pair = defaultdict(dict)
    keys = ("propagation", "precision", "origin", "family")
    for row in endpoints:
        by_pair[tuple(row[key] for key in keys)][row["policy"]] = row
    for identity, members in by_pair.items():
        rp, candidate = (members[policy] for policy in POLICIES)
        yield {**dict(zip(keys, identity, strict=True)),
               "rp_work": rp["net_work"], "candidate_work": candidate["net_work"],
               **{key: candidate[key] for key in ("rp_delta", "rp_retention", "state90", "state90_minimum_work", "same_sign_as_rp")},
               "rp_work_sign": rp["work_sign"], "candidate_work_sign": candidate["work_sign"],
               **{f"delta_{field}": candidate[field] - rp[field] for field in COSTS}}


def group_metrics(endpoints):
    for propagation, precision, _ in LANES:
        for scope in ("all", "reachable", "product"):
            by_policy = {
                policy: [row for row in endpoints if (row["propagation"], row["precision"], row["policy"])
                         == (propagation, precision, policy) and (scope == "all" or row["family"] == scope)]
                for policy in POLICIES
            }
            rp, candidate = (by_policy[policy] for policy in POLICIES)
            rp_work = math.fsum(row["net_work"] for row in rp) / len(rp)
            work = math.fsum(row["net_work"] for row in candidate) / len(candidate)
            ratio, passed = retention(work, rp_work, 0.95)
            failed = [row["origin"] for row in candidate if not row["state90"]]
            sign_changed = [row["origin"] for row in candidate if not row["same_sign_as_rp"]]
            ratios = [row["rp_retention"] for row in candidate if row["rp_retention"] is not None]
            yield {"propagation": propagation, "precision": precision, "scope": scope, "states": len(candidate),
                   "rp_mean_work": rp_work, "candidate_mean_work": work, "mean_work_delta": work - rp_work,
                   "mean_rp_retention": ratio, "mean95": passed, "all_states90": not failed,
                   "passes_both": passed and not failed, "states_below90": " ".join(failed),
                   "states_sign_changed": " ".join(sign_changed), "states_with_ratio": len(ratios),
                   "min_state_rp_retention": min(ratios, default=None),
                   **{f"{label}_{field}": math.fsum(row[field] for row in members) / len(members)
                      for label, members in (("rp_mean", rp), ("candidate_mean", candidate)) for field in COSTS}}


def first_difference(reference, candidate, fields):
    for number, (old, new) in enumerate(zip(reference, candidate), 1):
        if any(old[field] != new[field] for field in fields):
            return number, old, new
    common = min(len(reference), len(candidate))
    if len(reference) != len(candidate):
        return (common + 1, reference[common] if len(reference) > common else {},
                candidate[common] if len(candidate) > common else {})
    return None, {}, {}


def numerical_comparisons(endpoint_index, trial_index):
    for origin in ORIGINS:
        for policy in POLICIES:
            base = ("rk4", "coarse", origin, policy)
            for propagation, precision, _ in LANES[1:]:
                alternate = (propagation, precision, origin, policy)
                coarse, other = endpoint_index[base], endpoint_index[alternate]
                first, left, right = first_difference(trial_index[base], trial_index[alternate], DECISION_FIELDS)
                yield {"origin": origin, "family": FAMILY[origin], "policy": policy,
                       "comparison": "half" if precision == "half" else "exact_online",
                       "coarse_work": coarse["net_work"], "comparison_work": other["net_work"],
                       "work_difference": other["net_work"] - coarse["net_work"],
                       "same_work_sign": other["work_sign"] == coarse["work_sign"],
                       "same_state90": other["state90"] == coarse["state90"],
                       "same_chronology": first is None, "first_mismatch_attempt": first,
                       **{f"{label}_{field}": record.get(field) for label, record in (("coarse", left), ("comparison", right))
                          for field in DECISION_FIELDS}}


def policy_divergences(trial_index):
    details = (*DECISION_FIELDS, "tau", "cut_on", "reconnect_on", "passivation", "net_work")
    for propagation, precision, _ in LANES:
        for origin in ORIGINS:
            rp, candidate = (trial_index[propagation, precision, origin, policy] for policy in POLICIES)
            first, left, right = first_difference(rp, candidate, PHYSICAL_FIELDS)
            yield {"propagation": propagation, "precision": precision, "origin": origin, "family": FAMILY[origin],
                   "same_physical_schedule": first is None, "first_split_attempt": first,
                   "common_start_hash": left["start_state_hash"] == right["start_state_hash"] if left and right else None,
                   **{f"{label}_{field}": record.get(field) for label, record in (("rp", left), ("candidate", right))
                      for field in details}}


def plot(pairs, events, output):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np

    output.mkdir(parents=True, exist_ok=True)
    colors = {"RP": "#373e49", "P3+IA": "#17766c"}
    coarse = [row for row in pairs if (row["propagation"], row["precision"]) == ("rk4", "coarse")]
    x = np.arange(len(coarse))
    fig, (work, margin) = plt.subplots(2, 1, figsize=(9, 6.4), sharex=True, layout="constrained")
    work.bar(x - 0.18, [row["rp_work"] * 1e6 for row in coarse], 0.34, color=colors["RP"], label="RP")
    work.bar(x + 0.18, [row["candidate_work"] * 1e6 for row in coarse], 0.34, color=colors["P3+IA"], label="P3+IA")
    work.set_ylabel("Executed net work (×10⁻⁶)")
    work.legend(frameon=False, ncols=2)
    for propagation, precision, marker, label, offset in (("rk4", "coarse", "o", "RK4 coarse", -0.13),
                                                          ("rk4", "half", "s", "RK4 half", 0),
                                                          ("exact", "coarse", "D", "Exact online", 0.13)):
        selected = [row for row in pairs if (row["propagation"], row["precision"]) == (propagation, precision)]
        margins = [(row["candidate_work"] - row["state90_minimum_work"]) * 1e6 for row in selected]
        margin.scatter(x + offset, margins, marker=marker, s=32, label=label, zorder=3)
    margin.set_ylabel("P3+IA margin above state criterion (×10⁻⁶)")
    margin.set_xticks(x, [row["origin"] for row in coarse])
    margin.legend(frameon=False, ncols=3)
    for axis in (work, margin):
        axis.axhline(0, color="#707780", lw=0.85)
        axis.axvline(3.5, color="#9fa5a8", lw=0.7, ls=":")
        axis.grid(axis="y", alpha=0.20)
    fig.suptitle("Frozen M30 control on held-out initial states at elapsed 540")
    fig.savefig(output / "m31_01_endpoint_work.png", dpi=185)
    plt.close(fig)

    fig, panels = plt.subplots(2, 4, figsize=(12, 5.6), sharex=True, layout="constrained")
    by_lane = defaultdict(list)
    for event in events:
        if (event["propagation"], event["precision"]) == ("rk4", "coarse"):
            by_lane[event["origin"], event["policy"]].append(event)
    for axis, origin in zip(panels.flat, ORIGINS, strict=True):
        for policy in POLICIES:
            series = by_lane[origin, policy]
            clocks = [0, *(event["elapsed"] for event in series), 540]
            cumulative = np.cumsum([0, *(event["work_to_user"] * 1e6 for event in series), 0])
            axis.step(clocks, cumulative, where="post", color=colors[policy], lw=1.2, label=policy)
        axis.set_title(f"{origin}  ·  {FAMILY[origin]}")
        axis.set_xticks((0, 180, 360, 540))
        axis.axhline(0, color="#8d959c", lw=0.7)
        axis.grid(axis="y", alpha=0.17)
        if origin == "V08":
            axis.set_ylim(-TOL * 1e6, TOL * 1e6)
    panels[0, 0].legend(loc="upper left", frameon=False, fontsize="small")
    fig.supylabel("Executed net work (×10⁻⁶ model energy)")
    fig.supxlabel("Elapsed time from prepared state (panel y-scales vary)")
    fig.suptitle("Full online work trajectories, RK4 coarse")
    fig.savefig(output / "m31_02_work_trajectories.png", dpi=185)
    plt.close(fig)


def analyze(root, output, figures):
    timeline, events, endpoint_index, trial_index = [], [], {}, {}
    for propagation, precision, parent in LANES:
        for origin in ORIGINS:
            by_policy = {}
            for policy in POLICIES:
                path = root / parent / "holdout" / origin / policy / precision
                meta = {"propagation": propagation, "group": "holdout", "origin": origin, "precision": precision,
                        "policy": policy, "family": FAMILY[origin]}
                trials, branch_events, branch, _ = read_branch(path, meta)
                if branch[-1]["direct_stages"] != 3 or branch[-1]["fork_elapsed"] != 0:
                    raise ValueError(f"Expected three directly executed stages from time zero in {path}")
                key = (propagation, precision, origin, policy)
                endpoint_index[key] = branch[-1]
                trial_index[key] = trials
                by_policy[policy] = branch
                events.extend(branch_events)
            for rp, candidate in zip(*(by_policy[policy] for policy in POLICIES), strict=True):
                if rp["elapsed"] != candidate["elapsed"]:
                    raise ValueError(f"Endpoint clocks differ for {origin}")
                add_retention(rp, candidate)
                timeline.extend((rp, candidate))

    endpoints = list(endpoint_index.values())
    pairs = list(paired_endpoints(endpoints))
    groups = list(group_metrics(endpoints))
    numerical = list(numerical_comparisons(endpoint_index, trial_index))
    output.mkdir(parents=True, exist_ok=True)
    for name, content in (("endpoints", endpoints), ("paired_endpoints", pairs), ("timeline", timeline),
                          ("group_metrics", groups), ("numerical_comparison", numerical),
                          ("policy_divergences", policy_divergences(trial_index)), ("work_events", events),
                          ("information_design", (row for row in information_design() if row["policy"] in POLICIES))):
        table(output / f"m31_{name}.csv", content)
    plot(pairs, events, figures)
    print(json.dumps({"endpoints": len(endpoints), "trials": sum(map(len, trial_index.values())),
                      "work_events": len(events), "numerical_comparisons": len(numerical),
                      "same_chronology": sum(row["same_chronology"] for row in numerical),
                      "overall": [{key: row[key] for key in ("propagation", "precision", "mean_rp_retention",
                                                            "passes_both", "states_below90")}
                                  for row in groups if row["scope"] == "all"]}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT, help="Folder with stages and exact_online")
    parser.add_argument("--output", type=Path, help="Table destination (default is ROOT/results)")
    parser.add_argument("--figures", type=Path, help="Figure destination (default is ROOT/figures)")
    args = parser.parse_args()
    analyze(args.root, args.output or args.root / "results", args.figures or args.root / "figures")
