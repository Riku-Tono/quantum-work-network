"""Generate and register fixed M31 input states before running any policy."""

import argparse
from datetime import datetime
from decimal import Decimal
from itertools import combinations
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent
RECIPE = ROOT / "HOLDOUT_RECIPES_M31.json"
FREEZE = ROOT / "freeze.json"
PROTOCOL = ROOT / "PROTOCOL_M31.md"
M24_SOURCES = REPO / "Milestone_24/results/m24_sources.csv"
M29_SOURCES = REPO / "Milestone_29/unseen/sources.csv"
ORIGINS = tuple(f"V{i:02}" for i in range(1, 9))

os.environ["OPENBLAS_NUM_THREADS"] = "1"
sys.path.insert(0, str(REPO / "Milestone_29"))

import numpy as np
import prepare_unseen_m29 as prior


def checked_freeze():
    freeze = json.loads(FREEZE.read_text(encoding="utf-8"))
    files = {RECIPE: freeze["recipe_sha256"], PROTOCOL: freeze["protocol_sha256"],
             **{REPO / name: digest for name, digest in freeze["upstream_files"].items()}}
    for path, expected in files.items():
        if prior.digest(path.read_bytes()) != expected:
            raise ValueError(f"Frozen file changed: {path}")
    return freeze


def phase_factors(angle):
    return np.exp(1j * angle * prior.LOAD_LEVELS)


def product(settings):
    chain = np.ones((1, 1))
    for p in settings["chain_excited_probabilities"]:
        coherence = settings["chain_offdiagonal_fraction"] * np.sqrt(p * (1 - p))
        chain = np.kron(chain, [[1 - p, coherence], [coherence, p]])
    angle = settings["load_rotation_rad"]
    cos, sin = np.cos(angle), np.sin(angle)
    rotation = np.array([[cos, -sin, 0], [sin, cos, 0], [0, 0, 1]])
    load = rotation @ np.diag(settings["load_eigenvalues"]) @ rotation.T
    phase = phase_factors(settings["load_phase_rad"])
    rho = np.kron(chain, phase[:, None] * load * phase.conjugate()[None, :])
    return prior.Prepared((rho, rho.copy()), 0, prior.G, ())


def make_inputs(dynamics, recipe, sources):
    for origin, settings in recipe["reachable"].items():
        seed = sources[settings["seed"]]
        pair = prior.source_pair(prior.M23, seed)
        state = prior.apply_preparation(dynamics, pair, settings["operations"])
        angle = settings.get("load_phase_rad")
        if angle is not None:
            phase = np.tile(phase_factors(angle), prior.CHAIN_DIM)
            pair = tuple(phase[:, None] * rho * phase.conjugate()[None, :] for rho in state.pair)
            state = prior.record_step(dynamics, state, pair, 0, prior.G, "load_number_phase",
                                      factor=np.exp(1j * angle))
        time = float(Decimal(seed["source_time"]) + Decimal(state.clock) / 1000)
        yield state, {"origin": origin, "family": "reachable", "archived_source": settings["seed"],
                      "preparation_elapsed": state.clock / 1000, "source_time": time, "load_phase_rad": angle}
    for origin, settings in recipe["product"].items():
        yield product(settings), {"origin": origin, "family": "product", "archived_source": "",
                                  "preparation_elapsed": 0.0, "source_time": 0.0,
                                  "load_phase_rad": settings["load_phase_rad"]}


def references(sources):
    # M24's registry includes the M23 starts as well as the extra M25/M26 starts.
    old_rows = {row["origin"]: row for row in prior.read_rows(M24_SOURCES)}
    for origin, source in old_rows.items():
        if origin in sources:
            if source != sources[origin]:
                raise ValueError(f"Historical source registries disagree at {origin}")
            continue
        pair = prior.source_pair(prior.M23, source)
        for level, rho in zip(prior.PRECISIONS, pair, strict=True):
            yield rho, {"reference_group": "M24_sources", "reference_origin": origin,
                        "reference_precision": level, "reference_source_time": source["source_time"],
                        "reference_elapsed": 0.0, "reference_rho_sha256": prior.fingerprint(rho)}
    yield from prior.reference_pairs(sources.values())
    for source in prior.read_rows(M29_SOURCES):
        pair = load_registered_pair(M29_SOURCES.parent, source)
        for level, rho in zip(prior.PRECISIONS, pair, strict=True):
            yield rho, {"reference_group": "M29_M30_U", "reference_origin": source["origin"],
                        "reference_precision": level, "reference_source_time": source["source_time"],
                        "reference_elapsed": 0.0, "reference_rho_sha256": prior.fingerprint(rho)}


def load_registered_pair(folder, source):
    path = folder / source["archive_file"]
    if prior.digest(path.read_bytes()) != source["archive_sha256"]:
        raise ValueError(f"Wrong density archive: {path}")
    with np.load(path, allow_pickle=False) as saved:
        pair = tuple(saved[level] for level in prior.PRECISIONS)
        if (int(saved["tick"]) != 0 or json.loads(str(saved["records"].item())) != []
                or float(saved["source_time"]) != float(source["source_time"])):
            raise ValueError(f"Wrong evaluation seed metadata: {path}")
    for level, rho in zip(prior.PRECISIONS, pair, strict=True):
        if prior.fingerprint(rho) != source[f"{level}_sha256"]:
            raise ValueError(f"Wrong density key {level}: {path}")
    return pair


def distance_rows(inputs, sources):
    for rho, ref in references(sources):
        index = prior.PRECISIONS.index(ref["reference_precision"])
        for state, meta in inputs:
            yield prior.distance_row(meta["origin"], ref["reference_precision"], state.pair[index], rho, ref)
    for (left, a), (right, b) in combinations(inputs, 2):
        for level, rho, other in zip(prior.PRECISIONS, left.pair, right.pair, strict=True):
            yield prior.distance_row(a["origin"], level, rho, other,
                                     {"reference_group": "M31_holdout", "reference_origin": b["origin"],
                                      "reference_precision": level, "reference_source_time": b["source_time"],
                                      "reference_elapsed": 0.0, "reference_rho_sha256": prior.fingerprint(other)})


def prepare(output):
    freeze = checked_freeze()
    recipe = json.loads(RECIPE.read_text(encoding="utf-8"))
    if (recipe["time_ticks_per_unit"], recipe["coupling"], tuple(recipe["rk4_steps"])) != (1000, prior.G, prior.DT):
        raise ValueError("The frozen recipe and inherited dynamics disagree")
    sources = {row["origin"]: row for row in prior.read_rows(prior.SOURCE_TABLE)}
    dynamics = prior.model()
    inputs = list(make_inputs(dynamics, recipe, sources))
    if tuple(meta["origin"] for _, meta in inputs) != ORIGINS:
        raise ValueError("Recipes must cover exactly the registered V01–V08")
    distances = list(distance_rows(inputs, sources))
    nearest = min(row["global_trace_distance"] for row in distances)
    if nearest <= recipe["minimum_same_precision_trace_distance"]:
        raise ValueError(f"A registered input is too close to another input or a historical source: {nearest:g}")

    directory = output / "holdout"
    registry, physical, steps = [], [], []
    for state, meta in inputs:
        hashes = {f"{level}_sha256": prior.fingerprint(rho)
                  for level, rho in zip(prior.PRECISIONS, state.pair, strict=True)}
        name = f"densities/{meta['origin']}.npz"
        archive = prior.archive_bytes(state, meta["source_time"])
        for level, rho in zip(prior.PRECISIONS, state.pair, strict=True):
            metrics = prior.state_metrics(dynamics, rho)
            preparation_work = sum(row["signed_external_work_on_system"] for row in state.history
                                   if row["precision"] == level)
            physical.append({**meta, "precision": level, "coupling": prior.G, **metrics,
                             "q": -metrics["c_imag"],
                             "preparation_signed_external_work": preparation_work if state.history else None})
        registry.append({**meta, **hashes, "archive_file": name, "archive_sha256": prior.digest(archive),
                         "protocol_sha256": freeze["protocol_sha256"], "recipe_sha256": freeze["recipe_sha256"]})
        steps.extend({"origin": meta["origin"], "operation_index": index // 2 + 1, **row}
                     for index, row in enumerate(state.history))
        prior.write_once(directory / name, archive)

    prior.write_table(directory / "sources.csv", registry)
    prior.write_table(directory / "physical_metrics.csv", physical)
    prior.write_table(directory / "generation_steps.csv", steps)
    prior.write_table(directory / "trace_distances.csv", distances)
    manifest_path = directory / "manifest.json"
    timestamp = (json.loads(manifest_path.read_text(encoding="utf-8"))["registered_at"]
                 if manifest_path.exists() else datetime.now().astimezone().isoformat(timespec="seconds"))
    manifest = {"registered_at": timestamp, "freeze_sha256": prior.digest(FREEZE.read_bytes()),
                "generator_sha256": prior.digest(Path(__file__).read_bytes()),
                "input_archives": {row["origin"]: row["archive_sha256"] for row in registry},
                "input_registry_sha256": prior.digest((directory / "sources.csv").read_bytes()),
                "minimum_global_trace_distance": nearest,
                "historical_registries": {path.relative_to(REPO).as_posix(): prior.digest(path.read_bytes())
                                          for path in (M24_SOURCES, prior.SOURCE_TABLE, M29_SOURCES,
                                                       prior.M28_ANCHORS / "m28_anchors.csv")}}
    prior.write_once(manifest_path, (json.dumps(manifest, indent=2) + "\n").encode("utf-8"))
    print(f"Registered {len(inputs)} input states, {len(distances)} distance comparisons, minimum {nearest:.6g}", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT)
    prepare(parser.parse_args().output)
