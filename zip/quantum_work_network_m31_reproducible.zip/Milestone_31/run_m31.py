"""Evaluate the fixed M30 policies online from the registered M31 initial states."""

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import json
import os
from pathlib import Path
import sys

from prepare_m31 import FREEZE, ORIGINS, REPO, ROOT, checked_freeze, load_registered_pair, prior

os.environ["OPENBLAS_NUM_THREADS"] = "1"
sys.path.insert(0, str(REPO / "Milestone_30"))

import m30_control

POLICIES = ("RP", "P3+IA")
CUTOFFS = (150_000, 300_000, 540_000)


def registered_inputs(output):
    freeze = checked_freeze()
    folder = output / "holdout"
    registry = folder / "sources.csv"
    manifest = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
    if (manifest["freeze_sha256"] != prior.digest(FREEZE.read_bytes())
            or manifest["input_registry_sha256"] != prior.digest(registry.read_bytes())):
        raise ValueError("The input registration does not match the frozen experiment")
    sources = prior.read_rows(registry)
    if tuple(row["origin"] for row in sources) != ORIGINS:
        raise ValueError("Unexpected M31 input list")
    for row in sources:
        if (row["recipe_sha256"] != freeze["recipe_sha256"]
                or row["protocol_sha256"] != freeze["protocol_sha256"]
                or row["archive_sha256"] != manifest["input_archives"][row["origin"]]):
            raise ValueError(f"Input does not match the manifest: {row['origin']}")
        load_registered_pair(folder, row)
    return sources


def run_lane(output, source, precision, propagation):
    pair = load_registered_pair(output / "holdout", source)
    seed = (pair, 0, ())
    origin = source["origin"]
    stage_root = "stages" if propagation == "rk4" else "exact_online"
    for policy in POLICIES:
        destination = output / stage_root / "holdout" / origin / policy / precision
        summaries = m30_control.run_branch("holdout", origin, policy, precision, destination,
                                          CUTOFFS, source=source, seed=seed, propagation=propagation)
        result = summaries[-1]
        print(json.dumps({"origin": origin, "policy": policy, "precision": precision,
                          "propagation": propagation, "elapsed": float(result["elapsed_total"]),
                          "work": float(result["cumulative_physical_net"])}), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT)
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--origins", nargs="+", choices=ORIGINS, default=ORIGINS)
    parser.add_argument("--modes", nargs="+", choices=("rk4", "exact"), default=("rk4", "exact"))
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("--workers must be at least one")
    sources = registered_inputs(args.output)
    lanes = [(args.output, source, precision, mode)
             for mode, precision in (("rk4", "coarse"), ("rk4", "half"), ("exact", "coarse"))
             for source in sources if mode in args.modes and source["origin"] in args.origins]
    print(f"Starting {len(lanes)} paired lanes with {args.workers} workers", flush=True)
    if args.workers == 1:
        for lane in lanes:
            run_lane(*lane)
        return
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        tasks = [pool.submit(run_lane, *lane) for lane in lanes]
        for task in as_completed(tasks):
            task.result()


if __name__ == "__main__":
    main()
