# Restore frozen M23 and M28 inputs from their lossless packed bytes.

from pathlib import Path
import base64
import hashlib
import io
import json
import zipfile

import numpy as np


ROOT = Path(__file__).resolve().parent
DIM = 384
BODY = DIM * DIM * 16
TRI = np.triu_indices(DIM)
UPPER = np.triu_indices(DIM, 1)
SIGN = np.array([0, 1 << 63], dtype="<u8")


def unshuffle(raw):
    return np.frombuffer(raw, dtype="u1").reshape(16, -1).T.copy().view("<u8").reshape(-1, 2)


def restore_matrix(relative):
    packed = (ROOT / relative).read_bytes()
    if len(packed) != BODY:
        raise ValueError(f"Wrong packed matrix size: {relative}")
    split = DIM * (DIM + 1) // 2 * 16
    matrix = np.empty((DIM, DIM, 2), dtype="<u8")
    matrix[TRI] = unshuffle(packed[:split])
    matrix[UPPER[1], UPPER[0]] = unshuffle(packed[split:]) ^ matrix[UPPER] ^ SIGN
    return matrix.tobytes()


def verified(raw, expected, context):
    actual = hashlib.sha256(raw).hexdigest()
    if actual != expected:
        raise ValueError(f"Input SHA-256 mismatch: {context}")
    return raw


def publish(relative, raw, *, members=None):
    path = ROOT / relative
    if path.is_file():
        if path.read_bytes() == raw:
            return
        if members is not None:
            with zipfile.ZipFile(path) as current:
                if current.namelist() == list(members) and all(current.read(name) == data for name, data in members.items()):
                    return
        raise ValueError(f"Refusing to replace a different existing input: {relative}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as output:
        output.write(raw)


def main():
    manifest = json.loads((ROOT / "reproduction_inputs" / "packed_inputs.json").read_text(encoding="utf-8"))
    for path, source in manifest["m23"].items():
        raw = base64.b64decode(source["header"]) + restore_matrix(source["matrix"])
        publish(path, verified(raw, source["sha256"], path))

    reconstructed_original_archives = 0
    for path, source in manifest["m28"].items():
        members = {}
        for member, packed in source["members"].items():
            raw = base64.b64decode(packed["prefix"])
            if "matrix" in packed:
                raw += restore_matrix(packed["matrix"])
            members[member] = verified(raw, packed["sha256"], f"{path}/{member}")
        data = io.BytesIO()
        with zipfile.ZipFile(data, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for member, raw in members.items():
                info = zipfile.ZipInfo(member)
                info.create_system = 0
                info.compress_type = zipfile.ZIP_DEFLATED
                with archive.open(info, "w", force_zip64=True) as output:
                    output.write(raw)
        raw = data.getvalue()
        if hashlib.sha256(raw).hexdigest() == source["sha256"]:
            reconstructed_original_archives += 1
        publish(path, raw, members=members)

    print(f"Restored {len(manifest['m23'])} SHA-256-matched M23 binaries and {len(manifest['m28'])} M28 anchors.")
    print(f"M28 anchors matching the original ZIP wrapper bytes: {reconstructed_original_archives}/{len(manifest['m28'])}.")
    print("All M28 array members match their original SHA-256 values.")


if __name__ == "__main__":
    main()
