# M31 standalone reproduction package

M30で固定したP3+IAとRPを、未使用の初期状態V01〜V08で比較したM31の再現パッケージです。正式な実験条件、成果、通過判定は `Milestone_31` のプロトコル、報告書、CSVを参照してください。

## Windows PowerShellで再現

ZIPを展開し、このREADMEのあるフォルダーで実行します。参照環境はPython 3.14.10、NumPy 2.5.5、Matplotlib 3.10.9です。

```powershell
py -3.14 -m pip install -r requirements.txt
py -3.14 -B restore_m31_inputs.py
$m31Redo = Join-Path (Get-Location) 'Milestone_31/redo'
py -3.14 -B Milestone_31/prepare_m31.py --output $m31Redo
py -3.14 -B Milestone_31/run_m31.py --output $m31Redo --workers 6
py -3.14 -B Milestone_31/analyze_m31.py --root $m31Redo
py -3.14 -B Milestone_31/verify_m31.py --root $m31Redo --workers 6
```

公開時の初期密度から評価だけを再実行する場合は、入力復元と新規準備を省き、`run_m31.py`・`analyze_m31.py`・`verify_m31.py` を出力先指定なしで実行できます。集計表や監査への出力先を分けるには、上の再現コマンドを使用します。

## 収録内容

- M31の固定プロトコル・レシピ・評価コード、初期密度、結果CSV、図、独立監査、V04の待機観測記録。
- M31の実行・監査に利用するM23〜M30のコード、M29の未使用状態と来歴、M23とM28の圧縮済み入力。復元はM23の元バイナリとM28の要素配列・保存時刻・履歴をSHA-256で照合します。
- `SHA256SUMS.txt` に展開直後の収録ファイルのハッシュを記載しています。`reproduction_inputs/packed_inputs.json` は復元した入力のハッシュを記録しています。

粗刻み・半刻み・厳密オンラインの144保存境界および監査キャッシュは、上のコマンドで再生成できます。再計算には約1.4 GB以上の作業容量が必要です。過去の試行台帳との照合結果は `Milestone_31/results/audit_historical_fingerprints.json` に記録しています。元の台帳やM30の追加資料は既存の[公開資料](https://github.com/Riku-Tono/quantum-work-network/tree/ca760bb64584bb84ed8c917010c60faa0c092da0/zip)を参照してください。
