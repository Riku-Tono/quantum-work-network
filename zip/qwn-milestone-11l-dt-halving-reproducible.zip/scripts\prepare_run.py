#!/usr/bin/env python3
"""Prepare an isolated 11L full-reproduction run directory."""
from __future__ import annotations

import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "run"
SOURCES = [
    ROOT / "reference" / "coarse-formal" / "input_matching_interpolated_trial_timeseries.csv",
    ROOT / "reference" / "coarse-formal" / "input_matching_interpolated_trial_summary.csv",
    ROOT / "reference" / "coarse-formal" / "input_matching_interpolated_trial_checks.csv",
    ROOT / "reference" / "coarse-formal" / "MILESTONE_11F_REPORT.md",
    ROOT / "reference" / "run-inputs" / "input_matching_precheck_integrals.csv",
    ROOT / "reference" / "run-inputs" / "input_matching_single_probe_summary.csv",
    ROOT / "reference" / "run-inputs" / "input_matching_lower_probe_summary.csv",
    ROOT / "reference" / "run-inputs" / "fixed_total_gamma_1_5_xgamma_summary.csv",
]


def main() -> None:
    if RUN.exists() and any(RUN.iterdir()):
        raise SystemExit("run/ already contains files; use a new clean package extraction for another full run")
    RUN.mkdir(exist_ok=True)
    for source in SOURCES:
        if not source.is_file():
            raise SystemExit(f"missing packaged input: {source}")
        shutil.copy2(source, RUN / source.name)
    (RUN / "tools").mkdir(exist_ok=True)
    shutil.copy2(ROOT / "tools" / "finalize_milestone_11l.py", RUN / "tools" / "finalize_milestone_11l.py")
    print("prepared isolated run/ with 8 read-only inputs and the finalizer")


if __name__ == "__main__":
    main()
