# Milestone 11L: matched N=7条件のdt半減収束検証

## 1. 目的

Milestone 11fでmatchingされたN=7条件について、Omegaを変えず、内部時間刻みだけを0.0025から0.00125へ半減した。

## 2. 実行前ベンチマーク

同じHamiltonian、DiagonalDephasingKernel、RK4、診断経路で16 steps・3保存点を実測した。propagationは0.920835 s/step、diagnosticsは0.665323 s/saved point、full推定は8038.2 sだった。ベンチマーク結果は物理結果に使用していない。

## 3. coarse正式条件

N=7、TOTAL_GAMMA=1.5、Omega=0.18748395731510084、dt=0.0025。target input=5.9618618770136536e-02、formal coarse E_drive_in=5.9618450901925489e-02、relative mismatch=2.816e-06。11f正式CSVは再計算せず、SHA-256が実行前後で一致した。

## 4. fine計算条件

dt=0.00125、8000 RK4 steps、t=0..10、1001保存点。新規full trajectoryはこの1本だけ。

## 5. 変更していない物理条件

J=1、g=0.25、omega=1、tau=3.2、drive frequency=1、sin^2 pulse、drive site=0、load coupling site=6、load dimension=3、vacuum初期状態を固定した。gamma_site=1.5/7を全7 chain siteへ均等適用し、loadへ直接雑音を入れていない。

## 6. drive energy accounting

既存のsigned-power規約と保存点間の線形ゼロ交差分割を維持した。fine E_drive_in=5.9618450901723317e-02、out=0.0000000000000000e+00、net=5.9618450901723317e-02。net=in-out恒等式はPASS。

## 7. fine matching結果

F_fine=-1.6786841321864143e-07、absolute mismatch=1.6786841321864143e-07、relative mismatch=2.8157045010698592e-06。matching preservation verdict: **PASS**。

## 8. matching drift

fine-coarse E_drive_in=-2.0217161278424101e-13、relative change=3.3910913437992649e-12。Omega再調整は行っていない。

## 9. scalar収束

23 metricを比較し、23/23 PASS。FAIL=none。主要値: W_max coarse/fine=3.3852501213e-03/3.3852501213e-03、W(t10)=2.3264679067e-03/2.3264679067e-03、XGamma=5.3283047839e-02/5.3283047838e-02。

## 10. trajectory収束

同じ1001時刻で10量を直接比較し、10/10 PASS。FAIL=none。詳細はtrajectory comparison CSVに最大差、時刻、RMS、mean absolute、relative L2を保存した。

## 11. Wピーク形状

coarse/fine W_max=3.3852501213e-03/3.3852501213e-03、peak time=7.70/7.70、half-max width=3.85/3.85、90%-max width=1.47/1.47、post-peak W(t10)/Wmax=0.68723664/0.68723664。fine peakは内部保存点で、equal peak count=1。shape verdict=PASS。

## 12. 数値品質

finite=PASS、max trace error=3.775e-15、max Hermiticity error=0.000e+00、worst selected eigenvalue=-5.801e-18、primary success/failure=1000/1、fallback success/attempt=1/1、solver failure=0、max ledger residual=5.197e-07、XGamma checks=PASS。

## 13. matchingと物理収束の分離

- matching preservation verdict: **PASS**
- scalar/trajectory convergence verdict: **PASS**

## 14. 直接確認できたこと

指定した同一OmegaのN=7 fine-dt軌道1本について、input matching、主要scalar、同一時刻trajectory、Wピーク形状、数値品質をcoarse正式軌道と比較した。

## 15. 確認できていないこと

fine-dt専用Omega matching、別root、N=3 referenceのdt半減、N=5等入力、TOTAL_GAMMA=3.0等入力、eta=2.25、t>10、N>7、site-resolved機構、抽出サイクル、実機性能は確認していない。

## 16. 主張してはいけないこと

任意dtで収束済み、全matched条件で収束済み、RK4が完全正値写像、fine dtで新しいmatching rootが確定、一般的な長鎖優位、量子優位は主張しない。

## 17. 最終判定

**matched_condition_dt_halving_passed_with_fallback_diagnostic**

## 18. 次段階

結果確認後、Milestone 11iで設計したsite-resolved診断を同一軌道1本で実行する価値を判断する。次段階は自動実行していない。

## 実行記録

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo run --release --offline --bin matched_n7_dt_halving_validation -- --benchmark-only
cargo run --release --offline --bin matched_n7_dt_halving_validation -- --full-run
python tools/finalize_milestone_11l.py finalize
```

full実測 total=6713.820s、propagation=6056.415s、diagnostics=650.119s、comparison=0.146s。
