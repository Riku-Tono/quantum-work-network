#!/usr/bin/env python3
"""Validate supplied or regenerated Milestone 11L outputs."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def check(root: Path, label: str, hashes: dict[str, str] | None = None) -> None:
    coarse = root if hashes else ROOT / "reference" / "coarse-formal"
    if hashes:
        for name, expected in hashes.items():
            if sha256(coarse / name) != expected:
                raise SystemExit(f"FAIL {label}: coarse hash mismatch for {name}")
    summary = rows(root / "matched_n7_dt_halving_summary.csv")[0]
    time_rows = rows(root / "matched_n7_dt_halving_timeseries.csv")
    checks = rows(root / "matched_n7_dt_halving_checks.csv")
    scalar = rows(root / "matched_n7_dt_halving_scalar_comparison.csv")
    trajectory = rows(root / "matched_n7_dt_halving_trajectory_comparison.csv")
    if len(time_rows) != 1001:
        raise SystemExit(f"FAIL {label}: expected 1001 fine time rows")
    if summary["final_classification"] != "matched_condition_dt_halving_passed_with_fallback_diagnostic":
        raise SystemExit(f"FAIL {label}: final classification differs")
    if float(summary["solver_failure_count"]) != 0.0 or summary["matching_tolerance_passed"].lower() != "true":
        raise SystemExit(f"FAIL {label}: matching or solver check failed")
    if any(row["passed"].lower() != "true" for row in checks):
        raise SystemExit(f"FAIL {label}: an overall check failed")
    if len(scalar) != 23 or any(row["passed"].lower() != "true" for row in scalar):
        raise SystemExit(f"FAIL {label}: scalar comparison differs")
    if len(trajectory) != 10 or any(row["passed"].lower() != "true" for row in trajectory):
        raise SystemExit(f"FAIL {label}: trajectory comparison differs")
    print(f"PASS {label}: 1001 points, matching, 23 scalar, 10 trajectory, and final classification")


def main() -> None:
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--reference", action="store_true")
    group.add_argument("--generated", metavar="RUN_DIRECTORY")
    args = parser.parse_args()
    if args.reference:
        hashes = json.loads((ROOT / "reference" / "fine-results" / "matched_n7_dt_halving_input_hashes_before.json").read_text(encoding="utf-8"))
        for name, expected in hashes.items():
            path = ROOT / "reference" / "coarse-formal" / name
            if sha256(path) != expected:
                raise SystemExit(f"FAIL reference coarse hash: {name}")
        check(ROOT / "reference" / "fine-results", "stored reference")
        print("PASS stored coarse SHA-256 inputs")
    else:
        run = Path(args.generated).resolve()
        hashes = json.loads((run / "matched_n7_dt_halving_input_hashes_before.json").read_text(encoding="utf-8"))
        check(run, "generated run", hashes)


if __name__ == "__main__":
    main()
