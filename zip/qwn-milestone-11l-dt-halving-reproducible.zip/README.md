# Milestone 11L: matched N=7 dt-halving validation

This package reproduces Milestone 11L: the convergence check for the already matched `N=7` condition.
It holds `Omega` fixed and halves only the internal RK4 time step.

## Scope

| Item | Coarse formal trajectory | Fine trajectory |
| --- | ---: | ---: |
| Chain length | 7 | 7 |
| Total gamma | 1.5 | 1.5 |
| Omega | 0.18748395731510084 | unchanged |
| dt | 0.0025 | 0.00125 |
| RK4 steps | 4000 | 8000 |
| Saved points | 1001 | 1001 |
| Time interval | 0 to 10 | 0 to 10 |

The coarse trajectory is a read-only formal input. The full reproduction runs exactly one new fine
trajectory. It does not rematch Omega, scan for another root, add another chain length, or extend time
beyond 10.

## Recorded result

```text
matched_condition_dt_halving_passed_with_fallback_diagnostic
```

- Same-Omega input matching: PASS, relative mismatch `2.8157045010698592e-06`.
- Fine–coarse drive-input change: `3.3910913437992649e-12` relative.
- Scalar comparison: 23/23 PASS.
- Same-time trajectory comparison: 10/10 PASS.
- W peak: `3.3852501213e-03` at `t=7.70` for both coarse and fine.
- Solver failure count: 0. One robust-positivity fallback was used.

This does not establish convergence at arbitrary time step, for all matched conditions, or for all chain
lengths. It also does not prove that RK4 is completely positive.

## Quick verification (no long calculation)

Requirements: Python 3.10+; no third-party packages.

```bash
python scripts/verify.py --reference
```

This validates the copied coarse-input hashes, the 1001-point reference trajectories, all stored checks,
and the recorded final classification.

## Full reproduction

Requirements: Rust stable and Cargo. On a fresh machine Cargo normally needs network access once to
fetch the versions pinned in `Cargo.lock`.

```bash
python scripts/prepare_run.py
cd run
python tools/finalize_milestone_11l.py hash-before
cargo run --release --manifest-path ../Cargo.toml --bin matched_n7_dt_halving_validation -- --benchmark-only
cargo run --release --manifest-path ../Cargo.toml --bin matched_n7_dt_halving_validation -- --full-run
python tools/finalize_milestone_11l.py finalize
cd ..
python scripts/verify.py --generated run
```

The original benchmark estimated about 8038 seconds; the recorded full run took 6714 seconds on its
reference machine. The new output remains in `run/`, which is gitignored.

## Layout

- `src/`, `Cargo.toml`, `Cargo.lock`: exact Rust implementation and fixed dependency versions.
- `reference/coarse-formal/`: immutable Milestone 11f trajectory and its report/checks.
- `reference/run-inputs/`: fixed precheck and matching inputs required by the fine binary.
- `reference/fine-results/`: original 11L benchmark, fine trajectory, comparisons, checks, and report.
- `tools/finalize_milestone_11l.py`: original finalizer.
- `scripts/prepare_run.py`: copies only the declared inputs into an empty run directory.

## License note

`Cargo.toml` declares MIT for the Rust package. Confirm the intended copyright holder and add a
repository-level `LICENSE` before making a public release.
