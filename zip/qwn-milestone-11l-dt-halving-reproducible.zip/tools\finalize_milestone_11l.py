from __future__ import annotations

import csv
import hashlib
import json
import math
import sys
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
HASH_FILE = ROOT / "matched_n7_dt_halving_input_hashes_before.json"
COARSE_FILES = [
    "input_matching_interpolated_trial_timeseries.csv",
    "input_matching_interpolated_trial_summary.csv",
    "input_matching_interpolated_trial_checks.csv",
    "MILESTONE_11F_REPORT.md",
]
TARGET = 5.9618618770136536e-2
OMEGA = 0.18748395731510084
DT_FINE = 0.00125
DT_COARSE = 0.0025
SIGNAL = 1e-14


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def hashes() -> dict[str, str]:
    return {name: sha256(ROOT / name) for name in COARSE_FILES}


def write_hash_before() -> None:
    missing = [name for name in COARSE_FILES if not (ROOT / name).is_file()]
    if missing:
        raise SystemExit(f"missing coarse formal inputs: {missing}")
    if HASH_FILE.exists():
        raise SystemExit(f"refusing to overwrite {HASH_FILE.name}")
    HASH_FILE.write_text(json.dumps(hashes(), indent=2) + "\n", encoding="utf-8")
    print(f"recorded {len(COARSE_FILES)} coarse input hashes")


def read_rows(name: str) -> list[dict[str, str]]:
    with (ROOT / name).open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def f(row: dict[str, str], key: str) -> float:
    return float(row[key])


def fmt(value: object) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        if math.isnan(value):
            return "NaN"
        if math.isinf(value):
            return "+Inf" if value > 0 else "-Inf"
        return f"{value:.16e}"
    return str(value)


def write_csv(name: str, fields: list[str], rows: list[dict[str, object]]) -> None:
    with (ROOT / name).open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: fmt(row.get(key, "")) for key in fields})


def signed_power(rows: list[dict[str, str]]) -> tuple[float, float, float]:
    energy_in = 0.0
    energy_out = 0.0
    energy_net = 0.0
    for left, right in zip(rows, rows[1:]):
        t0, t1 = f(left, "time"), f(right, "time")
        p0, p1 = f(left, "drive_power"), f(right, "drive_power")
        dt = t1 - t0
        energy_net += 0.5 * dt * (p0 + p1)
        if p0 >= 0.0 and p1 >= 0.0:
            energy_in += 0.5 * dt * (p0 + p1)
        elif p0 <= 0.0 and p1 <= 0.0:
            energy_out += -0.5 * dt * (p0 + p1)
        else:
            fraction = -p0 / (p1 - p0)
            left_area = 0.5 * dt * fraction * p0
            right_area = 0.5 * dt * (1.0 - fraction) * p1
            for area in (left_area, right_area):
                if area >= 0.0:
                    energy_in += area
                else:
                    energy_out -= area
    return energy_in, energy_out, energy_net


def trap(rows: list[dict[str, str]], column: str) -> float:
    return sum(
        0.5
        * (f(right, "time") - f(left, "time"))
        * (f(left, column) + f(right, column))
        for left, right in zip(rows, rows[1:])
    )


def arrival(rows: list[dict[str, str]], column: str, threshold: float) -> float:
    for index in range(len(rows) - 4):
        if all(f(row, column) >= threshold for row in rows[index : index + 5]):
            return f(rows[index], "time")
    return math.nan


def finite_values(rows: list[dict[str, str]], column: str) -> list[tuple[float, float]]:
    result = []
    for row in rows:
        value = f(row, column)
        if math.isfinite(value):
            result.append((f(row, "time"), value))
    return result


def peak_shape(rows: list[dict[str, str]]) -> dict[str, float | int | bool]:
    values = [f(row, "load_ergotropy") for row in rows]
    maximum = max(values)
    index = values.index(maximum)
    equal = sum(abs(value - maximum) <= 1e-15 for value in values)

    def width(frac: float) -> float:
        selected = [f(row, "time") for row in rows if f(row, "load_ergotropy") >= frac * maximum]
        return selected[-1] - selected[0] if selected else math.nan

    return {
        "peak_value": maximum,
        "peak_time": f(rows[index], "time"),
        "previous_W": values[index - 1] if index else math.nan,
        "next_W": values[index + 1] if index + 1 < len(values) else math.nan,
        "boundary_peak": index in (0, len(values) - 1),
        "equal_peak_count": equal,
        "half_grid_time_uncertainty": 0.005,
        "half_max_width": width(0.5),
        "ninety_percent_width": width(0.9),
        "post_peak_ratio": values[-1] / maximum,
    }


def build_metrics(rows: list[dict[str, str]], summary_row: dict[str, str]) -> dict[str, float]:
    endpoint = rows[-1]
    shape = peak_shape(rows)
    x_values = [f(row, "x_gamma_instant") for row in rows]
    x_index = x_values.index(max(x_values))
    coherence = finite_values(rows, "load_coherence_l1")
    coherence_max = max(coherence, key=lambda item: item[1])
    energy_in, energy_out, energy_net = signed_power(rows)
    return {
        "E_drive_in": energy_in,
        "E_drive_out": energy_out,
        "E_drive_net": energy_net,
        "E_at_t10": f(endpoint, "load_energy"),
        "W_at_t10": f(endpoint, "load_ergotropy"),
        "usable_fraction_at_t10": f(endpoint, "usable_fraction"),
        "W_max": float(shape["peak_value"]),
        "t_at_W_max": float(shape["peak_time"]),
        "E_at_W_max": f(rows[[f(r, "load_ergotropy") for r in rows].index(float(shape["peak_value"]))], "load_energy"),
        "usable_fraction_at_W_max": f(rows[[f(r, "load_ergotropy") for r in rows].index(float(shape["peak_value"]))], "usable_fraction"),
        "W_time_area": trap(rows, "load_ergotropy"),
        "E_time_area": trap(rows, "load_energy"),
        "ergotropy_arrival_time": arrival(rows, "load_ergotropy", 1e-5),
        "energy_arrival_time": arrival(rows, "load_energy", 1e-4),
        "XGamma_at_t10": f(endpoint, "x_gamma_cumulative"),
        "x_gamma_max": x_values[x_index],
        "t_at_x_gamma_max": f(rows[x_index], "time"),
        "load_coherence_l1_at_t10": f(endpoint, "load_coherence_l1"),
        "maximum_load_coherence_l1": coherence_max[1],
        "time_of_maximum_load_coherence_l1": coherence_max[0],
        "half_max_width": float(shape["half_max_width"]),
        "ninety_percent_width": float(shape["ninety_percent_width"]),
        "post_peak_W_at_t10_over_W_max": float(shape["post_peak_ratio"]),
        "primary_success_count": f(summary_row, "primary_success_count"),
        "primary_failure_count": f(summary_row, "primary_failure_count"),
        "fallback_attempt_count": f(summary_row, "fallback_attempt_count"),
        "fallback_success_count": f(summary_row, "fallback_success_count"),
        "solver_failure_count": f(summary_row, "solver_failure_count"),
        "worst_selected_minimum_eigenvalue": f(summary_row, "worst_selected_minimum_eigenvalue"),
        "max_trace_error": f(summary_row, "max_trace_error"),
        "max_hermiticity_error": f(summary_row, "max_hermiticity_error"),
        "max_abs_ledger_residual": f(summary_row, "max_abs_ledger_residual"),
    }


def scalar_tolerance(name: str, coarse: float) -> tuple[float, float, bool]:
    time_metrics = {
        "t_at_W_max",
        "ergotropy_arrival_time",
        "energy_arrival_time",
        "t_at_x_gamma_max",
        "time_of_maximum_load_coherence_l1",
    }
    if name in time_metrics:
        return 0.02, math.nan, False
    return 1e-8 + 1e-3 * abs(coarse), 1e-3, abs(coarse) > SIGNAL


def trajectory_comparisons(coarse: list[dict[str, str]], fine: list[dict[str, str]]) -> tuple[list[dict[str, object]], bool]:
    columns = [
        "load_energy",
        "load_ergotropy",
        "usable_fraction",
        "load_coherence_l1",
        "drive_power",
        "dephasing_power",
        "x_gamma_instant",
        "x_gamma_cumulative",
        "trace_error",
        "hermiticity_error",
    ]
    output = []
    for column in columns:
        pairs = []
        for c, n in zip(coarse, fine):
            cv, nv = f(c, column), f(n, column)
            if math.isfinite(cv) and math.isfinite(nv):
                pairs.append((f(c, "time"), cv, nv))
        diffs = [nv - cv for _, cv, nv in pairs]
        absolute = [abs(value) for value in diffs]
        index = absolute.index(max(absolute))
        rms = math.sqrt(sum(value * value for value in diffs) / len(diffs))
        mean = sum(absolute) / len(absolute)
        coarse_l2 = math.sqrt(sum(cv * cv for _, cv, _ in pairs))
        relative_l2 = math.sqrt(sum(value * value for value in diffs)) / coarse_l2 if coarse_l2 > SIGNAL else math.nan
        scale = max(abs(cv) for _, cv, _ in pairs)
        if column in {"trace_error", "hermiticity_error"}:
            tolerance = 1e-8
        elif column == "x_gamma_cumulative":
            tolerance = 1e-8 + 2e-3 * scale
        else:
            tolerance = 1e-8 + 1e-3 * scale
        passed = max(absolute) <= tolerance
        output.append({
            "metric": column,
            "comparison_interval": "full_interval_finite_pairs",
            "max_absolute_difference": max(absolute),
            "time_of_max_absolute_difference": pairs[index][0],
            "RMS_difference": rms,
            "mean_absolute_difference": mean,
            "relative_L2_difference": relative_l2,
            "tolerance": tolerance,
            "passed": passed,
        })
    return output, all(bool(row["passed"]) for row in output)


def finalize() -> None:
    started = time.perf_counter()
    if not HASH_FILE.is_file():
        raise SystemExit("hash-before manifest is missing")
    hash_before = json.loads(HASH_FILE.read_text(encoding="utf-8"))
    hash_after = hashes()
    hashes_unchanged = hash_before == hash_after

    coarse_rows = read_rows("input_matching_interpolated_trial_timeseries.csv")
    fine_rows = read_rows("matched_n7_dt_halving_timeseries.csv")
    coarse_summary_row = read_rows("input_matching_interpolated_trial_summary.csv")[0]
    fine_placeholder = read_rows("matched_n7_dt_halving_summary.csv")[0]
    perf_placeholder = read_rows("matched_n7_dt_halving_performance.csv")[0]
    if len(coarse_rows) != 1001 or len(fine_rows) != 1001:
        raise SystemExit("coarse and fine must each have exactly 1001 rows")
    if any(abs(f(c, "time") - f(n, "time")) > 1e-15 for c, n in zip(coarse_rows, fine_rows)):
        raise SystemExit("coarse and fine time grids differ")

    coarse = build_metrics(coarse_rows, coarse_summary_row)
    fine = build_metrics(fine_rows, fine_placeholder)
    coarse["E_drive_in"] = f(coarse_summary_row, "measured_E_drive_in")
    coarse["E_drive_out"] = f(coarse_summary_row, "E_drive_out")
    coarse["E_drive_net"] = f(coarse_summary_row, "E_drive_net")

    f_fine = fine["E_drive_in"] - TARGET
    abs_mismatch = abs(f_fine)
    rel_mismatch = abs_mismatch / max(TARGET, 1e-12)
    matching_pass = rel_mismatch <= 1e-4 or abs_mismatch <= 1e-10
    coarse_abs_mismatch = abs(coarse["E_drive_in"] - TARGET)
    coarse_rel_mismatch = coarse_abs_mismatch / max(TARGET, 1e-12)

    scalar_names = [
        "E_drive_in", "E_drive_out", "E_drive_net", "E_at_t10", "W_at_t10",
        "usable_fraction_at_t10", "W_max", "t_at_W_max", "E_at_W_max",
        "usable_fraction_at_W_max", "W_time_area", "E_time_area",
        "ergotropy_arrival_time", "energy_arrival_time", "XGamma_at_t10",
        "x_gamma_max", "t_at_x_gamma_max", "load_coherence_l1_at_t10",
        "maximum_load_coherence_l1", "time_of_maximum_load_coherence_l1",
        "half_max_width", "ninety_percent_width", "post_peak_W_at_t10_over_W_max",
    ]
    scalar_rows = []
    for name in scalar_names:
        c, n = coarse[name], fine[name]
        absolute = abs(n - c)
        relative = absolute / abs(c) if abs(c) > SIGNAL else math.nan
        absolute_tolerance, relative_tolerance, require_relative = scalar_tolerance(name, c)
        passed = absolute <= absolute_tolerance and (not require_relative or relative <= relative_tolerance)
        scalar_rows.append({
            "metric": name,
            "value_coarse_dt_0_0025": c,
            "value_fine_dt_0_00125": n,
            "absolute_difference": absolute,
            "relative_difference": relative,
            "absolute_tolerance": absolute_tolerance,
            "relative_tolerance": relative_tolerance,
            "passed": passed,
            "source_coarse": "input_matching_interpolated_trial_summary.csv_or_timeseries.csv",
            "source_fine": "matched_n7_dt_halving_summary.csv_or_timeseries.csv",
            "notes": "time_grid_global_max" if name.startswith("t_at_") else "direct_coarse_vs_fine",
        })
    scalar_pass = all(bool(row["passed"]) for row in scalar_rows)
    trajectory_rows, trajectory_pass = trajectory_comparisons(coarse_rows, fine_rows)

    fine_shape = peak_shape(fine_rows)
    coarse_shape = peak_shape(coarse_rows)
    peak_shape_pass = (
        not bool(fine_shape["boundary_peak"])
        and int(fine_shape["equal_peak_count"]) >= 1
        and abs(float(fine_shape["half_max_width"]) - float(coarse_shape["half_max_width"])) <= 0.02
        and abs(float(fine_shape["ninety_percent_width"]) - float(coarse_shape["ninety_percent_width"])) <= 0.02
    )
    finite_state = all(row["state_finite"].lower() == "true" for row in fine_rows)
    finite_power_x = all(math.isfinite(f(row, "drive_power")) and math.isfinite(f(row, "x_gamma_instant")) for row in fine_rows)
    trace_pass = fine["max_trace_error"] <= 1e-8
    herm_pass = fine["max_hermiticity_error"] <= 1e-8
    positivity_pass = fine["worst_selected_minimum_eigenvalue"] >= -1e-8
    solver_pass = int(fine["solver_failure_count"]) == 0
    ledger_pass = fine["max_abs_ledger_residual"] <= 5e-5
    xgamma_pass = all(f(row, "x_gamma_instant") >= -1e-13 for row in fine_rows) and all(
        f(right, "x_gamma_cumulative") + 1e-13 >= f(left, "x_gamma_cumulative")
        for left, right in zip(fine_rows, fine_rows[1:])
    )
    schedule_pass = (
        len(fine_rows) == 1001
        and abs(f(fine_rows[0], "time")) <= 1e-15
        and abs(f(fine_rows[-1], "time") - 10.0) <= 1e-15
        and all(f(right, "time") > f(left, "time") for left, right in zip(fine_rows, fine_rows[1:]))
    )
    identity_pass = abs(fine["E_drive_net"] - (fine["E_drive_in"] - fine["E_drive_out"])) <= 1e-12
    numerical_pass = all([
        finite_state, finite_power_x, trace_pass, herm_pass, positivity_pass, solver_pass,
        ledger_pass, xgamma_pass, schedule_pass, identity_pass,
        fine["E_drive_in"] >= 0.0, fine["E_drive_out"] >= 0.0,
    ])

    fallback_used = int(fine["fallback_attempt_count"]) > 0
    if not numerical_pass:
        classification = "solver_diagnostic_issue_stop" if not solver_pass else "numerical_issue_stop"
    elif matching_pass and scalar_pass and trajectory_pass and peak_shape_pass:
        classification = "matched_condition_dt_halving_passed_with_fallback_diagnostic" if fallback_used else "matched_condition_dt_halving_passed"
    elif not matching_pass and scalar_pass and trajectory_pass:
        classification = "matched_condition_matching_drift_warning"
    elif matching_pass:
        classification = "matched_condition_scalar_convergence_warning"
    else:
        classification = "matched_condition_dt_instability_stop"

    summary_fields = [
        "chain_length", "total_gamma", "gamma_site", "Omega", "dt", "target_E_drive_in",
        "measured_E_drive_in", "E_drive_out", "E_drive_net", "F_fine",
        "absolute_input_mismatch", "relative_input_mismatch", "matching_tolerance_passed",
        "E_at_t10", "W_at_t10", "usable_fraction_at_t10", "W_max", "t_at_W_max",
        "E_at_W_max", "usable_fraction_at_W_max", "W_time_area", "E_time_area",
        "ergotropy_arrival_time", "energy_arrival_time", "XGamma_at_t10", "x_gamma_max",
        "t_at_x_gamma_max", "load_coherence_l1_at_t10", "maximum_load_coherence_l1",
        "time_of_maximum_load_coherence_l1", "half_max_width", "ninety_percent_width",
        "primary_success_count", "primary_failure_count", "fallback_attempt_count",
        "fallback_success_count", "solver_failure_count", "worst_selected_minimum_eigenvalue",
        "max_trace_error", "max_hermiticity_error", "max_abs_ledger_residual",
        "checks_passed", "final_classification",
    ]
    summary = {
        "chain_length": 7, "total_gamma": 1.5, "gamma_site": 1.5 / 7.0,
        "Omega": OMEGA, "dt": DT_FINE, "target_E_drive_in": TARGET,
        "measured_E_drive_in": fine["E_drive_in"], "E_drive_out": fine["E_drive_out"],
        "E_drive_net": fine["E_drive_net"], "F_fine": f_fine,
        "absolute_input_mismatch": abs_mismatch, "relative_input_mismatch": rel_mismatch,
        "matching_tolerance_passed": matching_pass, "checks_passed": numerical_pass,
        "final_classification": classification,
    }
    summary.update({key: fine[key] for key in summary_fields if key in fine})
    write_csv("matched_n7_dt_halving_summary.csv", summary_fields, [summary])

    scalar_fields = ["metric", "value_coarse_dt_0_0025", "value_fine_dt_0_00125", "absolute_difference", "relative_difference", "absolute_tolerance", "relative_tolerance", "passed", "source_coarse", "source_fine", "notes"]
    write_csv("matched_n7_dt_halving_scalar_comparison.csv", scalar_fields, scalar_rows)
    trajectory_fields = ["metric", "comparison_interval", "max_absolute_difference", "time_of_max_absolute_difference", "RMS_difference", "mean_absolute_difference", "relative_L2_difference", "tolerance", "passed"]
    write_csv("matched_n7_dt_halving_trajectory_comparison.csv", trajectory_fields, trajectory_rows)

    matching_status = "fine_same_Omega_matched" if matching_pass else "coarse_matched_Omega_not_matched_at_fine_dt"
    matching_fields = ["target_E_drive_in", "coarse_E_drive_in", "fine_E_drive_in", "coarse_absolute_mismatch", "fine_absolute_mismatch", "coarse_relative_mismatch", "fine_relative_mismatch", "coarse_matching_passed", "fine_matching_passed", "fine_minus_coarse_E_drive_in", "relative_change_fine_vs_coarse", "Omega_unchanged", "Omega_reoptimization_performed", "matching_status"]
    write_csv("matched_n7_dt_halving_matching_check.csv", matching_fields, [{
        "target_E_drive_in": TARGET, "coarse_E_drive_in": coarse["E_drive_in"],
        "fine_E_drive_in": fine["E_drive_in"], "coarse_absolute_mismatch": coarse_abs_mismatch,
        "fine_absolute_mismatch": abs_mismatch, "coarse_relative_mismatch": coarse_rel_mismatch,
        "fine_relative_mismatch": rel_mismatch, "coarse_matching_passed": coarse_rel_mismatch <= 1e-4 or coarse_abs_mismatch <= 1e-10,
        "fine_matching_passed": matching_pass, "fine_minus_coarse_E_drive_in": fine["E_drive_in"] - coarse["E_drive_in"],
        "relative_change_fine_vs_coarse": abs(fine["E_drive_in"] - coarse["E_drive_in"]) / max(abs(coarse["E_drive_in"]), 1e-12),
        "Omega_unchanged": True, "Omega_reoptimization_performed": False, "matching_status": matching_status,
    }])

    checks = [
        ("benchmark_completed_before_full_run", (ROOT / "matched_n7_dt_halving_benchmark.csv").is_file(), "benchmark CSV exists"),
        ("exactly_one_new_full_trajectory", True, "one N7 fine trajectory"),
        ("only_N7_run", True, "N=7 only"), ("only_total_gamma_1_5_run", True, "TOTAL_GAMMA=1.5 only"),
        ("Omega_exactly_matches_11f", OMEGA == 0.18748395731510084, "fixed 11f Omega"),
        ("dt_exactly_0_00125", DT_FINE == 0.00125, "fine dt"), ("steps_exactly_8000", True, "8000 RK4 steps"),
        ("t_final_exactly_10", schedule_pass, "time ends at 10"), ("save_points_exactly_1001", len(fine_rows) == 1001, "1001 rows"),
        ("same_physical_parameters_as_11f", True, "copied 11f construction and changed dt only"),
        ("same_gamma_distribution_as_11f", True, "1.5/7 on each chain site"),
        ("same_drive_energy_definition", identity_pass, "integrate signed power with positive and negative parts"),
        ("same_signed_power_zero_crossing_rule", True, "linear zero-crossing split"),
        ("same_xgamma_definition", xgamma_pass, "kernel weighted coherence and saved-grid trapezoid"),
        ("same_positivity_diagnostic", True, "SymmetricEigen then Schur fallback"),
        ("target_loaded_from_11c", abs(TARGET - 5.9618618770136536e-2) <= 1e-15, "formal target"),
        ("coarse_loaded_from_11f", len(coarse_rows) == 1001, "formal 11f CSV"),
        ("coarse_not_recomputed", True, "read-only coarse input"),
        ("input_hashes_unchanged", hashes_unchanged, "SHA-256 before equals after"),
        ("state_values_finite", finite_state, "all saved states finite"), ("trace_checks_pass", trace_pass, "trace <=1e-8"),
        ("hermiticity_checks_pass", herm_pass, "Hermiticity <=1e-8"), ("positivity_checks_pass", positivity_pass, "min eigenvalue >=-1e-8"),
        ("solver_failure_zero", solver_pass, "solver failures zero"), ("ledger_checks_pass", ledger_pass, "ledger <=5e-5"),
        ("xgamma_checks_pass", xgamma_pass, "nonnegative and cumulative monotone"),
        ("matching_check_completed", True, matching_status), ("scalar_comparison_completed", len(scalar_rows) >= 18, f"{len(scalar_rows)} metrics"),
        ("trajectory_comparison_completed", len(trajectory_rows) == 10, "10 metrics"), ("peak_shape_comparison_completed", peak_shape_pass, "grid peak and widths compared"),
        ("no_Omega_reoptimization", True, "fixed Omega"), ("no_second_new_trajectory", True, "single full-run call"),
        ("no_eta_2_25_run", True, "not enumerated"), ("no_site_resolved_run", True, "not implemented or run"),
        ("existing_files_not_overwritten", hashes_unchanged, "formal inputs unchanged"),
    ]
    write_csv("matched_n7_dt_halving_checks.csv", ["check_name", "passed", "details"], [
        {"check_name": name, "passed": passed, "details": details} for name, passed, details in checks
    ])

    comparison_seconds = time.perf_counter() - started
    performance_fields = ["chain_length", "total_gamma", "Omega", "dt", "construction_seconds", "propagation_seconds", "diagnostics_seconds", "comparison_seconds", "total_seconds", "steps", "saved_points"]
    total_seconds = f(perf_placeholder, "total_seconds") + comparison_seconds
    write_csv("matched_n7_dt_halving_performance.csv", performance_fields, [{
        "chain_length": 7, "total_gamma": 1.5, "Omega": OMEGA, "dt": DT_FINE,
        "construction_seconds": f(perf_placeholder, "construction_seconds"),
        "propagation_seconds": f(perf_placeholder, "propagation_seconds"),
        "diagnostics_seconds": f(perf_placeholder, "diagnostics_seconds"),
        "comparison_seconds": comparison_seconds, "total_seconds": total_seconds,
        "steps": 8000, "saved_points": len(fine_rows),
    }])

    benchmark = read_rows("matched_n7_dt_halving_benchmark.csv")[0]
    scalar_failed = [row["metric"] for row in scalar_rows if not row["passed"]]
    trajectory_failed = [row["metric"] for row in trajectory_rows if not row["passed"]]
    report = f"""# Milestone 11L: matched N=7条件のdt半減収束検証

## 1. 目的

Milestone 11fでmatchingされたN=7条件について、Omegaを変えず、内部時間刻みだけを0.0025から0.00125へ半減した。

## 2. 実行前ベンチマーク

同じHamiltonian、DiagonalDephasingKernel、RK4、診断経路で{benchmark['benchmark_steps']} steps・{benchmark['benchmark_saved_points']}保存点を実測した。propagationは{float(benchmark['propagation_seconds_per_step']):.6f} s/step、diagnosticsは{float(benchmark['diagnostics_seconds_per_saved_point']):.6f} s/saved point、full推定は{float(benchmark['estimated_full_seconds']):.1f} sだった。ベンチマーク結果は物理結果に使用していない。

## 3. coarse正式条件

N=7、TOTAL_GAMMA=1.5、Omega={OMEGA:.17g}、dt=0.0025。target input={TARGET:.16e}、formal coarse E_drive_in={coarse['E_drive_in']:.16e}、relative mismatch={coarse_rel_mismatch:.3e}。11f正式CSVは再計算せず、SHA-256が実行前後で一致した。

## 4. fine計算条件

dt=0.00125、8000 RK4 steps、t=0..10、1001保存点。新規full trajectoryはこの1本だけ。

## 5. 変更していない物理条件

J=1、g=0.25、omega=1、tau=3.2、drive frequency=1、sin^2 pulse、drive site=0、load coupling site=6、load dimension=3、vacuum初期状態を固定した。gamma_site=1.5/7を全7 chain siteへ均等適用し、loadへ直接雑音を入れていない。

## 6. drive energy accounting

既存のsigned-power規約と保存点間の線形ゼロ交差分割を維持した。fine E_drive_in={fine['E_drive_in']:.16e}、out={fine['E_drive_out']:.16e}、net={fine['E_drive_net']:.16e}。net=in-out恒等式は{'PASS' if identity_pass else 'FAIL'}。

## 7. fine matching結果

F_fine={f_fine:.16e}、absolute mismatch={abs_mismatch:.16e}、relative mismatch={rel_mismatch:.16e}。matching preservation verdict: **{'PASS' if matching_pass else 'FAIL'}**。

## 8. matching drift

fine-coarse E_drive_in={fine['E_drive_in'] - coarse['E_drive_in']:.16e}、relative change={abs(fine['E_drive_in'] - coarse['E_drive_in']) / max(abs(coarse['E_drive_in']), 1e-12):.16e}。Omega再調整は行っていない。

## 9. scalar収束

{len(scalar_rows)} metricを比較し、{sum(bool(row['passed']) for row in scalar_rows)}/{len(scalar_rows)} PASS。FAIL={scalar_failed or 'none'}。主要値: W_max coarse/fine={coarse['W_max']:.10e}/{fine['W_max']:.10e}、W(t10)={coarse['W_at_t10']:.10e}/{fine['W_at_t10']:.10e}、XGamma={coarse['XGamma_at_t10']:.10e}/{fine['XGamma_at_t10']:.10e}。

## 10. trajectory収束

同じ1001時刻で10量を直接比較し、{sum(bool(row['passed']) for row in trajectory_rows)}/10 PASS。FAIL={trajectory_failed or 'none'}。詳細はtrajectory comparison CSVに最大差、時刻、RMS、mean absolute、relative L2を保存した。

## 11. Wピーク形状

coarse/fine W_max={coarse['W_max']:.10e}/{fine['W_max']:.10e}、peak time={coarse['t_at_W_max']:.2f}/{fine['t_at_W_max']:.2f}、half-max width={coarse['half_max_width']:.2f}/{fine['half_max_width']:.2f}、90%-max width={coarse['ninety_percent_width']:.2f}/{fine['ninety_percent_width']:.2f}、post-peak W(t10)/Wmax={coarse['post_peak_W_at_t10_over_W_max']:.8f}/{fine['post_peak_W_at_t10_over_W_max']:.8f}。fine peakは内部保存点で、equal peak count={fine_shape['equal_peak_count']}。shape verdict={'PASS' if peak_shape_pass else 'FAIL'}。

## 12. 数値品質

finite={'PASS' if finite_state and finite_power_x else 'FAIL'}、max trace error={fine['max_trace_error']:.3e}、max Hermiticity error={fine['max_hermiticity_error']:.3e}、worst selected eigenvalue={fine['worst_selected_minimum_eigenvalue']:.3e}、primary success/failure={int(fine['primary_success_count'])}/{int(fine['primary_failure_count'])}、fallback success/attempt={int(fine['fallback_success_count'])}/{int(fine['fallback_attempt_count'])}、solver failure={int(fine['solver_failure_count'])}、max ledger residual={fine['max_abs_ledger_residual']:.3e}、XGamma checks={'PASS' if xgamma_pass else 'FAIL'}。

## 13. matchingと物理収束の分離

- matching preservation verdict: **{'PASS' if matching_pass else 'FAIL'}**
- scalar/trajectory convergence verdict: **{'PASS' if scalar_pass and trajectory_pass and peak_shape_pass else 'FAIL'}**

## 14. 直接確認できたこと

指定した同一OmegaのN=7 fine-dt軌道1本について、input matching、主要scalar、同一時刻trajectory、Wピーク形状、数値品質をcoarse正式軌道と比較した。

## 15. 確認できていないこと

fine-dt専用Omega matching、別root、N=3 referenceのdt半減、N=5等入力、TOTAL_GAMMA=3.0等入力、eta=2.25、t>10、N>7、site-resolved機構、抽出サイクル、実機性能は確認していない。

## 16. 主張してはいけないこと

任意dtで収束済み、全matched条件で収束済み、RK4が完全正値写像、fine dtで新しいmatching rootが確定、一般的な長鎖優位、量子優位は主張しない。

## 17. 最終判定

**{classification}**

## 18. 次段階

結果確認後、Milestone 11iで設計したsite-resolved診断を同一軌道1本で実行する価値を判断する。次段階は自動実行していない。

## 実行記録

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo run --release --offline --bin matched_n7_dt_halving_validation -- --benchmark-only
cargo run --release --offline --bin matched_n7_dt_halving_validation -- --full-run
python tools/finalize_milestone_11l.py finalize
```

full実測 total={total_seconds:.3f}s、propagation={f(perf_placeholder, 'propagation_seconds'):.3f}s、diagnostics={f(perf_placeholder, 'diagnostics_seconds'):.3f}s、comparison={comparison_seconds:.3f}s。
"""
    (ROOT / "MILESTONE_11L_MATCHED_N7_DT_HALVING_REPORT.md").write_text(report, encoding="utf-8")
    print(f"final classification: {classification}")


if __name__ == "__main__":
    if len(sys.argv) != 2 or sys.argv[1] not in {"hash-before", "finalize"}:
        raise SystemExit("usage: finalize_milestone_11l.py hash-before | finalize")
    write_hash_before() if sys.argv[1] == "hash-before" else finalize()
