# N=3〜7 イベント時間構造・最終報告

## 結論

最終分類は次とする。

```text
odd_even_alternation_candidate
```

これは有限サイズ `N=3..7` における記述的候補である。統計的有意差、普遍的parity order parameter、parity mechanismの証明ではない。

categorical signature単独はCase A条件を満たさなかった。一方、`backflow_amount_post_peak`、`post_peak_W_loss_fraction`、`Delta_passive_peak_to_t10` の3量で、局所交互差 `A_4,A_5,A_6` が非零の交互符号を示したため、PRECOMMITの連続量側の条件によりCase Aとした。なお `t_W_peak_end` は概ね滑らかに遅延しており、すべての量が交互的という結果ではない。

## 正式軌道

| N | 新規軌道数 | 正式Omega | relative input mismatch | 採用 |
|---:|---:|---:|---:|---|
| 3 | 1 | 0.2 | 0 | trial 1 |
| 4 | 3 | 0.19466050591180037 | 1.2882180e-5 | trial 3 |
| 5 | 3 | 0.19130947255811623 | 3.4047928e-5 | trial 3 |
| 6 | 3 | 0.18908284317778151 | 5.3571257e-5 | trial 3 |
| 7 | 0 | 0.18748395731510084 | 2.8157011e-6 | 既存11Mを再利用 |

新規軌道は合計10本で、各N最大3本の上限内である。matchingに初めて合格したfull trajectoryをそのまま正式event trajectoryに採用した。同一条件の成果物用再計算は行っていない。N=8の長時間計算は行っていない。

## イベント結果

| N | t_W_peak_end | negative onset | passive onset | signature |
|---:|---:|---:|---:|---|
| 3 | 5.63 | 未観測 | 5.63 | negative_not_observed |
| 4 | 6.04 | 8.69 | 6.04 | W->passive->negative |
| 5 | 6.62 | 未観測 | 6.62 | negative_not_observed |
| 6 | 7.16 | 7.72 | 7.16 | W->passive->negative |
| 7 | 7.70 | 8.16 | 7.70 | W->passive->negative |

N=3,5のcurrent未反転は正常完了軌道の有効なcategorical signatureであり、`temporal_pattern_incomplete` にはしていない。odd群はN=7だけsignatureが異なるため、categorical odd-even条件は不成立である。

主要な交互差は次の通り。

| X | A4 | A5 | A6 |
|---|---:|---:|---:|
| backflow amount | +1.22484e-5 | -1.12252e-4 | +1.62998e-5 |
| post-peak W loss fraction | +2.66514e-1 | -1.69126e-1 | +6.20135e-2 |
| passive increase to t=10 | -1.79209e-3 | +4.40464e-4 | -2.28239e-4 |

## 数値品質

- current sign unit test: PASS
- N=3,4,5,6,7 continuity operator tests: PASS
- 全正式時系列: 1001点、state/solver nonfinite 0
- 最大continuity残差: 1.373463149787011e-5（基準 5e-4以下）
- 最大trace error: 2.220446049250313e-15
- 最大energy-ledger residual: 5.197158434539854e-7
- N=7では既存のrobust positivity fallbackが1点あるが、state/solverは有限で正式11Mの再利用条件を維持している。

生成時のN=3〜6 CSVは、N=7由来の固定51列ヘッダーを持つ一方、データ行はN別の正しい可変列数だった。軌道を再計算せず、正式成果物ではデータ行を変更せずN別ヘッダーだけを正規化した。source/output hashを記録している。

## 実行時間

フォルダ時刻による新規full trajectoryの概算実測は約31分である（ビルド、matching間の準備、解析を除く）。内訳はN=3約3秒、N=4計3本約34秒、N=5計3本約4.1分、N=6計3本約26.6分。N=7は再利用、N=8は0本である。

## 判定上の制限

この結果は1軌道/鎖長、有限時間 `t<=10`、固定条件での候補である。特にN=7がcategoricalなodd群共通性を崩しており、連続量でも `t_W_peak_end` は滑らかな鎖長依存を示す。したがって「odd-even機構を確認」とは結論しない。
