#!/usr/bin/env python3
"""Verify archived formal inputs and reproduced event-analysis results."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_SIGNATURES = [
    "negative_not_observed",
    "W->passive->negative",
    "negative_not_observed",
    "W->passive->negative",
    "W->passive->negative",
]
EXPECTED_CLASSIFICATION = "odd_even_alternation_candidate"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def verify_formal_hashes() -> None:
    manifest = json.loads(
        (ROOT / "reference-results" / "input_hashes_before_after.json").read_text(
            encoding="utf-8"
        )
    )
    for item in manifest["files"]:
        path = ROOT / "data" / "formal-timeseries" / item["formal_output"]
        if not path.is_file():
            raise SystemExit(f"FAIL missing formal time series: {path.name}")
        if sha256(path) != item["formal_output_sha256"]:
            raise SystemExit(f"FAIL formal SHA-256: {path.name}")
    print("PASS all five formal time-series SHA-256 values")


def verify_result_set(result_dir: Path, label: str) -> None:
    summary = read_rows(result_dir / "event_summary.csv")
    signatures = [row["categorical_signature"] for row in summary]
    if signatures != EXPECTED_SIGNATURES:
        raise SystemExit(f"FAIL {label} categorical signatures: {signatures}")

    with (result_dir / "odd_even_temporal_comparison.csv").open(
        encoding="utf-8", newline=""
    ) as handle:
        comparison = dict(csv.reader(handle))
    if comparison.get("final_classification") != EXPECTED_CLASSIFICATION:
        raise SystemExit(
            "FAIL "
            f"{label} final classification: {comparison.get('final_classification')}"
        )

    numerical = read_rows(result_dir / "numerical_checks.csv")
    if len(numerical) != 5 or any(row["status"] != "PASS" for row in numerical):
        raise SystemExit(f"FAIL {label} numerical checks")

    continuity = read_rows(result_dir / "continuity_checks.csv")
    if any(row["status"] != "PASS" for row in continuity):
        raise SystemExit(f"FAIL {label} continuity checks")
    print(f"PASS {label} signatures, classification, numerical, and continuity checks")


def main() -> None:
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--reference", action="store_true")
    group.add_argument("--generated", action="store_true")
    args = parser.parse_args()

    verify_formal_hashes()
    result_dir = ROOT / ("reference-results" if args.reference else "generated-results")
    verify_result_set(result_dir, "reference" if args.reference else "generated")


if __name__ == "__main__":
    main()
