# 直列 N=3〜7 odd-evenイベント交互性：実行前固定仕様

## 0. 位置づけ

これは旧N=5,6,7,8実験の縮小版ではなく、N=3,4,5,6,7を連続して並べ、滑らかな鎖長依存とodd-even交互性候補を分離する新しい事前設計である。旧PRECOMMITは変更履歴として保存し、上書きしない。

中心質問：

> N=3〜7の有限直列鎖において、Wピーク後のcurrent負方向化とpassive energy増加のイベント構造に、滑らかな鎖長依存だけでは説明しにくいodd-even交互性の候補があるか。

odd群とeven群の平均比較を目的にしない。Nに沿った隣接差、局所交互差、categorical signatureを主診断とする。有限5条件の記述的探索であり、parity mechanismや普遍則の検証ではない。

## 1. 正式条件

```text
geometry = serial
N = 3,4,5,6,7
odd = 3,5,7
even = 4,6
TOTAL_GAMMA = 1.5
gamma_site = 1.5 / N
equal drive input
target_E_drive_in = 5.9618618770136536e-2
relative_matching_tolerance = 1e-4
dt = 0.0025
t = 0..10
saved interval = 0.01
saved points = 1001
integrator = fixed-step RK4
initial state = vacuum
J = 1, g = 0.25, omega = 1, tau = 3.2
```

各Nでequal-input条件を満たす。条件が異なる既存軌道を混ぜない。

## 2. 既存軌道と新規計算の境界

### N=7

Milestone 11Mの正式軌道を読み取り専用で再利用する。Omegaは `0.18748395731510084`、新規軌道は0本。11M時系列にはsite populations、bond currents、site7-to-load current、load E/W/passive、数値診断、continuity残差が1001点保存されている。イベント値は今回の共通抽出器で再抽出し、旧events CSVをそのまま混ぜない。

### N=3

既存equal-input referenceはtarget入力を定義する正式軌道であり、load energyとload ergotropyは1001点保存されているため `passive_energy = load_energy - load_ergotropy` は復元できる。一方、site3-to-load current、site populations、bond currents、continuity residualsは保存されていない。

このため、既存ファイルだけで正式currentイベントは抽出不能である。N=3は既存と同一の正式条件・Omegaを使い、site-resolved量を保存する新規full trajectoryを1本必要とする。これはmatchingのやり直しではない。再現比較に合格した1本を正式event trajectoryとし、同一条件を再計算しない。

### N=4,5,6

equal-input matching候補を一軌道ずつ実行する。すべての候補が最初からsite-resolved正式診断量を保存する。matching許容を初めて満たした軌道をそのまま正式event trajectoryに採用する。

## 3. 計算上限

```text
N=3: 最大3本の枠内。ただし計画上は正式条件のsite-resolved再現1本
N=4: matchingを含め最大3本
N=5: matchingを含め最大3本
N=6: matchingを含め最大3本
N=7: 新規0本
```

3本目で初めてmatchingに合格した場合も3本目を正式採用し、4本目を実行しない。成果物作成だけを理由に同一条件を再計算しない。3本以内にmatchingできなければ `matching_not_completed` とし、結果後にfixed-Omegaへ変更しない。

## 4. 必須時系列量とcurrent定義

全matching候補で、time、全site populations、全bond currents、last-site-to-load current、load energy、load ergotropy、passive energy、usable fraction、load coherence、drive power、累積drive input、XGamma、trace、Hermiticity、robust positivity、solver accounting、energy ledger、continuity residualsを保存する。

- bond current: `I_(j->j+1) = -2 J Im(<sigma_j^+ sigma_(j+1)^->)`
- last-site-to-load current: `I_(N->load) = <i[H_interaction,H_load]>`
- 正方向はdrive側からload側。
- 全Nで単純状態の符号test、演算子continuity test、数値continuity checkを通す。

## 5. 共通イベント抽出規則

旧PRECOMMITの規則を維持する。raw double precision値から抽出し、表示丸め値を判定に使わない。

### Wピーク

保存グリッド上のglobal maximumを使う。最大値との差が `max(1e-12, 1e-10*|W_peak|)` 以下で連続する点をplateauとし、開始・終了・中点を保存する。以後の基準は `t_W_peak_end`。

### currentイベント

`I_threshold = max(1e-10, 1e-3 * max_t |I_load(t)|)`。

W peak終了後の最初の `I_k > 0, I_(k+1) <= 0` を線形補間し、`t_current_zero_crossing_raw` とする。その後初めて `I <= -I_threshold` となり、5保存点連続で同条件が続く先頭を `t_current_negative_onset` とする。

### passive増加イベント

中央差分（端点のみ片側差分）で `dP/dt` を作る。`P_threshold = max(1e-10, 1e-3 * max_t |dP/dt|)`。W peak終了後に `dP/dt > P_threshold` が5保存点連続する最初を `t_passive_increase_onset` とする。

### 積分と時間差

保存グリッド上の台形則で次を計算する。

```text
backflow_amount_post_peak
positive_inflow_post_peak
Delta_t_negative_onset
Delta_t_passive
Delta_t_passive_after_negative
post_peak_W_loss_fraction
Delta_passive_peak_to_t10
```

各時間差を `t_W_peak_end` で割った補助値も併記する。

## 6. categorical signature

各Nを次の一つへ分類する。

```text
W->negative->passive
W->passive->negative
W->simultaneous
negative_not_observed
passive_not_observed
both_not_observed
diagnostic_invalid
```

`simultaneous` は2イベントの差が0.01以下。正常軌道でのcurrent未反転やpassive増加未観測は有効なsignatureであり、未観測だけで不完全扱いしない。

categoricalなodd-even候補には、N=3,5,7が同一signature、N=4,6が同一signature、oddとevenが異なることを要求する。

## 7. 隣接差と局所交互差

対象量は `t_W_peak_end`、`Delta_t_negative_onset`、`Delta_t_passive`、`backflow_amount_post_peak`、`post_peak_W_loss_fraction`、`Delta_passive_peak_to_t10`。

```text
D_3_4 = X(4) - X(3)
D_4_5 = X(5) - X(4)
D_5_6 = X(6) - X(5)
D_6_7 = X(7) - X(6)

A_4 = X(4) - [X(3)+X(5)]/2
A_5 = X(5) - [X(4)+X(6)]/2
A_6 = X(6) - [X(5)+X(7)]/2
```

Aは局所的に滑らかなN依存からのずれを表す記述量であり、統計的有意差、普遍的parity order parameter、機構証明とは呼ばない。欠損イベントを数値補完せず、該当D/Aは `not_computable_due_to_valid_event_absence` とする。

### 連続量によるCase A補助条件

- 6対象量のうちA_4,A_5,A_6をすべて計算できる量をeligibleとする。
- eligibleが2量以上必要。
- 各eligible量で `sign(A_4)=sign(A_6)=-sign(A_5)`、またはその全符号反転を満たす。
- 各Aの絶対値が、その量の4隣接差の絶対値中央値の10%以上かつ数値床 `1e-10` を超える。
- 同じ交互位相がeligible量の過半数かつ最低2量で一致する。
- この条件だけでCase Aとなる場合、`continuous_alternation_subcriterion_only` を明記する。

これは探索的記述基準であり、有意差検定ではない。

## 8. 最終分類

優先順位は F > E > A > D > B > C。

- Case A `odd_even_alternation_candidate`: categorical条件、または7節の連続量補助条件を満たす。
- Case B `smooth_length_dependence_candidate`: Aでなく、主要量がNに沿って滑らか・単調で明確な交互性がない。
- Case C `irregular_length_dependence`: 全診断有効だがA/B/Dに整理できない。
- Case D `common_temporal_pattern_across_N3_to_N7`: 全5条件が同じ有効signatureで、連続量交互性もない。
- Case E `temporal_pattern_incomplete`: matching失敗、required trajectory欠損、診断不能、input/reproduction failure、またはt=10でobserved/not_observedを確定できない。
- Case F `diagnostic_or_numerical_issue_stop`: current符号、continuity、再現、finite values、trace、Hermiticity、positivity accounting、energy ledgerに問題がある。

正常軌道の有効な未観測signatureはCase Eにしない。Case Aは有限サイズ候補でありparity mechanismとは呼ばない。

## 9. benchmarkと実行許可ゲート

- N=4とN=5を、正式site-resolved候補と同じコード経路で16 RK4 steps・5診断点benchmarkする。
- N=6は既存の同コード経路benchmarkをhash確認して再利用する。
- construction、propagation/step、diagnostics/saved point、4000 steps・1001点の1軌道推定を分ける。
- N=3,4,5,6の最大必要軌道数と総時間を提示するまでmatching/full runを開始しない。
- benchmarkのOmegaは時間測定用であり、未matching Nの正式物理値ではない。

## 10. 数値品質

1001 saved points、required values finite、既存正式trace/Hermiticity/energy-ledger tolerance、robust positivity、solver failure count=0、current tests PASS、continuity max residual `<=5e-4`、入力hash不変を必須とする。

N=3は既存reference集約量と全1001点で再現比較する。N=7は11Mを読み取り専用で使用し、入力hashを記録する。

## 11. 必須成果物

```text
QWN_N3_TO_N7_ODD_EVEN_EVENT_PRECOMMIT.md
existing_trajectory_availability.csv
feasibility_benchmark_N3_to_N7.csv
runtime_estimate_N3_to_N7.md
matching_summary.csv
event_timeseries_N3.csv ... event_timeseries_N7_reused.csv
event_summary.csv
adjacent_differences.csv
alternating_differences.csv
odd_even_temporal_comparison.csv
continuity_checks.csv
numerical_checks.csv
input_hashes_before_after.json
FINAL_REPORT.md
```

## 12. 実行順序と停止

```text
1. 新PRECOMMIT作成
2. N=3、N=7既存成果物の利用可能性確認
3. N=4 benchmark
4. N=5 benchmark
5. N=6既存benchmark再利用確認
6. N別必要軌道数と最大総時間を報告
7. 停止
```

ユーザーの明示確認前にmatching/full trajectoryを開始しない。

## 13. 禁止事項

```text
N=8
parallel geometry
additional noise
t>10
FFT
mode analysis
reflection mechanism analysis
disconnect
recovery/extraction operation
transformation operation
```

