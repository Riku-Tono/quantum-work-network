# N=3 to N=7 equal-input event-structure comparison

This package reproduces the descriptive event-structure analysis across finite serial chains `N=3,4,5,6,7`.
It uses the formally adopted, site-resolved trajectories saved during equal-input matching. N=7 is the
read-only Milestone 11M trajectory; N=3 through N=6 are the first matching trajectories that passed the
precommitted tolerance.

## Fixed conditions

```text
geometry = serial
TOTAL_GAMMA = 1.5; gamma_site = 1.5 / N
target_E_drive_in = 5.9618618770136536e-2
dt = 0.0025; t = 0..10; 1001 saved points
```

| N | formal Omega | relative input mismatch | source |
| ---: | ---: | ---: | --- |
| 3 | 0.2 | 0 | adopted trial 1 |
| 4 | 0.19466050591180037 | 1.2882180e-5 | adopted trial 3 |
| 5 | 0.19130947255811623 | 3.4047928e-5 | adopted trial 3 |
| 6 | 0.18908284317778151 | 5.3571257e-5 | adopted trial 3 |
| 7 | 0.18748395731510084 | 2.8157011e-6 | reused 11M trajectory |

## Recorded result

| N | categorical signature |
| ---: | --- |
| 3 | `negative_not_observed` |
| 4 | `W->passive->negative` |
| 5 | `negative_not_observed` |
| 6 | `W->passive->negative` |
| 7 | `W->passive->negative` |

The precommitted continuous-metric rule produced the formal label `odd_even_alternation_candidate`.
The categorical odd-even condition itself is false because N=7 does not share the N=3/N=5 signature.
The safe interpretation is therefore that simple odd/even event rules were not confirmed; only local
alternating differences in selected continuous quantities were observed.

## Reproduce the analysis

Requirements: Node.js 18+; no npm packages.

```bash
node scripts/analyze_odd_even_events.mjs
node scripts/audit_event_runs.mjs
python scripts/verify.py --generated
```

This writes `generated-results/` with event summaries, adjacent and alternating differences, numerical
checks, and continuity checks. It does not run a new quantum trajectory.

For the supplied reference data only:

```bash
python scripts/verify.py --reference
```

## Layout

- `data/formal-timeseries/`: five adopted formal trajectories, including normalized N=3–6 headers.
- `reference-results/`: precommit, matching table, final event tables, quality checks, and final report.
- `scripts/`: portable event extraction and numerical/continuity audit scripts.
- `rust-provenance/`: Rust source tree and lockfile used for the N=3–6 diagnostic trajectories.

The package is an analysis-reproduction set. It intentionally does not launch new matching searches or duplicate the formally adopted long trajectories merely to recreate presentation artifacts.

## License note

Confirm the intended copyright holder and add a repository-level `LICENSE` before public release.
