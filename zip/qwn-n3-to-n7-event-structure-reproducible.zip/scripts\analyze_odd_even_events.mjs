import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const outDir = path.join(root, "generated-results");
fs.mkdirSync(outDir, { recursive: true });
const sources = new Map([
  [3, path.join(root, "data/formal-timeseries/event_timeseries_N3.csv")],
  [4, path.join(root, "data/formal-timeseries/event_timeseries_N4.csv")],
  [5, path.join(root, "data/formal-timeseries/event_timeseries_N5.csv")],
  [6, path.join(root, "data/formal-timeseries/event_timeseries_N6.csv")],
  [7, path.join(root, "data/formal-timeseries/event_timeseries_N7_reused.csv")],
]);
const omegas = new Map([[3,0.2],[4,0.19466050591180037],[5,0.19130947255811623],[6,0.18908284317778151],[7,0.18748395731510084]]);
const inputMismatch = new Map([[3,0],[4,1.2882180268127424e-5],[5,3.4047927656004145e-5],[6,5.3571256552566652e-5],[7,2.8157011099880636e-6]]);

function parseCsv(file, n) {
  const lines = fs.readFileSync(file, "utf8").trim().split(/\r?\n/);
  return lines.slice(1).map(line => {
    const vals=line.split(",");
    const tail=5*n-2;
    return {
      time: vals[0],
      [`site${n}_to_load_current`]: vals[2*n],
      load_energy: vals[tail],
      load_ergotropy: vals[tail+1],
      passive_energy: vals[tail+2],
      drive_population_source: vals[tail+9],
      trace_error: vals[tail+10],
      hermiticity_error: vals[tail+11],
      selected_minimum_eigenvalue: vals[tail+12],
      positivity_solver: vals[tail+13],
      fallback_used: vals[tail+14],
      state_finite: vals[tail+15],
      solver_finite: vals[tail+16],
      ledger_residual: vals[tail+17],
      _values: vals,
    };
  });
}
function num(x){ return Number(x); }
function trap(rows, start, fn) {
  let sum=0;
  for(let i=start;i<rows.length-1;i++){
    const dt=num(rows[i+1].time)-num(rows[i].time);
    sum += .5*dt*(fn(rows[i])+fn(rows[i+1]));
  }
  return sum;
}
function fmt(x){
  if(x===null || x===undefined || Number.isNaN(x)) return "NaN";
  if(typeof x==="string") return x;
  return Number(x).toExponential(16);
}
function eventFor(n, rows) {
  const w=rows.map(r=>num(r.load_ergotropy));
  const p=rows.map(r=>num(r.passive_energy));
  const currentName=`site${n}_to_load_current`;
  const cur=rows.map(r=>num(r[currentName]));
  const times=rows.map(r=>num(r.time));
  const wPeak=Math.max(...w);
  const plateauTol=Math.max(1e-12,1e-10*Math.abs(wPeak));
  const peakIndices=w.map((v,i)=>({v,i})).filter(x=>wPeak-x.v<=plateauTol).map(x=>x.i);
  const peakStart=peakIndices[0], peakEnd=peakIndices[peakIndices.length-1];
  const iThreshold=Math.max(1e-10,1e-3*Math.max(...cur.map(Math.abs)));
  let rawCross=NaN, negOnset=NaN;
  for(let i=peakEnd;i<rows.length-1;i++){
    if(cur[i]>0 && cur[i+1]<=0){
      rawCross=times[i]+(0-cur[i])*(times[i+1]-times[i])/(cur[i+1]-cur[i]);
      for(let j=i+1;j<=rows.length-5;j++){
        if(cur.slice(j,j+5).every(v=>v<=-iThreshold)){ negOnset=times[j]; break; }
      }
      break;
    }
  }
  const dp=p.map((v,i)=>{
    if(i===0) return (p[1]-p[0])/(times[1]-times[0]);
    if(i===p.length-1) return (p[i]-p[i-1])/(times[i]-times[i-1]);
    return (p[i+1]-p[i-1])/(times[i+1]-times[i-1]);
  });
  const pThreshold=Math.max(1e-10,1e-3*Math.max(...dp.map(Math.abs)));
  let passiveOnset=NaN;
  for(let i=peakEnd;i<=rows.length-5;i++){
    if(dp.slice(i,i+5).every(v=>v>pThreshold)){ passiveOnset=times[i]; break; }
  }
  const negObs=Number.isFinite(negOnset), passObs=Number.isFinite(passiveOnset);
  let signature;
  if(!negObs&&!passObs) signature="both_not_observed";
  else if(!negObs) signature="negative_not_observed";
  else if(!passObs) signature="passive_not_observed";
  else if(Math.abs(negOnset-passiveOnset)<=0.01+1e-12) signature="W->simultaneous";
  else if(negOnset<passiveOnset) signature="W->negative->passive";
  else signature="W->passive->negative";
  const backflow=trap(rows,peakEnd,r=>Math.max(-num(r[currentName]),0));
  const positive=trap(rows,peakEnd,r=>Math.max(num(r[currentName]),0));
  const wLoss=(wPeak-w.at(-1))/wPeak;
  const deltaP=p.at(-1)-p[peakEnd];
  return {
    N:n, parity:n%2?"odd":"even", Omega:omegas.get(n),
    relative_input_mismatch:inputMismatch.get(n),
    W_peak:wPeak,t_W_peak_start:times[peakStart],t_W_peak_end:times[peakEnd],
    I_threshold:iThreshold,t_current_zero_crossing_raw:rawCross,
    t_current_negative_onset:negOnset,P_threshold:pThreshold,
    t_passive_increase_onset:passiveOnset,
    backflow_amount_post_peak:backflow,positive_inflow_post_peak:positive,
    Delta_t_negative_onset:negObs?negOnset-times[peakEnd]:NaN,
    Delta_t_passive:passObs?passiveOnset-times[peakEnd]:NaN,
    Delta_t_passive_after_negative:negObs&&passObs?passiveOnset-negOnset:NaN,
    post_peak_W_loss_fraction:wLoss,Delta_passive_peak_to_t10:deltaP,
    categorical_signature:signature,status:"valid"
  };
}
const events=[];
for(const [n,file] of sources) events.push(eventFor(n,parseCsv(file,n)));
const eventCols=Object.keys(events[0]);
fs.writeFileSync(path.join(outDir,"event_summary.csv"),eventCols.join(",")+"\n"+events.map(e=>eventCols.map(c=>fmt(e[c])).join(",")).join("\n")+"\n");

const metrics=["t_W_peak_end","Delta_t_negative_onset","Delta_t_passive","backflow_amount_post_peak","post_peak_W_loss_fraction","Delta_passive_peak_to_t10"];
const adjacent=[];
for(const metric of metrics){
  for(let n=3;n<7;n++){
    const a=events.find(e=>e.N===n)[metric], b=events.find(e=>e.N===n+1)[metric];
    adjacent.push({metric,difference:`D_${n}_${n+1}`,value:Number.isFinite(a)&&Number.isFinite(b)?b-a:NaN,status:Number.isFinite(a)&&Number.isFinite(b)?"computed":"not_computable_due_to_valid_event_absence"});
  }
}
fs.writeFileSync(path.join(outDir,"adjacent_differences.csv"),"metric,difference,value,status\n"+adjacent.map(x=>`${x.metric},${x.difference},${fmt(x.value)},${x.status}`).join("\n")+"\n");
const alternating=[];
for(const metric of metrics){
  for(let n=4;n<=6;n++){
    const l=events.find(e=>e.N===n-1)[metric], x=events.find(e=>e.N===n)[metric], r=events.find(e=>e.N===n+1)[metric];
    alternating.push({metric,difference:`A_${n}`,value:[l,x,r].every(Number.isFinite)?x-(l+r)/2:NaN,status:[l,x,r].every(Number.isFinite)?"computed":"not_computable_due_to_valid_event_absence"});
  }
}
fs.writeFileSync(path.join(outDir,"alternating_differences.csv"),"metric,difference,value,status\n"+alternating.map(x=>`${x.metric},${x.difference},${fmt(x.value)},${x.status}`).join("\n")+"\n");

const odd=events.filter(e=>e.parity==="odd").map(e=>e.categorical_signature);
const even=events.filter(e=>e.parity==="even").map(e=>e.categorical_signature);
const categoricalCandidate=new Set(odd).size===1 && new Set(even).size===1 && odd[0]!==even[0];
const eligible=[];
for(const metric of metrics){
  const aa=alternating.filter(x=>x.metric===metric);
  const dd=adjacent.filter(x=>x.metric===metric && Number.isFinite(x.value));
  if(aa.length!==3 || !aa.every(x=>Number.isFinite(x.value)) || dd.length!==4) continue;
  const absD=dd.map(x=>Math.abs(x.value)).sort((a,b)=>a-b);
  const median=(absD[1]+absD[2])/2;
  const s=aa.map(x=>Math.sign(x.value));
  const phase=(s[0]===s[2]&&s[0]===-s[1]&&s[0]!==0)?s[0]:0;
  const magnitude=aa.every(x=>Math.abs(x.value)>Math.max(1e-10,.1*median));
  if(phase&&magnitude) eligible.push({metric,phase});
}
let continuousCandidate=false;
if(eligible.length>=2){
 const counts=new Map();
 for(const e of eligible) counts.set(e.phase,(counts.get(e.phase)||0)+1);
 continuousCandidate=[...counts.values()].some(c=>c>=2&&c>eligible.length/2);
}
const allSame=new Set(events.map(e=>e.categorical_signature)).size===1;
let classification;
if(categoricalCandidate||continuousCandidate) classification="odd_even_alternation_candidate";
else if(allSame) classification="common_temporal_pattern_across_N3_to_N7";
else {
 let monotone=0, eligibleCount=0;
 for(const metric of metrics){
   const vals=events.map(e=>e[metric]);
   if(!vals.every(Number.isFinite)) continue;
   eligibleCount++;
   const dif=vals.slice(1).map((v,i)=>v-vals[i]);
   if(dif.every(x=>x>=0)||dif.every(x=>x<=0)) monotone++;
 }
 classification=eligibleCount>0&&monotone===eligibleCount?"smooth_length_dependence_candidate":"irregular_length_dependence";
}
const comp=[
 "criterion,value",
 `odd_signatures,${odd.join("|")}`,
 `even_signatures,${even.join("|")}`,
 `categorical_candidate,${categoricalCandidate}`,
 `eligible_continuous_alternating_metrics,${eligible.map(e=>e.metric+":"+e.phase).join("|")||"none"}`,
 `continuous_candidate,${continuousCandidate}`,
 `final_classification,${classification}`
].join("\n")+"\n";
fs.writeFileSync(path.join(outDir,"odd_even_temporal_comparison.csv"),comp);
console.log(JSON.stringify({events,eligible,categoricalCandidate,continuousCandidate,classification},null,2));
