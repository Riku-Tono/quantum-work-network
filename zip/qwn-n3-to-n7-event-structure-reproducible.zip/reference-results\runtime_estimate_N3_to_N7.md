# N=3〜7 odd-evenイベント実験：利用可能性・benchmark・実行時間報告

## 結論

新PRECOMMIT、N=3/N=7既存成果物監査、N=4/N=5 benchmark、N=6 benchmark再利用確認まで完了した。matchingと長時間full trajectoryは開始していない。

N=8は新設計の対象外であり、今回の計画・総時間から完全に除外した。

## 既存成果物

| N | 判定 | 理由 | 新規必要数 |
|---:|---|---|---:|
| 3 | 一部利用可能だが正式イベント抽出には不足 | 正式equal-input referenceはE/Wを1001点保存しpassiveは導出可能。しかしsite3-to-load current、site/bond量、continuity残差がない | 1本 |
| 7 | 正式再利用可能 | 11Mにsite7-to-load current、passive、全site/bond、continuity、数値診断が1001点保存済み | 0本 |

N=3でload energyの数値微分をcurrentの代用品にはしない。旧PRECOMMITが要求する直接のsite-to-load energy currentと同じ量ではなく、保存刻み差分誤差を含むためである。既存の異なる条件も混ぜない。

## benchmark

条件は16 RK4 steps、5 saved diagnostic points、正式候補と同じsite-resolved/positivity/current診断コード経路。Omega=0.18748395731510084は時間測定用で、N=4/5の正式matching値ではない。

| N | construction | propagation/step | diagnostics/point | 1軌道推定 |
|---:|---:|---:|---:|---:|
| 4 | 0.00865 s | 0.001609 s | 0.003337 s | 9.79 s |
| 5 | 0.1165 s | 0.01523 s | 0.03804 s | 99.11 s = 1.65 min |
| 6 | 1.0746 s | 0.09068 s | 0.2800 s | 644.12 s = 10.74 min |

N=6は前段で実測済みの同一コード経路CSVをSHA-256 `3D9452C55E29111044A606948F9132BD6070C581FB7035B32F53D9981DEEF2EC`で確認し、再benchmarkしていない。

N=3は今回benchmark対象ではない。N=4実測をdense dimensionのおおむね3乗で1/8へ縮小した1.22秒を計画値にする。既存N=3 standard診断full run実測1.00秒とも整合するが、site-resolved正式軌道の実測ではない。

## 必要軌道数と最大時間

| N | 必要／上限 | 1軌道 | 最大 |
|---:|---:|---:|---:|
| 3 | 必要1本 | 約1.22 s（推定） | 約1.22 s |
| 4 | 最大3本 | 9.79 s | 29.36 s |
| 5 | 最大3本 | 99.11 s | 297.32 s = 4.96 min |
| 6 | 最大3本 | 644.12 s | 1932.35 s = 32.21 min |
| 7 | 新規0本 | 既存11Mを再利用 | 0 |

```text
maximum new trajectory time
= 1.22 + 29.36 + 297.32 + 1932.35
= 2260.25 s
= 37.67 min
```

compile、候補間集計、ファイル検証、OS変動に15%の余裕を加えた運用上限は約43.3分。これは各Nが上限まで必要となる最悪ケースであり、matchingを早く満たせば短くなる。

## 停止状態

```text
new_precommit_created = true
N3_existing_only_formal_event_extraction = false
N3_site_resolved_reproduction_required = 1
N7_reuse = true
N4_benchmark = completed
N5_benchmark = completed
N6_benchmark = reused_hash_verified
N8_in_scope = false
matching_started = false
full_trajectory_started = false
```

指定された段階6まで完了し、ここで停止した。

