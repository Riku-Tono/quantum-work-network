# 直列 N=5・6・7・8 イベント時間構造：実行前固定仕様

## 0. この文書の位置づけ

この文書は計算結果を見る前に、比較条件、イベント定義、判定規則、停止条件を固定するための事前設計である。目的は、直列量子ネットワークの load ergotropy ピーク後に現れる時間構造を、N=5, 6, 7, 8 の4条件で記述的に比較することである。

中心質問は次の一つに限る。

> Wピーク、last-site-to-load energy current の持続的な負方向化、passive energy の持続的増加の順序と間隔に、調べた奇数群 N=5,7 と偶数群 N=6,8 を分ける候補があるか。

これは parity 機構の証明ではない。Nと同時に鎖長、Hilbert空間次元、伝播距離、bond数が変わるため、有限4条件の候補探索に限定する。

## 1. 固定する物理条件

| 項目 | 固定値 |
|---|---|
| geometry | 直列のみ |
| N | 5, 6, 7, 8 |
| initial state | 既存正式系列と同じ vacuum |
| J, g, omega, tau | 既存正式系列と同じ値（J=1, g=0.25, omega=1, tau=3.2） |
| time | 0 <= t <= 10 |
| integrator | fixed-step RK4 |
| formal dt | 0.0025 |
| saved grid | 0.01間隔、1001点 |
| noise convention | fixed-total |
| TOTAL_GAMMA | 1.5 |
| gamma_site | 1.5 / N、全chain siteへ均等、loadへ直接雑音なし |

### 1.1 入力条件

正式比較は **equal drive input** とする。

```text
target_E_drive_in = 5.9618618770136536e-2
relative_matching_tolerance = 1e-4
```

各Nで Omega を個別に合わせる。N=7は既存正式値を再利用する。

```text
Omega_N7 = 0.18748395731510084
```

N=5,6,8の matching は、短い探索を大量に走らせず、次の順で一軌道ずつ行う。

1. 既存値または弱駆動近似から初期候補を1点作る。
2. 必要な場合だけ上下1点ずつを追加し、局所 bracket を作る。
3. bracket 内の線形補間点を1点評価する。
4. 相対不一致が `1e-4` 以下なら停止する。
5. 各Nの新規 full trajectory は matching を含めて最大3本とする。3本で一致しなければ、そのNを `matching_not_completed` とし、条件を結果後に fixed-Omega へ変更しない。

matching許容を初めて満たした full trajectory を、そのNの正式 event trajectory として採用する。3本目で初めて合格した場合も3本目を採用し、4本目は実行しない。同一のN、Omega、dt、TOTAL_GAMMA条件を成果物作成だけのために再計算しない。

この再利用を可能にするため、すべてのmatching候補軌道で、4節に定めるsite-resolved量と正式数値診断を最初から保存する。matching探索用の軽量軌道と正式診断用軌道を分けない。

N=5,6,8のうち一つでも matching が完了しない場合、4条件の正式 parity 比較は `temporal_pattern_incomplete` とする。fixed-Omega は別実験として設計し直す。

## 2. 再利用と新規計算の境界

- N=7の既存 Milestone 11M site-resolved trajectory は正式参照として読み取り専用で再利用する。
- ただし、イベント値は全N共通の今回の抽出器で **N=7も再抽出** する。11Mの既存 events CSVをそのまま混ぜない。
- N=5,6,8は equal-input matching 候補を各N最大3本だけ新規計算する。全候補がsite-resolved正式診断量を保存し、最初の合格軌道をそのまま正式event trajectoryにする。
- matching合格後に、同一条件の「正式site-resolved軌道」を別途再計算しない。
- 既存ファイルを上書きしない。入力SHA-256を実行前後に保存する。

## 3. benchmark と実行許可ゲート

長時間計算は benchmark 結果と推定時間を提示するまで開始しない。

1. 共通コードの unit tests と current sign tests を先に実行する。
2. N=6、N=8について、正式条件と同じコード経路で16 RK4 steps、5 saved diagnostics pointsの benchmark を行う。
3. construction、propagation/step、diagnostics/saved point、1軌道推定時間を分けて記録する。
4. matching候補はすべて正式site-resolved量を保存する。同一軌道の再計算はないため、各N最大3軌道としてN別上限時間と全体上限を示す。
5. メモリ使用量、有限値、1 step完了を確認する。N=8が実行不能ならそこで停止し、自動的に小さいNだけの結論へ縮小しない。

推定式：

```text
estimated_full_seconds
= construction_seconds
 + propagation_seconds_per_step * 4000
 + diagnostics_seconds_per_saved_point * 1001
```

benchmarkは時間推定であり、正式物理結果には使わない。

## 4. 正式時系列に保存する量

```text
time
site_population_1 ... site_population_N
bond_current_1_to_2 ... bond_current_(N-1)_to_N
last_site_to_load_current
load_energy
load_ergotropy
passive_energy
usable_fraction
load_coherence_l1
drive_power
drive_energy_in_cumulative
x_gamma_instant
x_gamma_cumulative
trace_error
hermiticity_error
selected_minimum_eigenvalue
positivity_solver
fallback_used
state_finite
solver_finite
energy_ledger_residual
continuity_residuals
```

```text
passive_energy = load_energy - load_ergotropy
```

passive energy は独立した新しいエネルギー種ではなく、指定load Hamiltonianと状態に対して局所ユニタリで取り出せない部分である。

## 5. current の定義と事前テスト

- chain bond current は既存規約 `I_(j->j+1) = -2 J Im(<sigma_j^+ sigma_(j+1)^->)` を使う。
- last-site-to-load current は `I_(N->load) = <i[H_interaction,H_load]>` を使う。
- 正方向は drive側からload側とする。
- 単純状態の符号test、演算子continuity test、数値continuity checkを全Nで通す。

## 6. イベント抽出規則

すべて raw double precision 値から抽出する。丸めたCSV表示値で判定しない。

### 6.1 Wピーク

`t_W_peak_grid` は保存グリッド上の global maximum とする。最大値との差が `max(1e-12, 1e-10*|W_peak|)` 以下で連続する点を plateau とみなし、開始、終了、中点を保存する。単一点なら3値は同じである。以後の基準時刻は plateau終了時刻とする。

### 6.2 current のゼロ交差と持続的負方向化

```text
I_threshold = max(1e-10, 1e-3 * max_t |I_load(t)|)
```

Wピークplateau終了後について、隣接点 `I_k > 0`、`I_(k+1) <= 0` を満たす最初の組を探し、線形補間した時刻を `t_current_zero_crossing_raw` とする。

その交差を正式イベントとして採用する条件は、交差後に初めて `I <= -I_threshold` となった点から5保存点連続で `I <= -I_threshold` が続くことである。その先頭時刻を `t_current_negative_onset` とする。条件を満たさなければ、raw交差は診断欄だけに残し、正式statusは `not_observed_by_t10` とする。

この二つの時刻を混同しない。

### 6.3 passive energy の持続的増加開始

保存点の中央差分（端点のみ片側差分）で `dP/dt` を作る。

```text
P_threshold = max(1e-10, 1e-3 * max_t |dP/dt|)
```

Wピークplateau終了後に、`dP/dt > P_threshold` が5保存点連続する最初の点を `t_passive_increase_onset` とする。すでにピーク時点で条件が続いている場合は、基準時刻と同じ値を記録する。未観測なら `not_observed_by_t10` とする。

### 6.4 積分量

保存グリッド上の台形則で計算する。

```text
backflow_amount_post_peak
  = integral_[t_peak_end,10] max(-I_load(t), 0) dt

positive_inflow_post_peak
  = integral_[t_peak_end,10] max( I_load(t), 0) dt
```

これらを ergotropy損失量、passive energy変換量、熱、散逸とは呼ばない。

## 7. 時間差

```text
Delta_t_zero_crossing = t_current_zero_crossing_raw - t_W_peak_end
Delta_t_negative_onset = t_current_negative_onset - t_W_peak_end
Delta_t_passive = t_passive_increase_onset - t_W_peak_end
Delta_t_passive_after_negative
  = t_passive_increase_onset - t_current_negative_onset
```

補助値として各差を `t_W_peak_end` で割った値も必ず併記する。絶対値と正規化値の両方を報告し、結果を見て片方だけを採用しない。

## 8. 事前固定する分類

各Nの categorical signature は次のいずれかとする。

```text
W->negative->passive
W->passive->negative
W->simultaneous_passive_then_negative
negative_not_observed
passive_not_observed
both_not_observed
diagnostic_invalid
```

`simultaneous` は2イベントの差が保存間隔 `0.01` 以下の場合とする。

### A. odd-even temporal pattern candidate

次のどちらかを満たす場合だけ採用する。

1. **順序候補**：N=5とN=7の categorical signature が一致し、N=6とN=8も互いに一致し、奇数signatureと偶数signatureが異なる。
2. **時間差候補**：4条件で同じイベントが観測され、`Delta_t_negative_onset` または `Delta_t_passive` について、奇数2点が偶数2点より両方とも小さい、または両方とも大きく、最も近い群間差が `max(0.10, 0.05*t_W_peak_end)` 以上である。絶対差と正規化差が同じ方向であることも必要とする。

これは finite-size candidate であり parity mechanism とは呼ばない。

### B. common temporal pattern across tested lengths

4条件の categorical signature が一致し、Aの時間差候補を満たさない場合。

### C. length dependent without parity grouping

イベント差はあるがAの群分けを満たさず、全条件の診断が有効な場合。

### D. temporal pattern incomplete

次のいずれかに限る。

```text
matching_not_completed
N=8 execution infeasible
required trajectory missing
t=10までではイベント状態を判定不能
diagnostic_invalid
input or reproduction failure
```

正常に完了した軌道の `negative_not_observed`、`passive_not_observed`、`both_not_observed` は有効な categorical signature である。イベントが存在しなかったことだけを理由にDへ分類しない。たとえば奇数2条件が `W->negative->passive`、偶数2条件が `negative_not_observed` なら、Aの順序候補を評価できる。

### E. diagnostic or numerical issue stop

current sign/continuity、N=7再現、有限値、trace、Hermiticity、positivity solver accounting、energy ledgerのいずれかが規定を満たさない場合。

優先順位は E > D > A > B > C とする。複数の観測を都合よく一つへ選ばず、順序候補と時間差候補を別欄で報告する。

## 9. 数値品質と再現条件

各軌道について以下を必須とする。

```text
1001 saved points
all required state values finite
trace tolerance: existing formal implementation threshold
Hermiticity tolerance: existing formal implementation threshold
robust positivity: Hermitianize -> SymmetricEigen -> required fallback
solver failure count = 0
energy ledger: existing formal implementation threshold
current unit tests = PASS
continuity max residual <= 5e-4
```

N=7は11Mの8集約量と全1001点で既存許容値内に一致することを確認する。新抽出イベントが旧events CSVと違う場合、今回の共通定義による差として記録し、旧値を上書きしない。

## 10. 必須成果物

```text
PRECOMMIT.md
feasibility_benchmark.csv
runtime_estimate.md
matching_summary.csv
event_timeseries_N5.csv
event_timeseries_N6.csv
event_timeseries_N7_reused.csv
event_timeseries_N8.csv
event_summary.csv
odd_even_temporal_comparison.csv
continuity_checks.csv
numerical_checks.csv
input_hashes_before_after.json
FINAL_REPORT.md
```

`event_summary.csv` は最低限、N、parity、Omega、matching誤差、W peak plateau、raw zero crossing、negative onset、passive onset、各時間差、current積分、W/passiveのpeak-to-t10変化、categorical signature、statusを一行にまとめる。

## 11. 実行順序と停止条件

```text
1. 実装
2. current/continuity unit tests
3. N=6 benchmark
4. N=8 benchmark
5. N別・全体のETAと実行可能性を報告
6. ユーザー確認後にだけmatchingを開始（各候補が正式site-resolved軌道、各N最大3本）
7. N=7を含む共通イベント再抽出
8. A〜E分類
9. 成果物とhashを検証
10. 停止
```

並列geometry、輪、十字、N>8、t>10、追加gamma/eta、mutual information、negativity、mode、FFT、反射機構、切り離し・回収・変質操作へ自動的に進まない。

## 12. 主張しないこと

```text
奇数鎖は一般に逆流しやすい
偶数鎖は逆流しない
parityが原因である
current逆転がpassive増加を引き起こした
current逆転が境界反射を証明した
passive energyが別種のエネルギーへ変質した
普遍則、量子優位
```

直接報告するのは、指定有限条件でのイベント時刻、順序、間隔、current積分量、load状態量の対応だけである。
