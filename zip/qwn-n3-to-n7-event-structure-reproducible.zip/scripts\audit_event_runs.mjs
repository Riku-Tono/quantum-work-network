import fs from "node:fs";
import path from "node:path";

const root=process.cwd(), out=path.join(root,"generated-results");
fs.mkdirSync(out, { recursive: true });
const sources=new Map([
 [3,path.join(root,"data/formal-timeseries/event_timeseries_N3.csv")],
 [4,path.join(root,"data/formal-timeseries/event_timeseries_N4.csv")],
 [5,path.join(root,"data/formal-timeseries/event_timeseries_N5.csv")],
 [6,path.join(root,"data/formal-timeseries/event_timeseries_N6.csv")],
 [7,path.join(root,"data/formal-timeseries/event_timeseries_N7_reused.csv")],
]);
const derivative=(a,t,i)=>i===0?(a[1]-a[0])/(t[1]-t[0]):i===a.length-1?(a[i]-a[i-1])/(t[i]-t[i-1]):(a[i+1]-a[i-1])/(t[i+1]-t[i-1]);
const rms=a=>Math.sqrt(a.reduce((s,x)=>s+x*x,0)/a.length);
const fmt=x=>Number(x).toExponential(16);
const continuity=[], numerical=[];
for(const [n,file] of sources){
 const lines=fs.readFileSync(file,"utf8").trim().split(/\r?\n/).slice(1);
 const rows=lines.map(x=>x.split(","));
 const t=rows.map(r=>+r[0]), tail=5*n-2;
 const pops=Array.from({length:n},(_,s)=>rows.map(r=>+r[1+s]));
 const bonds=Array.from({length:n-1},(_,s)=>rows.map(r=>+r[1+n+s]));
 const loadI=rows.map(r=>+r[2*n]), loadE=rows.map(r=>+r[tail]);
 const source=rows.map(r=>+r[tail+9]);
 const residuals=Array.from({length:n+1},()=>[]);
 for(let i=0;i<rows.length;i++){
   residuals[0].push(derivative(pops[0],t,i)-(source[i]-bonds[0][i]));
   for(let s=1;s<n-1;s++) residuals[s].push(derivative(pops[s],t,i)-(bonds[s-1][i]-bonds[s][i]));
   residuals[n-1].push(derivative(pops[n-1],t,i)-(bonds[n-2][i]-loadI[i]));
   residuals[n].push(derivative(loadE,t,i)-loadI[i]);
 }
 for(let s=0;s<n;s++) continuity.push({N:n,equation:`site_${s+1}`,max_abs:Math.max(...residuals[s].map(Math.abs)),rms:rms(residuals[s])});
 continuity.push({N:n,equation:"load",max_abs:Math.max(...residuals[n].map(Math.abs)),rms:rms(residuals[n])});
 const col=k=>rows.map(r=>+r[tail+k]);
 const bool=k=>rows.map(r=>String(r[tail+k]).trim().toLowerCase());
 numerical.push({N:n,points:rows.length,max_trace_error:Math.max(...col(10).map(Math.abs)),max_hermiticity_error:Math.max(...col(11).map(Math.abs)),min_selected_eigenvalue:Math.min(...col(12)),fallback_count:bool(14).filter(x=>x==="true").length,state_nonfinite_count:bool(15).filter(x=>x!=="true").length,solver_nonfinite_count:bool(16).filter(x=>x!=="true").length,max_ledger_residual:Math.max(...col(17).map(Math.abs))});
}
fs.writeFileSync(path.join(out,"continuity_checks.csv"),"N,equation,max_abs,rms,threshold,status\n"+continuity.map(x=>`${x.N},${x.equation},${fmt(x.max_abs)},${fmt(x.rms)},5.0000000000000000e-4,${x.max_abs<=5e-4?"PASS":"FAIL"}`).join("\n")+"\n");
fs.writeFileSync(path.join(out,"numerical_checks.csv"),"N,points,max_trace_error,max_hermiticity_error,min_selected_eigenvalue,fallback_count,state_nonfinite_count,solver_nonfinite_count,max_ledger_residual,status\n"+numerical.map(x=>`${x.N},${x.points},${fmt(x.max_trace_error)},${fmt(x.max_hermiticity_error)},${fmt(x.min_selected_eigenvalue)},${x.fallback_count},${x.state_nonfinite_count},${x.solver_nonfinite_count},${fmt(x.max_ledger_residual)},${x.points===1001&&x.state_nonfinite_count===0&&x.solver_nonfinite_count===0?"PASS":"FAIL"}`).join("\n")+"\n");
console.log(JSON.stringify({maxContinuity:Math.max(...continuity.map(x=>x.max_abs)),continuityFailures:continuity.filter(x=>x.max_abs>5e-4),numerical},null,2));
