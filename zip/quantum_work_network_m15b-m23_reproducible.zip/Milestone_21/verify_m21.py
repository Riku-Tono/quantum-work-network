"""Audit M21 with an independently assembled Hamiltonian and propagator."""

import argparse
import csv
from dataclasses import dataclass
from functools import cached_property, lru_cache
import hashlib
import math
import os
from pathlib import Path, PurePosixPath
import struct

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import numpy as np
from scipy.sparse import csr_matrix, diags, eye, kron
from scipy.sparse.linalg import expm_multiply


PROTOCOLS = {"A_opt": 1.5, "B_opt": 0.75, "C_opt": 0.0, "B_fixed": 0.75, "C_fixed": 0.0}
CHAIN, LOAD = 128, 3
DIM = CHAIN * LOAD
LEVELS = np.arange(LOAD)
LOAD_H = np.diag(LEVELS)
CHAIN_OCCUPATION = np.array([basis.bit_count() for basis in range(CHAIN)])
OCCUPATION = (CHAIN_OCCUPATION[:, None] + LEVELS).ravel()
SECTORS = [np.flatnonzero(OCCUPATION == number) for number in range(10)]
BLOCKS = [np.ix_(indices, indices) for indices in SECTORS]
HEADER = struct.Struct("<8sQd")
SIZE = HEADER.size + DIM * DIM * 16
ANCHOR_NAME = "R4_observed_max_t1590_after.bin"
ANCHOR_SHA = "4C9A5EE8172E505592C43A7B522476715D418CAFA0CC677C04B853E72CC6F9ED"
M18_MANIFEST_SHA = "9F0512D6ED2D85C85A240869D5DEF20C1177D891C7D626F2D5BC37EC9436D8EC"
M18_EXTRACTION_SHA = "6A1C45F25B9B6A5408DF90402342C28F27920B8F7B184B23B086DE0DE8ED043C"
ANCHOR_TIME = 15.90
G = 0.25
WAIT = 2.0
HISTORY = 3.3852501212992755e-3 + 8.5126339753378424e-5
TOL = 1e-12
HALF_TOL = 1e-10
SWITCH_TOL = 1e-18
DIRECT_SWITCH_TOL = 1e-15


def require(condition, context):
    if not condition:
        raise ValueError(context)


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def max_abs(matrix):
    return float(np.max(np.abs(matrix)))


def hermitian(matrix):
    return (matrix + matrix.conj().T) * 0.5


def spectrum(matrix):
    return np.linalg.eigvalsh(hermitian(matrix))


def entropy(populations):
    positive = populations[populations > 0]
    normalized = positive / positive.sum()
    return float(-normalized @ np.log(normalized))


def expectation(matrix, operator):
    return float(np.sum(matrix * operator.T).real)


def marginals(matrix):
    state = matrix.reshape(CHAIN, LOAD, CHAIN, LOAD)
    terminal = matrix.reshape(CHAIN // 2, 2 * LOAD, CHAIN // 2, 2 * LOAD)
    return (np.trace(state, axis1=0, axis2=2), np.trace(state, axis1=1, axis2=3),
            np.trace(terminal, axis1=0, axis2=2))


def passivating_unitary(load):
    populations, vectors = np.linalg.eigh(hermitian(load))
    vectors = vectors[:, ::-1]
    magnitudes = np.abs(vectors)
    for vector, norms in zip(vectors.T, magnitudes.T):
        pivot = np.flatnonzero(norms == norms.max())[-1]
        vector *= vector[pivot].conj() / norms[pivot]
    return populations[::-1], vectors.conj().T


def apply_to_load(matrix, unitary):
    blocks = matrix.reshape(matrix.shape[0] // LOAD, LOAD, matrix.shape[1] // LOAD, LOAD)
    return np.einsum("ai,xiyj,bj->xayb", unitary, blocks, unitary.conj(), optimize=True).reshape(matrix.shape)


@dataclass
class State:
    matrix: np.ndarray
    time: float
    sha256: str = ""

    @cached_property
    def eigenvalues(self):
        return spectrum(self.matrix)

    @classmethod
    def from_file(cls, path, expected_time):
        data = path.read_bytes()
        require(len(data) == SIZE, f"Unexpected byte count in {path}")
        magic, dimension, clock = HEADER.unpack_from(data)
        require((magic, dimension) == (b"QWNRHO1\0", DIM), f"Unexpected header in {path}")
        require(abs(clock - expected_time) <= TOL, f"Unexpected time in {path}")
        matrix = np.frombuffer(data, dtype="<c16", offset=HEADER.size).reshape(DIM, DIM)
        require(np.isfinite(matrix).all(), f"Non-finite density matrix in {path}")
        return cls(matrix, clock, hashlib.sha256(data).hexdigest().upper())


class Audit:
    def __init__(self):
        self.rows = []
        self.manifest = []

    def check(self, protocol, cycle, phase, name, value, bound=TOL):
        value = abs(float(value))
        self.rows.append({
            "protocol": protocol, "cycle": cycle, "phase": phase, "check": name,
            "observed": value, "bound": bound,
            "status": "PASS" if math.isfinite(value) and value <= bound else "FAIL",
        })

    def compare(self, protocol, cycle, phase, observed, expected, bound=TOL):
        for name, value in expected.items():
            self.check(protocol, cycle, phase, name, float(observed[name]) - value, bound)

    def physical(self, protocol, cycle, phase, state):
        trace = np.trace(state.matrix)
        self.check(protocol, cycle, phase, "trace_error", abs(trace - 1))
        self.check(protocol, cycle, phase, "hermiticity_error", max_abs(state.matrix - state.matrix.conj().T))
        self.check(protocol, cycle, phase, "negative_eigenvalue", min(0.0, state.eigenvalues[0]))
        self.check(protocol, cycle, phase, "spectrum_trace_error", abs(state.eigenvalues.sum() - trace.real), HALF_TOL)


class Model:
    def __init__(self):
        self.chain = np.diag(CHAIN_OCCUPATION.astype(float))
        for basis in range(CHAIN):
            for bond in range(6):
                if ((basis >> bond) ^ (basis >> (bond + 1))) & 1:
                    self.chain[basis ^ (3 << bond), basis] = 1.0
        raising = np.array([[0, 0], [1, 0]])
        lowering = np.diag(np.sqrt(LEVELS[1:]), k=1)
        exchange = np.kron(raising, lowering)
        self.exchange = exchange + exchange.T
        terminal_load = np.kron(np.eye(2), LOAD_H)
        self.current = 1j * (self.exchange @ terminal_load - terminal_load @ self.exchange)
        self.bare = np.kron(self.chain, np.eye(LOAD)) + np.kron(np.eye(CHAIN), LOAD_H)
        self.coupling = np.kron(np.eye(CHAIN // 2), self.exchange)
        self.chain_levels = np.linalg.eigvalsh(self.chain)
        self.h = {g: self.bare + g * self.coupling for g in (0, G)}
        self.eigensystems = {g: np.linalg.eigh(hamiltonian) for g, hamiltonian in self.h.items()}
        self.sector_levels = {g: [np.linalg.eigvalsh(hamiltonian[block]) for block in BLOCKS]
                              for g, hamiltonian in self.h.items()}
        chains = np.arange(DIM) // LOAD
        hamming = CHAIN_OCCUPATION[np.bitwise_xor(chains[:, None], chains[None, :])]
        self.hamming = hamming.ravel()

    def local_scalars(self, matrix, g):
        _, _, terminal = marginals(matrix)
        return self.terminal_scalars(terminal, g)

    def terminal_scalars(self, terminal, g):
        load = terminal[:LOAD, :LOAD] + terminal[LOAD:, LOAD:]
        values, unitary = passivating_unitary(load)
        energy = expectation(load, LOAD_H)
        load_passive = float(LEVELS @ values)
        terminal_unitary = np.kron(np.eye(2), unitary)
        transformed = terminal_unitary @ terminal @ terminal_unitary.conj().T
        exchange_jump = g * expectation(transformed - terminal, self.exchange)
        return {
            "load_energy": energy, "load_ergotropy": energy - load_passive,
            "load_passive_energy": load_passive, "load_purity": float(np.vdot(load, load).real),
            "load_current": g * expectation(terminal, self.current),
            "gross_work": energy - load_passive, "interaction_jump": exchange_jump,
            "total_work": energy - load_passive - exchange_jump,
        }

    def energy(self, state, g):
        return expectation(state.matrix, self.h[g])

    def exchange_expectation(self, state):
        return expectation(state.matrix, self.coupling)

    def scalars(self, state, g):
        load, chain, terminal = marginals(state.matrix)
        load_spec, chain_spec = spectrum(load), spectrum(chain)
        chain_energy = expectation(chain, self.chain)
        load_energy = expectation(load, LOAD_H)
        load_passive = float(LEVELS @ load_spec[::-1])
        energy = self.energy(state, g)
        passive = float(self.eigensystems[g][0] @ state.eigenvalues[::-1])
        sector_passive = sum(float(levels @ spectrum(state.matrix[block])[::-1])
                             for block, levels in zip(BLOCKS, self.sector_levels[g]))
        probabilities = np.bincount(OCCUPATION, weights=np.diag(state.matrix).real, minlength=10)
        exchange = self.exchange_expectation(state)
        terminal_cross_norm = np.linalg.svd(terminal[:LOAD, LOAD:], compute_uv=False).sum()
        local_work_upper = max(0.0, load_energy - load_passive) + g * (
            exchange + 2 * np.sqrt(LOAD - 1) * terminal_cross_norm)
        return {
            "load_energy": load_energy, "load_ergotropy": load_energy - load_passive,
            "load_purity": float(np.vdot(load, load).real), "load_passive_energy": load_passive,
            "chain_energy": chain_energy,
            "chain_ergotropy": chain_energy - float(self.chain_levels @ chain_spec[::-1]),
            "global_energy": energy, "global_ergotropy": energy - passive,
            "global_passive_energy": passive, "global_purity": float(np.vdot(state.matrix, state.matrix).real),
            "sector_passive_energy": sector_passive, "sector_ergotropy": energy - sector_passive,
            "load_current": g * expectation(terminal, self.current),
            "terminal_exchange_expectation": exchange, "any_local_unitary_full_work_upper_bound": local_work_upper,
            "total_excitation": float(np.arange(10) @ probabilities),
            "mutual_information": entropy(load_spec) + entropy(chain_spec) - entropy(state.eigenvalues),
            "trace_error": abs(np.trace(state.matrix) - 1),
            "hermiticity_error": max_abs(state.matrix - state.matrix.conj().T),
            "minimum_eigenvalue": state.eigenvalues[0],
            **{f"sector_probability_{index}": float(value) for index, value in enumerate(probabilities)},
        }

    @lru_cache(maxsize=4)
    def liouville(self, g, gamma):
        identity = eye(DIM, format="csr")
        hamiltonian = csr_matrix(self.h[g])
        commutator = -1j * (kron(hamiltonian, identity, format="csr") -
                            kron(identity, hamiltonian.T, format="csr"))
        damping = (-gamma / 7.0) * self.hamming
        generator = commutator + diags(damping, format="csr")
        return generator, float(damping.sum())

    def evolve(self, state, g, gamma, elapsed):
        if elapsed == 0:
            return state
        if gamma == 0:
            energies, vectors = self.eigensystems[g]
            phases = np.exp(-1j * energies * elapsed)
            unitary = (vectors * phases) @ vectors.T
            matrix = unitary @ state.matrix @ unitary.conj().T
        else:
            generator, trace = self.liouville(g, gamma)
            vector = expm_multiply(generator * elapsed, state.matrix.ravel(), traceA=trace * elapsed)
            matrix = vector.reshape(DIM, DIM)
        return State(matrix, state.time + elapsed)

    @cached_property
    def terminal_spectral_observables(self):
        vectors = np.zeros((DIM, DIM))
        energies = np.zeros(DIM)
        # Resolve the connected Hamiltonian separately in each number sector.
        # This keeps each terminal matrix element in a single sector-pair class.
        for indices, block in zip(SECTORS, BLOCKS):
            energies[indices], vectors[block] = np.linalg.eigh(self.h[G][block])
        local_dim = 2 * LOAD
        local_occupations = OCCUPATION[:local_dim]
        upper = list(zip(*np.triu_indices(local_dim)))
        delta = OCCUPATION[:, None] - OCCUPATION[None, :]
        groups = []
        for difference in sorted({local_occupations[a] - local_occupations[b] for a, b in upper}):
            pairs = [(a, b) for a, b in upper if local_occupations[a] - local_occupations[b] == difference]
            indices = np.where(delta == difference)
            overlaps = np.array([(vectors[a::local_dim].T @ vectors[b::local_dim])[indices] for a, b in pairs])
            groups.append((pairs, indices, overlaps))
        return energies, vectors, groups

    def exact_terminal_grid(self, state, times):
        energies, vectors, groups = self.terminal_spectral_observables
        local_dim = 2 * LOAD
        spectral_density = vectors.T @ state.matrix @ vectors
        phase = np.exp(-1j * times[:, None] * energies)
        local = np.empty((len(times), local_dim, local_dim), dtype=complex)
        for pairs, indices, overlaps in groups:
            left, right = indices
            coefficients = (overlaps * spectral_density[indices]).T
            for start in range(0, len(times), 64):
                batch = slice(start, start + 64)
                waves = phase[batch, left] * phase[batch, right].conj()
                values = waves @ coefficients
                for column, (a, b) in enumerate(pairs):
                    local[batch, a, b] = values[:, column]
                    local[batch, b, a] = values[:, column].conj()
        return local


def verify_anchor(m18, audit, model):
    path = m18 / "m18_state_manifest.csv"
    require(hashlib.sha256(path.read_bytes()).hexdigest().upper() == M18_MANIFEST_SHA,
            "Official M18 state manifest SHA-256 differs")
    row, = (row for row in read_csv(path) if row["filename"] == f"states/{ANCHOR_NAME}")
    require((row["condition"], row["branch"], row["extraction_phase"], float(row["time"]), float(row["g"]),
             int(row["dimension"]), int(row["size_bytes"]), row["format_version"]) ==
            ("R4", "observed_max", "after", ANCHOR_TIME, G, DIM, SIZE, "QWNRHO1/1"),
            "Official M18 source metadata differs")
    path = m18 / ANCHOR_NAME
    state = State.from_file(path if path.is_file() else m18 / "states" / ANCHOR_NAME, ANCHOR_TIME)
    require(state.sha256 == row["sha256"].upper() == ANCHOR_SHA, "Official M18 source SHA-256 differs")
    extraction = m18 / "m18_second_extraction_ledger.csv"
    require(hashlib.sha256(extraction.read_bytes()).hexdigest().upper() == M18_EXTRACTION_SHA,
            "Official M18 extraction ledger SHA-256 differs")
    row, = (row for row in read_csv(extraction) if row["after_state"] == f"states/{ANCHOR_NAME}")
    require((row["condition"], row["branch"], float(row["time"]), float(row["g"])) ==
            ("R4", "observed_max", ANCHOR_TIME, G), "Official M18 extraction ledger metadata differs")
    audit.check("all", 2, "anchor", "official_manifest_state_and_extraction_ledger_sha256_mismatch", 0, 0)
    audit.physical("all", 2, "anchor", state)
    local = model.local_scalars(state.matrix, G)
    audit.check("all", 2, "anchor", "load_initial_passivity", local["load_ergotropy"])
    audit.compare("all", 2, "anchor", row, {
        "load_energy_after": local["load_energy"], "total_energy_after": model.energy(state, G),
    })
    audit.check("all", 2, "anchor", "pre_m21_net_work",
                float(row["first_total_work"]) + float(row["second_net_work"]) - HISTORY)
    return state


def path_for(root, name):
    relative = PurePosixPath(name)
    require(not relative.is_absolute() and ".." not in relative.parts and "\\" not in name,
            f"Unexpected state file path {name}")
    require(relative.parts[0] in ("states", "m18_inputs"), f"State is outside states/ and m18_inputs/: {name}")
    return root / relative


def keyed(rows, columns, context):
    result = {tuple(row[column] for column in columns): row for row in rows}
    require(len(rows) == len(result), f"Repeated keys in {context}")
    return result


def snapshots(results, name, audit, model, published=None):
    rows = keyed(read_csv(results / name), ("protocol", "cycle", "phase"), name)
    cache = {}
    output = {}
    kind = "coarse" if published is not None else "half"
    for key, row in rows.items():
        protocol, cycle, phase = key
        filename = row["filename"]
        time, g = float(row["time"]), float(row["g"])
        require(g in (0, G), f"Unexpected coupling in {name}: {key}")
        require(protocol in PROTOCOLS and float(row["gamma"]) == PROTOCOLS[protocol],
                f"Unexpected protocol or gamma in {name}: {key}")
        if filename not in cache:
            cache[filename] = State.from_file(path_for(results, filename), time)
        state = cache[filename]
        require(abs(time - state.time) <= TOL, f"Inconsistent time for {filename}")
        columns = model.scalars(state, g) if published is not None else {}
        audit.physical(protocol, cycle, f"{kind}/{phase}", state)
        if published is not None:
            audit.compare(protocol, cycle, phase, row, {k: v for k, v in columns.items() if k in row})
            table = published.pop(key)
            require((table["filename"], float(table["time"]), float(table["g"])) == (filename, time, g),
                    f"Published observables change state link for {key}")
            audit.compare(protocol, cycle, phase, table, columns)
            sector_probabilities = [columns[f"sector_probability_{n}"] for n in range(10)]
            audit.check(protocol, cycle, phase, "sector_probabilities_sum", sum(sector_probabilities) - 1)
            audit.check(protocol, cycle, phase, "negative_sector_probability", min(0.0, min(sector_probabilities)))
            audit.check(protocol, cycle, phase, "sector_ergotropy_outside_global_bound",
                        max(0.0, -columns["sector_ergotropy"],
                            columns["sector_ergotropy"] - columns["global_ergotropy"]))
        audit.manifest.append({
            "protocol": protocol, "cycle": cycle, "phase": phase, "resolution": kind,
            "time": row["time"], "g": row["g"], "filename": filename, "sha256": state.sha256,
            "source_initial_state_sha256": ANCHOR_SHA, "size_bytes": SIZE, "dimension": DIM,
            "format_version": "QWNRHO1/1", "tensor_order": "|q1,...,q7,load>; load fastest",
            "layout": "row-major little-endian complex f64",
        })
        output[key] = state, g, filename, columns
    require(not published, "Observable rows without a coarse state")
    return output


def ticks(value):
    clock = float(value)
    snapped = round(clock * 100)
    require(abs(clock - snapped / 100) <= TOL, f"Clock outside 0.01 precision: {value}")
    return snapped


def load_grid(path):
    grids = {}
    for row in read_csv(path):
        key = row["protocol"], row["cycle"]
        elapsed = ticks(row["elapsed"])
        grid = grids.setdefault(key, {})
        require(elapsed not in grid, f"Duplicate times in {path.name}: {key}/{elapsed}")
        grid[elapsed] = row
    return grids


def ranked(grid, field):
    require(all(math.isfinite(float(row[field])) for row in grid.values()), f"Non-finite grid field {field}")
    return min(grid, key=lambda point: (-float(grid[point][field]), point))


def verify_grid(audit, key, row, main, half, window, elapsed_a):
    protocol, cycle = key
    expected = set(range(0, window + 1, 2))
    require(main.keys() == half.keys() == expected, f"Candidate or half-step time grid differs for {key}")
    start = ticks(row["start_time"]) + ticks(WAIT)
    require(all(ticks(entry["time"]) == start + point and float(entry["wait"]) == WAIT and
                float(entry["g"]) == G and float(entry["gamma"]) == PROTOCOLS[protocol]
                for point, entry in main.items()), f"Candidate time, gamma or coupling differs for {key}")
    require(all(ticks(entry["time"]) == start + point and float(entry["gamma"]) == PROTOCOLS[protocol]
                for point, entry in half.items()), f"Half-step times or gamma differ for {key}")
    selected = ticks(row["elapsed"])
    main_peak, half_peak = ranked(main, "net_work"), ranked(half, "net_half")
    required = elapsed_a if protocol.endswith("_fixed") else main_peak
    require(selected == required, f"Unexpected selection for {key}: {selected} vs {required}")
    for field, half_field in (("net_work", "net_half"), ("load_ergotropy", "load_ergotropy_half")):
        audit.check(*key, "half_step", f"{field}_nominal_column",
                    max(abs(float(main[point][field]) - float(half[point][field])) for point in expected))
        audit.check(*key, "half_step", f"{field}_half_grid_error",
                    max(abs(float(main[point][field]) - float(half[point][half_field])) for point in expected), HALF_TOL)
    for field in ("load_energy_difference", "dissipative_energy_difference", "integrated_current_difference",
                  "global_energy_difference"):
        audit.check(*key, "half_step", f"{field}_grid_max", max(abs(float(row[field])) for row in half.values()), HALF_TOL)
    start_energy, start_load = (float(main[0][name]) for name in ("global_energy", "load_energy"))
    audit.check(*key, "connected_grid", "energy_bath_balance_max",
                max(abs(float(entry["global_energy"]) - start_energy - float(entry["dissipative_energy"]))
                    for entry in main.values()))
    audit.check(*key, "connected_grid", "load_integrated_current_balance_max",
                max(abs(float(entry["load_energy"]) - start_load - float(entry["integrated_load_current"]))
                    for entry in main.values()))
    candidate = main[selected]
    selected_half = float(half[selected]["net_half"])
    margin = float(candidate["net_work"]) - abs(float(candidate["net_work"]) - selected_half)
    audit.compare(*key, "half_step", row, {
        "net_half": selected_half, "half_peak_net": float(half[half_peak]["net_half"]),
        "half_peak_elapsed": half_peak / 100, "resolution_margin": margin,
    })
    audit.compare(*key, "connected_grid", row,
                  {"own_peak_elapsed": main_peak / 100, "own_peak_net": float(main[main_peak]["net_work"])})
    return candidate, margin, half[selected]


def verify_dynamics(audit, model, key, phase, start, end, g, gamma, replay):
    start_sectors = np.bincount(OCCUPATION, weights=np.diag(start.matrix).real, minlength=10)
    end_sectors = np.bincount(OCCUPATION, weights=np.diag(end.matrix).real, minlength=10)
    audit.check(*key, phase, "sector_probability_drift", max_abs(end_sectors - start_sectors))
    audit.check(*key, phase, "total_excitation_drift", abs((end_sectors - start_sectors) @ np.arange(10)))
    elapsed = end.time - start.time
    if g == 0:
        phase_factors = np.exp(-1j * LEVELS * elapsed)
        load_start, _, _ = marginals(start.matrix)
        load_end, _, _ = marginals(end.matrix)
        expected = phase_factors[:, None] * load_start * phase_factors[None, :].conj()
        audit.check(*key, phase, "disconnected_load_exact_phase", max_abs(load_end - expected))
    if gamma == 0:
        first = model.scalars(start, g)
        last = model.scalars(end, g)
        for name in ("global_energy", "global_ergotropy", "global_purity", "sector_ergotropy"):
            audit.check(*key, phase, f"gamma0_{name}_drift", last[name] - first[name])
        audit.check(*key, phase, "gamma0_spectrum_max_drift", max_abs(end.eigenvalues - start.eigenvalues))
    if gamma == 0 or replay:
        expected = model.evolve(start, g, gamma, elapsed)
        audit.check(*key, phase, "independent_propagation_density", max_abs(end.matrix - expected.matrix), HALF_TOL)
        audit.check(*key, phase, "independent_propagation_energy",
                    model.energy(end, g) - model.energy(expected, g), HALF_TOL)


def verify_extraction(audit, model, key, before, after):
    load, chain, _ = marginals(before.matrix)
    values, unitary = passivating_unitary(load)
    transformed = apply_to_load(before.matrix, unitary)
    if after is None:
        after = State(transformed, before.time)
    audit.check(*key, "extraction", "local_unitary_full_mapping", max_abs(transformed - after.matrix))
    audit.check(*key, "extraction", "full_spectrum_drift", max_abs(before.eigenvalues - after.eigenvalues))
    load_after, chain_after, _ = marginals(after.matrix)
    audit.check(*key, "extraction", "passive_load_mapping", max_abs(load_after - np.diag(values)))
    audit.check(*key, "extraction", "chain_state_drift", max_abs(chain_after - chain))
    gross = expectation(load - load_after, LOAD_H)
    jump = G * (model.exchange_expectation(after) - model.exchange_expectation(before))
    work = model.energy(before, G) - model.energy(after, G)
    audit.check(*key, "extraction", "full_work_identity", work - gross + jump)
    return gross, jump, work, after


def verify_switch(audit, model, key, phase, state, before_g, after_g, recorded):
    work = (after_g - before_g) * model.exchange_expectation(state)
    direct = model.energy(state, after_g) - model.energy(state, before_g)
    audit.check(*key, phase, "switch_work_linear", float(recorded) - work, SWITCH_TOL)
    audit.check(*key, phase, "switch_work_direct", direct - work, DIRECT_SWITCH_TOL)
    return work


def verify_candidate_state(audit, model, key, label, entry, state, cut, reconnect, bath):
    computed = model.local_scalars(state.matrix, G)
    computed["net_work"] = computed["total_work"] - cut - reconnect
    computed["dissipative_energy"] = bath
    computed["global_energy"] = model.energy(state, G)
    audit.compare(*key, label, entry, {name: value for name, value in computed.items() if name in entry})


def verify_unitary_grid(audit, model, key, grid, reconnect_state, cut, reconnect):
    points = sorted(grid)
    local = model.exact_terminal_grid(reconnect_state, np.array(points) / 100)
    errors = {}
    predicted_net = {}
    for point, terminal in zip(points, local):
        expected = model.terminal_scalars(terminal, G)
        expected["net_work"] = expected["total_work"] - cut - reconnect
        predicted_net[point] = expected["net_work"]
        for name, value in expected.items():
            if name in grid[point]:
                errors.setdefault(name, []).append(abs(float(grid[point][name]) - value))
    for name, differences in errors.items():
        audit.check(*key, "gamma0_exact_grid", f"{name}_max_error", max(differences), HALF_TOL)
    recorded_peak = ranked(grid, "net_work")
    exact_peak = max(predicted_net.values())
    audit.check(*key, "gamma0_exact_grid", "reported_peak_work_below_exact_optimum",
                exact_peak - predicted_net[recorded_peak], 2 * max(errors["net_work"]) + TOL)


def verify_protocol(audit, model, protocol, rounds, main, half, coarse, fine, anchor, times_a, args):
    gamma = PROTOCOLS[protocol]
    previous, previous_half = anchor, anchor
    cumulative, cumulative_bath = 0.0, 0.0
    selected = {}
    used_coarse, used_fine = set(), set()

    def retrieve(key, phase, states, used, expected_time, g):
        full_key = (*key, phase)
        state, coupling, filename, _ = states[full_key]
        require(coupling == g and abs(state.time - expected_time) <= TOL,
                f"Incorrect time or Hamiltonian for {full_key}")
        used.add(full_key)
        return state, filename

    max_cycle = args.last_cycle
    if protocol.endswith("_fixed"):
        max_cycle = min(max_cycle, max(times_a, default=2))
    stopped = False
    for cycle_int in range(3, max_cycle + 1):
        cycle = str(cycle_int)
        key = protocol, cycle
        if stopped:
            break
        row = rounds[key]
        require(float(row["gamma"]) == gamma and float(row["wait"]) == WAIT and float(row["g"]) == G,
                f"Unexpected gamma, wait or coupling for {key}")
        candidate, margin, candidate_half = verify_grid(
            audit, key, row, main[key], half[key], args.window_ticks, times_a.get(cycle_int))
        start, time = float(row["start_time"]), float(row["time"])
        elapsed = ticks(row["elapsed"])
        wait_end_time = start + WAIT
        end_time = wait_end_time + args.window_ticks / 100
        audit.check(*key, "sequence", "cycle_starts_from_previous_extraction", start - previous.time)
        audit.check(*key, "sequence", "time_includes_fixed_wait_and_elapsed", time - wait_end_time - elapsed / 100)

        def load_coarse(phase, time, g):
            return retrieve(key, phase, coarse, used_coarse, time, g)

        def load_fine(phase, time, g):
            return retrieve(key, phase, fine, used_fine, time, g)

        wait_start, _ = load_coarse("wait_start", start, G)
        cut_state, _ = load_coarse("cut_after", start, 0)
        wait_end, _ = load_coarse("wait_end", wait_end_time, 0)
        reconnect_state, _ = load_coarse("reconnect_after", wait_end_time, G)
        before, before_name = load_coarse("before", time, G)
        window_end, _ = load_coarse("window_end", end_time, G)
        wait_half, _ = load_fine("wait_end", wait_end_time, 0)
        before_half, _ = load_fine("before", time, G)
        window_half, _ = load_fine("window_end", end_time, G)
        require(before_name == row["before_state"], f"Ledger state link differs for {key}")
        audit.check(*key, "sequence", "previous_state_carried_exactly", max_abs(wait_start.matrix - previous.matrix), 0)
        audit.check(*key, "cut", "instantaneous_state_continuity", max_abs(wait_start.matrix - cut_state.matrix), 0)
        audit.check(*key, "reconnect", "instantaneous_state_continuity", max_abs(wait_end.matrix - reconnect_state.matrix), 0)

        cut = verify_switch(audit, model, key, "cut", cut_state, G, 0, row["cut_on"])
        reconnect = verify_switch(audit, model, key, "reconnect", reconnect_state, 0, G, row["reconnect_on"])
        cut_half = verify_switch(audit, model, key, "cut_half", previous_half, G, 0, row["cut_half"])
        reconnect_half = verify_switch(audit, model, key, "reconnect_half", wait_half, 0, G, row["reconnect_half"])
        independent_dissipative = cycle_int == 3 and protocol in ("A_opt", "B_opt")
        verify_dynamics(audit, model, key, "wait", cut_state, wait_end, 0, gamma, independent_dissipative)
        verify_dynamics(audit, model, key, "connected_selected", reconnect_state, before, G, gamma, independent_dissipative)
        verify_dynamics(audit, model, key, "connected_full_window", reconnect_state, window_end, G, gamma, False)
        verify_dynamics(audit, model, key, "wait_half", previous_half, wait_half, 0, gamma, False)
        verify_dynamics(audit, model, key, "connected_selected_half", wait_half, before_half, G, gamma, False)
        verify_dynamics(audit, model, key, "connected_full_window_half", wait_half, window_half, G, gamma, False)
        if gamma == 0:
            verify_unitary_grid(audit, model, key, main[key], reconnect_state, cut, reconnect)

        for phase, state, state_half in (("wait_end", wait_end, wait_half), ("before", before, before_half),
                                         ("window_end", window_end, window_half)):
            difference = max_abs(state.matrix - state_half.matrix)
            audit.check(*key, "half_step", f"{phase}_density_max_error", difference, HALF_TOL)
            if phase == "before" and candidate_half.get("state_max_abs_difference"):
                audit.check(*key, "half_step", "reported_selected_density_max_error",
                            difference - float(candidate_half["state_max_abs_difference"]))
            elif phase in ("wait_end", "window_end"):
                prefix = "wait" if phase == "wait_end" else "window_end"
                audit.check(*key, "half_step", f"reported_{prefix}_density_max_error",
                            difference - float(row[f"{prefix}_state_max_abs_difference"]))
            x = model.scalars(state, 0 if phase == "wait_end" else G)
            y = model.scalars(state_half, 0 if phase == "wait_end" else G)
            for name in ("load_energy", "load_ergotropy", "global_energy", "global_ergotropy", "sector_ergotropy",
                         "global_purity", "load_purity", "load_current", "mutual_information"):
                audit.check(*key, "half_step", f"{phase}_{name}_error", x[name] - y[name], HALF_TOL)

        bath_wait = model.energy(wait_end, 0) - model.energy(cut_state, 0)
        bath_connected = model.energy(before, G) - model.energy(reconnect_state, G)
        bath_wait_half = model.energy(wait_half, 0) - model.energy(previous_half, 0)
        bath_connected_half = model.energy(before_half, G) - model.energy(wait_half, G)
        verify_candidate_state(audit, model, key, "chosen_grid_row", candidate,
                               before, cut, reconnect, bath_connected)
        verify_candidate_state(audit, model, key, "last_grid_row", main[key][args.window_ticks], window_end, cut,
                               reconnect, model.energy(window_end, G) - model.energy(reconnect_state, G))
        accepted = row["accepted"] in ("true", "YES")
        require(row["accepted"] in ("true", "false", "YES", "NO"), f"Invalid acceptance field for {key}")

        after = after_half = None
        if accepted:
            after, after_name = load_coarse("after", time, G)
            after_half, _ = load_fine("after", time, G)
            require(row["after_state"] == after_name, f"Post-extraction link differs for {key}")
        else:
            require(not row["after_state"], f"Unaccepted trial has post-extraction link for {key}")
        gross, jump, work, transformed = verify_extraction(audit, model, key, before, after)
        _, _, work_half, _ = verify_extraction(audit, model, key, before_half, after_half)
        initial = model.energy(previous, G)
        final = model.energy(transformed, G)
        net = work - cut - reconnect
        net_half = work_half - cut_half - reconnect_half
        local_bound = coarse[(*key, "before")][3]["any_local_unitary_full_work_upper_bound"]
        audit.check(*key, "extraction", "local_work_exceeds_theoretical_upper_bound", max(0.0, work - local_bound))
        require(accepted == (margin > TOL and net > TOL), f"Direct-energy acceptance criterion differs for {key}")
        predicted_final = (initial + cut + reconnect + float(row["dissipative_wait"]) +
                           float(row["dissipative_connected"]) - work)
        audit.check(*key, "sequence", "energy_balance", final - predicted_final)
        if gamma == 0:
            for field in ("dissipative_wait", "dissipative_connected", "dissipative_wait_half", "dissipative_connected_half"):
                audit.check(*key, "sequence", f"gamma0_{field}", float(row[field]), 0)
            audit.check(*key, "connected_grid", "gamma0_dissipative_energy_max",
                        max(abs(float(entry["dissipative_energy"])) for entry in main[key].values()), 0)
        if accepted:
            cumulative += net
            cumulative_bath += float(row["dissipative_wait"]) + float(row["dissipative_connected"])
            previous, previous_half = after, after_half
            selected[cycle_int] = elapsed
            cumulative_balance = final - model.energy(anchor, G) - cumulative_bath + cumulative
            audit.check(*key, "sequence", "cumulative_energy_balance", cumulative_balance)
            audit.compare(*key, "sequence", row, {"cumulative_balance_residual": cumulative_balance})
            difference = max_abs(after.matrix - after_half.matrix)
            audit.check(*key, "half_step", "post_extraction_density_max_error", difference, HALF_TOL)
            audit.check(*key, "half_step", "reported_post_extraction_density_max_error",
                        difference - float(row["after_state_max_abs_difference"]))
            if gamma == 0:
                start_metrics = coarse[(*key, "wait_start")][3]
                before_metrics = coarse[(*key, "before")][3]
                after_metrics = coarse[(*key, "after")][3]
                global_change = after_metrics["global_ergotropy"] - model.scalars(anchor, G)["global_ergotropy"]
                audit.check(*key, "sequence", "gamma0_cumulative_global_ergotropy_work_identity",
                            global_change + cumulative)
                cycle_sector_passive_change = after_metrics["sector_passive_energy"] - start_metrics["sector_passive_energy"]
                extraction_sector_passive_change = after_metrics["sector_passive_energy"] - before_metrics["sector_passive_energy"]
                audit.check(*key, "sequence", "gamma0_cycle_sector_passive_change_matches_extraction",
                            cycle_sector_passive_change - extraction_sector_passive_change)
        else:
            stopped = True
        audit.compare(*key, "sequence", row, {
            "start_total_energy": initial, "pre_total_energy": model.energy(before, G), "post_total_energy": final,
            "gross_work": gross, "interaction_jump": jump, "total_work": work, "net_work": net,
            "dissipative_wait": bath_wait, "dissipative_connected": bath_connected,
            "dissipative_wait_half": bath_wait_half, "dissipative_connected_half": bath_connected_half,
            "cumulative_m21_net": cumulative, "net_plus_history": cumulative + HISTORY,
            "balance_residual": final - predicted_final, "net_half_direct": net_half,
            "cycle_rate": net / (time - start), "cumulative_rate": cumulative / (time - ANCHOR_TIME),
            "attempted_elapsed_since_anchor": time - ANCHOR_TIME,
            "accepted_elapsed_since_anchor": previous.time - ANCHOR_TIME,
            "selected_load_current": model.local_scalars(before.matrix, G)["load_current"],
            "selected_integrated_load_current": (model.local_scalars(before.matrix, G)["load_energy"] -
                                                 model.local_scalars(reconnect_state.matrix, G)["load_energy"]),
        })
    allowed_keys = {state_key[:2] for state_key in used_coarse}
    for table in (rounds, main, half):
        require({row_key for row_key in table if row_key[0] == protocol} == allowed_keys,
                f"Ledger/candidate coverage differs for {protocol}")
    require({state_key for state_key in coarse if state_key[0] == protocol and state_key[2] != "anchor"} == used_coarse,
            f"Coarse snapshot coverage differs for {protocol}")
    require({state_key for state_key in fine if state_key[0] == protocol and state_key[2] != "anchor"} == used_fine,
            f"Fine snapshot coverage differs for {protocol}")
    return selected


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path)
    parser.add_argument("--m18", type=Path, help="Optional separate M18 input directory")
    parser.add_argument("--window", default="16.00", help="Search window, including shortened benchmark")
    parser.add_argument("--last-cycle", type=int, default=10)
    parser.add_argument("--read-only", action="store_true")
    args = parser.parse_args()
    args.window_ticks = ticks(args.window)
    require(args.window_ticks % 2 == 0 and 0 <= args.window_ticks <= 1600, "Invalid registered window")
    require(3 <= args.last_cycle <= 10, "Invalid last cycle")
    model, audit = Model(), Audit()
    for g in (0, G):
        commutator = model.h[g] * (OCCUPATION[None, :] - OCCUPATION[:, None])
        audit.check("all", 2, "model", f"hamiltonian_excitation_commutator_g{g}", max_abs(commutator), 0)
    anchor = verify_anchor(args.m18 or args.results / "m18_inputs", audit, model)
    observables = keyed(read_csv(args.results / "m21_state_metrics.csv"), ("protocol", "cycle", "phase"), "state observables")
    coarse = snapshots(args.results, "m21_state_basic.csv", audit, model, observables)
    fine = snapshots(args.results, "m21_state_half.csv", audit, model)
    for key, (state, g, _, _) in coarse.items():
        if key[2] == "anchor":
            require(state.sha256 == ANCHOR_SHA and g == G, f"Incorrect archived anchor for {key}")
    filenames = {row["filename"] for row in audit.manifest if row["filename"].startswith("states/")}
    inventory = {path.relative_to(args.results).as_posix() for path in (args.results / "states").rglob("*.bin")}
    require(inventory == filenames, "State archive and snapshot manifests differ")
    ledger = keyed(read_csv(args.results / "m21_cycle_ledger.csv"), ("protocol", "cycle"), "cycle ledger")
    candidates = load_grid(args.results / "m21_candidates.csv")
    half_grid = load_grid(args.results / "m21_half_step.csv")
    require({protocol for protocol, _ in ledger} <= PROTOCOLS.keys(), "Unknown protocol in cycle ledger")
    times_a = {}
    for protocol in PROTOCOLS:
        selected = verify_protocol(audit, model, protocol, ledger, candidates, half_grid, coarse, fine, anchor, times_a, args)
        if protocol == "A_opt":
            times_a = selected
    failures = [row for row in audit.rows if row["status"] == "FAIL"]
    if not args.read_only:
        write_csv(args.results / "m21_independent_audit.csv", audit.rows)
        write_csv(args.results / "m21_state_manifest.csv", audit.manifest)
    for row in failures[:30]:
        print(row)
    print(f"Independent verification: {len(audit.rows) - len(failures)}/{len(audit.rows)} passed.")
    return bool(failures)


if __name__ == "__main__":
    raise SystemExit(main())
