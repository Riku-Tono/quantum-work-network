"""Draw M21 comparisons from the cycle, candidate, and state-metrics CSVs."""

import argparse
import csv
from collections import defaultdict
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parent
CYCLES = range(3, 11)
WORK_FLOOR = 1e-12
INK = "#152637"
MUTED = "#42586C"
GRID = "#DFE7ED"
AXIS = "#8797A5"
CONDITIONS = {
    "A": ("#225886", "o", "-", r"A  ·  $\gamma=\gamma_0$"),
    "B": ("#007172", "s", "--", r"B  ·  $\gamma=0.5\gamma_0$"),
    "C": ("#A2441A", "D", "-.", r"C  ·  $\gamma=0$"),
}
COMPARISONS = (
    ("Independent timing", ("A_opt", "B_opt", "C_opt")),
    ("Timing fixed to A", ("A_opt", "B_fixed", "C_fixed")),
)
PHASE_ORDER = {
    phase: index
    for index, phase in enumerate(("wait_start", "cut_after", "wait_end", "reconnect_after", "before", "after"))
}


def read_protocol_rows(path):
    groups = defaultdict(list)
    with path.open(encoding="utf-8-sig", newline="") as source:
        for row in csv.DictReader(source):
            groups[row["protocol"]].append(row)
    return groups


def number(row, column):
    return float(row[column])


def cycle(row):
    return int(row["cycle"])


def accepted(row):
    return row["accepted"].lower() == "true"


def draw_line(ax, protocol, x, y, *, markers=True, drawstyle="default"):
    color, marker, linestyle, _ = CONDITIONS[protocol[0]]
    ax.plot(x, y, color=color, linestyle=linestyle, linewidth=1.6, marker=marker if markers else None,
            markersize=4.6, markerfacecolor="white", markeredgewidth=1.15, drawstyle=drawstyle)


def mark_choice(ax, protocol, x, y, is_accepted):
    color, marker, _, _ = CONDITIONS[protocol[0]]
    if is_accepted:
        ax.scatter(x, y, s=30, color=color, marker=marker, facecolors="white", linewidths=1.2, zorder=4)
    else:
        ax.scatter(x, y, s=38, color=color, marker="X", zorder=4)


def style_axis(ax, *, title=None, xlabel=None, ylabel=None):
    ax.set_axisbelow(True)
    ax.yaxis.grid(True, color=GRID, linewidth=0.8, which="major")
    ax.spines[["top", "right"]].set_visible(False)
    for edge in ("bottom", "left"):
        ax.spines[edge].set_color(AXIS)
    ax.tick_params(axis="both", color=AXIS, labelcolor=INK, labelsize=9)
    if ax.get_yscale() == "linear":
        ax.ticklabel_format(axis="y", style="sci", scilimits=(-3, 3), useMathText=True, useOffset=False)
        ax.yaxis.offsetText.set_color(MUTED)
        ax.yaxis.offsetText.set_fontsize(8)
    if title is not None:
        ax.set_title(title, loc="left", fontsize=11, color=INK, pad=8)
    if xlabel is not None:
        ax.set_xlabel(xlabel, fontsize=10, color=INK)
    if ylabel is not None:
        ax.set_ylabel(ylabel, fontsize=10, color=INK)


def label_cycle_axis(ax):
    ax.set_xticks(CYCLES)
    ax.set_xlim(2.75, 10.25)


def zero_line(ax):
    ax.axhline(0.0, color=AXIS, linewidth=0.8, zorder=1)


def add_header(fig, title, subtitle, *, top, bottom, show_declined=False, **spacing):
    from matplotlib.lines import Line2D

    fig.subplots_adjust(left=0.105, right=0.975, top=top, bottom=bottom, **spacing)
    fig.text(0.105, 0.974, title, fontsize=18, color=INK, fontweight="bold", va="top")
    fig.text(0.105, 0.928, subtitle, fontsize=10, color=MUTED, va="top")
    handles = [
        Line2D([], [], color=color, marker=marker, linestyle=linestyle, markerfacecolor="white", label=label)
        for color, marker, linestyle, label in CONDITIONS.values()
    ]
    if show_declined:
        handles.append(Line2D([], [], color=MUTED, marker="X", linestyle="none", label="Declined proposal"))
    fig.legend(handles=handles, loc="upper left", bbox_to_anchor=(0.099, 0.89), frameon=False,
               ncols=len(handles), labelcolor=INK, fontsize=9.8, columnspacing=1.8, handlelength=2.5)


def add_comparison_titles(fig, axes):
    title_offset = 19 / (72 * fig.get_figheight())
    for ax, (title, _) in zip(axes, COMPARISONS):
        bounds = ax.get_position()
        fig.text(bounds.x0, bounds.y1 + title_offset, title, fontsize=11, color=INK, va="bottom")


def save(plt, figure, output, filename):
    figure.savefig(output / filename, dpi=190, facecolor="white")
    plt.close(figure)


def plot_net_work(plt, ledger, output):
    fig, axes = plt.subplots(2, 2, figsize=(11.2, 7.65), sharey="row")
    add_header(fig, "Net work per extraction", "The logarithmic panels show positive values. The dotted line marks the acceptance floor.",
               top=0.785, bottom=0.09, wspace=0.24, hspace=0.36,
               show_declined=any(not accepted(row) for rows in ledger.values() for row in rows))
    for col, (_, protocols) in enumerate(COMPARISONS):
        for index in range(2):
            ax = axes[index, col]
            log = index == 1
            if log:
                ax.set_yscale("log")
                ax.axhline(WORK_FLOOR, color=AXIS, linewidth=0.9, linestyle=":", zorder=1)
            else:
                zero_line(ax)
            for protocol in protocols:
                rows = [row for row in ledger[protocol] if not log or number(row, "net_work") > 0]
                adopted = [row for row in rows if accepted(row)]
                draw_line(ax, protocol, [cycle(row) for row in adopted], [number(row, "net_work") for row in adopted])
                for row in rows:
                    if not accepted(row):
                        mark_choice(ax, protocol, cycle(row), number(row, "net_work"), False)
            style_axis(ax, ylabel=("Net work (log scale)" if log else "Net work (linear scale)") if col == 0 else None,
                       xlabel="Extraction cycle" if log else None)
            label_cycle_axis(ax)
    add_comparison_titles(fig, axes[0])
    save(plt, fig, output, "m21_01_net_work.png")


def plot_work_rates(plt, ledger, output):
    fig, axes = plt.subplots(3, 2, figsize=(11.2, 9.45), sharey="row")
    add_header(fig, "Cumulative work and time efficiency",
               "Time since the common state includes each disconnected wait. Rates use accepted extractions.",
               top=0.785, bottom=0.095, wspace=0.24, hspace=0.60)
    cohort_start = min(number(row, "start_time") for rows in ledger.values() for row in rows)
    cohort_duration = max(number(row, "time") for rows in ledger.values() for row in rows) - cohort_start
    for col, (_, protocols) in enumerate(COMPARISONS):
        cumulative_ax, rate_ax, mean_ax = axes[:, col]
        for protocol in protocols:
            adopted = [row for row in ledger[protocol] if accepted(row)]
            elapsed = [number(row, "time") - cohort_start for row in adopted]
            cumulative = [number(row, "cumulative_m21_net") for row in adopted]
            draw_line(cumulative_ax, protocol, [0.0, *elapsed], [0.0, *cumulative], drawstyle="steps-post")
            cumulative_ax.hlines(cumulative[-1] if cumulative else 0.0, elapsed[-1] if elapsed else 0.0,
                                 cohort_duration, color=CONDITIONS[protocol[0]][0],
                                 linestyle=CONDITIONS[protocol[0]][2], linewidth=1.6)
            indices = [cycle(row) for row in adopted]
            draw_line(rate_ax, protocol, indices, [number(row, "cycle_rate") for row in adopted])
            draw_line(mean_ax, protocol, indices, [number(row, "cumulative_rate") for row in adopted])
        for ax, y_label, x_label in (
            (cumulative_ax, "Cumulative net work", "Model time since common state"),
            (rate_ax, "Net work / cycle time", "Extraction cycle"),
            (mean_ax, "Cumulative net work / elapsed time", "Extraction cycle"),
        ):
            zero_line(ax)
            style_axis(ax, xlabel=x_label, ylabel=y_label if col == 0 else None)
            if ax is not cumulative_ax:
                label_cycle_axis(ax)
        cumulative_ax.set_xlim(-0.02 * cohort_duration, 1.02 * cohort_duration)
    add_comparison_titles(fig, axes[0])
    save(plt, fig, output, "m21_02_cumulative_and_time_efficiency.png")


def plot_state_metrics(plt, states, specifications, output, filename, title, subtitle):
    fig, axes = plt.subplots(len(specifications), 2, figsize=(11.2, 3.0 + 2.4 * len(specifications)),
                             sharex=True, sharey="row")
    add_header(fig, title, subtitle, top=0.785, bottom=0.09, wspace=0.26, hspace=0.52)
    for col, (_, protocols) in enumerate(COMPARISONS):
        for index, (column, ylabel) in enumerate(specifications):
            ax = axes[index, col]
            if column == "sector_ergotropy":
                ax.set_yscale("symlog", linthresh=WORK_FLOOR, linscale=0.5)
            for protocol in protocols:
                trajectory = states.get(protocol, ())
                times = [number(row, "time") for row in trajectory]
                values = [number(row, column) for row in trajectory]
                draw_line(ax, protocol, times, values, markers=False)
                for row, time, value in zip(trajectory, times, values):
                    if row["phase"] == "after":
                        mark_choice(ax, protocol, time, value, True)
            style_axis(ax, ylabel=ylabel if col == 0 else None,
                       xlabel="Model time" if index == len(specifications) - 1 else None)
    add_comparison_titles(fig, axes[0])
    save(plt, fig, output, filename)


def plot_load_recovery(plt, ledger, candidates, output):
    traces = defaultdict(list)
    for protocol, rows in candidates.items():
        for row in rows:
            traces[protocol, cycle(row)].append(row)
    window = max(number(row, "elapsed") for rows in candidates.values() for row in rows)
    for rows in traces.values():
        rows.sort(key=lambda row: number(row, "elapsed"))
    selected = {(protocol, cycle(row)): row for protocol, rows in ledger.items() for row in rows}

    # A given cycle uses the same ordinate range under both timing policies.
    per_cycle_max = defaultdict(float)
    for (_, cycle_index), rows in traces.items():
        per_cycle_max[cycle_index] = max(per_cycle_max[cycle_index], max(number(row, "load_ergotropy") for row in rows))
    for (label, protocols), suffix in zip(COMPARISONS, ("independent", "fixed_to_a")):
        fig, axes = plt.subplots(2, 4, figsize=(14.7, 7.25), sharex=True)
        add_header(fig, f"Load ergotropy after reconnection  ·  {label}",
                   f"Curves show evolution through the {window:g}-unit window before hypothetical extraction. Symbols mark selected times.",
                   top=0.80, bottom=0.12, wspace=0.39, hspace=0.38,
                   show_declined=any(not accepted(row) for protocol in protocols for row in ledger[protocol]))
        for index, (ax, cycle_index) in enumerate(zip(axes.flat, CYCLES)):
            ax.set_yscale("symlog", linthresh=WORK_FLOOR, linscale=0.5)
            ax.set_ylim(-WORK_FLOOR * 0.18, max(per_cycle_max[cycle_index] * 1.6, WORK_FLOOR * 2))
            ax.set_xlim(-0.01875 * window, 1.01875 * window)
            ax.set_xticks(tuple(window * index / 4 for index in range(5)))
            show_plot = False
            for protocol in protocols:
                trace = traces[protocol, cycle_index]
                if not trace:
                    continue
                show_plot = True
                x = [number(row, "elapsed") for row in trace]
                y = [number(row, "load_ergotropy") for row in trace]
                draw_line(ax, protocol, x, y, markers=False)
                choice = selected[protocol, cycle_index]
                time = number(choice, "elapsed")
                at_choice = min(range(len(x)), key=lambda i: abs(x[i] - time))
                if abs(x[at_choice] - time) > 1e-9:
                    raise ValueError(f"Missing candidate at {protocol} cycle {cycle_index} time {time}")
                mark_choice(ax, protocol, time, y[at_choice], accepted(choice))
            if not show_plot:
                ax.text(0.5, 0.5, "No trial", transform=ax.transAxes, ha="center", va="center", color=MUTED)
            zero_line(ax)
            style_axis(ax, title=f"Cycle {cycle_index}", ylabel="Load ergotropy (symlog)" if index % 4 == 0 else None)
        fig.supxlabel("Model time after reconnection", color=INK, fontsize=10, y=0.035)
        save(plt, fig, output, f"m21_load_recovery_{suffix}.png")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=ROOT, help="Directory containing the three M21 CSVs")
    parser.add_argument("--output", type=Path, help="Figure directory, defaulting to figures/ under --data")
    parser.add_argument("--plot-deps", type=Path, help="Directory containing Matplotlib and its dependencies")
    args = parser.parse_args()
    if args.plot_deps:
        sys.path.insert(0, str(args.plot_deps.resolve()))

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    ledger = read_protocol_rows(args.data / "m21_cycle_ledger.csv")
    for rows in ledger.values():
        rows.sort(key=cycle)
    candidates = read_protocol_rows(args.data / "m21_candidates.csv")
    raw_states = read_protocol_rows(args.data / "m21_state_metrics.csv")
    states = {
        protocol: sorted((row for row in rows if row["phase"] in PHASE_ORDER),
                         key=lambda row: (cycle(row), PHASE_ORDER[row["phase"]]))
        for protocol, rows in raw_states.items()
    }
    output = args.output or args.data / "figures"
    output.mkdir(parents=True, exist_ok=True)
    plot_net_work(plt, ledger, output)
    plot_work_rates(plt, ledger, output)
    plot_state_metrics(plt, states, (("global_ergotropy", "Global ergotropy"),
                                    ("sector_ergotropy", "Excitation-preserving ergotropy\n(symlog)")), output,
                       "m21_03_ergotropy.png", "Remaining work in the full system",
                       "Lines join recorded protocol stages. Open symbols mark post-extraction states.")
    plot_state_metrics(plt, states, (("global_passive_energy", "Global passive energy"),
                                    ("load_passive_energy", "Load passive energy"),
                                    ("global_purity", "Global purity"), ("load_purity", "Load purity")), output,
                       "m21_04_passive_energy_and_purity.png", "Passive energy and purity",
                       "Vertical changes in passive energy include Hamiltonian switches. Symbols mark post-extraction states.")
    plot_load_recovery(plt, ledger, candidates, output)


if __name__ == "__main__":
    main()
