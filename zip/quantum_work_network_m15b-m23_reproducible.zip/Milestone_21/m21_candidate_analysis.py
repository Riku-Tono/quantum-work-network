"""Compare M21's virtual candidate trajectories without changing any adopted operations.

The RK4 cumulative current gives signed load inflow. The positive-only and
negative-only integrals use trapezoids of the clipped current on the saved
candidate grid. Local peak prominence uses both sides of the peak, ending at
the first strictly higher point or a window boundary on each side. The
absolute step-halving differences are numerical resolution indicators.
"""

import argparse
from collections import defaultdict
import csv
from dataclasses import dataclass
from pathlib import Path


THRESHOLD = 1e-12
PROTOCOLS = ("A_opt", "B_opt", "C_opt", "B_fixed", "C_fixed")
PEAK_METRICS = ("net_work", "load_ergotropy")


@dataclass(frozen=True)
class Candidate:
    elapsed: float
    time: float
    wait: float
    net_work: float
    load_ergotropy: float
    load_energy: float
    load_current: float
    integrated_load_current: float
    net_error: float
    ergotropy_error: float
    integrated_current_error: float

    @property
    def rate(self):
        return self.net_work / (self.wait + self.elapsed)

    def error(self, metric):
        if metric == "net_work":
            return self.net_error
        return self.ergotropy_error


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows):
    if not rows:
        return
    with path.open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def cycle_key(row):
    return row["protocol"], int(row["cycle"])


def grid_key(row):
    return (*cycle_key(row), float(row["elapsed"]))


def trajectories(data):
    coarse = read_csv(data / "m21_candidates.csv")
    fine = {grid_key(row): row for row in read_csv(data / "m21_half_step.csv")}
    paths = defaultdict(list)
    for row in coarse:
        half = fine[grid_key(row)]
        net_work = float(row["net_work"])
        load_ergotropy = float(row["load_ergotropy"])
        paths[cycle_key(row)].append(Candidate(
            elapsed=float(row["elapsed"]), time=float(row["time"]), wait=float(row["wait"]),
            net_work=net_work, load_ergotropy=load_ergotropy, load_energy=float(row["load_energy"]),
            load_current=float(row["load_current"]), integrated_load_current=float(row["integrated_load_current"]),
            net_error=abs(net_work - float(half["net_half"])),
            ergotropy_error=abs(load_ergotropy - float(half["load_ergotropy_half"])),
            integrated_current_error=abs(float(half["integrated_current_difference"])),
        ))
    for key, path in paths.items():
        path.sort(key=lambda point: point.elapsed)
        if any(abs(point.elapsed - i * 0.02) > THRESHOLD for i, point in enumerate(path)):
            raise ValueError(f"Unexpected candidate grid for {key}")
    return paths


def current_integrals(path):
    signed, positive, negative = 0.0, 0.0, 0.0
    result = [(signed, positive, negative)]
    for before, after in zip(path, path[1:]):
        half_dt = (after.elapsed - before.elapsed) * 0.5
        first, last = before.load_current, after.load_current
        signed += half_dt * (first + last)
        positive += half_dt * (max(0.0, first) + max(0.0, last))
        negative += half_dt * (max(0.0, -first) + max(0.0, -last))
        result.append((signed, positive, negative))
    return result


def rate_comparison(paths, ledger):
    rows = []
    for left, right in (("B_opt", "C_opt"), ("A_opt", "C_opt"), ("A_opt", "B_opt")):
        left_path, right_path = paths[left, 3], paths[right, 3]
        left_values = current_integrals(left_path)
        right_values = current_integrals(right_path)
        for p, q, lp, rp in zip(left_path, right_path, left_values, right_values, strict=True):
            if (p.elapsed, p.time) != (q.elapsed, q.time):
                raise ValueError("Cycle 3 candidate clocks differ across dephasing rates")
            net_delta = p.net_work - q.net_work
            net_error = p.net_error + q.net_error
            erg_delta = p.load_ergotropy - q.load_ergotropy
            erg_error = p.ergotropy_error + q.ergotropy_error
            inflow_delta = p.integrated_load_current - q.integrated_load_current
            inflow_error = p.integrated_current_error + q.integrated_current_error
            rows.append({
                "higher_gamma_protocol": left, "lower_gamma_protocol": right,
                "higher_gamma": ledger[left, 3]["gamma"], "lower_gamma": ledger[right, 3]["gamma"],
                "elapsed": p.elapsed, "time": p.time,
                "load_energy_higher_gamma": p.load_energy, "load_energy_lower_gamma": q.load_energy,
                "load_energy_delta": p.load_energy - q.load_energy,
                "load_current_higher_gamma": p.load_current, "load_current_lower_gamma": q.load_current,
                "load_current_delta": p.load_current - q.load_current,
                "signed_inflow_rk4_higher_gamma": p.integrated_load_current,
                "signed_inflow_rk4_lower_gamma": q.integrated_load_current,
                "signed_inflow_rk4_delta": inflow_delta, "signed_inflow_step_error": inflow_error,
                "signed_inflow_difference_resolved": abs(inflow_delta) > inflow_error + THRESHOLD,
                "signed_inflow_trapezoid_higher_gamma": lp[0], "signed_inflow_trapezoid_lower_gamma": rp[0],
                "positive_inflow_trapezoid_higher_gamma": lp[1], "positive_inflow_trapezoid_lower_gamma": rp[1],
                "positive_inflow_trapezoid_delta": lp[1] - rp[1],
                "gross_outflow_trapezoid_higher_gamma": lp[2], "gross_outflow_trapezoid_lower_gamma": rp[2],
                "load_ergotropy_higher_gamma": p.load_ergotropy, "load_ergotropy_lower_gamma": q.load_ergotropy,
                "load_ergotropy_delta": erg_delta, "load_ergotropy_step_error": erg_error,
                "load_ergotropy_difference_resolved": abs(erg_delta) > erg_error + THRESHOLD,
                "net_work_higher_gamma": p.net_work, "net_work_lower_gamma": q.net_work,
                "net_work_delta": net_delta, "net_step_error": net_error,
                "net_work_difference_resolved": abs(net_delta) > net_error + THRESHOLD,
                "higher_gamma_work_gain_resolved": net_delta > net_error + THRESHOLD,
                "net_rate_higher_gamma": p.rate, "net_rate_lower_gamma": q.rate,
                "net_rate_delta": p.rate - q.rate,
            })
    return rows


def intervening_minimum(values, peak, direction):
    minimum = peak
    extent = range(peak + direction, -1 if direction < 0 else len(values), direction)
    for index in extent:
        if values[index] > values[peak]:
            break
        if values[index] < values[minimum]:
            minimum = index
    return minimum


def local_peaks(path, metric):
    values = [getattr(point, metric) for point in path]
    for index, value in enumerate(values):
        if index and value <= values[index - 1]:
            continue
        if index + 1 < len(path) and (value < values[index + 1] or (index == 0 and value == values[1])):
            continue
        yield index, [
            intervening_minimum(values, index, direction)
            for direction in (-1, 1) if 0 <= index + direction < len(path)
        ]


def peak_records(key, path, metric, selected, gamma):
    values = [getattr(point, metric) for point in path]
    winner = max(range(len(path)), key=values.__getitem__)
    rows = []
    for index, valleys in local_peaks(path, metric):
        point = path[index]
        left = valleys[0] if index else None
        right = valleys[-1] if index + 1 < len(path) else None
        rises = [values[index] - values[valley] for valley in valleys]
        slacks = [rise - point.error(metric) - path[valley].error(metric)
                  for rise, valley in zip(rises, valleys, strict=True)]
        margin = min(slacks, default=0.0)
        location = "left_boundary" if index == 0 else "right_boundary" if index == len(path) - 1 else "interior"
        rows.append({
            "protocol": key[0], "gamma": gamma, "cycle": key[1], "metric": metric,
            "elapsed": point.elapsed, "time": point.time, "value": values[index],
            "step_error": point.error(metric), "location": location,
            "window_maximum": index == winner, "at_selected_time": point.elapsed == selected,
            "left_valley_elapsed": "" if left is None else path[left].elapsed,
            "left_valley_value": "" if left is None else values[left],
            "right_valley_elapsed": "" if right is None else path[right].elapsed,
            "right_valley_value": "" if right is None else values[right],
            "prominence": min(rises, default=0.0), "prominence_resolution_margin": margin,
            "prominence_resolved": margin > THRESHOLD,
        })
    return rows


def peak_and_recovery(paths, ledger):
    peaks, summaries = [], []
    for key, path in paths.items():
        selected_elapsed = float(ledger[key]["elapsed"])
        selected, = (point for point in path if point.elapsed == selected_elapsed)
        signed_trap, positive, negative = current_integrals(path)[-1]
        for metric in PEAK_METRICS:
            records = peak_records(key, path, metric, selected_elapsed, ledger[key]["gamma"])
            peaks.extend(records)
            interior = [row for row in records if row["location"] == "interior"]
            resolved = [row for row in interior if row["prominence_resolved"]]
            def value(point):
                return getattr(point, metric)

            maximum = max(path, key=value)
            early = max((point for point in path if point.elapsed <= 8.0), key=value)
            late = max((point for point in path if point.elapsed > 8.0), key=value, default=None)
            late_gain = "" if late is None else value(late) - value(early)
            late_margin = "" if late is None else late_gain - early.error(metric) - late.error(metric)
            summaries.append({
                "protocol": key[0], "gamma": ledger[key]["gamma"], "cycle": key[1], "metric": metric,
                "adopted": ledger[key]["accepted"], "window_end": path[-1].elapsed,
                "selected_elapsed": selected.elapsed, "selected_value": value(selected),
                "window_peak_elapsed": maximum.elapsed, "window_peak_value": value(maximum),
                "window_peak_at_boundary": maximum in (path[0], path[-1]),
                "interior_peaks": len(interior), "resolved_interior_peaks": len(resolved),
                "first_resolved_peak_elapsed": resolved[0]["elapsed"] if resolved else "",
                "last_resolved_peak_elapsed": resolved[-1]["elapsed"] if resolved else "",
                "early_peak_elapsed": early.elapsed, "early_peak_value": value(early),
                "late_peak_elapsed": "" if late is None else late.elapsed,
                "late_peak_value": "" if late is None else value(late),
                "late_minus_early_peak": late_gain, "late_gain_resolution_margin": late_margin,
                "late_gain_resolved": "" if late is None else late_margin > THRESHOLD,
                "minimum_sampled_load_current": min(point.load_current for point in path),
                "maximum_sampled_load_current": max(point.load_current for point in path),
                "window_signed_inflow_rk4": path[-1].integrated_load_current,
                "window_signed_inflow_trapezoid": signed_trap,
                "window_positive_inflow_trapezoid": positive, "window_gross_outflow_trapezoid": negative,
            })
    return peaks, summaries


def fixed_history_decomposition(paths, ledger):
    rows = []
    for fixed in ("B_fixed", "C_fixed"):
        optimal = f"{fixed[0]}_opt"
        for protocol, cycle in sorted(paths):
            if protocol != fixed:
                continue
            fixed_path = paths[fixed, cycle]
            fixed_ledger = ledger[fixed, cycle]
            selected_time = float(fixed_ledger["elapsed"])
            fixed_selected, = (point for point in fixed_path if point.elapsed == selected_time)
            fixed_maximum = max(fixed_path, key=lambda point: point.net_work)
            timing_gap = fixed_maximum.net_work - fixed_selected.net_work
            timing_error = fixed_maximum.net_error + fixed_selected.net_error
            own_path = paths.get((optimal, cycle), [])
            own_maximum = max(own_path, key=lambda point: point.net_work, default=None)
            own_at_fixed = next((point for point in own_path if point.elapsed == selected_time), None)
            history_gap = "" if own_maximum is None else own_maximum.net_work - fixed_maximum.net_work
            history_error = "" if own_maximum is None else own_maximum.net_error + fixed_maximum.net_error
            total_gap = "" if own_maximum is None else own_maximum.net_work - fixed_selected.net_work
            matched_history_gap = "" if own_at_fixed is None else own_at_fixed.net_work - fixed_selected.net_work
            matched_history_error = "" if own_at_fixed is None else own_at_fixed.net_error + fixed_selected.net_error
            actual_fixed_accepted = fixed_ledger["accepted"] == "true"
            own_ledger = ledger.get((optimal, cycle), {})
            actual_own_accepted = own_ledger.get("accepted") == "true"
            rows.append({
                "fixed_protocol": fixed, "independent_protocol": optimal, "cycle": cycle,
                "fixed_accepted": fixed_ledger["accepted"], "independent_accepted": own_ledger.get("accepted", ""),
                "fixed_selected_elapsed": fixed_selected.elapsed, "fixed_selected_net_candidate": fixed_selected.net_work,
                "fixed_window_peak_elapsed": fixed_maximum.elapsed, "fixed_window_peak_net": fixed_maximum.net_work,
                "fixed_history_timing_gain": timing_gap, "fixed_history_timing_step_error": timing_error,
                "fixed_history_timing_gain_resolved": timing_gap > timing_error + THRESHOLD,
                "independent_window_peak_elapsed": "" if own_maximum is None else own_maximum.elapsed,
                "independent_window_peak_net": "" if own_maximum is None else own_maximum.net_work,
                "independent_minus_fixed_history_peak_net": history_gap, "peak_history_step_error": history_error,
                "peak_history_difference_resolved": "" if own_maximum is None else abs(history_gap) > history_error + THRESHOLD,
                "independent_at_a_elapsed_net": "" if own_at_fixed is None else own_at_fixed.net_work,
                "history_gap_at_a_elapsed": matched_history_gap, "history_step_error_at_a_elapsed": matched_history_error,
                "history_difference_resolved_at_a_elapsed": ("" if own_at_fixed is None else
                                                             abs(matched_history_gap) > matched_history_error + THRESHOLD),
                "independent_minus_fixed_selected_net_candidate": total_gap,
                "decomposition_residual": "" if own_maximum is None else total_gap - timing_gap - history_gap,
                "actual_accepted_net_gap": (float(own_ledger["net_work"]) - float(fixed_ledger["net_work"])
                                            if actual_own_accepted and actual_fixed_accepted else ""),
            })
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("data", type=Path, help="Directory containing the merged M21 solver CSVs")
    parser.add_argument("--output", type=Path, help="Write the four analyses to this directory")
    args = parser.parse_args()
    output = args.output or args.data
    output.mkdir(parents=True, exist_ok=True)
    paths = trajectories(args.data)
    ledger = {cycle_key(row): row for row in read_csv(args.data / "m21_cycle_ledger.csv")}
    if set(paths) != set(ledger) or any((protocol, 3) not in ledger for protocol in PROTOCOLS[:3]):
        raise ValueError("Candidate trajectories do not match the M21 ledgers")
    peaks, recovery = peak_and_recovery(paths, ledger)
    tables = {
        "m21_cycle03_rate_comparison.csv": rate_comparison(paths, ledger),
        "m21_candidate_peaks.csv": peaks,
        "m21_candidate_recovery.csv": recovery,
        "m21_fixed_history_decomposition.csv": fixed_history_decomposition(paths, ledger),
    }
    for name, rows in tables.items():
        write_csv(output / name, rows)
        print(f"{name}: {len(rows)} rows")


if __name__ == "__main__":
    main()
