"""Summarize adopted work, energy accounting, and γ=0 conservation."""
import argparse
from collections import defaultdict
import csv
from pathlib import Path

from run_m21 import PROTOCOLS, rows

ANCHOR_TIME = 15.90
RESOLUTION = 1e-12
ENERGY_TOL = 1e-12
OBSERVABLES = (
    "load_energy", "load_ergotropy", "global_energy", "global_ergotropy", "global_passive_energy",
    "sector_ergotropy", "sector_passive_energy", "global_purity", "load_purity",
    "total_excitation", "load_current", "mutual_information", "any_local_unitary_full_work_upper_bound",
)
GAMMA = {"A_opt": 1.5, "B_opt": 0.75, "C_opt": 0, "B_fixed": 0.75, "C_fixed": 0}


def write_table(path, records):
    with path.open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)


def gap_status(delta, uncertainty):
    if delta - uncertainty > RESOLUTION:
        return "increase"
    if -delta - uncertainty > RESOLUTION:
        return "decrease"
    return "within_resolution"


def snapshot_columns(row, before, after):
    for key in OBSERVABLES:
        row[f"before_{key}"] = before[key]
        row[f"after_{key}"] = after[key] if after is not None else ""


def create_reports(root):
    ledger = rows(root / "m21_cycle_ledger.csv")
    metrics = {(s["protocol"], int(s["cycle"]), s["phase"]): s for s in rows(root / "m21_state_metrics.csv")}
    half = {(s["protocol"], int(s["cycle"]), s["elapsed"]): s for s in rows(root / "m21_half_step.csv")}
    old_m20 = {int(s["cycle"]): s for s in rows(root / "m20_reference" / "m20_cycle_ledger.csv")}
    runs = defaultdict(list)
    comparisons, balances, conservation = [], [], []
    sum_bath = defaultdict(float)
    for trial in ledger:
        protocol = trial["protocol"]
        cycle = int(trial["cycle"])
        accepted = trial["accepted"] == "true"
        s = {phase: metrics[protocol, cycle, phase] for phase in (
            "wait_start", "cut_after", "wait_end", "reconnect_after", "before", "window_end"
        )}
        after = metrics.get((protocol, cycle, "after"))
        anchor = metrics[protocol, 2, "anchor"]
        sampled = half[protocol, cycle, trial["elapsed"]]
        uncertainty = abs(float(sampled["net_work"]) - float(sampled["net_half"]))
        net = float(trial["net_work"])
        previous = runs[protocol][-1] if runs[protocol] else None
        f = lambda key: float(trial[key])
        record = {
            **trial,
            "mode": "fixed_A_timing" if protocol.endswith("_fixed") else "independent",
            "adopted_net_work": net if accepted else 0.0,
            "numerical_net_indicator": uncertainty,
            "change_from_previous_net": "",
            "change_from_previous_status": "",
            "own_peak_at_window_boundary": float(trial["own_peak_elapsed"]) in (0.0, 16.0),
            "adopted_net_to_start_global_ergotropy": (
                net / float(s["wait_start"]["global_ergotropy"]) if accepted else ""
            ),
            "m20_formal_net_8_window": old_m20.get(cycle, {}).get("net_work", ""),
            "m20_formal_elapsed_8_window": old_m20.get(cycle, {}).get("elapsed", ""),
        }
        if accepted and previous and previous["accepted"] == "true":
            change = net - float(previous["net_work"])
            record["change_from_previous_net"] = change
            record["change_from_previous_status"] = gap_status(
                change, uncertainty + float(previous["numerical_net_indicator"])
            )
        snapshot_columns(record, s["before"], after)
        comparisons.append(record)
        runs[protocol].append(record)

        e = {phase: float(snapshot["global_energy"]) for phase, snapshot in s.items()}
        e_virtual_after = f("post_total_energy")
        current_bath = f("dissipative_wait") + f("dissipative_connected")
        if accepted:
            sum_bath[protocol] += current_bath
        cumulative_residual = (
            e_virtual_after - float(anchor["global_energy"]) - sum_bath[protocol] + f("cumulative_m21_net")
        ) if accepted else ""
        balances.append({
            "protocol": protocol, "gamma": trial["gamma"], "cycle": cycle, "accepted": accepted,
            "E_before_cut": e["wait_start"], "W_cut_on": f("cut_on"),
            "E_after_cut": e["cut_after"], "Q_wait": f("dissipative_wait"),
            "E_wait_end": e["wait_end"], "W_reconnect_on": f("reconnect_on"),
            "E_after_reconnect": e["reconnect_after"], "Q_connected_to_selected": f("dissipative_connected"),
            "E_before_extraction": e["before"], "W_gross_load": f("gross_work"),
            "interaction_energy_jump": f("interaction_jump"), "W_extraction_out": f("total_work"),
            "E_after_actual_or_virtual_extraction": e_virtual_after,
            "W_net_actual_or_virtual": net, "adopted_W_net": net if accepted else 0.0,
            "adopted_cumulative_W_net": f("cumulative_m21_net"), "adopted_cumulative_Q": sum_bath[protocol],
            "residual_cut": e["cut_after"] - e["wait_start"] - f("cut_on"),
            "residual_wait": e["wait_end"] - e["cut_after"] - f("dissipative_wait"),
            "residual_reconnect": e["reconnect_after"] - e["wait_end"] - f("reconnect_on"),
            "residual_connected": e["before"] - e["reconnect_after"] - f("dissipative_connected"),
            "residual_extraction": e_virtual_after - e["before"] + f("total_work"),
            "residual_work_identity": f("total_work") - f("gross_work") + f("interaction_jump"),
            "residual_cycle": e_virtual_after - e["wait_start"] - current_bath + net,
            "residual_cumulative": cumulative_residual,
            "energy_tolerance": ENERGY_TOL,
        })

        if float(trial["gamma"]) == 0:
            boundaries = [
                ("switch_cut", "wait_start", "cut_after"),
                ("continuous_wait", "cut_after", "wait_end"),
                ("switch_reconnect", "wait_end", "reconnect_after"),
                ("continuous_to_selection", "reconnect_after", "before"),
                ("continuous_full_window_trial", "reconnect_after", "window_end"),
            ]
            if accepted:
                s["after"] = after
                boundaries.append(("local_extraction", "before", "after"))
            for segment, first, last in boundaries:
                start, end = s[first], s[last]
                values = [
                    "global_energy", "global_purity", "global_ergotropy", "global_passive_energy",
                    "sector_ergotropy", "sector_passive_energy", "total_excitation",
                ] + [f"sector_probability_{n}" for n in range(10)]
                delta = {f"delta_{name}": float(end[name]) - float(start[name]) for name in values}
                max_sector_drift = max(abs(delta[f"delta_sector_probability_{n}"]) for n in range(10))
                conservation.append({
                    "protocol": protocol, "cycle": cycle, "accepted": accepted, "segment": segment,
                    "time_start": start["time"], "time_end": end["time"], "g_start": start["g"], "g_end": end["g"],
                    **delta, "sector_probability_max_abs_delta": max_sector_drift,
                })

    for record in balances:
        for field, value in record.items():
            if field.startswith("residual_") and value != "" and abs(value) > ENERGY_TOL:
                raise ValueError(f"Energy balance {record['protocol']} cycle {record['cycle']} {field}: {value}")
    write_table(root / "m21_comparison.csv", comparisons)
    write_table(root / "m21_energy_balance.csv", balances)
    if conservation:
        write_table(root / "m21_gamma0_conservation.csv", conservation)

    adoptions = {p: [r for r in runs[p] if r["accepted"] == "true"] for p in PROTOCOLS}
    common_count = min(map(len, adoptions.values()))
    common_elapsed = min(float(runs[p][-1]["attempted_elapsed_since_anchor"]) if runs[p] else 0 for p in PROTOCOLS)
    summaries = []
    for p, accepted_rows in adoptions.items():
        accepted_last = accepted_rows[-1] if accepted_rows else None
        final_row = runs[p][-1] if runs[p] else None
        first_net = float(accepted_rows[0]["net_work"]) if accepted_rows else 0.0
        last_net = float(accepted_last["net_work"]) if accepted_last else 0.0
        duration = float(accepted_last["accepted_elapsed_since_anchor"]) if accepted_last else 0.0
        total = float(accepted_last["cumulative_m21_net"]) if accepted_last else 0.0
        common_time_total = sum(
            float(r["net_work"]) for r in accepted_rows
            if float(r["accepted_elapsed_since_anchor"]) <= common_elapsed + 1e-12
        )
        end_metrics = metrics[p, int(accepted_last["cycle"]), "after"] if accepted_last else metrics[p, 2, "anchor"]
        summarised = {
            "protocol": p, "gamma": GAMMA[p], "adopted_cycles": len(accepted_rows),
            "last_attempted_cycle": final_row["cycle"] if final_row else "",
            "last_adopted_cycle": accepted_last["cycle"] if accepted_last else "",
            "termination": (
                "A_schedule_unavailable" if final_row is None else
                "adoption_rule_failure" if final_row["accepted"] == "false" else
                "cycle_cap" if final_row["cycle"] == "10" else "end_of_scope_or_A_schedule"
            ),
            "first_net_work": first_net, "last_net_work": last_net,
            "last_to_first_net_ratio": last_net / first_net if first_net else "",
            "first_to_last_adopted_elapsed_since_anchor": duration,
            "adopted_cumulative_net_work": total, "work_per_model_time_at_own_last_adoption": total / duration if duration else "",
            "common_adoption_count": common_count,
            "cumulative_net_at_common_adoption_count": sum(float(r["net_work"]) for r in accepted_rows[:common_count]),
            "common_attempted_elapsed_since_anchor": common_elapsed,
            "work_accumulated_by_common_elapsed": common_time_total,
            "work_per_model_time_at_common_elapsed": common_time_total / common_elapsed if common_elapsed else "",
            "numerically_resolved_increase_cycles": " ".join(
                r["cycle"] for r in accepted_rows if r["change_from_previous_status"] == "increase"
            ),
            "cumulative_dephasing_energy_change": sum_bath[p],
        }
        summarised.update({f"endpoint_{key}": end_metrics[key] for key in OBSERVABLES})
        summaries.append(summarised)
    write_table(root / "m21_protocol_summary.csv", summaries)
    print(f"M21 comparison: {len(comparisons)} trials, {sum(map(len, adoptions.values()))} adoptions.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path)
    args = parser.parse_args()
    create_reports(args.results)
