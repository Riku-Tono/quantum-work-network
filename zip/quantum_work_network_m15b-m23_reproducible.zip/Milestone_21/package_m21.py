"""Collect final M21 calculation outputs and package the deliverables."""
import argparse
import hashlib
from pathlib import Path
import shutil
import zipfile

from run_m21 import CSVS

ROOT = Path(__file__).resolve().parent
REPORT = "MILESTONE_21_DEPHASING_REPORT.md"
FIGURES = (
    "m21_01_net_work.png", "m21_02_cumulative_and_time_efficiency.png", "m21_03_ergotropy.png",
    "m21_04_passive_energy_and_purity.png", "m21_load_recovery_independent.png",
    "m21_load_recovery_fixed_to_a.png",
)


def copy(src, dst):
    if dst.exists():
        raise FileExistsError(dst)
    try:
        dst.hardlink_to(src)
    except OSError:
        shutil.copy2(src, dst)


def collect(formal, benchmark, destination):
    formal_csvs = [formal / "merged" / name for name in CSVS]
    if any(not path.is_file() for path in formal_csvs) or not (formal / "m21_batch_runtime.csv").is_file():
        raise ValueError(f"Formal calculation has not finished: {formal}")
    snapshots = sorted((formal / "merged" / "states").glob("*.bin"))
    if not snapshots:
        raise ValueError(f"No snapshots: {formal}")
    destination.mkdir(exist_ok=True)
    (destination / "states").mkdir()
    for path in snapshots:
        copy(path, destination / "states" / path.name)
    for path in formal_csvs:
        copy(path, destination / path.name)
    for name in ("m21_batch_runtime.csv", "a_schedule_ticks.txt"):
        copy(formal / name, destination / name)
    (destination / "benchmark").mkdir()
    benchmark_merge = benchmark / "merged"
    for path in sorted(benchmark_merge.glob("m21_*.csv")):
        copy(path, destination / "benchmark" / path.name)
    copy(benchmark / "m21_batch_runtime.csv", destination / "benchmark" / "m21_batch_runtime.csv")
    for folder in ("states", "m18_inputs"):
        target = destination / "benchmark" / folder
        target.mkdir()
        for path in sorted((benchmark_merge / folder).glob("*")):
            if path.is_file():
                copy(path, target / path.name)


def package(root):
    required = [
        REPORT, "PRECOMMIT_M21.md", "README_M21.md", "m21_comparison.csv",
        "m21_candidates.csv", "m21_state_metrics.csv", "m21_half_step.csv",
        "m21_energy_balance.csv", "m21_gamma0_conservation.csv", "m21_independent_audit.csv",
        "m21_state_manifest.csv", "m21_protocol_summary.csv", "benchmark/m21_runtime_estimate.csv",
        "m21_cycle03_rate_comparison.csv", "m21_candidate_peaks.csv", "m21_candidate_recovery.csv",
        "m21_fixed_history_decomposition.csv",
        *(f"figures/{name}" for name in FIGURES),
    ]
    for name in required:
        if not (root / name).is_file() or not (root / name).stat().st_size:
            raise FileNotFoundError(root / name)
    archive_path = root / "M21_all_results.zip"
    temporary = root / "M21_all_results.zip.incomplete"
    if archive_path.exists() or temporary.exists():
        raise FileExistsError(archive_path)
    excluded_paths = {"__pycache__", ".git", "target"}
    files = [
        path for path in root.rglob("*") if path.is_file()
        and excluded_paths.isdisjoint(path.relative_to(root).parts)
        and path.suffix not in {".zip", ".pyc", ".incomplete", ".sha256"}
    ]
    names = [f"Milestone_21/{path.relative_to(root).as_posix()}" for path in files]
    with zipfile.ZipFile(temporary, "x", zipfile.ZIP_DEFLATED, compresslevel=3) as archive:
        for path, name in zip(files, names, strict=True):
            archive.write(path, name)
    with zipfile.ZipFile(temporary) as archive:
        if set(archive.namelist()) != set(names) or archive.testzip() is not None:
            raise ValueError("M21 archive verification failed")
    temporary.rename(archive_path)
    with archive_path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    (root / "M21_all_results.sha256").write_text(f"{digest}  {archive_path.name}\n", encoding="ascii")
    print(f"{archive_path.name}: {len(files)} files, {archive_path.stat().st_size:,} bytes, SHA-256 {digest}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    transfer = commands.add_parser("collect")
    transfer.add_argument("formal", type=Path)
    transfer.add_argument("benchmark", type=Path)
    transfer.add_argument("--destination", type=Path, default=ROOT)
    pack = commands.add_parser("package")
    pack.add_argument("--directory", type=Path, default=ROOT)
    args = parser.parse_args()
    if args.command == "collect":
        collect(args.formal, args.benchmark, args.destination)
    else:
        package(args.directory)
