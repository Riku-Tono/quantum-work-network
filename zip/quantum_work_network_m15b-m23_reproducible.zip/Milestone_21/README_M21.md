# M21 再現手順

結果フォルダーは M18 の登録済み起点、M20 の参照値、Rust実装、Python集計、図、CSV、粗刻み・半刻みの保存状態を含む。概要は [M21実験報告書](MILESTONE_21_DEPHASING_REPORT.md) に記載した。

## 入力と計算条件

[事前登録](PRECOMMIT_M21.md) と [登録時SHA-256](m21_precommit_sha256.csv) で条件を確認する。モデル時間の起点は M18 R4 の第2回抽出直後 t=15.90。候補CSVの time は絶対モデル時刻、elapsed はその回の再接続後の時間、gamma は鎖全体の率。A_opt、B_opt、C_opt は独立選定、B_fixed、C_fixed は A の採択時刻を適用した枝。window_end は未抽出のまま窓終端まで進めた診断状態。accepted=false の仕事・抽出後エネルギーは仮想値で、正味仕事の累積には入らない。

## Windows PowerShellで再実行

このフォルダーで実行する。Python 3.14 と Rust の安定版ツールチェーンを用意する。既存の成果物を使った独立監査は --read-only で出力を上書きせず再実行できる。

    py -3.14 -m pip install -r requirements.txt
    $env:OPENBLAS_NUM_THREADS = '1'
    py -3.14 -B verify_m21.py . --read-only

再計算時は、新規の相対出力フォルダーを指定する。Windows配布バイナリを使うコマンドは次のとおり。

    py -3.14 -B run_m21.py benchmark m21_dephasing.exe redo_benchmark --jobs 2
    Copy-Item -LiteralPath m18_inputs -Destination redo_benchmark/merged -Recurse
    py -3.14 -B m21_observables.py redo_benchmark/merged
    py -3.14 -B verify_m21.py redo_benchmark/merged --window 0.50 --last-cycle 3
    py -3.14 -B run_m21.py formal m21_dephasing.exe redo_formal --jobs 2

ソースから実行ファイルを作る場合は以下でコンパイルし、前掲コマンド中の実行ファイルを redo_build/release/m21_dephasing.exe に変更して --allow-rebuilt を付ける。ソース・入力・事前登録のハッシュは照合される。再ビルドでは実行ファイルのバイト列と浮動小数点の丸めが変わり得る。

    $env:RUSTFLAGS = '-C target-cpu=native'
    cargo build --release --locked --manifest-path solver/Cargo.toml --target-dir redo_build --bin m21_dephasing

再計算結果を独立に監査して集計する。

    py -3.14 -B package_m21.py collect redo_formal redo_benchmark --destination redo_results
    Copy-Item -LiteralPath m18_inputs,m20_reference -Destination redo_results -Recurse
    py -3.14 -B m21_observables.py redo_results
    py -3.14 -B verify_m21.py redo_results
    py -3.14 -B summarize_m21.py redo_results
    py -3.14 -B m21_candidate_analysis.py redo_results
    py -3.14 -B plot_m21.py --data redo_results

## 仕事と電流

切断・再接続は全系への入力を正、局所抽出は全系からの出力を正とする。gross_work は裸の負荷からの出力、total_work は相互作用の変化を含む全ハミルトニアンでの出力、net_work は二つの切替の入力を差し引いた値。load_current は鎖第7サイトから負荷へ向かう向きを正とする。integrated_load_current は直近の再接続直後をゼロとした符号付き積分。刻み差は回・枝別の同一候補時刻で評価し、正味の解像度指標にも用いる。

m21_state_metrics.csv は観測量、m21_state_basic.csv と m21_state_half.csv は保存状態への参照、m21_state_manifest.csv は状態のハッシュと時刻を記録する。状態ファイルは8バイトの QWNRHO1＋NUL、little endianの64ビット次元、64ビット時刻、行優先の複素128ビット行列の順。基底は鎖の占有ビットの後ろに負荷準位を変化させる順。相互情報量はナット。
