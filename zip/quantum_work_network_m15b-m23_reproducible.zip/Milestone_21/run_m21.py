"""Check the registered solver and run or merge the five M21 histories."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import csv
import hashlib
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
SOURCE = "R4_observed_max_t1590_after.bin"
SOURCE_SHA = "4C9A5EE8172E505592C43A7B522476715D418CAFA0CC677C04B853E72CC6F9ED"
MANIFEST_SHA = "9F0512D6ED2D85C85A240869D5DEF20C1177D891C7D626F2D5BC37EC9436D8EC"
PROTOCOLS = ("A_opt", "B_opt", "C_opt", "B_fixed", "C_fixed")
CSVS = (
    "m21_candidates.csv", "m21_cycle_ledger.csv", "m21_state_basic.csv",
    "m21_state_half.csv", "m21_half_step.csv", "m21_runtime.csv", "m21_model_checks.csv",
)


def rows(path):
    with path.open(encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))


def digest(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest().upper()


def verify_source():
    inputs = ROOT / "m18_inputs"
    path = inputs / SOURCE
    if digest(path) != SOURCE_SHA or digest(inputs / "m18_state_manifest.csv") != MANIFEST_SHA:
        raise ValueError("Published M18 input SHA-256 mismatch")
    row, = (row for row in rows(inputs / "m18_state_manifest.csv") if row["filename"] == f"states/{SOURCE}")
    observed = (
        row["sha256"], row["condition"], float(row["time"]), float(row["g"]),
        row["branch"], row["extraction_phase"], int(row["dimension"]), int(row["size_bytes"]),
    )
    if observed != (SOURCE_SHA, "R4", 15.90, 0.25, "observed_max", "after", 384, 2359320):
        raise ValueError("Published M18 provenance mismatch")
    return path


def verify_registration(exe, allow_rebuilt=False):
    verify_source()
    frozen = rows(ROOT / "m21_precommit_sha256.csv")
    for item in frozen:
        name = item["filename"]
        path = exe if name == "m21_dephasing.exe" else ROOT / name
        if name == "m21_dephasing.exe" and allow_rebuilt:
            continue
        if digest(path) != item["sha256"]:
            raise ValueError(f"Registered SHA-256 mismatch for {name}")
    if not {"m21_dephasing.exe", "PRECOMMIT_M21.md"} <= {item["filename"] for item in frozen}:
        raise ValueError("Incomplete registration")


def write_csv(path, header, data):
    with path.open("x", encoding="utf-8", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(header)
        writer.writerows(data)


def estimate(directory, elapsed, jobs):
    measured = rows(directory / "m21_runtime.csv")
    factor = (2 + 16) / (2 + 0.50)
    projected = [
        (row["protocol"], float(row["setup_seconds"]), float(row["wall_seconds"]), factor,
         float(row["setup_seconds"]) + 8 * factor * float(row["wall_seconds"]))
        for row in measured
    ]
    # The two replay runs depend on A. Other branches can overlap A.
    estimate_seconds = elapsed * 8 * factor
    write_csv(
        directory / "m21_runtime_estimate.csv",
        ("estimate", "setup_seconds", "benchmark_cycle_seconds", "propagation_ratio", "projected_seconds"),
        [*projected, (f"five_branch_wall_based_on_benchmark_jobs_{jobs}", 0, elapsed, factor, estimate_seconds)],
    )
    print(f"Full five-branch estimate at {jobs} parallel protocol jobs: {estimate_seconds / 60:.1f} minutes (including scaled overhead).", flush=True)


def merge(branches, destination):
    if (destination / "states").exists():
        raise FileExistsError(destination / "states")
    destination.mkdir(parents=True, exist_ok=True)
    (destination / "states").mkdir()
    for protocol in PROTOCOLS:
        for source in (branches / protocol / "states").glob("*.bin"):
            target = destination / "states" / source.name
            try:
                target.hardlink_to(source)
            except OSError:
                shutil.copy2(source, target)
    for name in CSVS:
        with (destination / name).open("x", encoding="utf8", newline="") as output:
            header = None
            for protocol in PROTOCOLS:
                with (branches / protocol / name).open(encoding="utf8", newline="") as part:
                    part_header = part.readline()
                    if header is None:
                        header = part_header
                        output.write(header)
                    if part_header != header:
                        raise ValueError(f"Branch schema mismatch: {name}: {protocol}")
                    shutil.copyfileobj(part, output)


def run(mode, exe, directory, jobs, allow_rebuilt):
    verify_registration(exe, allow_rebuilt)
    source = verify_source()
    directory.mkdir()
    branches = directory / "branches"
    branches.mkdir()
    schedule = directory / "a_schedule_ticks.txt"

    def invoke(protocol):
        subprocess.run(
            [exe, mode, protocol, source, branches / protocol, schedule if protocol.endswith("fixed") else "-"],
            check=True,
        )

    started = time.perf_counter()
    with ThreadPoolExecutor(max_workers=jobs) as pool:
        a = pool.submit(invoke, "A_opt")
        b = pool.submit(invoke, "B_opt")
        c = pool.submit(invoke, "C_opt")
        a.result()
        accepted = [row for row in rows(branches / "A_opt" / "m21_cycle_ledger.csv") if row["accepted"] == "true"]
        schedule.write_text("".join(f"{round(float(row['elapsed']) * 100)}\n" for row in accepted), encoding="ascii")
        b_fixed = pool.submit(invoke, "B_fixed")
        c_fixed = pool.submit(invoke, "C_fixed")
        for future in (b, c, b_fixed, c_fixed):
            future.result()
    verify_registration(exe, allow_rebuilt)
    elapsed = time.perf_counter() - started
    merge(branches, directory / "merged")
    write_csv(directory / "m21_batch_runtime.csv", ("mode", "parallel_protocol_jobs", "elapsed_seconds"), [(mode, jobs, elapsed)])
    if mode == "benchmark":
        estimate(directory / "merged", elapsed, jobs)
    print(f"{mode}: completed in {elapsed:.3f} seconds.", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("register", "benchmark", "formal", "merge"))
    parser.add_argument("path", type=Path, help="solver path, or branch folder for merge")
    parser.add_argument("directory", type=Path, nargs="?")
    parser.add_argument("--jobs", type=int, default=2, choices=(1, 2, 3, 4, 5))
    parser.add_argument("--allow-rebuilt", action="store_true", help="Allow a newly compiled executable after checking source hashes.")
    args = parser.parse_args()
    path = args.path.resolve()
    if args.mode == "register":
        verify_source()
        paths = [ROOT / "PRECOMMIT_M21.md", ROOT / "run_m21.py"]
        paths.extend(sorted((ROOT / "m18_inputs").glob("*")))
        paths.extend(sorted((ROOT / "m20_reference").glob("*")))
        paths.extend(sorted(p for p in (ROOT / "solver").rglob("*") if p.is_file() and "target" not in p.relative_to(ROOT / "solver").parts))
        write_csv(ROOT / "m21_precommit_sha256.csv", ("filename", "sha256"),
                  [(p.relative_to(ROOT).as_posix(), digest(p)) for p in paths] + [("m21_dephasing.exe", digest(path))])
    elif args.directory is None:
        parser.error("directory is required")
    elif args.mode == "merge":
        merge(path, args.directory.resolve())
    else:
        run(args.mode, path, args.directory.resolve(), args.jobs, args.allow_rebuilt)


if __name__ == "__main__":
    main()
