"""Render the M19 work, search and energy figures from CSV ledgers."""

import argparse
import csv
from itertools import product
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parent
GRID = tuple(product((0.0, 2.0), (0.05, 0.125, 0.25)))
INK = "#152637"
MUTED = "#42586C"
GUIDE = "#DFE7ED"
AXIS = "#8293A2"
BLUE = "#225886"
TEAL = "#007172"
ORANGE = "#A2441A"
PURPLE = "#704984"
GRAY = "#546579"
COUPLING_COLORS = {0.05: TEAL, 0.125: ORANGE, 0.25: PURPLE}
WORK_FLOOR = 1e-12
FIGURES = (
    "m19_01_repeated_work.png",
    "m19_02_candidate_trajectories.png",
    "m19_03_sampled_maxima.png",
    "m19_04_energy_and_remaining_work.png",
)


def read_csv(directory, name):
    with (directory / name).open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def floats(rows, field):
    return [float(row[field]) for row in rows]


def cycles(rows):
    return [int(row["cycle"]) for row in rows]


def is_accepted(row):
    return row["accepted"] == "YES"


def scientific_tick(value, _position):
    return "0" if value == 0.0 else f"{value:.1e}"


def title_figure(figure, title, subtitle, *, top=0.79, bottom=0.12, left=0.108, **spacing):
    figure.subplots_adjust(left=left, right=0.974, bottom=bottom, top=top, **spacing)
    figure.text(left, 0.967, title, color=INK, fontsize=19, fontweight="bold", va="top")
    figure.text(left, 0.915, subtitle, color=MUTED, fontsize=10.2, va="top")


def style_axis(ax, *, scientific=True, zero=False):
    ax.set_axisbelow(True)
    ax.yaxis.grid(True, color=GUIDE, linewidth=0.8)
    ax.spines[["top", "right"]].set_visible(False)
    for edge in ("bottom", "left"):
        ax.spines[edge].set_color(AXIS)
    ax.tick_params(axis="both", color=AXIS, labelcolor=INK, labelsize=9)
    if scientific:
        ax.yaxis.set_major_formatter(scientific_tick)
    if zero:
        ax.axhline(0.0, color=AXIS, linewidth=0.85, zorder=1)


def label_axis(ax, title, ylabel):
    ax.set_title(title, loc="left", color=INK, fontsize=10.8, pad=7)
    ax.set_ylabel(ylabel, color=INK, fontsize=9.3, labelpad=7)


def legend(ax, columns=1):
    ax.legend(loc="best", ncols=columns, frameon=True, framealpha=0.94, edgecolor=GUIDE,
              labelcolor=INK, fontsize=8.3)


def legend_at_top(figure, ax, columns):
    handles, labels = ax.get_legend_handles_labels()
    figure.legend(handles, labels, loc="upper left", bbox_to_anchor=(0.103, 0.887), ncols=columns,
                  frameon=False, handlelength=2.4, columnspacing=1.6, labelcolor=INK, fontsize=9.2)


def line(ax, x, y, label, color, marker="o", linestyle="-"):
    ax.plot(x, y, label=label, color=color, linestyle=linestyle, linewidth=1.55, marker=marker,
            markersize=4.8, markerfacecolor="white", markeredgewidth=1.2)


def save(plt, figure, output, index):
    with (output / FIGURES[index]).open("xb") as stream:
        figure.savefig(stream, format="png", dpi=200, facecolor="white")
    plt.close(figure)


def plot_repeated_work(plt, ledger, control, output):
    figure, (work_ax, cumulative_ax, control_ax) = plt.subplots(3, 1, figsize=(11.3, 8.5), sharex=True)
    title_figure(figure, "Work extracted over repeated cycles",
                 "Net work includes the coupling switches. Cumulative work starts with the first M19 cycle.",
                 top=0.81, bottom=0.10, hspace=0.35)
    completed = [row for row in ledger if is_accepted(row)]
    work_ax.set_yscale("symlog", linthresh=WORK_FLOOR, linscale=0.65)
    work_series = (
        ("gross_work", "Bare-load gross", BLUE, "o", -0.16),
        ("total_work", "Full-system extraction", TEAL, "s", 0.0),
        ("net_work", "Cycle net", PURPLE, "D", 0.16),
    )
    for field, label, color, marker, offset in work_series:
        line(work_ax, [cycle + offset for cycle in cycles(completed)], floats(completed, field),
             label, color, marker)
    for row in completed[-2:]:
        cycle = int(row["cycle"])
        work = float(row["net_work"])
        work_ax.annotate(f"C{cycle} {work:.2e}", (cycle + 0.16, work), xytext=(-2, 8),
                         textcoords="offset points", ha="right", color=PURPLE, fontsize=8.0,
                         bbox={"facecolor": "white", "edgecolor": "none", "pad": 0.5, "alpha": 0.92})
    tested = [row for row in ledger if not is_accepted(row)]
    if tested:
        work_ax.scatter(cycles(tested), floats(tested, "net_work"), color=ORANGE, marker="x",
                        label="Tested and declined", s=42, zorder=4)
    work_ax.axhline(WORK_FLOOR, color=AXIS, linewidth=0.9, linestyle=":", label="Work floor")
    label_axis(work_ax, "Selected operations", "Work per cycle (symlog)")
    legend_at_top(figure, work_ax, len(work_series) + bool(tested) + 1)

    if completed:
        line(cumulative_ax, cycles(completed), floats(completed, "cumulative_m19_net"), "M19 net", PURPLE, "D")
    label_axis(cumulative_ax, "Cumulative accepted net work", "Cumulative work")

    if control:
        line(control_ax, cycles(control), floats(control, "load_ergotropy"), "Load ergotropy", BLUE)
        line(control_ax, cycles(control), floats(control, "test_total"), "Full-system test work", ORANGE, "s", "--")
        control_bound = max(abs(float(row[field])) for row in control for field in ("load_ergotropy", "test_total"))
        if control_bound <= WORK_FLOOR:
            control_ax.set_ylim(-WORK_FLOOR, WORK_FLOOR)
        legend(control_ax, 2)
    label_axis(control_ax, "Disconnected control", "Ergotropy / test work")

    for ax in (work_ax, cumulative_ax, control_ax):
        style_axis(ax, zero=True)
    control_ax.set_xticks(cycles(ledger))
    control_ax.set_xlabel("Extraction cycle", color=INK)
    save(plt, figure, output, 0)


def candidate_groups(rows):
    grouped = {}
    for row in rows:
        key = int(row["cycle"]), float(row["wait"]), float(row["g"])
        grouped.setdefault(key, []).append(row)
    for group in grouped.values():
        group.sort(key=lambda row: float(row["elapsed"]))
    return grouped


def candidate_label(wait, coupling):
    return f"Wait {wait:g}, $g$ = {coupling:g}"


def plot_trajectories(plt, ledger, candidates, output):
    figure, axes = plt.subplots(3, 3, figsize=(12.0, 8.4), sharex=True)
    title_figure(figure, "Net work across each sampled reconnection window",
                 "The marker identifies the tested choice for that cycle. Each panel uses its own vertical scale.",
                 top=0.81, bottom=0.11, wspace=0.37, hspace=0.37)
    for ax, chosen in zip(axes.flat, ledger):
        cycle = int(chosen["cycle"])
        max_absolute = 0.0
        for wait, coupling in GRID:
            group = candidates[cycle, wait, coupling]
            net = floats(group, "net_work")
            max_absolute = max(max_absolute, max(map(abs, net)))
            ax.plot(floats(group, "elapsed"), net,
                    label=candidate_label(wait, coupling), color=COUPLING_COLORS[coupling],
                    linestyle="--" if wait else "-", linewidth=1.45)
        accepted = is_accepted(chosen)
        ax.scatter(float(chosen["elapsed"]), float(chosen["net_work"]), marker="o" if accepted else "X",
                   s=45, facecolors="white" if accepted else ORANGE, edgecolors=INK, linewidths=1.35, zorder=3)
        status = "" if accepted else " · declined"
        ax.set_title(f"Cycle {cycle}{status}", loc="left", color=INK, fontsize=10.7)
        ax.set_xticks((0, 2, 4, 6, 8))
        ax.set_xlim(-0.16, 8.16)
        style_axis(ax, zero=True)
        ax.locator_params(axis="y", nbins=4)
        ax.tick_params(labelbottom=True, labelsize=8.6)
        if max_absolute <= WORK_FLOOR:
            ax.set_ylim(-WORK_FLOOR, WORK_FLOOR)
    for ax in list(axes.flat)[len(ledger):]:
        ax.set_visible(False)
    figure.supxlabel("Elapsed time after reconnection", y=0.049, color=INK, fontsize=10)
    figure.supylabel("Ideal net work", x=0.027, color=INK, fontsize=10)
    legend_at_top(figure, axes[0, 0], 6)
    save(plt, figure, output, 1)


def plot_maxima(plt, norm_type, rectangle, ledger, candidates, output):
    figure, ax = plt.subplots(figsize=(10.8, 6.3))
    title_figure(figure, "Largest sampled net work for each wait and coupling",
                 "Each cell gives work and elapsed time after reconnection. The outline marks the tested choice.",
                 top=0.84, bottom=0.14)
    row_labels = cycles(ledger)
    peaks = [[max(candidates[cycle, wait, coupling], key=lambda row: float(row["net_work"]))
              for wait, coupling in GRID] for cycle in row_labels]
    peak_work = [floats(row, "net_work") for row in peaks]
    low = min(min(row) for row in peak_work)
    high = max(max(row) for row in peak_work)
    if low < 0.0 < high:
        bound = max(abs(low), high)
        norm = norm_type(WORK_FLOOR, linscale=0.65, vmin=-bound, vmax=bound)
        palette = "RdBu"
    else:
        norm = norm_type(WORK_FLOOR, linscale=0.65, vmin=min(low, 0.0), vmax=max(high, WORK_FLOOR))
        palette = "YlGnBu"
    image = ax.imshow(peak_work, cmap=palette, norm=norm, aspect="auto")
    for y, (work_row, peak_row, chosen) in enumerate(zip(peak_work, peaks, ledger)):
        for x, (work, peak) in enumerate(zip(work_row, peak_row)):
            red, green, blue, _ = image.cmap(image.norm(work))
            brightness = 0.2126 * red + 0.7152 * green + 0.0722 * blue
            color = "white" if brightness < 0.55 else INK
            elapsed = float(peak["elapsed"])
            ax.text(x, y, f"{work:.3e}\n$t_{{\\mathrm{{rec}}}}$ = {elapsed:.2f}", color=color,
                    ha="center", va="center", fontsize=8.35)
        x = GRID.index((float(chosen["wait"]), float(chosen["g"])))
        linestyle = "-" if is_accepted(chosen) else "--"
        ax.add_patch(rectangle((x - 0.485, y - 0.485), 0.97, 0.97, fill=False,
                               edgecolor="white", linewidth=3.3, linestyle=linestyle))
        ax.add_patch(rectangle((x - 0.485, y - 0.485), 0.97, 0.97, fill=False,
                               edgecolor=INK, linewidth=1.25, linestyle=linestyle))
    ax.set_xticks(range(len(GRID)), [f"Wait {wait:g}\n$g$ = {coupling:g}" for wait, coupling in GRID])
    ax.set_yticks(range(len(row_labels)), row_labels)
    ax.set_ylabel("Extraction cycle", color=INK)
    ax.tick_params(length=0, labelcolor=INK, labelsize=9)
    for spine in ax.spines.values():
        spine.set_visible(False)
    scale = figure.colorbar(image, ax=ax, pad=0.027)
    scale.set_label("Sampled net work (symlog)", color=INK, fontsize=9.3)
    scale.ax.yaxis.set_major_formatter(scientific_tick)
    scale.ax.tick_params(labelsize=8, labelcolor=INK, color=AXIS)
    save(plt, figure, output, 2)


def state_progression(states):
    starting = [row for row in states if row["phase"] == "anchor"]
    terminal = sorted((row for row in states if row["phase"] == "after"), key=lambda row: int(row["cycle"]))
    return [*starting[:1], *terminal]


def plot_energy(plt, ledger, states, output):
    figure, axes = plt.subplots(2, 2, figsize=(11.8, 7.7))
    title_figure(figure, "Energy and remaining work after the selected operations",
                 "State diagnostics are sampled after extraction. Positive switch and dissipator terms add system energy.",
                 top=0.85, bottom=0.105, wspace=0.31, hspace=0.32)
    energy_ax, resource_ax, changes_ax, exchange_ax = axes.flat
    progression = state_progression(states)
    state_index = list(range(len(progression)))
    state_labels = [row["cycle"] if row["phase"] == "after" else "Seed" for row in progression]
    for ax, title, ylabel, series in (
        (energy_ax, "Energy change from the M18 anchor", "Energy change",
         (("global_energy", "Full system", BLUE, "o"), ("chain_energy", "Chain", TEAL, "s"),
          ("load_energy", "Load", ORANGE, "^"))),
        (resource_ax, "Remaining ergotropy change from the M18 anchor", "Ergotropy change",
         (("global_ergotropy", "Full system", BLUE, "o"), ("chain_ergotropy", "Chain", TEAL, "s"))),
    ):
        for field, label, color, marker in series:
            data = floats(progression, field)
            if data:
                initial = data[0]
                line(ax, state_index, [value - initial for value in data], f"{label} ({initial:.5g})", color, marker)
        label_axis(ax, title, ylabel)
        ax.set_xticks(state_index, state_labels)
        legend(ax, 2)

    completed = [row for row in ledger if is_accepted(row)]
    index = cycles(completed)
    changes_ax.set_yscale("symlog", linthresh=WORK_FLOOR, linscale=0.65)
    measured_change = [float(row["post_total_energy"]) - float(row["start_total_energy"]) for row in completed]
    accounted = [float(row["dissipative_wait"]) + float(row["dissipative_connected"]) - float(row["net_work"])
                 for row in completed]
    line(changes_ax, index, measured_change, "Measured change", BLUE)
    line(changes_ax, index, accounted, "Dissipator minus net work", ORANGE, "s", "--")
    label_axis(changes_ax, "Per-cycle energy balance", "Energy change (symlog)")
    legend(changes_ax)

    for label, color, marker, evaluate in (
        ("Coupling switches", TEAL, "o", lambda row: float(row["cut_on"]) + float(row["reconnect_on"])),
        ("Dissipator", ORANGE, "s", lambda row: float(row["dissipative_wait"]) + float(row["dissipative_connected"])),
        ("Balance residual", PURPLE, "D", lambda row: float(row["balance_residual"])),
    ):
        line(exchange_ax, index, [evaluate(row) for row in completed], label, color, marker)
    label_axis(exchange_ax, "Signed exchanges and residual", "Energy change")
    legend(exchange_ax)

    for ax in (changes_ax, exchange_ax):
        ax.set_xticks(index)
        ax.set_xlabel("Extraction cycle", color=INK, fontsize=9.5)
    for ax in axes.flat:
        style_axis(ax, zero=True)
    save(plt, figure, output, 3)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=ROOT, help="directory containing the M19 CSV files")
    parser.add_argument("--output", type=Path, help="figure directory (defaults to figures/ under --data)")
    parser.add_argument("--plot-deps", type=Path, help="directory with Matplotlib and its dependencies")
    args = parser.parse_args()
    if args.plot_deps:
        sys.path.insert(0, str(args.plot_deps.resolve()))

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import SymLogNorm
    from matplotlib.patches import Rectangle

    output = args.output or args.data / "figures"
    output.mkdir(parents=True, exist_ok=True)
    for filename in FIGURES:
        if (output / filename).exists():
            raise FileExistsError(output / filename)
    candidates = candidate_groups(read_csv(args.data, "m19_candidates.csv"))
    ledger = sorted(read_csv(args.data, "m19_cycle_ledger.csv"), key=lambda row: int(row["cycle"]))
    states = read_csv(args.data, "m19_state_metrics.csv")
    control = sorted(read_csv(args.data, "m19_control.csv"), key=lambda row: int(row["cycle"]))

    plot_repeated_work(plt, ledger, control, output)
    plot_trajectories(plt, ledger, candidates, output)
    plot_maxima(plt, SymLogNorm, Rectangle, ledger, candidates, output)
    plot_energy(plt, ledger, states, output)


if __name__ == "__main__":
    main()
