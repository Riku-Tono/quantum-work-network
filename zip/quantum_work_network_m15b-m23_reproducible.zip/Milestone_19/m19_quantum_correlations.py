"""Measure chain–load negativity on the saved M19 states.

The load partial transpose swaps the two load indices in the density tensor.
Raw negativity is the sum of absolute negative eigenvalues of that transpose.
Log negativity uses the natural logarithm after normalizing by the stored trace.
A resolved negative eigenvalue witnesses entanglement. Absence of this witness
does not establish separability.
"""

import argparse
import math
from pathlib import Path

from verify_m19 import (
    ANCHOR_SHA,
    CHAIN,
    DIM,
    LOAD,
    SPECTRUM_TOL,
    TOL,
    Audit,
    State,
    max_abs,
    np,
    phase_path,
    read_csv,
    require,
    symmetrize,
    verify_source,
    write_csv,
)


def negativity(state):
    """Return diagnostics and the ascending partial-transpose eigenvalues."""
    require(state.trace_error <= TOL and state.hermiticity_error <= TOL, "Invalid density matrix for partial transpose")
    require(state.spectrum[0] >= -TOL, "Nonpositive density matrix for partial transpose")
    load_transposed = state.matrix.reshape(CHAIN, LOAD, CHAIN, LOAD).transpose(0, 3, 2, 1).reshape(DIM, DIM)
    trace = np.trace(state.matrix).real
    trace_error = abs(np.trace(load_transposed) - np.trace(state.matrix))
    hermiticity_error = max_abs(load_transposed - load_transposed.conj().T)
    require(trace_error <= TOL and hermiticity_error <= TOL, "Partial transpose did not preserve trace or Hermiticity")
    spectrum = np.linalg.eigvalsh(symmetrize(load_transposed))
    spectrum_trace_error = abs(float(spectrum.sum()) - trace)
    require(np.isfinite(spectrum).all() and spectrum_trace_error <= SPECTRUM_TOL, "Invalid partial-transpose eigenspectrum")
    negative = spectrum[spectrum < 0]
    resolved_negative = spectrum[spectrum < -TOL]
    raw = float(-negative.sum()) if negative.size else 0.0
    resolved = float(-resolved_negative.sum()) if resolved_negative.size else 0.0
    return {
        "trace": trace,
        "partial_transpose_trace_error": trace_error,
        "partial_transpose_hermiticity_error": hermiticity_error,
        "partial_transpose_spectrum_trace_error": spectrum_trace_error,
        "partial_transpose_minimum_eigenvalue": spectrum[0],
        "raw_negativity": raw,
        "log_negativity_nats": math.log1p(2 * raw / trace),
        "negative_eigenvalue_count": negative.size,
        "resolution_threshold": TOL,
        "resolved_negative_eigenvalue_count": resolved_negative.size,
        "resolved_negativity": resolved,
        "negativity_witness_status": "NPT_WITNESSED" if resolved_negative.size else "NO_NEGATIVITY_RESOLVED",
    }, spectrum


def correlations(m18, m19):
    audit = Audit()
    official = verify_source(m18, audit)
    require(all(row["status"] == "PASS" for row in audit.rows), "M18 anchor failed its independent checks")
    found = set()
    pre_spectra = {}
    rows = []
    for record in read_csv(m19 / "m19_state_metrics.csv"):
        cycle, phase = int(record["cycle"]), record["phase"]
        key = (cycle, phase)
        require(key not in found, f"Repeated saved phase {key}")
        found.add(key)
        relative = phase_path(cycle, phase, record["filename"])
        time = float(record["time"])
        state = State.read(m19 / relative, time)
        if phase == "anchor":
            require(state.sha256 == official.sha256 == ANCHOR_SHA, "M19 anchor copy differs from M18")
        values, spectrum = negativity(state)
        spectrum_change = ""
        if phase == "before":
            pre_spectra[cycle] = spectrum
        elif phase == "after":
            require(cycle in pre_spectra, f"Missing before-state spectrum in cycle {cycle}")
            spectrum_change = max_abs(spectrum - pre_spectra[cycle])
            require(spectrum_change <= TOL, f"Partial-transpose spectrum changed during the cycle {cycle} local unitary")
        rows.append({
            "cycle": cycle, "phase": phase, "time": record["time"], "g": record["g"],
            "filename": record["filename"], "sha256": state.sha256, **values,
            "before_after_pt_spectrum_max_abs_difference": spectrum_change,
        })
    require((2, "anchor") in found, "Missing archived anchor in M19 state metrics")
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("m18", type=Path, help="published M18 result directory")
    parser.add_argument("m19", type=Path, help="M19 result directory")
    args = parser.parse_args()
    rows = correlations(args.m18, args.m19)
    write_csv(args.m19 / "m19_quantum_correlations.csv", rows)
    resolved = sum(row["negativity_witness_status"] == "NPT_WITNESSED" for row in rows)
    print(f"Negativity resolved in {resolved} of {len(rows)} saved states at threshold {TOL:.0e}.")


if __name__ == "__main__":
    main()
