"""Verify the frozen M19 inputs and solver, then run the selected computation."""

import argparse
import csv
import hashlib
import subprocess
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SOURCE = "R4_observed_max_t1590_after.bin"
SOURCE_SHA = "4C9A5EE8172E505592C43A7B522476715D418CAFA0CC677C04B853E72CC6F9ED"
PINNED_INPUTS = {
    SOURCE: SOURCE_SHA,
    "m18_state_manifest.csv": "9F0512D6ED2D85C85A240869D5DEF20C1177D891C7D626F2D5BC37EC9436D8EC",
    "m18_second_extraction_ledger.csv": "6A1C45F25B9B6A5408DF90402342C28F27920B8F7B184B23B086DE0DE8ED043C",
    "m18_energy_balance.csv": "86ACD899249668C6065489DCC1FCC1CD38CCB4AAECFDFF0CF666CB1AD17B60E8",
    "m18_reconnection_work.csv": "A4B5CCE44F279E928E1BDE18057D7E45037269DCA495B619E7E3C7BAF1879CB0",
}


def digest(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest().upper()


def verify(executable):
    archive = ROOT / "m18_inputs"
    for name, expected in PINNED_INPUTS.items():
        if digest(archive / name) != expected:
            raise ValueError(f"Official M18 SHA-256 mismatch for {name}")
    with (archive / "m18_state_manifest.csv").open(encoding="utf-8-sig", newline="") as file:
        row, = (row for row in csv.DictReader(file) if row["filename"] == f"states/{SOURCE}")
    if (row["sha256"], row["condition"], float(row["time"]), float(row["g"]),
            row["branch"], row["extraction_phase"], int(row["dimension"]), int(row["size_bytes"])) != (
            SOURCE_SHA, "R4", 15.90, 0.25, "observed_max", "after", 384, 2359320):
        raise ValueError("Official manifest metadata mismatch")
    with (ROOT / "m19_precommit_sha256.csv").open(encoding="utf-8-sig", newline="") as file:
        frozen = {row["filename"]: row["sha256"] for row in csv.DictReader(file)}
    for name, expected in frozen.items():
        path = executable if name == "m19_repeated.exe" else ROOT / name
        if digest(path) != expected:
            raise ValueError(f"Frozen file SHA-256 mismatch for {name}")
    if not {"m19_repeated.exe", "PRECOMMIT_M19.md"} <= frozen.keys():
        raise ValueError("Incomplete hash freeze")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("benchmark", "formal"))
    parser.add_argument("executable", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    executable, output = args.executable.resolve(), args.output.resolve()
    if output.exists():
        raise FileExistsError(output)
    verify(executable)
    started = time.perf_counter()
    subprocess.run([executable, args.mode, ROOT / "m18_inputs" / SOURCE, output], check=True)
    verify(executable)
    elapsed = time.perf_counter() - started
    with (output / "m19_batch_runtime.csv").open("x", encoding="utf-8", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(("mode", "elapsed_seconds"))
        writer.writerow((args.mode, f"{elapsed:.9f}"))
    print(f"{args.mode}: complete in {elapsed:.3f} s", flush=True)


if __name__ == "__main__":
    main()
