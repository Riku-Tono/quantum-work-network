"""Synthesize M19's sequential-recovery measurements and energy accounting."""

import argparse
import csv
import hashlib
import math
from collections import defaultdict
from pathlib import Path


TOL = 1e-12
HALF_TOL = 1e-10
W_FIRST = 3.385250121299e-3
SOURCE_STATE = "states/R4_observed_max_t1590_after.bin"
SOURCE_SHA256 = "4C9A5EE8172E505592C43A7B522476715D418CAFA0CC677C04B853E72CC6F9ED"
WAITS = (0.0, 2.0)
COUPLINGS = (0.05, 0.125, 0.25)


def read_csv(path):
    with path.open(newline="", encoding="utf-8-sig") as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows):
    with path.open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def number(row, field):
    value = float(row[field])
    if not math.isfinite(value):
        raise ValueError(f"Nonfinite measurement {field}")
    return value


def fmt(value, digits=6):
    return "—" if value is None else f"{value:.{digits}e}"


def t_fmt(value):
    return "—" if value is None else f"{value:.2f}"


def percent(ratio):
    return "—" if ratio is None else f"{ratio * 100:.6f}%"


def table(headers, rows):
    return [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
        *("| " + " | ".join(str(cell) for cell in row) + " |" for row in rows),
    ]


def historical_inputs(m18):
    state, = (row for row in read_csv(m18 / "m18_state_manifest.csv") if row["filename"] == SOURCE_STATE)
    with (m18 / SOURCE_STATE).open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest().upper()
    if digest != SOURCE_SHA256 or digest != state["sha256"].upper():
        raise ValueError("The official M18 source state does not match its fixed SHA-256")
    ledger, = (
        row for row in read_csv(m18 / "m18_energy_balance.csv")
        if row["condition"] == "R4" and row["branch"] == "observed_max" and number(row, "time") == 15.9
    )
    return ledger, digest


def optional(row, field):
    return number(row, field) if row.get(field) else None


def accepted(row):
    value = row["accepted"].strip().lower()
    if value not in {"true", "false", "1", "0", "yes", "no"}:
        raise ValueError(f"Unknown acceptance indicator {row['accepted']}")
    return value in {"true", "1", "yes"}


def candidate_order(row):
    return -number(row, "net_work"), number(row, "time"), number(row, "wait"), number(row, "g")


def analyze_candidates(candidates, cycles):
    grouped = defaultdict(list)
    for row in candidates:
        key = int(row["cycle"]), number(row, "wait"), number(row, "g")
        grouped[key].append(row)
    expected = {(int(row["cycle"]), wait, g) for row in cycles for wait in WAITS for g in COUPLINGS}
    if grouped.keys() != expected:
        raise ValueError("The candidate grid does not contain the six precommitted protocols for each cycle")
    summary = []
    winners = {}
    by_cycle = {int(row["cycle"]): row for row in cycles}
    for (cycle, wait, g), rows in sorted(grouped.items()):
        rows.sort(key=lambda row: number(row, "elapsed"))
        if len(rows) != 401 or any(abs(number(row, "elapsed") - index * 0.02) > TOL for index, row in enumerate(rows)):
            raise ValueError(f"Candidate time grid mismatch for cycle {cycle}, wait {wait}, g={g}")
        work = [number(row, "net_work") for row in rows]
        load_energy = [number(row, "load_energy") for row in rows]
        local_work = [number(row, "load_ergotropy") for row in rows]
        best = min(rows, key=candidate_order)
        if cycle not in winners or candidate_order(best) < candidate_order(winners[cycle]):
            winners[cycle] = best
        chosen = by_cycle[cycle]
        selected = number(chosen, "wait") == wait and number(chosen, "g") == g
        first = next((number(row, "elapsed") for row in rows if number(row, "net_work") > TOL), None)
        changes = [after - before for before, after in zip(work, work[1:])]
        summary.append({
            "cycle": cycle, "wait": wait, "g": g, "candidate_count": len(rows), "selected_protocol": selected,
            "selected_and_accepted": selected and accepted(chosen),
            "peak_time": number(best, "time"), "peak_elapsed": number(best, "elapsed"),
            "peak_net_work": number(best, "net_work"), "peak_total_work": number(best, "total_work"),
            "peak_gross_work": number(best, "gross_work"), "load_ergotropy_at_net_peak": number(best, "load_ergotropy"),
            "peak_net_first_ratio": number(best, "net_work") / W_FIRST,
            "first_positive_elapsed": first, "final_net_work": work[-1], "max_load_ergotropy": max(local_work),
            "net_positive_count": sum(value > TOL for value in work),
            "net_falling_intervals": sum(change < -TOL for change in changes),
            "net_rising_intervals": sum(change > TOL for change in changes),
            "load_energy_rises_without_ergotropy_increase": sum(
                e_after - e_before > TOL and w_after - w_before <= TOL
                for e_before, e_after, w_before, w_after in zip(load_energy, load_energy[1:], local_work, local_work[1:])
            ),
        })
    return summary, winners


def energy_balance(cycles, history):
    anchor = number(history, "total_energy_after_second")
    work_first = number(history, "first_total_work")
    work_second = number(history, "second_net_work")
    with_cut = number(history, "ideal_total_operation_work_out_including_cut")
    energy_before_first = number(history, "total_energy_initial")
    bath_through_m18 = number(history, "dissipative_energy_change_cumulative")
    historical_cut_work_on = number(history, "m17_cut_work_on")
    historical_storage = number(history, "m17_storage_energy_change")
    pre_cut_energy = number(history, "m17_pre_cut_total_energy")
    bath = 0.0
    running_net = 0.0
    rows = []
    for cycle in [None, *cycles]:
        if cycle is not None and not accepted(cycle):
            continue
        start = anchor if cycle is None else number(cycle, "start_total_energy")
        post = anchor if cycle is None else number(cycle, "post_total_energy")
        cut = 0.0 if cycle is None else number(cycle, "cut_on")
        reconnect = 0.0 if cycle is None else number(cycle, "reconnect_on")
        total = 0.0 if cycle is None else number(cycle, "total_work")
        net = total - cut - reconnect
        q_wait = 0.0 if cycle is None else number(cycle, "dissipative_wait")
        q_connected = 0.0 if cycle is None else number(cycle, "dissipative_connected")
        bath += q_wait + q_connected
        running_net += net
        rows.append({
            "cycle": 2 if cycle is None else int(cycle["cycle"]),
            "time": 15.9 if cycle is None else number(cycle, "time"),
            "start_total_energy": start,
            "pre_total_energy": anchor if cycle is None else number(cycle, "pre_total_energy"), "post_total_energy": post,
            "cut_on": cut, "reconnect_on": reconnect, "net_switch_on": cut + reconnect,
            "gross_work": 0.0 if cycle is None else number(cycle, "gross_work"),
            "interaction_jump": 0.0 if cycle is None else number(cycle, "interaction_jump"),
            "total_work": total, "net_work": net, "dissipative_wait": q_wait, "dissipative_connected": q_connected,
            "dissipative_cumulative_m19": bath, "net_cumulative_m19": running_net,
            "cycle_residual": post - (start - net + q_wait + q_connected),
            "anchor_total_energy": anchor, "anchor_balance_residual": post - (anchor - running_net + bath),
            "historical_first_total_work": work_first, "historical_second_net_work": work_second,
            "net_cumulative_from_first": work_first + work_second + running_net,
            "net_cumulative_including_m17_cut": with_cut + running_net,
            "pre_first_balance_residual": post - (energy_before_first - work_first - work_second - running_net + bath_through_m18 + bath),
            "pre_cut_balance_residual": post - (
                pre_cut_energy + historical_cut_work_on + historical_storage - work_first - work_second
                - running_net + bath_through_m18 + bath
            ),
        })
    return rows


def numerical_checks(cycles, winners, states, control, half, balance, digest, result):
    checks = []

    def record(name, cycle, observed, bound, rule, ok):
        checks.append({"check": name, "cycle": cycle, "observed": observed, "bound": bound,
                       "rule": rule, "status": "PASS" if ok else "FAIL"})

    def absolute(name, cycle, residual, bound=TOL):
        record(name, cycle, abs(residual), bound, "<=", abs(residual) <= bound)

    def equal(name, cycle, observed, expected):
        record(name, cycle, observed, expected, "=", observed == expected)

    half_by_cycle = defaultdict(list)
    for row in half:
        half_by_cycle[int(row["cycle"])].append(row)
    control_by_cycle = {int(row["cycle"]): row for row in control}
    phase_by_cycle = {(int(row["cycle"]), row["phase"]): row for row in states}
    balances = {row["cycle"]: row for row in balance}
    equal("archive_sha256", 2, digest, SOURCE_SHA256)
    indexes = [int(row["cycle"]) for row in cycles]
    equal("sequential_cycle_labels", "ALL", "/".join(map(str, indexes)), "/".join(map(str, range(3, indexes[-1] + 1))))
    equal("third_through_at_most_tenth", "ALL", indexes[-1] <= 10, True)
    equal("stopped_after_first_rejection", "ALL", all(accepted(row) for row in cycles[:-1]), True)
    equal("completed_through_tenth_or_rejected", "ALL", indexes[-1] == 10 or not accepted(cycles[-1]), True)
    equal("control_checkpoint_coverage", "ALL", set(control_by_cycle) == set(indexes), True)
    anchor = phase_by_cycle[2, "anchor"]
    absolute("anchor_stored_load_ergotropy", 2, number(anchor, "load_ergotropy"))
    absolute("anchor_stored_total_energy", 2, number(anchor, "global_energy") - balances[2]["anchor_total_energy"])
    previous_time = 15.9
    previous_total = balances[2]["anchor_total_energy"]
    for row in cycles:
        cycle = int(row["cycle"])
        winner = winners[cycle]
        time = number(row, "time")
        elapsed = number(row, "elapsed")
        absolute("time_continuity", cycle, number(row, "start_time") - previous_time)
        absolute("start_energy_continuity", cycle, number(row, "start_total_energy") - previous_total)
        absolute("cycle_time_identity", cycle, time - number(row, "start_time") - number(row, "wait") - elapsed)
        for field in ("time", "elapsed", "wait", "g", "net_work"):
            absolute(f"strict_maximum_matches_{field}", cycle, number(row, field) - number(winner, field))
        for field in ("gross_work", "total_work"):
            absolute(f"selected_candidate_matches_{field}", cycle, number(row, field) - number(winner, field))
        net = number(row, "net_work")
        net_half = number(row, "net_half")
        candidate_net = number(winner, "net_work")
        margin = candidate_net - abs(candidate_net - net_half)
        if row.get("resolution_margin"):
            absolute("recorded_resolution_margin", cycle, number(row, "resolution_margin") - margin)
        equal("resolvable_net_acceptance", cycle, accepted(row), margin > TOL and net > TOL)
        absolute("switch_subtracted_net", cycle, net - number(row, "total_work") + number(row, "cut_on") + number(row, "reconnect_on"))
        absolute("operation_work_identity", cycle, number(row, "total_work") - number(row, "gross_work") + number(row, "interaction_jump"))
        half_rows = half_by_cycle[cycle]
        equal("half_step_grid_size", cycle, len(half_rows), 401)
        if half_rows:
            half_best = min(half_rows, key=lambda point: (-number(point, "net_half"), number(point, "elapsed")))
            at_selected, = (point for point in half_rows if abs(number(point, "elapsed") - elapsed) <= TOL)
            absolute("nominal_at_selected_time_vs_candidate_grid", cycle, number(at_selected, "net_work") - candidate_net)
            absolute("half_step_at_selected_time_vs_ledger", cycle, number(at_selected, "net_half") - net_half)
            absolute("half_step_peak_net_vs_ledger", cycle, number(half_best, "net_half") - number(row, "half_peak_net"))
            absolute("half_step_peak_elapsed_vs_ledger", cycle, number(half_best, "elapsed") - number(row, "half_peak_elapsed"))
            absolute("half_step_net_max_difference", cycle, max(abs(number(point, "net_work") - number(point, "net_half")) for point in half_rows), HALF_TOL)
            absolute("half_step_ergotropy_max_difference", cycle, max(abs(
                number(point, "load_ergotropy") - number(point, "load_ergotropy_half")
            ) for point in half_rows), HALF_TOL)
            if at_selected.get("state_max_abs_difference"):
                absolute("half_step_before_state_maximum_element_difference", cycle, number(at_selected, "state_max_abs_difference"), HALF_TOL)
        if accepted(row) and row.get("after_state_max_abs_difference"):
            absolute("half_step_after_state_maximum_element_difference", cycle, number(row, "after_state_max_abs_difference"), HALF_TOL)
        if cycle in control_by_cycle:
            negative = control_by_cycle[cycle]
            absolute("control_matches_selected_time", cycle, number(negative, "time") - time)
            for field in ("free_error", "load_ergotropy", "test_gross", "test_total", "test_net"):
                absolute(f"control_{field}", cycle, number(negative, field))
        if accepted(row):
            after = phase_by_cycle[cycle, "after"]
            before = phase_by_cycle[cycle, "before"]
            absolute("load_ergotropy_after_extraction", cycle, number(after, "load_ergotropy"))
            absolute("gross_work_from_load_energy_difference", cycle, number(before, "load_energy") - number(after, "load_energy") - number(row, "gross_work"))
            absolute("total_work_from_global_energy_difference", cycle, number(before, "global_energy") - number(after, "global_energy") - number(row, "total_work"))
            absolute("gross_work_vs_preextraction_ergotropy", cycle, number(before, "load_ergotropy") - number(row, "gross_work"))
            absolute("chain_energy_local_unitary_invariance", cycle, number(before, "chain_energy") - number(after, "chain_energy"))
            absolute("load_purity_local_unitary_invariance", cycle, number(before, "load_purity") - number(after, "load_purity"))
            for field in ("cycle_residual", "anchor_balance_residual", "pre_first_balance_residual", "pre_cut_balance_residual"):
                absolute(field, cycle, balances[cycle][field])
            absolute("cycle_residual_vs_solver_ledger", cycle, balances[cycle]["cycle_residual"] - number(row, "balance_residual"))
            absolute("cumulative_net_vs_solver_ledger", cycle, balances[cycle]["net_cumulative_m19"] - number(row, "cumulative_m19_net"))
            previous_time = time
            previous_total = number(row, "post_total_energy")
    for field in ("trace_error", "hermiticity_error"):
        absolute(field, "ALL", max(number(row, field) for row in states))
    minimum = min(number(row, "minimum_eigenvalue") for row in states)
    record("minimum_eigenvalue", "ALL", minimum, -TOL, ">=", minimum >= -TOL)
    model_checks = result / "m19_model_checks.csv"
    if model_checks.exists():
        for row in read_csv(model_checks):
            absolute(f"{row['check']}_g{row['g']}", "ALL", number(row, "error"), number(row, "tolerance"))
    audit = result / "m19_independent_audit.csv"
    if audit.exists():
        rows = read_csv(audit)
        status_column = next((key for key in ("status", "verdict", "result") if rows and key in rows[0]), None)
        if status_column:
            equal("independent_saved_state_failures", "ALL", sum(row[status_column].upper() != "PASS" for row in rows), 0)
    return checks


def generate_report(cycles, protocols, states, control, balance, checks, history, result, benchmark):
    taken = [row for row in cycles if accepted(row)]
    final = balance[-1]
    anchor, = (row for row in states if row["phase"] == "anchor")
    last_after = next((row for row in states if row["phase"] == "after" and int(row["cycle"]) == final["cycle"]), anchor)
    first = number(history, "first_total_work")
    second = number(history, "second_net_work")
    additional = final["net_cumulative_m19"]
    benefit = final["net_cumulative_from_first"] - first
    completed = final["cycle"]
    rejected = None if accepted(cycles[-1]) else cycles[-1]
    failures = [row for row in checks if row["status"] != "PASS"]
    lines = [
        "# Milestone 19 抽出と再接続を実際に繰り返したときの仕事回収", "",
        f"**M19 で再抽出を実行したのは {len(taken)} 回。M18 の第二回からつないで第 {completed} 回まで進んだ。**"
        f" 再接続と切断の仕事を差し引いた M19 の累計は `{fmt(additional)}`（初回抽出の `{percent(additional / W_FIRST)}`）。"
        f" 初回だけの場合の `{fmt(first)}` に対して、第二回以降を含む累計は `{fmt(final['net_cumulative_from_first'])}`。"
        f" 差は `{fmt(benefit)}`（初回比 `{percent(benefit / W_FIRST)}`）やで。", "",
    ]
    if rejected is not None:
        margin = number(rejected, "resolution_margin")
        lines += [
            f"第 {rejected['cycle']} 回の候補では最大正味 `W={fmt(number(rejected, 'net_work'))}`、"
            f"刻み半減との差を差し引いた値は `{fmt(margin)}`。`1e-12` の採用基準に達しなかったため、そこで停止した。", "",
        ]
    else:
        lines += ["事前に設定した第 10 回までの操作を完了した。", ""]
    lines += [
        "## 入力と操作順序", "",
        "初期状態は M18 R4 `g=0.25`、`t=15.90` の観測最大で行った第二回抽出の直後。"
        "QWNRHO1 の 384×384 全体系状態をそのまま開始状態とし、公開マニフェストと照合した。"
        f" SHA-256 は `{SOURCE_SHA256}`。 [数値監査](m19_numerical_checks.csv)", "",
        "鎖7サイト、負荷3準位、鎖の合計デフェージング率 `1.5`、前史の `Omega=0.18748395731510084`。"
        "各回で直前の抽出後状態を引き継ぎ、切断して `g=0` で `0.00` または `2.00` 待機し、"
        "`g=0.05`、`0.125`、`0.25` のいずれかに再接続した。再接続後の `0.00–8.00` を `0.02` 刻みで比較した。"
        "外部駆動はゼロで、鎖も負荷もリセットしていない。 [事前固定](PRECOMMIT_M19.md)", "",
        "候補の `W_net` は M18 と同じ局所抽出の全ハミルトニアン仕事から、切断と再接続時の符号付き入力仕事を引いた値。"
        "各回の最大値を逐次選び、厳密な同値では絶対時刻が早い点、次に待機、結合が小さい点を優先した。"
        "選択した時刻での `W_net(dt)−|W_net(dt)−W_net(dt/2)|` と、全エネルギー差で再計算した正味仕事が"
        "ともに `1e-12` を超えたときに、その操作を採用した。"
        "候補最大の比較は各回の固定グリッドに限られる。 [全候補](m19_candidates.csv) [逐次台帳](m19_cycle_ledger.csv)", "",
        "## 各回の選択と仕事", "",
    ]
    lines.extend(table(
        ["抽出回", "採用", "開始 t", "待機", "再接続 g", "接続後時間", "絶対時刻", "負荷 gross", "全体系 total", "切替込み net", "net／初回"],
        ([row["cycle"], "採用" if accepted(row) else "棄却", t_fmt(number(row, "start_time")),
          t_fmt(number(row, "wait")), f"{number(row, 'g'):g}", t_fmt(number(row, "elapsed")), t_fmt(number(row, "time")),
          *(fmt(number(row, column)) for column in ("gross_work", "total_work", "net_work")),
          percent(number(row, "net_work") / W_FIRST)] for row in cycles),
    ))
    if len(taken) >= 2:
        nets = [number(row, "net_work") for row in taken]
        rises = sum(after - before > TOL for before, after in zip(nets, nets[1:]))
        falls = sum(before - after > TOL for before, after in zip(nets, nets[1:]))
        ties = len(nets) - 1 - rises - falls
        lines += [
            "", f"採用した隣接回を `1e-12` の同値幅で比べると、増加 {rises}、減少 {falls}、同値 {ties}。"
            f" 第 {taken[0]['cycle']} 回の `{fmt(nets[0])}` から、第 {taken[-1]['cycle']} 回は `{fmt(nets[-1])}` になった。", "",
        ]
        if rises:
            index = max(range(1, len(nets)), key=lambda i: nets[i] - nets[i - 1])
            lines += [
                f"増加幅が最大だったのは第 {taken[index - 1]['cycle']} 回から第 {taken[index]['cycle']} 回。"
                f"正味仕事は `{fmt(nets[index - 1])}` から `{fmt(nets[index])}` へ "
                f"`{nets[index] / nets[index - 1]:.3f}` 倍になった。", "",
            ]
    else:
        lines.append("")
    at_boundary = [row["cycle"] for row in cycles if number(row, "elapsed") in {0.0, 8.0}]
    if at_boundary:
        lines += [f"候補窓の端で最大を取った回は {', '.join(at_boundary)}。", ""]
    immediate_same_g = []
    prior_g = 0.25
    for row in taken:
        if number(row, "wait") == 0 and number(row, "g") == prior_g:
            immediate_same_g.append(row["cycle"])
        prior_g = number(row, "g")
    if immediate_same_g:
        lines += [
            f"採択枝のうち第 {', '.join(immediate_same_g)} 回は、待機時間ゼロで直前と同じ `g` に再接続した。"
            "この場合は同じ状態で切断・再接続の仕事が相殺し、その後の発展は結合を続けた場合と等価。", "",
        ]
    lines += [
        "局所ユニタリの `gross` は負荷エルゴトロピーに対応する。`total` は相互作用エネルギーのジャンプも含み、"
        "`net` は切断と再接続の仕事をさらに反映する。負荷エネルギーと抽出可能仕事の時間変化も候補ごとに記録した。"
        " [仕事の比較](m19_protocol_summary.csv)", "",
        "## 待機・結合・探索窓の比較", "",
        "同じ回の6候補は、その回の同一の全体系状態から分岐する。次の表は再接続後の候補窓内で得た最大正味仕事。", "",
    ]
    protocol_index = {(row["cycle"], row["wait"], row["g"]): row for row in protocols}
    lines.extend(table(
        ["抽出回", *(f"待機 {wait:g}・g={g:g}" for wait in WAITS for g in COUPLINGS)],
        ([row["cycle"], *(
            fmt(protocol_index[int(row["cycle"]), wait, g]["peak_net_work"]) for wait in WAITS for g in COUPLINGS
        )] for row in cycles),
    ))
    comparisons = [
        protocol_index[int(row["cycle"]), 2.0, coupling]["peak_net_work"]
        - protocol_index[int(row["cycle"]), 0.0, coupling]["peak_net_work"]
        for row in cycles for coupling in COUPLINGS
    ]
    waiting_better = sum(change > TOL for change in comparisons)
    waiting_worse = sum(change < -TOL for change in comparisons)
    best_gain = max(comparisons)
    gain_index = comparisons.index(best_gain)
    gain_cycle = cycles[gain_index // len(COUPLINGS)]["cycle"]
    gain_g = COUPLINGS[gain_index % len(COUPLINGS)]
    increases = 0
    for row in cycles:
        for wait in WAITS:
            g_values = [protocol_index[int(row["cycle"]), wait, g]["peak_net_work"] for g in COUPLINGS]
            increases += int(all(right - left > TOL for left, right in zip(g_values, g_values[1:])))
    examples = sum(row["load_energy_rises_without_ergotropy_increase"] for row in protocols)
    finite_wait_useful = sum(
        any(protocol_index[int(row["cycle"]), 2.0, g]["peak_net_work"] > TOL for g in COUPLINGS)
        for row in cycles
    )
    lines += [
        "", f"同じ回・同じ結合で待機を 0 から 2 に延ばすと、候補最大値が増加した比較は {waiting_better}、"
        f"減少は {waiting_worse}、許容差内の同値は {len(comparisons) - waiting_better - waiting_worse}。"
        f" 同じ回・待機で結合を増すたびに候補最大値が増えた枝は {increases}/{2 * len(cycles)}。"
        f" 負荷エネルギーが `1e-12` 超増加し、負荷エルゴトロピーの増加が `1e-12` 以下だった隣接区間は"
        f"全探索軌道で延べ {examples}。", "",
        f"待機 2.00 を選ぶ候補で基準値を超えた回は {finite_wait_useful}/{len(cycles)}。"
        "この比較は各採択開始状態からの一回分の分岐。待機 2.00 のみを選び続ける全操作列とは別になる。", "",
        "## 切断対照と数値収束", "",
        "同じ M18 状態から始めた完全切断対照は最初の一度だけ切断し、再接続せずに選択枝と同じ絶対時刻まで伝播した。"
        "表の対照抽出は比較のための独立な仮想操作で、後続の対照軌道には反映しない。"
        "鎖と負荷が切断された場合の負荷の自由発展を解析式で照合した。 [切断対照](m19_control.csv)", "",
    ]
    if waiting_better:
        position = lines.index("## 切断対照と数値収束")
        lines[position:position] = [
            f"待機での改善が最大だった比較は第 {gain_cycle} 回の `g={gain_g:g}`。"
            f"待機を 0 から 2 に変えた候補最大値の差は `{fmt(best_gain)}`。", "",
        ]
    if control:
        lines.extend(table(
            ["抽出回", "t", "負荷 W", "解析状態差", "負荷 gross", "全体系 total", "切断込み net"],
            ([row["cycle"], t_fmt(number(row, "time")), *(fmt(number(row, key)) for key in (
                "load_ergotropy", "free_error", "test_gross", "test_total", "test_net",
            ))] for row in control),
        ))
        lines.append("")
    lines += [
        "基本の RK4 刻みは `0.0025`、半減刻みは `0.00125`。半減計算では同じ選択時刻と操作順序を引き継ぎ、"
        "各回の選択済み待機・結合を固定したまま半減軌道での候補最大も併記した。 [刻み半減](m19_half_step.csv)", "",
    ]
    lines.extend(table(
        ["抽出回", "選択された接続後時間", "本刻み net", "同時刻の半減 net", "半減での最大点（接続後）", "採用判定値"],
        ([row["cycle"], t_fmt(number(row, "elapsed")), fmt(number(row, "net_work")), fmt(number(row, "net_half")),
          t_fmt(number(row, "half_peak_elapsed")), fmt(number(row, "resolution_margin"))]
         for row in cycles),
    ))
    lines += [
        "", "## 全体系に残る抽出可能仕事", "",
        "全体系エルゴトロピーは、対応する結合 `g` での全ハミルトニアンに対して全体系の固有値を受動配置に並べた場合の仕事。"
        "鎖エルゴトロピーは鎖の縮約状態と鎖のハミルトニアンに対する量。"
        "両者を保存状態から評価し、負荷の局所ユニタリで実際に得た正味仕事と個別に記録した。"
        "この定義では励起数を変える全体ユニタリも許す。ハミルトニアンに負の固有エネルギーがあるため、"
        "受動化で到達できるエネルギーは現在のエネルギーゼロより低くなり得る。 [状態診断](m19_state_metrics.csv) "
        "[Allahverdyan、Balian、Nieuwenhuizen](https://arxiv.org/abs/cond-mat/0401574)", "",
        f"M18 の第二回抽出直後の全体系エルゴトロピーは `{fmt(number(anchor, 'global_ergotropy'))}`、"
        f"第 {completed} 回の抽出直後は `{fmt(number(last_after, 'global_ergotropy'))}`。"
        f"M19 の局所操作で回収した累計は、M19 起点の全体系エルゴトロピーの "
        f"`{percent(additional / number(anchor, 'global_ergotropy'))}`。"
        "各行の全体系エルゴトロピーは表の `g` でその状態から評価した。相互情報量は nats 単位の診断値。", "",
    ]
    lines.extend(table(
        ["抽出回", "状態", "t", "g", "負荷 W", "鎖 W", "全体系 W", "相互情報量"],
        ([row["cycle"], row["phase"], t_fmt(number(row, "time")), f"{number(row, 'g'):g}",
          *(fmt(number(row, k)) for k in ("load_ergotropy", "chain_ergotropy", "global_ergotropy", "mutual_information"))]
         for row in states if row["phase"] in {"anchor", "before", "after"}),
    ))
    quantum_path = result / "m19_quantum_correlations.csv"
    if quantum_path.exists():
        quantum = read_csv(quantum_path)
        witnessed = [row for row in quantum if row["negativity_witness_status"] == "NPT_WITNESSED"]
        quantum_anchor, = (row for row in quantum if row["phase"] == "anchor")
        quantum_last = next(
            (row for row in quantum if row["phase"] == "after" and int(row["cycle"]) == completed),
            quantum_anchor,
        )
        lines += [
            "",
            f"エンタングルメントの診断には負荷で部分転置した密度行列も用いた。"
            f"閾値 `1e-12` で負の固有値を検出したのは全 {len(quantum)} 状態のうち {len(witnessed)} 件。"
            f"ネガティビティは M19 起点で `{fmt(number(quantum_anchor, 'raw_negativity'))}`、"
            f"最後の抽出直後で `{fmt(number(quantum_last, 'raw_negativity'))}`。"
            "検出できた場合はエンタングルメントの証拠になる。相関と仕事の因果関係には別の介入が必要。"
            " [量子相関の診断](m19_quantum_correlations.csv)"
            " [Peres の部分転置基準](https://arxiv.org/abs/quant-ph/9604005)"
            " [Vidal・Werner のネガティビティ](https://arxiv.org/abs/quant-ph/0102117)", "",
        ]
    lines += [
        "", "## エネルギー収支と初回のみの場合との比較", "",
        f"前史の初回全操作仕事は `{fmt(first)}`、M18 の切替を引いた第二回は `{fmt(second)}`。"
        "各回で切断と再接続の入力仕事を足し、切断待機中と接続中の散逸による符号付きエネルギー変化を足し、"
        "抽出の全操作仕事を引いて、次の状態の全エネルギーと照合した。 [エネルギー収支](m19_energy_balance.csv)", "",
    ]
    lines.extend(table(
        ["抽出回", "切断 系へ", "再接続 系へ", "散逸 ΔE 待機", "散逸 ΔE 接続", "残存全 E", "M19 net 累計", "初回からの net 累計", "閉合差"],
        ([row["cycle"], *(fmt(row[key]) for key in (
            "cut_on", "reconnect_on", "dissipative_wait", "dissipative_connected", "post_total_energy",
            "net_cumulative_m19", "net_cumulative_from_first", "anchor_balance_residual",
        ))] for row in balance),
    ))
    lines += [
        "", f"初回までで止めた場合の比較値は `{fmt(first)}`。M17 の保存前切断まで数えた確定累計は"
        f" `{fmt(final['net_cumulative_including_m17_cut'])}`。その閉合差は `{fmt(final['pre_cut_balance_residual'])}`。"
        "散逸による移動も符号付きで測定し、エネルギー会計に含めた。", "",
        "## 監査と保存成果物", "",
        f"集計監査は **{len(checks) - len(failures)}/{len(checks)} 合格**。"
        "時系列候補の選択、完全切断、操作台帳、刻み半減、負荷の受動化、連続するエネルギー収支を照合した。"
        " [集計監査](m19_numerical_checks.csv) [独立監査](m19_independent_audit.csv) [全体系状態マニフェスト](m19_state_manifest.csv)", "",
    ]
    if failures:
        lines += ["要確認項目は " + "、".join(f"{entry['cycle']} {entry['check']}" for entry in failures) + "。", ""]
    independent_path = result / "m19_independent_audit.csv"
    if independent_path.exists():
        audit_rows = read_csv(independent_path)
        lines += [
            f"保存状態から再計算した独立監査は {sum(row['status'] == 'PASS' for row in audit_rows)}/{len(audit_rows)} 合格。"
            f" M19 起点からの採択済み会計の最大残差は "
            f"`{fmt(max(abs(row['anchor_balance_residual']) for row in balance))}`。", "",
        ]
    lines.extend(timing_report(result, benchmark))
    figures = sorted((result / "figures").glob("*.png")) + sorted(result.glob("m19_*.png"))
    if figures:
        lines += ["## グラフ", "", *(f"- [{figure.stem}]({figure.relative_to(result).as_posix()})" for figure in figures), ""]
    lines += [
        "## 再現用ファイル", "",
        "同梱の Windows 実行ファイルを `py -3.14 -B run_m19.py formal ./m19_repeated.exe rerun` で再実行できる。"
        "出力先には新しいフォルダ名を指定する。起点の M18 バイナリと同じ入力を同梱し、"
        "ランチャーが再計算の前後で固定ハッシュを照合する。"
        " [固定 SHA-256](m19_precommit_sha256.csv)", "",
    ]
    lines += ["結論の範囲は、同じ全体系を引き継ぎ、固定された候補窓で逐次選択した有限の理想操作列。", ""]
    return "\n".join(lines)


def timing_report(result, benchmark):
    paths = [result / "m19_runtime.csv"]
    if benchmark is not None:
        paths.insert(0, benchmark / "m19_runtime.csv")
    groups = defaultdict(list)
    for path in paths:
        if path.is_file():
            for row in read_csv(path):
                groups[row["mode"]].append(number(row, "wall_seconds"))
    if not groups:
        return []
    lines = [
        "## 実測時間", "",
        *table(["モード", "記録数", "計測合計（秒）"],
               ([mode, len(elapsed), f"{sum(elapsed):.2f}"] for mode, elapsed in groups.items())),
        "", "各回の探索、刻み半減、対照、計測総時間を分けて記録した。 [実行時間台帳](m19_runtime.csv)", "",
    ]
    if benchmark is not None and (benchmark / "m19_batch_runtime.csv").exists():
        bench, = read_csv(benchmark / "m19_batch_runtime.csv")
        lines += [f"短縮ベンチのバッチ実測は `{number(bench, 'elapsed_seconds'):.2f}` 秒。"
                  "正式実行を始める前に第10回まで約20分と見積もった。 [ベンチ実測](m19_benchmark_runtime.csv)", ""]
    if (result / "m19_batch_runtime.csv").exists():
        formal, = read_csv(result / "m19_batch_runtime.csv")
        lines += [f"正式実行のバッチ経過時間は `{number(formal, 'elapsed_seconds'):.2f}` 秒。"
                  " [バッチ実測](m19_batch_runtime.csv)", ""]
    return lines


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path, help="M19 formal results directory")
    parser.add_argument("m18", type=Path, help="M18 published results directory")
    parser.add_argument("--benchmark", type=Path, help="M19 benchmark results directory")
    phase = parser.add_mutually_exclusive_group()
    phase.add_argument("--tables-only", action="store_true", help="write protocol and energy tables")
    phase.add_argument("--report-only", action="store_true", help="write checks and report after independent audit and plotting")
    args = parser.parse_args()
    result = args.results
    history, digest = historical_inputs(args.m18)
    cycles = read_csv(result / "m19_cycle_ledger.csv")
    states = read_csv(result / "m19_state_metrics.csv")
    protocols, winners = analyze_candidates(read_csv(result / "m19_candidates.csv"), cycles)
    balance = energy_balance(cycles, history)
    tables = {"m19_protocol_summary.csv": protocols, "m19_energy_balance.csv": balance}
    if args.report_only and not all((result / name).is_file() for name in tables):
        raise ValueError("Synthesis tables are missing. Run --tables-only first.")
    outputs = {} if args.report_only else dict(tables)
    checks = []
    if not args.tables_only:
        control = read_csv(result / "m19_control.csv")
        half = read_csv(result / "m19_half_step.csv")
        checks = numerical_checks(cycles, winners, states, control, half, balance, digest, result)
        outputs["m19_numerical_checks.csv"] = checks
        outputs["MILESTONE_19_REPEAT_RECOVERY_REPORT.md"] = generate_report(
            cycles, protocols, states, control, balance, checks, history, result, args.benchmark,
        )
    if any((result / name).exists() for name in outputs):
        raise FileExistsError("An M19 synthesis output already exists")
    for name, content in outputs.items():
        path = result / name
        if isinstance(content, str):
            with path.open("x", newline="\n", encoding="utf-8") as stream:
                stream.write(content)
        else:
            write_csv(path, content)
    failures = [row for row in checks if row["status"] != "PASS"]
    print(f"M19 synthesis: {len(protocols)} protocol rows, {len(balance)} energy rows")
    if checks:
        print(f"M19 numerical checks: {len(checks) - len(failures)}/{len(checks)} pass")
    if failures:
        for row in failures:
            print(f"FAIL cycle {row['cycle']} {row['check']}: {row['observed']} {row['rule']} {row['bound']}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
