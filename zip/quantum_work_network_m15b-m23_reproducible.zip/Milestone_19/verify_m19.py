"""Independently reopen M19 QWNRHO1 states and audit the selected cycle sequence."""

import argparse
import csv
from dataclasses import dataclass
import hashlib
import math
import os
from pathlib import Path, PurePosixPath
import struct

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import numpy as np


N, LOAD = 7, 3
CHAIN = 1 << N
DIM = CHAIN * LOAD
LEVELS = np.arange(LOAD)
HEADER = struct.Struct("<8sQd")
SIZE = HEADER.size + DIM * DIM * 16
TOL = 1e-12
SPECTRUM_TOL = 1e-10
HALF_TOL = 1e-10
SWITCH_TOL = 1e-18
DIRECT_SWITCH_TOL = 1e-15
ANCHOR_TIME = 15.90
ANCHOR_G = 0.25
ANCHOR_NAME = "R4_observed_max_t1590_after.bin"
ANCHOR_SHA = "4C9A5EE8172E505592C43A7B522476715D418CAFA0CC677C04B853E72CC6F9ED"
M18_MANIFEST_SHA = "9F0512D6ED2D85C85A240869D5DEF20C1177D891C7D626F2D5BC37EC9436D8EC"


def require(condition, description):
    if not condition:
        raise ValueError(description)


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows):
    with path.open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def file_digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest().upper()


def max_abs(array):
    return float(np.max(np.abs(array)))


def symmetrize(matrix):
    return (matrix + matrix.conj().T) * 0.5


@dataclass
class State:
    matrix: np.ndarray
    spectrum: np.ndarray
    time: float
    sha256: str

    @classmethod
    def read(cls, path, expected_time):
        data = path.read_bytes()
        require(len(data) == SIZE, f"Unexpected byte count for {path}")
        magic, dimension, time = HEADER.unpack_from(data)
        require(magic == b"QWNRHO1\0" and dimension == DIM, f"Bad density header in {path}")
        require(abs(time - expected_time) <= TOL, f"Unexpected time in {path}: {time}")
        matrix = np.frombuffer(data, dtype="<c16", offset=HEADER.size).reshape(DIM, DIM)
        require(np.isfinite(matrix).all(), f"Nonfinite density values in {path}")
        spectrum = np.linalg.eigvalsh(symmetrize(matrix))
        require(np.isfinite(spectrum).all(), f"Nonfinite eigenvalues in {path}")
        return cls(matrix, spectrum, time, hashlib.sha256(data).hexdigest().upper())

    @property
    def trace_error(self):
        return abs(np.trace(self.matrix) - 1)

    @property
    def hermiticity_error(self):
        return max_abs(self.matrix - self.matrix.conj().T)


class Audit:
    def __init__(self):
        self.rows = []

    def error(self, cycle, phase, label, value, tolerance=TOL):
        value = float(value)
        self.rows.append({
            "cycle": cycle, "phase": phase, "check": label, "observed": value, "bound": tolerance,
            "rule": "<=", "status": "PASS" if math.isfinite(value) and 0 <= value <= tolerance else "FAIL",
        })

    def state(self, cycle, phase, state):
        self.error(cycle, phase, "trace_error", state.trace_error)
        self.error(cycle, phase, "hermiticity_error", state.hermiticity_error)
        self.error(cycle, phase, "negative_eigenvalue_magnitude", max(0, -state.spectrum[0]))
        self.error(cycle, phase, "spectrum_trace_residual", abs(state.spectrum.sum() - np.trace(state.matrix).real), SPECTRUM_TOL)

    def compare(self, cycle, phase, row, derived):
        for name, value in derived.items():
            self.error(cycle, phase, f"{name}_vs_independent", abs(float(row[name]) - value))


def partial_traces(matrix):
    blocks = matrix.reshape(CHAIN, LOAD, CHAIN, LOAD)
    terminal_blocks = matrix.reshape(CHAIN // 2, 2 * LOAD, CHAIN // 2, 2 * LOAD)
    return (
        np.trace(blocks, axis1=0, axis2=2),
        np.trace(blocks, axis1=1, axis2=3),
        np.trace(terminal_blocks, axis1=0, axis2=2),
    )


def expectation(matrix, operator):
    return float(np.sum(matrix * operator.T).real)


def entropy(spectrum):
    positive = spectrum[spectrum > 0]
    populations = positive / positive.sum()
    return float(-np.dot(populations, np.log(populations)))


class Model:
    def __init__(self):
        self.chain_onsite = np.diag([basis.bit_count() for basis in range(CHAIN)])
        self.chain_h = self.chain_onsite.astype(float)
        for basis in range(CHAIN):
            for site in range(N - 1):
                if ((basis >> site) ^ (basis >> (site + 1))) & 1:
                    self.chain_h[basis ^ (3 << site), basis] = 1.0
        self.chain_levels = np.linalg.eigvalsh(self.chain_h)
        raise_spin = np.array([[0, 0], [1, 0]])
        lower_load = np.diag(np.sqrt(LEVELS[1:]), k=1)
        exchange = np.kron(raise_spin, lower_load)
        self.exchange = exchange + exchange.T
        self.exchange_full = np.kron(np.eye(CHAIN // 2), self.exchange)
        terminal_load = np.diag(np.tile(LEVELS, 2))
        self.current = 1j * (self.exchange @ terminal_load - terminal_load @ self.exchange)
        self.base = np.kron(self.chain_h, np.eye(LOAD)) + np.kron(np.eye(CHAIN), np.diag(LEVELS))
        self.global_levels = {}

    def levels(self, g):
        if g not in self.global_levels:
            self.global_levels[g] = np.linalg.eigvalsh(self.base + g * self.exchange_full)
        return self.global_levels[g]

    def scalars(self, state, g):
        load, chain, terminal = partial_traces(state.matrix)
        load_spec = np.linalg.eigvalsh(symmetrize(load))
        chain_spec = np.linalg.eigvalsh(symmetrize(chain))
        load_energy = float(LEVELS @ np.diag(load).real)
        chain_energy = expectation(chain, self.chain_h)
        exchange = expectation(terminal, self.exchange)
        total = load_energy + chain_energy + g * exchange
        return {
            "load_ergotropy": load_energy - float(LEVELS @ load_spec[::-1]),
            "load_energy": load_energy,
            "load_purity": float(np.sum(np.abs(load) ** 2)),
            "chain_energy": chain_energy,
            "chain_ergotropy": chain_energy - float(self.chain_levels @ chain_spec[::-1]),
            "global_energy": total,
            "global_ergotropy": total - float(self.levels(g) @ state.spectrum[::-1]),
            "mutual_information": entropy(chain_spec) + entropy(load_spec) - entropy(state.spectrum),
            "trace_error": state.trace_error,
            "hermiticity_error": state.hermiticity_error,
            "minimum_eigenvalue": state.spectrum[0],
        }

    def exchange_expectation(self, state):
        _, _, terminal = partial_traces(state.matrix)
        return expectation(terminal, self.exchange)

    def excitation(self, state):
        load, chain, _ = partial_traces(state.matrix)
        return expectation(chain, self.chain_onsite) + float(LEVELS @ np.diag(load).real)

    def energy(self, state, g):
        return expectation(state.matrix, self.base) + g * self.exchange_expectation(state)


def verify_source(m18, audit):
    manifest = m18 / "m18_state_manifest.csv"
    require(file_digest(manifest) == M18_MANIFEST_SHA, "Official M18 state-manifest SHA-256 mismatch")
    row, = (row for row in read_csv(manifest) if row["filename"] == f"states/{ANCHOR_NAME}")
    require(
        row["condition"] == "R4" and row["branch"] == "observed_max" and row["extraction_phase"] == "after"
        and float(row["g"]) == ANCHOR_G and float(row["time"]) == ANCHOR_TIME
        and int(row["dimension"]) == DIM and int(row["size_bytes"]) == SIZE and row["format_version"] == "QWNRHO1/1",
        "Unexpected M18 anchor manifest metadata",
    )
    state = State.read(m18 / "states" / ANCHOR_NAME, ANCHOR_TIME)
    require(state.sha256 == row["sha256"].upper() == ANCHOR_SHA, "Official M18 source SHA-256 mismatch")
    audit.error(2, "official_anchor", "manifest_and_state_sha256_mismatch", 0, 0)
    audit.state(2, "official_anchor", state)
    return state


def phase_path(cycle, phase, name):
    relative = PurePosixPath(name)
    require(not relative.is_absolute() and ".." not in relative.parts and "\\" not in name, f"Invalid state path {name}")
    if phase == "anchor":
        require(cycle == 2 and relative == PurePosixPath("m18_inputs") / ANCHOR_NAME, "Unexpected M19 anchor path")
    else:
        require(phase in {"wait_end", "before", "after", "control"} and relative.parts[0] == "states", f"Unexpected saved-state phase or path {name}")
    return relative


def verify_states(results, audit, model):
    states, rows, manifest = {}, {}, []
    for row in read_csv(results / "m19_state_metrics.csv"):
        cycle, phase = int(row["cycle"]), row["phase"]
        key = (cycle, phase)
        require(key not in states, f"Duplicate saved-state key {key}")
        name = row["filename"]
        state = State.read(results / phase_path(cycle, phase, name), float(row["time"]))
        g = float(row["g"])
        audit.state(cycle, phase, state)
        audit.compare(cycle, phase, row, model.scalars(state, g))
        states[key], rows[key] = state, row
        physical = state.trace_error <= TOL and state.hermiticity_error <= TOL and state.spectrum[0] >= -TOL
        manifest.append({
            "cycle": cycle, "phase": phase, "time": row["time"], "g": g, "filename": name,
            "sha256": state.sha256, "source_initial_state_sha256": ANCHOR_SHA, "size_bytes": SIZE,
            "dimension": DIM, "subsystem_dims": "2,2,2,2,2,2,2,3", "format_version": "QWNRHO1/1",
            "tensor_order": "|q1,...,q7,load>; load fastest", "layout": "row-major little-endian complex f64",
            "trace_error": state.trace_error, "hermiticity_error": state.hermiticity_error,
            "minimum_eigenvalue": state.spectrum[0], "positivity_status": "PASS" if physical else "FAIL",
            "independent_eigensolver": "numpy.linalg.eigvalsh (LAPACK)",
        })
    filenames = {row["filename"] for row in manifest}
    require(len(filenames) == len(states), "Repeated state filename")
    written = {path.relative_to(results).as_posix() for path in (results / "states").rglob("*.bin")}
    require(written == filenames - {f"m18_inputs/{ANCHOR_NAME}"}, "Saved-state inventory differs from metrics CSV")
    require(states[2, "anchor"].sha256 == ANCHOR_SHA, "M19 local anchor does not match M18")
    return states, rows, manifest


def free_load_error(before, after):
    load_before, _, _ = partial_traces(before.matrix)
    load_after, _, _ = partial_traces(after.matrix)
    phase = np.exp(-1j * LEVELS * (after.time - before.time))
    expected = phase[:, None] * load_before * phase[None, :].conj()
    return max_abs(load_after - expected)


def extraction(audit, model, cycle, before, after, g):
    load_before, chain_before, _ = partial_traces(before.matrix)
    values, vectors = np.linalg.eigh(symmetrize(load_before))
    vectors = vectors[:, ::-1]
    for vector in vectors.T:
        magnitudes = np.abs(vector)
        pivot = np.flatnonzero(magnitudes == np.max(magnitudes))[-1]
        vector *= vector[pivot].conjugate() / magnitudes[pivot]
    unitary = vectors.conj().T
    rotated = np.einsum(
        "ai,xiyj,bj->xayb", unitary, before.matrix.reshape(CHAIN, LOAD, CHAIN, LOAD), unitary.conj(), optimize=True,
    ).reshape(DIM, DIM)
    if after is not None:
        audit.error(cycle, "extraction", "full_local_unitary_mapping", max_abs(after.matrix - rotated))
        audit.error(cycle, "extraction", "full_spectrum_preservation", max_abs(before.spectrum - after.spectrum))
    else:
        after = State(rotated, before.spectrum, before.time, "")
    load_after, chain_after, _ = partial_traces(after.matrix)
    audit.error(cycle, "extraction", "load_passive_mapping", max_abs(load_after - np.diag(values[::-1])))
    audit.error(cycle, "extraction", "chain_reduced_matrix_preservation", np.linalg.norm(chain_before - chain_after))
    gross = float(LEVELS @ np.diag(load_before - load_after).real)
    interaction_jump = g * (model.exchange_expectation(after) - model.exchange_expectation(before))
    total_work = model.energy(before, g) - model.energy(after, g)
    audit.error(cycle, "extraction", "operation_work_identity", abs(total_work - gross + interaction_jump))
    audit.error(cycle, "extraction", "gross_matches_initial_ergotropy", abs(gross - model.scalars(before, g)["load_ergotropy"]))
    audit.error(cycle, "extraction", "residual_load_ergotropy", abs(model.scalars(after, g)["load_ergotropy"]))
    return gross, interaction_jump, total_work, after


def verify_sequence(results, audit, model, states, metrics):
    rounds = sorted(read_csv(results / "m19_cycle_ledger.csv"), key=lambda row: int(row["cycle"]))
    controls = {int(row["cycle"]): row for row in read_csv(results / "m19_control.csv")}
    anchor = states[2, "anchor"]
    previous, previous_g = anchor, ANCHOR_G
    control_cut = -ANCHOR_G * model.exchange_expectation(anchor)
    audit.error(2, "anchor", "initial_load_passivity", abs(model.scalars(previous, previous_g)["load_ergotropy"]))
    require(float(metrics[2, "anchor"]["g"]) == ANCHOR_G, "M19 local anchor coupling mismatch")
    cumulative, cumulative_bath, stopped = 0.0, 0.0, False
    selected_states = {}
    for cycle, row in enumerate(rounds, start=3):
        require(cycle == int(row["cycle"]) and not stopped, "Cycle ledger skips a cycle or continues after rejection")
        accepted = row["accepted"]
        require(accepted in ("YES", "NO"), f"Unknown acceptance indicator {accepted}")
        g, wait, elapsed = (float(row[key]) for key in ("g", "wait", "elapsed"))
        audit.error(cycle, "sequence", "start_matches_previous_state_time", abs(float(row["start_time"]) - previous.time))
        audit.error(cycle, "sequence", "operation_timestamp", abs(float(row["time"]) - (previous.time + wait + elapsed)))
        initial = model.energy(previous, previous_g)
        cut = -previous_g * model.exchange_expectation(previous)
        audit.error(cycle, "cut", "cut_on_vs_linear", abs(float(row["cut_on"]) - cut), SWITCH_TOL)
        audit.error(cycle, "cut", "cut_on_vs_hamiltonian_difference", abs(model.energy(previous, 0) - initial - cut), DIRECT_SWITCH_TOL)
        audit.error(cycle, "sequence", "start_total_energy_vs_anchor", abs(initial - float(row["start_total_energy"])))

        control = controls[cycle]
        control_state = states[cycle, "control"]
        require(control["filename"] == metrics[cycle, "control"]["filename"], f"Control filename mismatch in cycle {cycle}")
        require(float(metrics[cycle, "control"]["g"]) == 0, f"Control is coupled in cycle {cycle}")
        free = free_load_error(anchor, control_state)
        control_observables = model.scalars(control_state, 0)
        audit.error(cycle, "control", "free_load_analytic_error", free)
        audit.error(cycle, "control", "control_cut_on_vs_linear", abs(control_cut - float(control["cut_on"])), SWITCH_TOL)
        audit.error(cycle, "control", "control_matches_proposal_time", abs(control_state.time - float(row["time"])))
        audit.error(cycle, "control", "control_excitation_conservation", abs(model.excitation(control_state) - model.excitation(anchor)))
        audit.compare(cycle, "control", control, {
            "time": control_state.time, "load_ergotropy": control_observables["load_ergotropy"],
            "load_energy": control_observables["load_energy"], "free_error": free,
            "test_gross": 0, "test_total": 0, "test_net": -control_cut,
        })

        wait_end, before = (states[cycle, phase] for phase in ("wait_end", "before"))
        after = states.get((cycle, "after"))
        require((after is not None) == (accepted == "YES"), f"Cycle {cycle} passivated or missed an accepted state")
        require(bool(row["after_state"]) == (accepted == "YES"), f"Cycle {cycle} after link differs from acceptance")
        for phase in (("before", "after") if after is not None else ("before",)):
            require(row[f"{phase}_state"] == metrics[cycle, phase]["filename"], f"Missing or mismatched state link for cycle {cycle} {phase}")
            require(float(metrics[cycle, phase]["g"]) == g, f"Coupling mismatch for cycle {cycle} {phase}")
            audit.error(cycle, phase, "timestamp_vs_cycle_ledger", abs(states[cycle, phase].time - float(row["time"])))
        require(float(metrics[cycle, "wait_end"]["g"]) == 0, f"Inter-cycle wait is coupled in cycle {cycle}")
        audit.error(cycle, "wait_end", "timestamp_vs_wait", abs(wait_end.time - previous.time - wait))
        audit.error(cycle, "wait_end", "free_load_analytic_error", free_load_error(previous, wait_end))
        audit.error(cycle, "wait_end", "total_excitation_conservation", abs(model.excitation(wait_end) - model.excitation(previous)))
        audit.error(cycle, "before", "total_excitation_conservation", abs(model.excitation(before) - model.excitation(wait_end)))
        if wait == 0:
            audit.error(cycle, "wait_end", "zero_wait_state_sha256_mismatch", int(wait_end.sha256 != previous.sha256), 0)

        reconnect = g * model.exchange_expectation(wait_end)
        audit.error(cycle, "reconnection", "reconnect_on_vs_linear", abs(float(row["reconnect_on"]) - reconnect), SWITCH_TOL)
        audit.error(cycle, "reconnection", "reconnect_on_vs_hamiltonian_difference", abs(model.energy(wait_end, g) - model.energy(wait_end, 0) - reconnect), DIRECT_SWITCH_TOL)
        dissipative_wait = model.energy(wait_end, 0) - model.energy(previous, 0)
        pre = model.energy(before, g)
        dissipative_connected = pre - model.energy(wait_end, g)
        gross, jump, total_work, rotated = extraction(audit, model, cycle, before, after, g)
        post = model.energy(rotated, g)
        net = total_work - cut - reconnect
        bath_ledger = float(row["dissipative_wait"]) + float(row["dissipative_connected"])
        if accepted == "YES":
            cumulative += net
            cumulative_bath += bath_ledger
            previous, previous_g = after, g
            expected_cumulative_energy = model.energy(anchor, ANCHOR_G) + cumulative_bath - cumulative
            audit.error(cycle, "sequence", "cumulative_anchor_energy_balance", abs(post - expected_cumulative_energy))
        else:
            stopped = True
        predicted_post = initial + cut + reconnect + bath_ledger - total_work
        audit.error(cycle, "sequence", "independent_energy_balance", abs(post - predicted_post))
        audit.compare(cycle, "sequence", row, {
            "pre_total_energy": pre, "post_total_energy": post, "reconnect_on": reconnect,
            "gross_work": gross, "interaction_jump": jump, "total_work": total_work, "net_work": net,
            "dissipative_wait": dissipative_wait, "dissipative_connected": dissipative_connected,
            "cumulative_m19_net": cumulative, "balance_residual": post - predicted_post,
        })
        selected_states[cycle] = before
    require(controls.keys() == {int(row["cycle"]) for row in rounds}, "Control/cycle coverage mismatch")
    require(rounds and 3 <= int(rounds[-1]["cycle"]) <= 10, "M19 cycle count exceeds its plan")
    require(stopped or int(rounds[-1]["cycle"]) == 10, "M19 finishes before completing all allowed accepted cycles")
    expected_states = {(2, "anchor")}
    for row in rounds:
        cycle = int(row["cycle"])
        expected_states.update((cycle, phase) for phase in ("wait_end", "before", "control"))
        if row["accepted"] == "YES":
            expected_states.add((cycle, "after"))
    require(states.keys() == expected_states, "Cycle ledger does not explain the saved states")
    return rounds, selected_states


def tick(time):
    value = float(time)
    ticks = round(value * 100)
    require(abs(value - ticks / 100) <= TOL, f"Off-grid clock value {time}")
    return ticks


def by_cycle(path, numeric_columns):
    indexed = {}
    for row in read_csv(path):
        cycle = int(row["cycle"])
        require(all(math.isfinite(float(row[name])) for name in numeric_columns), f"Nonfinite {path.name} value in cycle {cycle}")
        indexed.setdefault(cycle, []).append(row)
    return indexed


def verify_grid(selection, candidates, half):
    cycle = int(selection["cycle"])
    start = tick(selection["start_time"])
    protocols = {(wait, g) for wait in (0.0, 2.0) for g in (0.05, 0.125, 0.25)}
    clock = set(range(0, 801, 2))
    indexed = {}
    for row in candidates:
        wait, g, elapsed = float(row["wait"]), float(row["g"]), tick(row["elapsed"])
        key = (wait, g, elapsed)
        require(key not in indexed, f"Repeated candidate in cycle {cycle}: {key}")
        require(tick(row["time"]) == start + tick(wait) + elapsed, f"Incorrect candidate time in cycle {cycle}")
        indexed[key] = row
    expected = {(wait, g, elapsed) for wait, g in protocols for elapsed in clock}
    require(indexed.keys() == expected, f"Cycle {cycle} candidate grid is incomplete")
    best = min(candidates, key=lambda row: (-float(row["net_work"]), tick(row["time"]), float(row["wait"]), float(row["g"])))
    select_key = (float(selection["wait"]), float(selection["g"]), tick(selection["elapsed"]))
    require(best is indexed[select_key] and tick(best["time"]) == tick(selection["time"]), f"Cycle {cycle} selected candidate breaches ranking")
    half_by_time = {tick(row["elapsed"]): row for row in half}
    require(len(half) == len(half_by_time) and half_by_time.keys() == clock, f"Cycle {cycle} half-step grid is incomplete")
    return indexed, select_key, half_by_time


def verify_candidates(results, audit, model, rounds, selected_states):
    measures = ("load_ergotropy", "load_energy", "load_purity", "gross_work", "total_work", "net_work", "dissipative_energy", "load_current")
    candidates = by_cycle(results / "m19_candidates.csv", measures)
    half = by_cycle(results / "m19_half_step.csv", ("net_work", "net_half", "load_ergotropy", "load_ergotropy_half"))
    expected_cycles = {int(row["cycle"]) for row in rounds}
    require(candidates.keys() == half.keys() == expected_cycles, "Candidate or half-step cycles do not match cycle ledger")
    for row in rounds:
        cycle = int(row["cycle"])
        indexed, key, half_by_time = verify_grid(row, candidates[cycle], half[cycle])
        wait, g, elapsed = key
        proposal = indexed[key]
        pose = selected_states[cycle]
        observations = model.scalars(pose, g)
        _, _, terminal = partial_traces(pose.matrix)
        current = g * expectation(terminal, model.current)
        audit.compare(cycle, "candidates", proposal, {
            **{name: observations[name] for name in measures[:3]},
            **{name: float(row[name]) for name in ("gross_work", "total_work", "net_work")},
            "dissipative_energy": float(row["dissipative_connected"]), "load_current": current,
        })
        net_difference, ergotropy_difference, state_differences = [], [], {}
        for tick_elapsed, fine in half_by_time.items():
            base = indexed[wait, g, tick_elapsed]
            require(tick(fine["time"]) == tick(base["time"]), f"Cycle {cycle} half-step offset differs from nominal")
            require(abs(float(fine["net_work"]) - float(base["net_work"])) <= TOL, f"Cycle {cycle} half-step nominal work column differs")
            require(abs(float(fine["load_ergotropy"]) - float(base["load_ergotropy"])) <= TOL, f"Cycle {cycle} half-step nominal ergotropy column differs")
            net_difference.append(abs(float(fine["net_half"]) - float(base["net_work"])))
            ergotropy_difference.append(abs(float(fine["load_ergotropy_half"]) - float(base["load_ergotropy"])))
            if fine["state_max_abs_difference"]:
                state_differences[tick_elapsed] = float(fine["state_max_abs_difference"])
        audit.error(cycle, "half_step", "net_work_dt_half_max_error", max(net_difference), HALF_TOL)
        audit.error(cycle, "half_step", "load_ergotropy_dt_half_max_error", max(ergotropy_difference), HALF_TOL)
        require(state_differences.keys() == {elapsed}, f"Cycle {cycle} half-step selected state difference coverage is incorrect")
        for tick_elapsed, difference in state_differences.items():
            audit.error(cycle, "half_step", f"state_matrix_dt_half_error_at_{tick_elapsed / 100:.2f}", difference, HALF_TOL)
        net_half = float(half_by_time[elapsed]["net_half"])
        peak_elapsed = min(half_by_time, key=lambda t: (-float(half_by_time[t]["net_half"]), t))
        margin = float(proposal["net_work"]) - abs(float(proposal["net_work"]) - net_half)
        derived = {
            "net_half": net_half, "half_peak_net": float(half_by_time[peak_elapsed]["net_half"]),
            "half_peak_elapsed": peak_elapsed / 100,
        }
        if "resolution_margin" in row:
            derived["resolution_margin"] = margin
        audit.compare(cycle, "half_step", row, derived)
        require((row["accepted"] == "YES") == (margin > TOL and float(row["net_work"]) > TOL),
                f"Cycle {cycle} acceptance differs from numerical-resolution rule")
        for reference, compared in (
            ("cut_on", "cut_half"), ("reconnect_on", "reconnect_half"),
            ("dissipative_wait", "dissipative_wait_half"), ("dissipative_connected", "dissipative_connected_half"),
        ):
            if row.get(compared):
                audit.error(cycle, "half_step", f"{reference}_dt_half_error", abs(float(row[reference]) - float(row[compared])), HALF_TOL)
        after_delta = row.get("after_state_max_abs_difference")
        if after_delta:
            audit.error(cycle, "half_step", "postpassivation_state_dt_half_error", float(after_delta), HALF_TOL)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("m18", type=Path, help="published M18 result directory")
    parser.add_argument("m19", nargs="?", type=Path, help="M19 artifact directory")
    parser.add_argument("--read-only", action="store_true", help="run checks without writing audit artifacts")
    args = parser.parse_args()
    audit = Audit()
    verify_source(args.m18, audit)
    if args.m19 is not None:
        model = Model()
        states, metrics, manifest = verify_states(args.m19, audit, model)
        rounds, selected_states = verify_sequence(args.m19, audit, model, states, metrics)
        verify_candidates(args.m19, audit, model, rounds, selected_states)
        if not args.read_only:
            write_csv(args.m19 / "m19_state_manifest.csv", manifest)
            write_csv(args.m19 / "m19_independent_audit.csv", audit.rows)
    failures = [row for row in audit.rows if row["status"] == "FAIL"]
    for row in failures:
        print(row)
    print(f"Independent LAPACK verification: {len(audit.rows) - len(failures)}/{len(audit.rows)} checks passed.")
    return bool(failures)


if __name__ == "__main__":
    raise SystemExit(main())
