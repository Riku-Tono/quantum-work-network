"""Independently verify the four saved M17 density matrices with NumPy."""

import argparse
import csv
import hashlib
from pathlib import Path
import struct
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "plot-deps"))
import numpy as np


CHAIN = 128
LOAD = 3
DIM = CHAIN * LOAD
TOL = 1e-12
LOAD_LEVELS = np.arange(LOAD)
SHARED_SHA256 = "db695f6a8f90b08248748118d4d786855eae5335666c5f76fcab789c3b014250"
BRANCHES = (("C4", "g001", 0.01), ("C5", "g000", 0.0))


def read_state(path, expected_time):
    data = path.read_bytes()
    if len(data) != 24 + 16 * DIM * DIM:
        raise ValueError(f"Invalid byte length for {path.name}: {len(data)}")
    magic, dimension, time = struct.unpack_from("<8sQd", data)
    if (magic, dimension, time) != (b"QWNRHO1\0", DIM, expected_time):
        raise ValueError(f"Invalid magic, dimension or time for {path.name}")
    matrix = np.frombuffer(data, dtype="<c16", offset=24).reshape(DIM, DIM)
    if not np.isfinite(matrix).all():
        raise ValueError(f"Nonfinite matrix entries in {path.name}")
    return matrix, hashlib.sha256(data).hexdigest()


def max_abs(matrix):
    return float(np.max(np.abs(matrix)))


def hermitian_part(matrix):
    return (matrix + matrix.conj().T) * 0.5


def check(protocol, name, error, limit=TOL):
    error = float(error)
    return {
        "protocol": protocol, "check": name, "value": error, "limit": limit,
        "status": "PASS" if np.isfinite(error) and 0 <= error <= limit else "FAIL",
    }


def reduced_load(matrix):
    blocks = matrix.reshape(CHAIN, LOAD, CHAIN, LOAD)
    return np.trace(blocks, axis1=0, axis2=2)


def reduced_chain(matrix):
    blocks = matrix.reshape(CHAIN, LOAD, CHAIN, LOAD)
    return np.trace(blocks, axis1=1, axis2=3)


def reduced_site7_load(matrix):
    blocks = matrix.reshape(CHAIN // 2, 2 * LOAD, CHAIN // 2, 2 * LOAD)
    return np.trace(blocks, axis1=0, axis2=2)


def passive_rotation(load):
    values, vectors = np.linalg.eigh(hermitian_part(load))
    values, vectors = values[::-1], vectors[:, ::-1]
    for vector in vectors.T:
        magnitudes = np.abs(vector)
        pivot = np.flatnonzero(magnitudes == np.max(magnitudes))[-1]
        vector *= vector[pivot].conjugate() / magnitudes[pivot]
    return np.diag(values), vectors.conj().T


def chain_hamiltonian():
    hamiltonian = np.zeros((CHAIN, CHAIN))
    for basis in range(CHAIN):
        hamiltonian[basis, basis] = basis.bit_count()
        for site in range(6):
            if ((basis >> site) ^ (basis >> (site + 1))) & 1:
                other = basis ^ (3 << site)
                hamiltonian[other, basis] = 1.0
    return hamiltonian


def interaction_hamiltonian(g):
    plus = np.array([[0, 0], [1, 0]])
    annihilation = np.diag(np.sqrt(LOAD_LEVELS[1:]), k=1)
    exchange = np.kron(plus, annihilation)
    return g * (exchange + exchange.T)


def energy_ledger(matrix, coupling, chain_h):
    load_energy = float(np.dot(LOAD_LEVELS, np.diag(reduced_load(matrix))).real)
    interaction = float(np.sum(reduced_site7_load(matrix) * interaction_hamiltonian(coupling).T).real)
    chain_energy = float(np.sum(reduced_chain(matrix) * chain_h.T).real)
    return load_energy, interaction, load_energy + interaction + chain_energy


def inspect_pair(path, protocol, prefix, coupling, shared_load, chain_h, archived):
    before, before_hash = read_state(path / f"{prefix}_t1000_before.bin", 10.00)
    after, after_hash = read_state(path / f"{prefix}_t1000_after.bin", 10.00)
    before_spectrum = np.linalg.eigvalsh(hermitian_part(before))
    after_spectrum = np.linalg.eigvalsh(hermitian_part(after))
    checks = []
    for phase, matrix, spectrum in (
        ("before", before, before_spectrum), ("after", after, after_spectrum),
    ):
        checks.extend((
            check(protocol, f"{phase}_trace_error", abs(np.trace(matrix) - 1)),
            check(protocol, f"{phase}_hermiticity_error", max_abs(matrix - matrix.conj().T)),
            check(protocol, f"{phase}_negative_eigenvalue_magnitude", max(0, -spectrum[0])),
        ))
        print(f"{protocol} {phase}: SHA-256 {(before_hash if phase == 'before' else after_hash)}; minimum eigenvalue {spectrum[0]:.4e}")

    passive, unitary = passive_rotation(reduced_load(before))
    rotated = np.einsum(
        "ai,xiyj,bj->xayb", unitary, before.reshape(CHAIN, LOAD, CHAIN, LOAD),
        unitary.conj(), optimize=True,
    ).reshape(DIM, DIM)
    checks.extend((
        check(protocol, "full_local_passivation_max_abs_error", max_abs(after - rotated)),
        check(protocol, "full_spectrum_preservation_max_abs_error", max_abs(before_spectrum - after_spectrum)),
        check(protocol, "load_passive_mapping_max_abs_error", max_abs(reduced_load(after) - passive)),
        check(protocol, "chain_preservation_frobenius_error", np.linalg.norm(reduced_chain(before) - reduced_chain(after))),
        check(protocol, "local_unitarity_frobenius_error", np.linalg.norm(unitary @ unitary.conj().T - np.eye(LOAD))),
    ))

    load_before, interaction_before, total_before = energy_ledger(before, coupling, chain_h)
    load_after, interaction_after, total_after = energy_ledger(after, coupling, chain_h)
    work = load_before - load_after
    total_work = total_before - total_after
    interaction_jump = interaction_after - interaction_before
    checks.append(check(protocol, "total_work_closure", abs(total_work - work + interaction_jump)))
    independently_derived = {
        "load_before": load_before, "load_after": load_after, "gross": work,
        "interaction_before": interaction_before, "interaction_after": interaction_after,
        "interaction_jump": interaction_jump, "total_before": total_before,
        "total_after": total_after, "total_work": total_work,
    }
    for name, value in independently_derived.items():
        checks.append(check(protocol, f"{name}_vs_extraction_ledger", abs(value - float(archived[name]))))

    if coupling == 0:
        phase = np.exp(-1j * LOAD_LEVELS * (10.00 - 7.70))
        expected = phase[:, None] * shared_load * phase[None, :].conj()
        checks.extend((
            check(protocol, "free_load_state_max_abs_error", max_abs(reduced_load(before) - expected)),
            check(protocol, "zero_interaction_jump", abs(interaction_jump), 0),
        ))
    return checks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("formal", type=Path)
    parser.add_argument("shared_state", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    shared, shared_hash = read_state(args.shared_state, 7.70)
    if shared_hash != SHARED_SHA256:
        raise ValueError("Common t=7.70 state does not match the formal SHA-256")
    with (args.formal / "extraction_ledger.csv").open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    ledger = {row["protocol"]: row for row in rows}
    if len(rows) != 2 or set(ledger) != {"C4", "C5"}:
        raise ValueError("Expected exactly one extraction row for each new branch")

    shared_load = reduced_load(shared)
    chain_h = chain_hamiltonian()
    checks = []
    for protocol, prefix, coupling in BRANCHES:
        row = ledger[protocol]
        if (float(row["g"]), float(row["time"])) != (coupling, 10.00):
            raise ValueError(f"Incorrect protocol metadata for {protocol} in extraction ledger")
        checks.extend(inspect_pair(args.formal, protocol, prefix, coupling, shared_load, chain_h, row))

    with args.output.open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(checks[0]))
        writer.writeheader()
        writer.writerows(checks)
    for row in checks:
        print(f"{row['protocol']} {row['check']:<46} {row['value']:.4e} {row['status']}")
    failures = sum(row["status"] != "PASS" for row in checks)
    print(f"{len(checks) - failures}/{len(checks)} serialized-state checks passed")
    return bool(failures)


if __name__ == "__main__":
    sys.exit(main())
