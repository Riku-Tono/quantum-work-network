"""Validate and join the M17 formal storage branches and immutable references."""

import argparse
import cmath
import csv
from itertools import pairwise
import json
import math
from pathlib import Path
import struct


G = {0.25: "C0", 0.125: "C2", 0.05: "C3", 0.01: "C4", 0.0: "C5"}
NEW = (0.01, 0.0)
OLD = (0.25, 0.125, 0.05)
REPLAY = (0.125, 0.05)
GRID = range(770, 1001)
SELECTED = (770, 850, 900, 950, 1000)
START, END = GRID[0], GRID[-1]
TOL = 1e-12
SPECTRUM_TOL = 1e-10
SWITCH_TOL = 1e-18
DIRECT_SWITCH_TOL = 1e-15
STEP_TOL = 1e-13
DIM = 384
POP = tuple(f"load_population_{i}" for i in range(3))
SPEC = tuple(f"load_eigenvalue_{i}" for i in range(3))
CORE = ("load_energy", "load_ergotropy", "load_passive_energy", "trace_error", "hermiticity_error")
WORK = "load_ergotropy"
METHODS = ("positivity_method", "solver_status")
PHASE = "free_load_state_max_abs_error"
CURRENT = "site7_to_load_current"
DIAGONAL = "load_diagonal_ergotropy"
COHERENCE = "load_coherence_ergotropy"
PURITY = "load_purity"
MIN_EIGEN = "minimum_eigenvalue"
EXTRA = (DIAGONAL, COHERENCE, *POP, PURITY, *SPEC, CURRENT, MIN_EIGEN, *METHODS, PHASE)
INVARIANT = ("load_energy", WORK, "load_passive_energy", DIAGONAL, COHERENCE, *POP, PURITY, *SPEC)
STORAGE_HEADER = (
    "protocol", "g", "time", *CORE, *EXTRA, "retention_ratio", "work_source",
    "supplemental_diagnostics_source",
)


def require(condition, description):
    if not condition:
        raise ValueError(description)


def val(row, name):
    value = float(row[name])
    require(math.isfinite(value), f"Nonfinite {name}: {row}")
    return value


def time_key(row):
    t = val(row, "time")
    i = round(100 * t)
    require(abs(t - i / 100) <= TOL, f"Off-grid time {t}")
    return i


def read_rows(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def indexed(rows, key_of, expected, label):
    result = {}
    for row in rows:
        key = key_of(row)
        require(key not in result, f"{label}: duplicate key {key}")
        result[key] = row
    require(result.keys() == expected, f"{label}: unexpected/missing keys {result.keys() ^ expected}")
    return result


def by_gt(path, couplings, times, allow_extra=False):
    expected = {(g, t) for g in couplings for t in times}
    rows = read_rows(path)
    if allow_extra:
        rows = [row for row in rows if (val(row, "g"), time_key(row)) in expected]
    return indexed(rows, lambda row: (val(row, "g"), time_key(row)), expected, path.name)


def historical_series(path):
    return indexed(
        [row for row in read_rows(path) if time_key(row) in GRID],
        time_key, set(GRID), path.name,
    )


class Checks:
    def __init__(self):
        self.rows = []

    def upper(self, name, observed, tolerance=TOL, unit="absolute"):
        status = "PASS" if math.isfinite(observed) and 0 <= observed <= tolerance else "FAIL"
        self.rows.append(dict(check=name, observed=observed, bound=tolerance, rule="<=",
                              unit=unit, status=status))
        return status == "PASS"

    def floor(self, name, observed, bound):
        self.rows.append(dict(check=name, observed=observed, bound=bound, rule=">=",
                              unit="absolute", status="PASS" if observed >= bound else "FAIL"))

    def reject_failures(self):
        failed = [row for row in self.rows if row["status"] == "FAIL"]
        require(not failed, f"Failed checks: {failed}")


def max_abs(values):
    return max(map(abs, values), default=0.0)


def differences(left, right, fields):
    return max_abs(val(left, field) - val(right, field) for field in fields)


def write_csv(path, rows, header=None):
    with path.open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=header or list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def combine_series(args, checks):
    saved = by_gt(args.m16 / "coupling_timeseries.csv", OLD, GRID, allow_extra=True)
    new = by_gt(args.formal / "storage_timeseries.csv", NEW, GRID)
    replay = by_gt(args.diagnostic_replay / "storage_timeseries.csv", REPLAY, GRID)
    c0 = historical_series(args.hist_c0_series)
    c2 = historical_series(args.hist_c2_series)
    for key, row in replay.items():
        require(not row[PHASE], f"Unexpected analytic phase sentinel in replay {key}")
    checks.upper("m16_overlap_c2_c3_max_error", max(
        differences(row, saved[key], CORE) for key, row in replay.items()
    ))
    checks.upper("c0_m12c_m16_work_overlap_max_error", max(
        differences(c0[t], saved[0.25, t], CORE[:3]) for t in GRID
    ))
    checks.upper("c0_m12c_m16_numeric_overlap_max_error", max(
        max_abs(val(c0[t], field + "_total") - val(saved[0.25, t], field) for field in CORE[3:])
        for t in GRID
    ))
    reusable_c2 = (*CORE, DIAGONAL, COHERENCE, *POP, CURRENT, MIN_EIGEN)
    checks.upper("c2_extension_diagnostics_replay_max_error", max(
        differences(c2[t], replay[0.125, t], reusable_c2) for t in GRID
    ))
    initial_work = val(saved[0.25, START], WORK)
    require(initial_work > TOL, "Common initial work cannot define retention")
    rows = {}
    for g, protocol in G.items():
        for t in GRID:
            key = g, t
            if g in NEW:
                state = new[key]
                row = {name: state[name] for name in (*CORE, *EXTRA)}
                work_source = diagnostic_source = "m17_formal"
            else:
                row = {name: saved[key][name] for name in CORE}
                work_source = "m16_archive"
                if g == 0.25:
                    state = c0[t]
                    fallback = state["fallback_used_total"]
                    primary = state["primary_solver_success_total"]
                    require(fallback in ("true", "false") and primary in ("true", "false"),
                            f"Unexpected M12C solver fields at {t}")
                    require(fallback == "true" or primary == "true",
                            f"M12C solver unresolved at {t}")
                    row.update({name: state[name] for name in (DIAGONAL, COHERENCE, *POP)})
                    row.update({
                        PURITY: state["purity_load"],
                        CURRENT: state["site7_to_load_energy_current"],
                        MIN_EIGEN: state["minimum_raw_eigenvalue_total"],
                        "positivity_method": "m12c_fallback" if fallback == "true" else "m12c_primary",
                        "solver_status": "fallback_validated" if fallback == "true" else "primary_validated",
                        **dict.fromkeys(SPEC, ""), PHASE: "",
                    })
                    diagnostic_source = "m12c_archive"
                elif g == 0.125:
                    state = c2[t]
                    row.update({name: state[name] for name in (DIAGONAL, COHERENCE, *POP, CURRENT, MIN_EIGEN, *METHODS)})
                    row.update({name: replay[key][name] for name in (PURITY, *SPEC)})
                    row[PHASE] = ""
                    diagnostic_source = "c2_extension_archive_and_m17_diagnostic_replay_purity_spectrum"
                else:
                    row.update({name: replay[key][name] for name in EXTRA})
                    diagnostic_source = "m17_diagnostic_replay"
            row.update(protocol=protocol, g=g, time=f"{t / 100:.2f}",
                       work_source=work_source, supplemental_diagnostics_source=diagnostic_source)
            row["retention_ratio"] = val(row, WORK) / initial_work
            rows[key] = row
    return rows


def audit_series(rows, checks):
    values = list(rows.values())
    if any(row["solver_status"] not in ("primary_validated", "fallback_validated") for row in values):
        bad = sorted({row["solver_status"] for row in values})
        raise ValueError(f"Unresolved or unexpected positivity solver statuses: {bad}")
    require(all(row["positivity_method"] for row in values), "Missing positivity solver method")
    require(all(bool(row[PHASE]) == (val(row, "g") == 0) for row in values),
            "Free-load phase value must be present on the g=0 branch only")

    for field in ("trace_error", "hermiticity_error"):
        xs = [val(row, field) for row in values]
        checks.floor(f"{field}_minimum", min(xs), 0)
        checks.upper(f"{field}_maximum", max(xs))
    checks.floor("full_state_minimum_eigenvalue", min(val(row, MIN_EIGEN) for row in values), -TOL)
    checks.floor("minimum_population", min(val(row, pop) for row in values for pop in POP), -TOL)
    checks.floor("minimum_ergotropy", min(val(row, work) for row in values for work in (WORK, DIAGONAL, COHERENCE)), -TOL)
    checks.floor("load_purity_physical_lower_bound", min(val(row, PURITY) for row in values), 1 / 3 - TOL)
    checks.upper("load_purity_physical_upper_bound_excess", max(0.0, max(val(row, PURITY) for row in values) - 1))

    checks.upper("common_initial_load_observables", max(
        differences(rows[g, START], rows[0.25, START], INVARIANT[:-len(SPEC)]) for g in G
    ))
    checks.upper("load_population_normalization", max_abs(
        sum(val(row, pop) for pop in POP) - 1 for row in values
    ))
    checks.upper("load_energy_from_population", max_abs(
        val(row, "load_energy") - val(row, POP[1]) - 2 * val(row, POP[2]) for row in values
    ))
    checks.upper("ergotropy_energy_passive_identity", max_abs(
        val(row, "load_energy") - val(row, "load_passive_energy") - val(row, WORK)
        for row in values
    ))
    checks.upper("ergotropy_population_coherence_identity", max_abs(
        val(row, WORK) - val(row, DIAGONAL) - val(row, COHERENCE) for row in values
    ))
    marginal_rows = [row for row in values if all(row[field] for field in SPEC)]
    require(len(marginal_rows) == len(GRID) * (len(G) - 1), "Unexpected load spectrum coverage")
    spectra = [tuple(val(row, field) for field in SPEC) for row in marginal_rows]
    checks.floor("minimum_marginal_eigenvalue", min(x[0] for x in spectra), -TOL)
    checks.upper("marginal_spectrum_ordering", max(0.0, max(a - b for s in spectra for a, b in pairwise(s))))
    checks.upper("marginal_spectrum_trace", max_abs(sum(x) - 1 for x in spectra), SPECTRUM_TOL)
    checks.upper("marginal_purity_from_spectrum", max_abs(
        val(row, PURITY) - sum(eig * eig for eig in spectrum)
        for row, spectrum in zip(marginal_rows, spectra, strict=True)
    ))
    checks.upper("marginal_passive_energy_from_spectrum", max_abs(
        val(row, "load_passive_energy") - (spectrum[1] + 2 * spectrum[0])
        for row, spectrum in zip(marginal_rows, spectra, strict=True)
    ))


def audit_switches(args, checks):
    old_path, new_path = (d / "switching_ledger.csv" for d in (args.m16, args.formal))
    old = by_gt(old_path, OLD, (START,), allow_extra=True)
    new = by_gt(new_path, NEW, (START,))
    archived, = (row for row in read_rows(args.m14_switch) if row["protocol"] == "C2")
    v = val(archived, "interaction_expectation_V")
    m14_work = val(archived, "switching_work_on_system")
    require(abs(val(archived, "switch_time") - START / 100) <= TOL, "Archived M14 C2 quench time mismatch")
    require(val(archived, "g_before") == 0.25 and val(archived, "g_after") == 0.125,
            "Archived M14 C2 coupling mismatch")
    rows = []
    for g, protocol in G.items():
        row = (new if g in NEW else old)[g, START].copy()
        require(val(row, "g_before") == 0.25, f"{protocol} g before quench")
        label = f"{protocol}_switch"
        expectation = val(row, "interaction_expectation_v")
        work = val(row, "work_on_system")
        direct = val(row, "direct_total_jump")
        checks.upper(f"{label}_m14_common_interaction", abs(expectation - v), SWITCH_TOL)
        checks.upper(f"{label}_linear_formula", abs(work - (g - 0.25) * expectation), SWITCH_TOL)
        checks.upper(f"{label}_residual_definition", abs(val(row, "residual") - (direct - work)), SWITCH_TOL)
        checks.upper(f"{label}_total_jump", abs(direct - work), DIRECT_SWITCH_TOL)
        checks.upper(f"{label}_sparse_dense_step", val(row, "sparse_dense_step_error"), STEP_TOL)
        if g in NEW:
            checks.upper(f"{label}_state_invariance", val(row, "state_invariance_max_abs"), 0)
            checks.upper(f"{label}_independent_total_difference", abs(
                val(row, "total_after") - val(row, "total_before") - direct
            ), DIRECT_SWITCH_TOL)
            checks.upper(f"{label}_independent_interaction_difference", abs(
                val(row, "interaction_after") - val(row, "interaction_before") - work
            ), DIRECT_SWITCH_TOL)
        if g == 0.125:
            checks.upper(f"{label}_m14_archived_switch_work", abs(work - m14_work), SWITCH_TOL)
        row.update(protocol=protocol, source="m17_formal" if g in NEW else "m16_archive",
                   work_out=-work,
                   state_invariance_evidence="verified_identical_density" if g in NEW
                   else "m16_same_input_density_by_construction")
        rows.append(row)
    header = list(dict.fromkeys(["protocol", *rows[0], *rows[-1]]))
    return rows, header


def audit_extractions(args, series, checks):
    old = by_gt(args.m16 / "extraction_ledger.csv", OLD, (END,), allow_extra=True)
    new = by_gt(args.formal / "extraction_ledger.csv", NEW, (END,))
    rows = []
    for g, protocol in G.items():
        row = (new if g in NEW else old)[g, END].copy()
        expected = {0.25: "G025", 0.125: "G0125", 0.05: "G005"}.get(g, protocol)
        require(row["protocol"] == expected and row["state_source"] == "shared_t770_replay",
                f"{protocol} unexpected extraction provenance")
        state = series[g, END]
        gross = val(row, "gross")
        total = val(row, "total_work")
        interaction = val(row, "interaction_jump")
        comparison = {
            "load_before": val(state, "load_energy"),
            "load_after": val(state, "load_passive_energy"),
            "ergotropy_before": val(state, WORK),
            "ergotropy_after": 0.0,
            "gross": val(state, WORK),
            "total_work": val(row, "total_before") - val(row, "total_after"),
            "interaction_jump": val(row, "interaction_after") - val(row, "interaction_before"),
            "identity_residual": total - (gross - interaction),
        }
        for field, reference in comparison.items():
            checks.upper(f"{protocol}_extraction_{field}", abs(val(row, field) - reference))
        checks.upper(f"{protocol}_extraction_independent_load_work", abs(
            gross - (val(row, "load_before") - val(row, "load_after"))
        ))
        checks.upper(f"{protocol}_extraction_total_closure", abs(val(row, "identity_residual")))
        for field in (
            "trace_before_error", "trace_after_error", "hermiticity_before_error",
            "hermiticity_after_error", "unitarity_error", "passive_mapping_error",
            "load_mapping_error", "chain_invariance_error",
        ):
            checks.upper(f"{protocol}_extraction_{field}", val(row, field))
        for field in ("min_eigenvalue_before", "min_eigenvalue_after"):
            checks.floor(f"{protocol}_extraction_{field}", val(row, field), -TOL)
        if g == 0.125:
            checks.upper(f"{protocol}_m16_archived_state_error", val(row, "archived_state_max_abs_error"))
        row.update(protocol=protocol, source="m17_formal" if g in NEW else "m16_archive",
                   original_protocol=expected)
        rows.append(row)
    return rows


def read_state(path, t):
    data = path.read_bytes()
    require(len(data) == 24 + 16 * DIM * DIM, f"{path.name}: invalid state size")
    magic, dimension, time = struct.unpack_from("<8sQd", data)
    require(magic == b"QWNRHO1\x00" and dimension == DIM and abs(time - t) <= TOL,
            f"{path.name}: unexpected state metadata {(magic, dimension, time)}")
    matrix = [complex(r, i) for r, i in struct.iter_unpack("<dd", memoryview(data)[24:])]
    require(all(math.isfinite(z.real) and math.isfinite(z.imag) for z in matrix),
            f"{path.name}: nonfinite matrix")
    return matrix


def reduced_load(matrix):
    return [
        sum(matrix[(base + i) * DIM + base + j] for base in range(0, DIM, 3))
        for i in range(3) for j in range(3)
    ]


def reduced_chain(matrix):
    return [
        sum(matrix[(i + k) * DIM + j + k] for k in range(3))
        for i in range(0, DIM, 3) for j in range(0, DIM, 3)
    ]


def energy(load):
    return (load[4] + 2 * load[8]).real


def audit_saved_states(args, series, extractions, checks, theory):
    initial = reduced_load(read_state(args.common_state, START / 100))
    initial_row = series[0.0, START]
    checks.upper("decoded_initial_load_energy", abs(energy(initial) - val(initial_row, "load_energy")))
    checks.upper("decoded_initial_load_purity", abs(sum(abs(z) ** 2 for z in initial) - val(initial_row, PURITY)))
    capture = {val(row, "g"): row for row in extractions}
    for g, name in ((0.01, "g001"), (0.0, "g000")):
        before = read_state(args.formal / f"{name}_t1000_before.bin", END / 100)
        after = read_state(args.formal / f"{name}_t1000_after.bin", END / 100)
        for phase, matrix in (("before", before), ("after", after)):
            checks.upper(f"{name}_{phase}_decoded_trace", abs(sum(matrix[DIM * i + i] for i in range(DIM)) - 1))
            checks.upper(f"{name}_{phase}_decoded_hermiticity", max_abs(
                matrix[DIM * i + j] - matrix[DIM * j + i].conjugate()
                for i in range(DIM) for j in range(i, DIM)
            ))
            checks.upper(f"{name}_{phase}_decoded_load_energy", abs(
                energy(reduced_load(matrix)) - val(capture[g], f"load_{phase}")
            ))
        load_before = reduced_load(before)
        checks.upper(f"{name}_decoded_load_populations", max_abs(
            load_before[i * 4].real - val(series[g, END], POP[i]) for i in range(3)
        ))
        checks.upper(f"{name}_decoded_load_purity", abs(
            sum(abs(z) ** 2 for z in load_before) - val(series[g, END], PURITY)
        ))
        chain_before, chain_after = reduced_chain(before), reduced_chain(after)
        checks.upper(f"{name}_decoded_local_operation_chain_invariance", max_abs(
            x - y for x, y in zip(chain_before, chain_after, strict=True)
        ))
        passive = reduced_load(after)
        checks.upper(f"{name}_decoded_passive_off_diagonal", max_abs(
            passive[3 * i + j] for i in range(3) for j in range(3) if i != j
        ))
        checks.upper(f"{name}_decoded_passive_ordering", max(0.0, passive[4].real - passive[0].real,
                                                             passive[8].real - passive[4].real))
        if g == 0.0:
            elapsed = (END - START) / 100
            analytic = [initial[3 * i + j] * cmath.exp(-1j * (i - j) * elapsed)
                        for i in range(3) for j in range(3)]
            theory.upper("g0_decoded_endpoint_load_density_vs_analytic_phase", max_abs(
                a - b for a, b in zip(analytic, load_before, strict=True)
            ))


def invariance(series, extractions, theory):
    initial = series[0.0, START]
    rows = [series[0.0, t] for t in GRID]
    for field in INVARIANT:
        theory.upper(f"g0_{field}_maximum_drift", max_abs(
            val(row, field) - val(initial, field) for row in rows
        ))
    theory.upper("g0_site7_to_load_current_maximum", max_abs(val(row, CURRENT) for row in rows))
    theory.upper("g0_load_phase_vs_analytic_all_points", max(val(row, PHASE) for row in rows))
    theory.floor("g0_load_phase_error_minimum", min(val(row, PHASE) for row in rows), 0.0)
    capture, = (row for row in extractions if val(row, "g") == 0)
    theory.upper("g0_extraction_work_gross_total_agreement", abs(val(capture, "gross") - val(capture, "total_work")))
    theory.upper("g0_extraction_zero_interaction_jump", abs(val(capture, "interaction_jump")))


def selected_comparison(series):
    rows = []
    for t in SELECTED:
        work = {g: val(series[g, t], WORK) for g in G}
        baseline = work[0.05]
        for g in G:
            row = series[g, t].copy()
            row["retention_percent"] = 100 * row["retention_ratio"]
            row["work_gain_vs_g005"] = work[g] - baseline
            row["relative_work_gain_vs_g005"] = row["work_gain_vs_g005"] / baseline
            row["work_rank_ties_shared"] = 1 + sum(value - work[g] > TOL for value in work.values())
            rows.append(row)
    return rows


def storage_metrics(series, switches, extractions):
    def work(g, t):
        return val(series[g, t], WORK)

    gaps = [(strong, weak) for strong, weak in pairwise(G)]
    ordered = {
        t: [work(weak, t) - work(strong, t) for strong, weak in gaps] for t in GRID
    }
    baseline = 0.05
    result = {
        "saved_points_per_coupling": len(GRID),
        "common_initial_work": work(0.25, START),
        "couplings": {},
        "strict_weaker_order_count_after_switch": sum(
            all(gap > TOL for gap in ordered[t]) for t in GRID if t > START
        ),
        "noninverted_weaker_order_count_after_switch": sum(
            all(gap >= -TOL for gap in ordered[t]) for t in GRID if t > START
        ),
        "adjacent_pair_reversals": {
            f"{G[weak]}_minus_{G[strong]}": [t / 100 for t in GRID if ordered[t][i] < -TOL]
            for i, (strong, weak) in enumerate(gaps)
        },
        "adjacent_pair_ties_after_switch": {
            f"{G[weak]}_minus_{G[strong]}": [
                t / 100 for t in GRID if t > START and abs(ordered[t][i]) <= TOL
            ] for i, (strong, weak) in enumerate(gaps)
        },
        "theoretical_reference_g": 0.0,
    }
    for switch, extraction in zip(switches, extractions, strict=True):
        g = val(switch, "g")
        require(val(extraction, "g") == g, "Ledger order mismatch")
        final_work = work(g, END)
        currents = [val(series[g, t], CURRENT) for t in GRID]
        largest_current = max_abs(currents)
        increasing_intervals = [(a, b) for a, b in pairwise(GRID) if work(g, b) - work(g, a) > TOL]
        low_time = min(GRID, key=lambda t: work(g, t))
        result["couplings"][G[g]] = {
            "g": g,
            "t10_work": final_work,
            "t10_work_loss_from_common_state": work(0.25, START) - final_work,
            "t10_retention_ratio": series[g, END]["retention_ratio"],
            "t10_absolute_gain_vs_g005": final_work - work(baseline, END),
            "t10_relative_gain_vs_g005": final_work / work(baseline, END) - 1,
            "saved_steps_with_work_increase": len(increasing_intervals),
            "first_detectable_work_increase_interval": [t / 100 for t in increasing_intervals[0]]
            if increasing_intervals else None,
            "last_detectable_work_increase_interval": [t / 100 for t in increasing_intervals[-1]]
            if increasing_intervals else None,
            "minimum_work_time": low_time / 100,
            "minimum_work": work(g, low_time),
            "t10_work_above_window_minimum": final_work - work(g, low_time),
            "saved_steps_with_work_decrease": sum(work(g, a) - work(g, b) > TOL for a, b in pairwise(GRID)),
            "max_abs_site7_load_current": largest_current,
            "min_site7_load_current": min(currents),
            "max_site7_load_current": max(currents),
            "definite_nonzero_current": largest_current > TOL,
            "t10_site7_load_current": val(series[g, END], CURRENT),
            "t10_load_energy_drift": val(series[g, END], "load_energy") - val(series[g, START], "load_energy"),
            "max_abs_load_energy_drift": max_abs(
                val(series[g, t], "load_energy") - val(series[g, START], "load_energy") for t in GRID
            ),
            "switch_work_on_system": val(switch, "work_on_system"),
            "t10_ideal_gross_extraction": val(extraction, "gross"),
            "t10_total_extraction": val(extraction, "total_work"),
            "t10_interaction_jump": val(extraction, "interaction_jump"),
        }
    result["t10_extraction_order_strict"] = all(
        val(weak, "total_work") - val(strong, "total_work") > TOL
        for strong, weak in pairwise(extractions)
    )
    result["selected_times"] = {
        f"{t / 100:.2f}": {
            G[g]: { "work": work(g, t), "retention_ratio": series[g, t]["retention_ratio"] }
            for g in G
        } for t in SELECTED
    }
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("formal", "diagnostic-replay", "m16", "common-state", "hist-c0-series",
                 "hist-c2-series", "m14-switch"):
        parser.add_argument("--" + name, required=True, type=Path)
    parser.add_argument("--output", type=Path, help="New scratch staging directory")
    parser.add_argument("--plots", action="store_true", help="Build both plots in staging")
    args = parser.parse_args()
    if args.plots and args.output is None:
        parser.error("--plots requires --output")
    try:
        checks, theory = Checks(), Checks()
        series = combine_series(args, checks)
        audit_series(series, checks)
        switches, switch_header = audit_switches(args, checks)
        extractions = audit_extractions(args, series, checks)
        audit_saved_states(args, series, extractions, checks, theory)
        invariance(series, extractions, theory)
        checks.reject_failures()
        theory.reject_failures()
        metrics = storage_metrics(series, switches, extractions)
        metrics["numerical_checks_passed"] = len(checks.rows)
        metrics["theoretical_checks_passed"] = len(theory.rows)
        metrics["fallback_counts"] = {
            G[g]: sum(series[g, t]["solver_status"] == "fallback_validated" for t in GRID)
            for g in G
        }
        if args.output is not None:
            args.output.mkdir()
            write_csv(args.output / "m17_storage_timeseries.csv", list(series.values()), STORAGE_HEADER)
            compare_header = (*STORAGE_HEADER, "retention_percent", "work_gain_vs_g005",
                              "relative_work_gain_vs_g005", "work_rank_ties_shared")
            write_csv(args.output / "m17_coupling_comparison.csv", selected_comparison(series), compare_header)
            write_csv(args.output / "m17_switching_work.csv", switches, switch_header)
            write_csv(args.output / "m17_extraction_ledger.csv", extractions)
            write_csv(args.output / "m17_numerical_checks.csv", checks.rows)
            write_csv(args.output / "m17_theoretical_invariance_checks.csv", theory.rows)
            (args.output / "m17_metrics.json").write_text(json.dumps(metrics, indent=2) + "\n",
                                                          encoding="utf-8")
            if args.plots:
                from plot_m17 import draw
                draw(series, G, GRID, SELECTED, args.output)
        print(json.dumps(metrics, indent=2))
    except (OSError, TypeError, KeyError, ValueError) as exc:
        parser.exit(1, f"FAIL: {exc}\n")


if __name__ == "__main__":
    main()
