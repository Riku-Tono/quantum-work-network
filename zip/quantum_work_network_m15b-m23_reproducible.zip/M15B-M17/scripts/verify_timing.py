"""Verify the four-time ideal extraction comparison against the formal archives."""

import argparse
import csv
import hashlib
import math
from pathlib import Path


TIMES = (8.5, 9.0, 9.5, 10.0)
COUPLINGS = {"C0": 0.25, "C2": 0.125}
SOURCES = {
    8.5: ("saved_c2_t850",),
    9.0: ("c2_t850_replay",),
    9.5: ("c2_t850_replay",),
    10.0: ("saved_c2_t1000", "c2_t850_replay"),
}
REFERENCE_TOL = 1e-12
INVARIANT_TOL = 1e-10
PASSIVITY_TOL = 1e-9
POSITIVITY_TOL = 1e-12

FORMAL_COMPARISON = "outputs/c0_c2_extended_comparison_timeseries.csv"
M15A = "work/c2_extension_project/reference/milestone_15a"
ARCHIVE_HASHES = {
    FORMAL_COMPARISON: "739AA3257752B8FB85D76ECDB115764BB3BE3EEF69731F81D50F8C6CFA327C61",
    f"{M15A}/gross_work.csv": "DD84E7A1B7851E3948EAD0837F81A4E23A7B2DAA1E5106B37891808C77026C20",
    f"{M15A}/operation_work.csv": "071687FAF0C11AF49007FC85C803013AD74267FF1208B7B421B1FACC48E8A098",
    "outputs/c2_pre_extraction_state_t850.bin": "1E3E574C107959D37763610C1081BFDFEE95B41D8FBD559FE203CFDCD45CD109",
    "outputs/c2_pre_extraction_state_t1000.bin": "58E9B6B44D82ADBD7A6A0EBFCFACB67B721B1886EB4A479ACED8C4F00C169970",
    "work/c2_extension_project/inputs/m14_plan_b/m14_plan_b_rho_t770.bin": "DB695F6A8F90B08248748118D4D786855EAE5335666C5F76FCAB789C3B014250",
}


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def require(condition, description):
    if not condition:
        raise ValueError(description)


def near(actual, expected, tolerance, description):
    require(
        abs(actual - expected) <= tolerance,
        f"{description}: got {actual:.16e}, expected {expected:.16e} (abs tol {tolerance:.1e})",
    )


def verify_row(row, reference):
    protocol, time, source = row["protocol"], float(row["time"]), row["state_source"]
    label = f"{protocol} t={time:.2f}"
    allowed_sources = ("shared_t770_replay",) if protocol == "C0" else SOURCES[time]
    require(source in allowed_sources, f"{label}: unexpected state source {source}")
    numeric = {
        name: float(value)
        for name, value in row.items()
        if name not in ("protocol", "time", "state_source", "archived_state_max_abs_error")
    }
    require(all(math.isfinite(value) for value in numeric.values()), f"{label}: non-finite values")
    near(numeric["g"], COUPLINGS[protocol], 0, f"{label} g")

    reference_pairs = {
        "load_before": f"E_load_{protocol}",
        "load_after": f"E_passive_{protocol}",
        "ergotropy_before": f"W_{protocol}",
        "gross": f"W_{protocol}",
    }
    for name, reference_name in reference_pairs.items():
        near(numeric[name], float(reference[reference_name]), REFERENCE_TOL, f"{label} {name}")

    identities = {
        "gross": numeric["load_before"] - numeric["load_after"],
        "total_work": numeric["total_before"] - numeric["total_after"],
        "interaction_jump": numeric["interaction_after"] - numeric["interaction_before"],
        "identity_residual": numeric["total_work"] - (numeric["gross"] - numeric["interaction_jump"]),
    }
    for name, expected in identities.items():
        near(numeric[name], expected, REFERENCE_TOL, f"{label} {name} accounting")
    near(numeric["identity_residual"], 0, REFERENCE_TOL, f"{label} total work closure")
    near(numeric["ergotropy_after"], 0, PASSIVITY_TOL, f"{label} post-extraction ergotropy")

    invariant_errors = (
        "trace_before_error", "trace_after_error", "hermiticity_before_error",
        "hermiticity_after_error", "unitarity_error", "passive_mapping_error",
        "load_mapping_error", "chain_invariance_error",
    )
    for name in invariant_errors:
        require(0 <= numeric[name] <= INVARIANT_TOL, f"{label} {name}: {numeric[name]:.3e}")
    for name in ("min_eigenvalue_before", "min_eigenvalue_after"):
        require(numeric[name] >= -POSITIVITY_TOL, f"{label} {name}: {numeric[name]:.3e}")
    archived_error = row["archived_state_max_abs_error"]
    if archived_error or (protocol, time) == ("C2", 10.0):
        require(bool(archived_error), f"{label}: missing replay/archive state comparison")
        value = float(archived_error)
        require(0 <= value <= REFERENCE_TOL, f"{label}: replay/archive max matrix error {value:.3e}")
    return numeric


def verify(captured, archive):
    for relative_path, expected_hash in ARCHIVE_HASHES.items():
        actual_hash = hashlib.sha256((archive / relative_path).read_bytes()).hexdigest().upper()
        require(actual_hash == expected_hash, f"Archive SHA-256 mismatch: {relative_path}")
    reference = {float(row["time"]): row for row in read_csv(archive / FORMAL_COMPARISON)}
    m15a_gross = {row["protocol"]: row for row in read_csv(archive / M15A / "gross_work.csv")}
    m15a_work = {row["protocol"]: row for row in read_csv(archive / M15A / "operation_work.csv")}

    rows = read_csv(captured)
    indexed = {(row["protocol"], float(row["time"])): row for row in rows}
    expected = {(protocol, time) for protocol in COUPLINGS for time in TIMES}
    require(len(rows) == len(expected) and indexed.keys() == expected, "Expected one row for each protocol/time")
    checked = {key: verify_row(row, reference[key[1]]) for key, row in indexed.items()}
    for protocol in COUPLINGS:
        row = checked[protocol, 8.5]
        m15a_checks = {
            "gross": m15a_gross[protocol]["W_load_gross"],
            "ergotropy_after": m15a_gross[protocol]["post_load_ergotropy"],
            "total_before": m15a_work[protocol]["total_energy_before"],
            "total_after": m15a_work[protocol]["total_energy_after"],
            "total_work": m15a_work[protocol]["W_operation_out_total"],
            "interaction_before": m15a_work[protocol]["interaction_before"],
            "interaction_after": m15a_work[protocol]["interaction_after"],
            "interaction_jump": m15a_work[protocol]["interaction_jump"],
        }
        for name, value in m15a_checks.items():
            near(row[name], float(value), REFERENCE_TOL, f"{protocol} t=8.50 M15A {name}")

    summary = []
    print("time       gross C0     gross C2     C2 minus C0   increase     total C0     total C2")
    for time in TIMES:
        c0, c2 = checked["C0", time], checked["C2", time]
        delta = c2["gross"] - c0["gross"]
        relative = delta / c0["gross"]
        near(delta, float(reference[time]["Delta_W"]), REFERENCE_TOL, f"t={time:.2f} gross gap")
        near(relative, float(reference[time]["relative_difference"]), INVARIANT_TOL, f"t={time:.2f} relative gap")
        print(
            f"{time:5.2f}   {c0['gross']:12.6e} {c2['gross']:12.6e} "
            f"{delta:12.6e}  {relative:9.4%}  {c0['total_work']:12.6e} {c2['total_work']:12.6e}"
        )
        summary.append({
            "time": f"{time:.2f}",
            "gross_C0": c0["gross"],
            "gross_C2": c2["gross"],
            "gross_C2_minus_C0": delta,
            "gross_C2_advantage_percent": 100 * relative,
            "total_work_C0": c0["total_work"],
            "total_work_C2": c2["total_work"],
            "total_work_C2_minus_C0": c2["total_work"] - c0["total_work"],
            "interaction_jump_C0": c0["interaction_jump"],
            "interaction_jump_C2": c2["interaction_jump"],
        })
    matrix_error = float(indexed["C2", 10.0]["archived_state_max_abs_error"])
    print(f"PASS. Eight extraction rows, six archive SHA-256 checks, M15A reproduction.")
    print(f"C2 t=10.00 replay versus archived state max matrix error: {matrix_error:.3e}")
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("captured", type=Path, help="CSV with the eight extraction checks and ledgers")
    parser.add_argument("archive", type=Path, help="Archived c2-extension-to-t-10-and directory")
    parser.add_argument("--output", type=Path, help="Optional path for the four-time comparison CSV")
    args = parser.parse_args()
    try:
        summary = verify(args.captured, args.archive)
        if args.output:
            with args.output.open("x", encoding="utf-8", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=list(summary[0]))
                writer.writeheader()
                writer.writerows(summary)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        parser.exit(1, f"FAIL: {exc}\n")


if __name__ == "__main__":
    main()
