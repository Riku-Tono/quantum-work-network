"""Render the M17 storage trajectories and endpoint retention comparison."""

from pathlib import Path
import sys

dependencies = Path(__file__).resolve().parent.parent / "plot-deps"
if dependencies.is_dir():
    sys.path.insert(0, str(dependencies))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter, MultipleLocator, PercentFormatter


INK = "#152637"
MUTED = "#42586C"
GRID_COLOR = "#DFE7ED"
STYLES = {
    0.25: ("#546579", "--", "o"),
    0.125: ("#704984", "-.", "s"),
    0.05: ("#A2441A", "-", "^"),
    0.01: ("#007172", "-", "D"),
    0.0: ("#225886", ":", "P"),
}
LABELS = {0.25: "0.25", 0.125: "0.125", 0.05: "0.05", 0.01: "0.01", 0.0: "0.00"}


def canvas(title, subtitle, ylabel, xlabel, legend=False):
    fig, ax = plt.subplots(figsize=(9.1, 5.2), facecolor="white")
    left = 0.118
    fig.subplots_adjust(left=left, bottom=0.15, right=0.955, top=0.76 if legend else 0.835)
    fig.text(left, 0.944, title, color=INK, fontsize=17, fontweight="bold")
    fig.text(left, 0.893, subtitle, color=MUTED, fontsize=10.3)
    ax.set_axisbelow(True)
    ax.yaxis.grid(True, color=GRID_COLOR, linewidth=0.8)
    ax.spines[["top", "right"]].set_visible(False)
    for edge in ("bottom", "left"):
        ax.spines[edge].set_color("#8293A2")
    ax.tick_params(axis="both", color="#8293A2", labelcolor=INK, labelsize=10)
    ax.set_xlabel(xlabel, color=INK, fontsize=11, labelpad=10)
    ax.set_ylabel(ylabel, color=INK, fontsize=11, labelpad=10)
    return fig, ax


def draw(series, couplings, grid, selected, output):
    fig, ax = canvas(
        "Stored ergotropy after weakening the load coupling",
        "N = 7  |  Shared pre-quench state at t = 7.70",
        r"Bare-load ergotropy ($\times 10^{-3}$)",
        "Time",
        legend=True,
    )
    times = [t / 100 for t in grid]
    markers = [grid.index(t) for t in selected[1:]]
    for g in couplings:
        color, linestyle, marker = STYLES[g]
        ergotropy = [1000 * float(series[g, t]["load_ergotropy"]) for t in grid]
        ax.plot(
            times, ergotropy, color=color, linestyle=linestyle, marker=marker,
            markevery=markers, markersize=4.8, markerfacecolor="white",
            markeredgewidth=1.3, linewidth=1.85, label=f"g = {LABELS[g]}",
        )
    fig.legend(
        loc="upper left", bbox_to_anchor=(0.113, 0.855), ncols=len(couplings),
        frameon=False, handlelength=2.35, columnspacing=1.7, labelcolor=INK, fontsize=10,
    )
    ax.set_xlim(times[0] - 0.03, times[-1] + 0.04)
    ax.set_xticks([t / 100 for t in selected])
    ax.xaxis.set_major_formatter(FormatStrFormatter("%.2f"))
    ax.yaxis.set_major_locator(MultipleLocator(0.2))
    ax.yaxis.set_major_formatter(FormatStrFormatter("%.1f"))
    fig.savefig(output / "m17_ergotropy_vs_time.png", dpi=180)
    plt.close(fig)

    fig, ax = canvas(
        "Ergotropy retained at t = 10.00",
        "Five tested couplings  |  Retention relative to the common t = 7.70 state",
        "Ergotropy retained",
        "Post-quench coupling, g",
    )
    endpoint = grid[-1]
    ax.axhline(100, color="#8293A2", linestyle=":", linewidth=1.05)
    y_values = []
    for g in reversed(couplings):
        color, _, marker = STYLES[g]
        y = 100 * series[g, endpoint]["retention_ratio"]
        y_values.append(y)
        ax.scatter(g, y, s=65, c=color, marker=marker, zorder=3)
        offset = (6, -13 if g == 0.01 else 8)
        ax.annotate(f"{y:.2f}%", (g, y), xytext=offset, textcoords="offset points",
                    color=color, fontsize=9.7)
    ax.set_xlim(-0.016, 0.276)
    min_y = min(y_values)
    ax.set_ylim(min_y - 4, max(100, max(y_values)) + 5)
    ax.set_xticks(list(reversed(couplings)), ["0" if g == 0 else LABELS[g] for g in reversed(couplings)])
    ax.yaxis.set_major_locator(MultipleLocator(5))
    ax.yaxis.set_major_formatter(PercentFormatter(100, decimals=0))
    fig.savefig(output / "m17_t10_retention_vs_g.png", dpi=180)
    plt.close(fig)
