"""Plot the ergotropy trajectories for the four tested couplings."""

import argparse
import csv
import math
from pathlib import Path
import sys


dependencies = Path(__file__).with_name("plot-deps")
if dependencies.is_dir():
    sys.path.insert(0, str(dependencies))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter, MultipleLocator


STYLES = {
    0.25: {"color": "#687585", "linestyle": "--", "marker": "o", "linewidth": 1.7},
    0.20: {"color": "#B44D00", "linestyle": "-", "marker": "^", "linewidth": 2.3},
    0.125: {"color": "#655B8C", "linestyle": "-.", "marker": "s", "linewidth": 1.7},
    0.05: {"color": "#006E73", "linestyle": "-", "marker": "D", "linewidth": 2.3},
}
LABELS = {0.25: "0.25", 0.20: "0.20", 0.125: "0.125", 0.05: "0.05"}
SAMPLE_TIMES = (8.50, 9.00, 9.50, 10.00)
GRID = [step / 100 for step in range(770, 1001)]


def read_trajectories(path):
    trajectories = {coupling: [] for coupling in STYLES}
    with path.open(encoding="utf-8-sig", newline="") as stream:
        for row in csv.DictReader(stream):
            coupling = float(row["g"])
            if coupling not in trajectories:
                raise ValueError(f"Unexpected coupling {coupling}")
            time = float(row["time"])
            work = float(row["load_ergotropy"])
            if not math.isfinite(time) or not math.isfinite(work):
                raise ValueError(f"Non-finite trajectory value at g={coupling}")
            trajectories[coupling].append((time, work))
    for coupling, trajectory in trajectories.items():
        trajectory.sort()
        times = [time for time, _ in trajectory]
        if len(times) != len(GRID) or any(abs(a - b) > 1e-12 for a, b in zip(times, GRID)):
            raise ValueError(f"Unexpected saved time grid for g={coupling}")
    return trajectories


def draw(trajectories, output):
    fig, ax = plt.subplots(figsize=(8.7, 5.0), facecolor="white")
    fig.subplots_adjust(left=0.12, bottom=0.15, right=0.96, top=0.76)
    ax.set_axisbelow(True)
    ax.yaxis.grid(True, color="#DEE5EA", linewidth=0.8)
    ax.spines[["top", "right"]].set_visible(False)
    for edge in ("bottom", "left"):
        ax.spines[edge].set_color("#8C99A5")
    ax.tick_params(axis="both", color="#8C99A5", labelcolor="#263542", labelsize=10)

    sampled_indices = [GRID.index(time) for time in SAMPLE_TIMES]
    for coupling, trajectory in trajectories.items():
        times, work = zip(*trajectory)
        ax.plot(
            times,
            [value * 1000 for value in work],
            **STYLES[coupling],
            markevery=sampled_indices,
            markersize=5.3,
            markerfacecolor="white",
            markeredgewidth=1.35,
            label=f"g = {LABELS[coupling]}",
        )

    ax.set_xlim(7.66, 10.04)
    ax.set_xticks([7.70, 8.00, *SAMPLE_TIMES])
    ax.xaxis.set_major_formatter(FormatStrFormatter("%.2f"))
    ax.yaxis.set_major_locator(MultipleLocator(0.2))
    ax.yaxis.set_major_formatter(FormatStrFormatter("%.1f"))
    ax.set_xlabel("Time", color="#1F2E3D", fontsize=11, labelpad=9)
    ax.set_ylabel(r"Bare-load ergotropy ($\times 10^{-3}$)", color="#1F2E3D", fontsize=11, labelpad=10)
    fig.text(
        0.12, 0.94, "Bare-load ergotropy by coupling strength",
        color="#162738", fontsize=18, fontweight="bold",
    )
    fig.text(0.12, 0.885, "N = 7, shared state at t = 7.70", color="#415469", fontsize=10.5)
    fig.legend(
        loc="upper left", bbox_to_anchor=(0.116, 0.85), ncols=4, frameon=False,
        handlelength=2.6, columnspacing=1.65, fontsize=10.5, labelcolor="#263542",
    )
    fig.savefig(output, dpi=180, facecolor=fig.get_facecolor())
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("timeseries", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    draw(read_trajectories(args.timeseries), args.output)


if __name__ == "__main__":
    main()
