"""Validate the four-coupling experiment against the previous timing experiment."""

import argparse
import csv
import hashlib
import math
from itertools import pairwise
from pathlib import Path

COUPLINGS = {0.25: "G025", 0.20: "G020", 0.125: "G0125", 0.05: "G005"}
GRID = range(770, 1001)
EXTRACTION_TIMES = (850, 900, 950, 1000)
SOURCE = "shared_t770_replay"
PREVIOUS = {0.25: "C0", 0.125: "C2"}
TOL = 1e-12
SWITCH_ARCHIVE_TOL = 1e-18
SWITCH_DIRECT_TOL = 1e-15
STEP_TOL = 1e-13

HISTORICAL_CSV = "outputs/c0_c2_extended_comparison_timeseries.csv"
COMMON_STATE = "work/c2_extension_project/inputs/m14_plan_b/m14_plan_b_rho_t770.bin"
ARCHIVE_HASHES = {
    HISTORICAL_CSV: "739AA3257752B8FB85D76ECDB115764BB3BE3EEF69731F81D50F8C6CFA327C61",
    COMMON_STATE: "DB695F6A8F90B08248748118D4D786855EAE5335666C5F76FCAB789C3B014250",
    "outputs/c2_pre_extraction_state_t850.bin": "1E3E574C107959D37763610C1081BFDFEE95B41D8FBD559FE203CFDCD45CD109",
    "outputs/c2_pre_extraction_state_t1000.bin": "58E9B6B44D82ADBD7A6A0EBFCFACB67B721B1886EB4A479ACED8C4F00C169970",
}
DEFAULT_PREVIOUS_LEDGER = (
    Path(__file__).resolve().parents[1] / "outputs" / "m15b_extraction_ledger.csv"
)


def require(condition, description):
    if not condition:
        raise ValueError(description)


def near(actual, expected, description, tolerance=TOL):
    error = abs(actual - expected)
    require(
        error <= tolerance,
        f"{description}: {actual:.16e} differs from {expected:.16e} "
        f"by {error:.3e} (tolerance {tolerance:.0e})",
    )
    return error


def value(row, key):
    result = float(row[key])
    require(math.isfinite(result), f"Nonfinite {key}: {row}")
    return result


def time_key(row):
    time = value(row, "time")
    hundredths = round(time * 100)
    near(time, hundredths / 100, "Saved time grid")
    return hundredths


def coupling_key(row):
    coupling = value(row, "g")
    require(coupling in COUPLINGS, f"Unexpected coupling {coupling}")
    return coupling


def read_indexed(path, key_of, expected):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        index = {}
        for row in csv.DictReader(stream):
            key = key_of(row)
            require(key not in index, f"{path.name}: duplicate row {key}")
            index[key] = row
    require(
        index.keys() == expected,
        f"{path.name}: missing {sorted(expected - index.keys())}, "
        f"unexpected {sorted(index.keys() - expected)}",
    )
    return index


def verify_trajectories(run, archive):
    expected = {(g, t) for g in COUPLINGS for t in GRID}
    raw = read_indexed(
        run / "coupling_timeseries.csv",
        lambda row: (coupling_key(row), time_key(row)),
        expected,
    )
    previous = read_indexed(archive / HISTORICAL_CSV, time_key, set(GRID))

    fields = {
        "load_energy": "E_load",
        "load_ergotropy": "W",
        "load_passive_energy": "E_passive",
    }
    trajectories = {}
    previous_max_error = 0
    initial = {field: value(raw[0.25, GRID.start], field) for field in fields}
    for (g, t), row in raw.items():
        label = f"g={g:g}, t={t / 100:.2f}"
        current = {field: value(row, field) for field in fields}
        for field in ("trace_error", "hermiticity_error"):
            error = value(row, field)
            require(0 <= error <= TOL, f"{label}: {field} = {error:.3e}")
        for field, archive_field in fields.items():
            if t == GRID.start:
                near(current[field], initial[field], f"{label} common initial {field}")
            if g in PREVIOUS:
                reference = value(previous[t], f"{archive_field}_{PREVIOUS[g]}")
                error = near(current[field], reference, f"{label} historical {field}")
                previous_max_error = max(previous_max_error, error)
        require(all(v >= -TOL for v in current.values()), f"{label}: negative load observable")
        near(
            current["load_ergotropy"],
            current["load_energy"] - current["load_passive_energy"],
            f"{label} ergotropy accounting",
        )
        trajectories[g, t] = current
    return trajectories, previous_max_error


def verify_extractions(run, previous_ledger, trajectories):
    index = read_indexed(
        run / "extraction_ledger.csv",
        lambda row: (coupling_key(row), time_key(row)),
        {(g, t) for g in COUPLINGS for t in EXTRACTION_TIMES},
    )
    previous = read_indexed(
        previous_ledger,
        lambda row: (row["protocol"], time_key(row)),
        {(protocol, t) for protocol in PREVIOUS.values() for t in EXTRACTION_TIMES},
    )
    previous_max_error = 0
    archived_state_max = 0
    ergotropy_max_error = 0
    result = {}
    invariants = (
        "trace_before_error", "trace_after_error",
        "hermiticity_before_error", "hermiticity_after_error",
        "unitarity_error", "passive_mapping_error", "load_mapping_error",
        "chain_invariance_error",
    )
    fields = (
        "load_before", "load_after", "ergotropy_before", "gross", "ergotropy_after",
        "total_before", "total_after", "total_work", "interaction_before",
        "interaction_after", "interaction_jump", "identity_residual",
        "min_eigenvalue_before", "min_eigenvalue_after",
    )
    for (g, t), row in index.items():
        label = f"g={g:g}, t={t / 100:.2f}"
        require(row["protocol"] == COUPLINGS[g], f"{label}: protocol mismatch")
        require(row["state_source"] == SOURCE, f"{label}: unexpected input state provenance")
        checked = {field: value(row, field) for field in fields}
        for field in invariants:
            error = value(row, field)
            require(0 <= error <= TOL, f"{label}: {field} = {error:.3e}")
        for field in ("min_eigenvalue_before", "min_eigenvalue_after"):
            require(checked[field] >= -TOL, f"{label}: {field} = {checked[field]:.3e}")

        state = trajectories[g, t]
        expected = {
            "load_before": state["load_energy"],
            "load_after": state["load_passive_energy"],
            "ergotropy_before": state["load_ergotropy"],
            "ergotropy_after": 0.0,
            "gross": checked["load_before"] - checked["load_after"],
            "total_work": checked["total_before"] - checked["total_after"],
            "interaction_jump": checked["interaction_after"] - checked["interaction_before"],
            "identity_residual": checked["total_work"]
            - (checked["gross"] - checked["interaction_jump"]),
        }
        for field, expected_value in expected.items():
            near(checked[field], expected_value, f"{label} {field}")
        near(checked["identity_residual"], 0, f"{label} total work closure")
        error = near(checked["gross"], checked["ergotropy_before"], f"{label} gross work")
        ergotropy_max_error = max(ergotropy_max_error, error)

        if g in PREVIOUS:
            old = previous[PREVIOUS[g], t]
            for field in ("gross", "total_work", "interaction_jump"):
                error = near(checked[field], value(old, field), f"{label} experiment A {field}")
                previous_max_error = max(previous_max_error, error)

        if g == 0.125 and t in (850, 1000):
            error = value(row, "archived_state_max_abs_error")
            require(0 <= error <= TOL, f"{label} archived matrix max error = {error:.3e}")
            archived_state_max = max(archived_state_max, error)
        else:
            require(not row["archived_state_max_abs_error"], f"{label}: unexpected archived matrix")
        result[g, t] = checked

    return result, previous_max_error, ergotropy_max_error, archived_state_max


def verify_switches(run, archive):
    index = read_indexed(run / "switching_ledger.csv", coupling_key, set(COUPLINGS))
    archived_c2 = None
    relative = "work/c2_extension_project/inputs/m14_plan_b/m14_plan_b_switching_work.csv"
    with (archive / relative).open(encoding="utf-8-sig", newline="") as stream:
        for row in csv.DictReader(stream):
            if row["protocol"] == "C2":
                archived_c2 = row
    require(archived_c2 is not None, "Archived C2 switching work missing")
    archived_expectation = value(archived_c2, "interaction_expectation_V")
    max_residual = 0
    max_step_error = 0
    common_expectation = value(index[0.25], "interaction_expectation_v")
    for g, row in index.items():
        label = f"g={g:g} quench"
        require(time_key(row) == GRID.start, f"{label}: wrong quench time")
        g_before = value(row, "g_before")
        near(g_before, 0.25, f"{label} pre-quench g", tolerance=0)
        expectation = value(row, "interaction_expectation_v")
        near(expectation, archived_expectation, f"{label} archived interaction expectation", SWITCH_ARCHIVE_TOL)
        near(expectation, common_expectation, f"{label} common interaction expectation", SWITCH_ARCHIVE_TOL)
        work = value(row, "work_on_system")
        near(work, (g - g_before) * expectation, f"{label} linear switching work", SWITCH_ARCHIVE_TOL)
        jump = value(row, "direct_total_jump")
        residual = value(row, "residual")
        near(residual, jump - work, f"{label} residual accounting", SWITCH_ARCHIVE_TOL)
        near(jump, work, f"{label} total energy jump", SWITCH_DIRECT_TOL)
        step_error = value(row, "sparse_dense_step_error")
        require(0 <= step_error <= STEP_TOL, f"{label}: sparse/dense step error {step_error:.3e}")
        max_residual = max(max_residual, abs(residual))
        max_step_error = max(max_step_error, step_error)
    near(
        value(index[0.125], "work_on_system"),
        value(archived_c2, "switching_work_on_system"),
        "C2 archived switch work",
        SWITCH_ARCHIVE_TOL,
    )
    return index, max_residual, max_step_error


def time_ranges(times):
    if not times:
        return "none"
    ranges = []
    start = last = times[0]
    for time in times[1:]:
        if time != last + 1:
            ranges.append((start, last))
            start = time
        last = time
    ranges.append((start, last))
    return ", ".join(
        f"{start / 100:.2f}" if start == end else f"{start / 100:.2f}-{end / 100:.2f}"
        for start, end in ranges
    )


def present(trajectories, extraction, switches):
    def ergotropy(g, t):
        return trajectories[g, t]["load_ergotropy"]

    print("Time   " + "".join(f"g={g:g}".rjust(17) for g in COUPLINGS))
    summary = []
    for t in (GRID.start, *EXTRACTION_TIMES):
        print(f"{t / 100:5.2f}  " + "".join(f"{ergotropy(g,t):17.9e}" for g in COUPLINGS))
        entry = {"time": f"{t / 100:.2f}"}
        for g, protocol in COUPLINGS.items():
            entry[f"ergotropy_{protocol}"] = ergotropy(g, t)
            entry[f"retention_percent_{protocol}"] = 100 * ergotropy(g, t) / ergotropy(g, GRID.start)
            captured = extraction.get((g, t))
            entry[f"extracted_gross_{protocol}"] = "" if captured is None else captured["gross"]
            entry[f"extracted_total_{protocol}"] = "" if captured is None else captured["total_work"]
        summary.append(entry)

    print(f"Trajectory changes, comparisons at tolerance {TOL:.0e}:")
    for g in COUPLINGS:
        initial, final = ergotropy(g, GRID.start), ergotropy(g, GRID[-1])
        changes = [ergotropy(g, b) - ergotropy(g, a) for a, b in pairwise(GRID)]
        increases = sum(change > TOL for change in changes)
        decreases = sum(change < -TOL for change in changes)
        flats = len(changes) - increases - decreases
        peak_time = max(GRID, key=lambda t: ergotropy(g, t))
        largest_increase_time = max(range(len(changes)), key=changes.__getitem__) + GRID.start + 1
        gross_peak = max(EXTRACTION_TIMES, key=lambda t: extraction[g, t]["gross"])
        total_peak = max(EXTRACTION_TIMES, key=lambda t: extraction[g, t]["total_work"])
        wait_loss = 100 * (1 - final / ergotropy(g, EXTRACTION_TIMES[0]))
        print(
            f"g={g:g}: final retention={100 * final / initial:.6f}%; "
            f"8.50 to 10 loss={wait_loss:.6f}%; increases/decreases/flats={increases}/{decreases}/{flats}; "
            f"largest step increase={max(changes):+.3e} ending at t={largest_increase_time / 100:.2f}; "
            f"grid/gross/total peak times={peak_time / 100:.2f}/{gross_peak / 100:.2f}/{total_peak / 100:.2f}; "
            f"quench on-system={value(switches[g], 'work_on_system'):+.3e}"
        )
    all_strict = 0
    noninverted = 0
    for t in GRID:
        gaps = [ergotropy(weak, t) - ergotropy(strong, t) for strong, weak in pairwise(COUPLINGS)]
        all_strict += all(gap > TOL for gap in gaps)
        noninverted += all(gap >= -TOL for gap in gaps)
    print(f"Weaker ordering: {all_strict}/{len(GRID)} strictly ordered, {noninverted}/{len(GRID)} ordered allowing ties.")
    for strong, weak in pairwise(COUPLINGS):
        gaps = {t: ergotropy(weak, t) - ergotropy(strong, t) for t in GRID}
        low_time = min(gaps, key=gaps.__getitem__)
        high_time = max(gaps, key=gaps.__getitem__)
        inversions = [t for t, gap in gaps.items() if gap < -TOL]
        observed_positive = [t for t, gap in gaps.items() if gap > TOL]
        first_ahead = "none" if not observed_positive else f"{observed_positive[0] / 100:.2f}"
        print(
            f"g={weak:g} minus g={strong:g}: "
            f"first positive t={first_ahead}, reversals={len(inversions)} at t={time_ranges(inversions)}, "
            f"min={gaps[low_time]:+.6e} at {low_time / 100:.2f}, "
            f"max={gaps[high_time]:+.6e} at {high_time / 100:.2f}, "
            f"t=10 gap={gaps[GRID[-1]]:+.6e} ({gaps[GRID[-1]] / ergotropy(strong, GRID[-1]):+.6%})"
        )
    final = GRID[-1]
    primary_gap = ergotropy(0.05, final) - ergotropy(0.25, final)
    print(f"g=0.05 minus g=0.25 at t=10: {primary_gap:+.9e} ({primary_gap / ergotropy(0.25, final):+.6%})")
    total_ordered = sum(
        all(extraction[weak, t]["total_work"] - extraction[strong, t]["total_work"] >= -TOL
            for strong, weak in pairwise(COUPLINGS))
        for t in EXTRACTION_TIMES
    )
    max_interaction_jump = max(abs(row["interaction_jump"]) for row in extraction.values())
    print(f"Total-work weaker ordering: {total_ordered}/{len(EXTRACTION_TIMES)} extraction times.")
    print(f"Maximum absolute extraction interaction jump: {max_interaction_jump:.3e}")
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=Path, help="Directory containing the three B CSVs")
    parser.add_argument("archive", type=Path, help="Historical C0/C2 archive root")
    parser.add_argument("--previous-ledger", type=Path, default=DEFAULT_PREVIOUS_LEDGER)
    parser.add_argument("--output", type=Path, help="Optional new summary CSV path")
    args = parser.parse_args()
    try:
        for relative_path, expected_hash in ARCHIVE_HASHES.items():
            path = args.archive / relative_path
            actual_hash = hashlib.sha256(path.read_bytes()).hexdigest().upper()
            require(actual_hash == expected_hash, f"Archive SHA-256 mismatch: {relative_path}")
        trajectories, trajectory_error = verify_trajectories(args.run, args.archive)
        extraction, extraction_error, gross_error, matrix_error = verify_extractions(
            args.run, args.previous_ledger, trajectories,
        )
        switches, quench_error, step_error = verify_switches(args.run, args.archive)
        summary = present(trajectories, extraction, switches)
        print(
            f"PASS: {len(trajectories)} trajectory points, {len(extraction)} extractions, "
            f"{len(switches)} switch ledgers, {len(ARCHIVE_HASHES)} archive hashes."
        )
        print(
            f"Max historical trajectory diff={trajectory_error:.3e}, "
            f"A extraction diff={extraction_error:.3e}, gross vs ergotropy={gross_error:.3e}, "
            f"C2 saved matrix diff={matrix_error:.3e}, "
            f"switch residual={quench_error:.3e}, sparse/dense step diff={step_error:.3e}."
        )
        if args.output is not None:
            with args.output.open("x", encoding="utf-8", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=list(summary[0]))
                writer.writeheader()
                writer.writerows(summary)
    except (OSError, ValueError, TypeError, KeyError) as exc:
        parser.exit(1, f"FAIL: {exc}\n")


if __name__ == "__main__":
    main()
