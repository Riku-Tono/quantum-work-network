# Reproducing Milestones 15B–17

These experiments start from the registered matched N=7 density matrix at
`t=7.70`. The archive contains the Rust source and vendored dependencies,
historical input states and comparison CSVs, and the published results.
The original M15A package is available in the repository's `zip/` directory.

| Milestone | Included reference |
| --- | --- |
| 15B | [Four-time comparison](reference/M15B/m15b_timing_comparison.csv) and [extraction ledger](reference/M15B/m15b_extraction_ledger.csv) |
| 16 | [Coupling comparison](reference/M16/coupling_comparison.csv), [raw CSV archive](reference/M16/coupling_details.zip), and [time series figure](reference/M16/coupling_ergotropy.png) |
| 17 | [Report](reference/M17/MILESTONE_17_DECOUPLING_STORAGE_REPORT.md), [preregistration](reference/M17/PRECOMMIT_M17.md), and [state manifest](reference/M17/m17_state_manifest.csv) |

`history/` contains the original C2 extension study's states and C0/C2 tables,
the earlier M14 switching ledger and common state, the M15A gross and operation
work tables, and the saved M12C load/chain observables. Their original bytes are
retained. In the historical M17 SHA-256 audit, the local directory prefixes have
been replaced with `historical-data/` and `november-experiment/` aliases.
The original input and state hashes are retained.

## Check the supplied results

Run PowerShell in this directory with Python 3.13 or newer. Install the listed
Python dependencies for the M17 independent state audit and optional plots.
Use a fresh output folder on each run.

```powershell
python -m pip install -r requirements.txt
$env:OPENBLAS_NUM_THREADS = '1'
$common = 'history/work/c2_extension_project/inputs/m14_plan_b/m14_plan_b_rho_t770.bin'
New-Item -ItemType Directory -Path redo
python -m zipfile -e reference/M16/coupling_details.zip redo/m16-reference
python -B scripts/verify_timing.py reference/M15B/m15b_extraction_ledger.csv history
python -B scripts/verify_coupling.py redo/m16-reference history --previous-ledger reference/M15B/m15b_extraction_ledger.csv
python -B scripts/verify_saved_states.py reference/M17 $common redo/m17-reference-state-check.csv
```

The M15B verifier checks eight extractions and six historical hashes. The M16
verifier checks 924 trajectory points, 16 extractions, four switching entries
and four historical hashes. The M17 verifier independently checks the four
saved density matrices and reports 44 state and accounting checks.

## Recompute from source

Run the following in the same PowerShell session. The commands use the stable
Rust toolchain and the included Cargo vendor directory. The numerical checks
use their recorded tolerances. Runtime and floating-point rounding can vary
with the compiler and CPU.

```powershell
$env:RUSTFLAGS = '-C target-cpu=native'
Push-Location solver
cargo build --release --locked --offline --target-dir ../redo/build --bin m15b_timing_extraction --bin coupling_sweep --bin m17_storage
Pop-Location

$c2Before850 = 'history/outputs/c2_pre_extraction_state_t850.bin'
$c2Before1000 = 'history/outputs/c2_pre_extraction_state_t1000.bin'
$m14Switch = 'history/work/c2_extension_project/inputs/m14_plan_b/m14_plan_b_switching_work.csv'
$c0Series = 'history/outputs/matched_n7_load_chain_correlation_timeseries.csv'
$c2Series = 'history/outputs/c2_extended_t770_t1000_timeseries.csv'

./redo/build/release/m15b_timing_extraction.exe $common $c2Before850 $c2Before1000 redo/m15b_extraction_ledger.csv
python -B scripts/verify_timing.py redo/m15b_extraction_ledger.csv history --output redo/m15b_timing_comparison.csv

./redo/build/release/coupling_sweep.exe $common $c2Before850 $c2Before1000 redo/m16
python -B scripts/verify_coupling.py redo/m16 history --previous-ledger redo/m15b_extraction_ledger.csv --output redo/coupling_comparison.csv
python -B scripts/plot_coupling.py redo/m16/coupling_timeseries.csv redo/coupling_ergotropy.png

./redo/build/release/m17_storage.exe benchmark $common redo/m17-benchmark
./redo/build/release/m17_storage.exe formal $common redo/m17-formal
./redo/build/release/m17_storage.exe diagnostic_replay $common redo/m17-diagnostic
python -B scripts/process_m17.py --formal redo/m17-formal --diagnostic-replay redo/m17-diagnostic --m16 redo/m16-reference --common-state $common --hist-c0-series $c0Series --hist-c2-series $c2Series --m14-switch $m14Switch --output redo/m17-results --plots
python -B scripts/verify_saved_states.py redo/m17-formal $common redo/m17-state-check.csv
```

M17 uses the original M16 results in `redo/m16-reference` for the previously
reported work values. The diagnostic replay supplies observables missing from
those archived trajectories. The four regenerated M17 state files are written
under `redo/m17-formal`.

The published M17 trajectory and comparison tables include a final
`positivity_status` column. The recomputation script reports the positivity
checks in the numerical audit and keeps `positivity_method` and
`solver_status` in its tables.
