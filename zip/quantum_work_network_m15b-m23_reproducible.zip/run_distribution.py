"""Check distribution solvers and run the original milestone launchers."""
import argparse
import csv
import hashlib
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parent
SOLVERS = {
    18: "m18_reconnection.exe",
    19: "m19_repeated.exe",
    20: "m20_fixed_wait.exe",
    21: "m21_dephasing.exe",
    22: "m22_connected.exe",
}


def sha256(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest().upper()


def read_registry(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def run_legacy(number, source, launcher, executable, mode, arguments):
    registry = f"m{number}_precommit_sha256.csv"
    entries = read_registry(source / registry)
    if sum(entry["filename"] == executable.name for entry in entries) != 1:
        raise ValueError("Expected one original executable record")
    if sum(entry["filename"] == launcher for entry in entries) != 1:
        raise ValueError("Expected one registered launcher record")

    with tempfile.TemporaryDirectory(prefix=f"qwn-m{number}-") as temporary:
        replica = Path(temporary)
        for entry in entries:
            name = entry["filename"]
            if name == executable.name:
                entry["sha256"] = sha256(executable)
                continue
            path = PurePosixPath(name)
            if path.is_absolute() or ".." in path.parts or ":" in name or "\\" in name:
                raise ValueError(f"Invalid registered path: {name}")
            target = replica / path
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source / path, target)

        with (replica / registry).open("x", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=("filename", "sha256"))
            writer.writeheader()
            writer.writerows(entries)
        return subprocess.call([sys.executable, "-B", replica / launcher, mode, executable, *arguments])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("milestone", type=int, choices=SOLVERS)
    parser.add_argument("mode", choices=("benchmark", "formal"))
    parser.add_argument("original_arguments", nargs=argparse.REMAINDER)
    args = parser.parse_args()

    source = ROOT / f"Milestone_{args.milestone}"
    launcher = f"run_m{args.milestone}.py"
    executable = source / SOLVERS[args.milestone]
    relative = executable.relative_to(ROOT).as_posix()
    published = read_registry(ROOT / "m18_m22_distribution_sha256.csv")
    expected, = (entry["sha256"] for entry in published if entry["filename"] == relative)
    if sha256(executable) != expected:
        raise ValueError(f"Distribution binary SHA-256 mismatch: {relative}")

    if args.milestone <= 20:
        return run_legacy(args.milestone, source, launcher, executable, args.mode, args.original_arguments)
    return subprocess.call(
        [sys.executable, "-B", source / launcher, args.mode, executable, *args.original_arguments, "--allow-rebuilt"]
    )


if __name__ == "__main__":
    raise SystemExit(main())
