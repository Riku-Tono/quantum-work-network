# Quantum Work Network | M15B–M23 reproduction package

This Windows x64 package begins at the saved matched N=7 state used after
M15A. It includes frozen input states, Rust and Python source, stage reports,
selected reference results, and step-by-step commands.
M18–M22 include Windows solvers rebuilt from the registered source with
local build paths remapped. The package records their SHA-256 separately from
the original preregistration records.

- [M15B–M17 reproduction](M15B-M17/README.md) covers extraction timing,
  coupling strength, and decoupled storage. The Cargo dependencies for these
  stages are vendored.
- [M18–M23 reproduction](REPRODUCE_M18_M23.md) covers reconnection, repeated
  extraction, dephasing, continuous connection, and variable waits. Start with
  the short benchmarks or run the formal calculations in fresh output folders.
  Stage reports describe the finite grids and acceptance thresholds.
- SHA256SUMS records the SHA-256 of every other file in this package, using
  paths relative to this directory.

The starting states come from the registered calculations. Use the included
copies when reproducing a later stage against its published values. The formal
runs regenerate full candidate grids, output states, and audit CSVs. Some
report links point to those generated files.

Use Windows PowerShell with Python 3.14 x64. The stage instructions list Python
packages and the Rust toolchain needed for source builds. Model time in the
CSV tables measures simulation time.

[Project README and earlier archives](https://github.com/Riku-Tono/quantum-work-network)

