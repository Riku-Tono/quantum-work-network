# M18–M23 再現手順

登録済みソースと入力、Windows x64 用に再ビルドした配布ソルバー、正式報告書、主要な比較表と図を収録した。再計算で得られる全候補、全保存状態、詳細監査の一部は各実験の正式全成果物ZIPに収録されている。元の報告書が参照するそれらのファイルは、下記の再計算でも生成できる。過去の全成果物ZIPと入力を再照合する手順を実行する場合は、元ZIPを別途用意する。

Windows PowerShell と Python 3.14 x64 を使用する。以下を展開先のルートで実行し、各節では対象フォルダーへ移動してからコマンドを実行する。出力先 `redo_*` は新しい名前にする。再計算した状態を監査する際は、正式入力として同梱した過去の状態を使う。

```powershell
py -3.14 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-m18-m23.txt
$QwnPython = (Resolve-Path .\.venv\Scripts\python.exe).Path
$env:OPENBLAS_NUM_THREADS = '1'
```

## M18 再接続と第二回抽出

作業ディレクトリは `Milestone_18`。M17 C5 の抽出前後状態と履歴台帳は `m17_inputs/` にある。入力のみを確認する場合は最初のコマンドを使う。正式出力は短縮ベンチマークと異なるパスに保存する。 [M18 正式報告書](Milestone_18/MILESTONE_18_RECONNECTION_RECOVERY_REPORT.md)

```powershell
& $QwnPython -B verify_m18.py m17_inputs
& $QwnPython -B ../run_distribution.py 18 benchmark redo_benchmark_branches redo_benchmark --workers 2
& $QwnPython -B ../run_distribution.py 18 formal redo_formal_branches redo_formal --workers 2
& $QwnPython -B summarize_m18.py redo_formal m17_inputs --tables-only
& $QwnPython -B verify_m18.py m17_inputs redo_formal
& $QwnPython -B summarize_m18.py redo_formal m17_inputs --benchmark redo_benchmark --report-only
& $QwnPython -B plot_m18.py --data redo_formal
```

## M19 反復抽出

作業ディレクトリは `Milestone_19`。独立監査は同梱の `../Milestone_18` にある正式起点を参照する。 [M19 正式報告書](Milestone_19/MILESTONE_19_REPEAT_RECOVERY_REPORT.md)

```powershell
& $QwnPython -B verify_m19.py ../Milestone_18 --read-only
& $QwnPython -B ../run_distribution.py 19 benchmark redo_benchmark
& $QwnPython -B ../run_distribution.py 19 formal redo_formal
Copy-Item -LiteralPath m18_inputs -Destination redo_formal -Recurse
& $QwnPython -B summarize_m19.py redo_formal ../Milestone_18 --tables-only
& $QwnPython -B verify_m19.py ../Milestone_18 redo_formal
& $QwnPython -B m19_quantum_correlations.py ../Milestone_18 redo_formal
& $QwnPython -B summarize_m19.py redo_formal ../Milestone_18 --benchmark redo_benchmark --report-only
& $QwnPython -B plot_m19.py --data redo_formal
```

## M20 待機時間固定

作業ディレクトリは `Milestone_20`。M19 の比較には同梱の `m19_reference/` を使う。 [M20 正式報告書](Milestone_20/MILESTONE_20_FIXED_WAIT_RECOVERY_REPORT.md)

```powershell
& $QwnPython -B verify_m20.py ../Milestone_18 --read-only
& $QwnPython -B ../run_distribution.py 20 benchmark redo_benchmark
& $QwnPython -B ../run_distribution.py 20 formal redo_formal
& $QwnPython -B summarize_m20.py redo_formal ../Milestone_18 m19_reference --tables-only
& $QwnPython -B verify_m20.py ../Milestone_18 redo_formal
& $QwnPython -B m20_sector_diagnostics.py ../Milestone_18 m19_reference redo_formal
& $QwnPython -B m20_dephasing_accounting.py redo_formal
& $QwnPython -B summarize_m20.py redo_formal ../Milestone_18 m19_reference --benchmark redo_benchmark --report-only
& $QwnPython -B plot_m20.py --data redo_formal --reference m19_reference/m19_cycle_ledger.csv
```

## M21 デフェージング率比較

作業ディレクトリは `Milestone_21`。[正式再計算の手順](Milestone_21/README_M21.md) の再計算と集計を実行する。案内中の `py -3.14` は `& $QwnPython` に読み替えられる。正式計算の起動は `& $QwnPython -B ../run_distribution.py 21 formal redo_formal --jobs 2`。短縮ベンチマークと監査は次のとおり。 [M21 正式報告書](Milestone_21/MILESTONE_21_DEPHASING_REPORT.md)

```powershell
& $QwnPython -B ../run_distribution.py 21 benchmark redo_benchmark --jobs 2
Copy-Item -LiteralPath m18_inputs -Destination redo_benchmark/merged -Recurse
& $QwnPython -B m21_observables.py redo_benchmark/merged
& $QwnPython -B verify_m21.py redo_benchmark/merged --window 0.50 --last-cycle 3 --read-only
```

## M22 常時接続との比較

作業ディレクトリは `Milestone_22`。[正式再計算の手順](Milestone_22/README_M22.md) の正式再計算と集計を実行する。参照入力は照合済みの `m18_inputs/` と `reference/` を使う。正式計算の起動は `& $QwnPython -B ../run_distribution.py 22 formal redo_formal --jobs 2`。短縮ベンチマークと監査は次のとおり。 [M22 正式報告書](Milestone_22/MILESTONE_22_CONTINUOUS_CONNECTION_REPORT.md)

```powershell
& $QwnPython -B ../run_distribution.py 22 benchmark redo_benchmark --jobs 2
& $QwnPython -B package_m22.py benchmark redo_benchmark --destination redo_benchmark_results
& $QwnPython -B m22_observables.py redo_benchmark_results
& $QwnPython -B m22_observables.py redo_benchmark_results/single --input-root redo_benchmark_results
& $QwnPython -B verify_m22.py redo_benchmark_results --benchmark --window 0.50 --single-window 2.50 --read-only
```

## M23 切断待機時間掃引と反復抽出

作業ディレクトリは `Milestone_23`。単回掃引と所定のゲートを経る反復計算は [正式再計算の手順](Milestone_23/README_M23.md) に従う。入力照合、短縮計算、M22 との照合、独立監査は次のとおり。 [M23 正式報告書](Milestone_23/MILESTONE_23_PHASE_CONTROL_REPORT.md)

```powershell
& $QwnPython -B package_m23.py verify-inputs
$env:OPENBLAS_NUM_THREADS = '2'
& $QwnPython -B run_m23.py benchmark redo_benchmark --inputs .
& $QwnPython -B benchmark_validate_m23.py redo_benchmark --inputs .
$env:OPENBLAS_NUM_THREADS = '1'
& $QwnPython -B verify_m23.py redo_benchmark --inputs . --benchmark --read-only
```

## M18–M22 ソースのビルド

各フォルダーの `solver/` に MIT ライセンス、Rust のソース、`Cargo.lock` がある。安定版 Rust と依存パッケージを取得できるネットワーク環境で各ソルバーをビルドできる。次は M18 の例。M19〜M22 では `--bin` に対応する同梱実行ファイル名から `.exe` を除いた名前を指定する。

```powershell
$env:RUSTFLAGS = '-C target-cpu=native'
cargo build --release --locked --manifest-path solver/Cargo.toml --target-dir redo_build --bin m18_reconnection
```

正式報告書に記載された元バイナリの登録ハッシュは、各実験の登録表に保存している。同梱バイナリはビルド時のローカルパスを置換して再作成した。上記の起動コマンドは [配布版 SHA-256](m18_m22_distribution_sha256.csv) を照合する。M18〜M20 では元ランチャーと登録ファイルを一時領域に複製し、実行ファイルのハッシュ欄だけを一時的に配布版へ置き換える。M21 と M22 では元ランチャーの `--allow-rebuilt` が登録済みソースと入力を照合する。再ビルド、実行環境や BLAS の違いにより、実行時間や浮動小数点の丸めは変わり得る。
