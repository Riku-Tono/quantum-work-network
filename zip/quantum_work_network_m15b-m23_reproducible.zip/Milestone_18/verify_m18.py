"""Reopen and independently validate M18 QWNRHO1 density matrices with NumPy/LAPACK."""

import argparse
import csv
from dataclasses import dataclass
import hashlib
import math
import os
from pathlib import Path, PurePosixPath
import struct

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import numpy as np


CONDITIONS = {"R0": 0.0, "R1": 0.01, "R2": 0.05, "R3": 0.125, "R4": 0.25, "U4": 0.25}
START, END = 1000, 2000
FIXED = (1200, 1500, 2000)
N, LOAD = 7, 3
CHAIN = 1 << N
DIM = CHAIN * LOAD
LEVELS = np.arange(LOAD)
HEADER = struct.Struct("<8sQd")
SIZE = HEADER.size + DIM * DIM * 16
TOL = 1e-12
SPECTRUM_TOL = 1e-10
SWITCH_TOL = 1e-18
DIRECT_SWITCH_TOL = 1e-15
GAMMA = 1.5 / N
W_FIRST = 3.385250121299e-3
M17_HASHES = {
    "g000_t1000_before.bin": "DFD6E1329C4036C198A1435855E1E33BEBD266B75754F76F504F702E738C5571",
    "g000_t1000_after.bin": "A88FB15482BFEEE2F122603CEEF4F8A64A761C1D8F6C97185B34107844BB9977",
    "m17_state_manifest.csv": "D84705717D73D20B3945958A70B167D8D8D50DABBEF41695C49433F326317D6F",
    "m17_switching_work.csv": "934C490DA35E78969A2DD79E601E9B1A24DD186F88635D5FC5A10C339F8FDACD",
    "m17_extraction_ledger.csv": "60399380377E5DFC7FA9C57C9A358CD09A4D955D63350AF95A27A7AC1529E078",
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_csv(path):
    with path.open(newline="", encoding="utf-8-sig") as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows):
    with path.open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def grid_key(time):
    time = float(time)
    key = round(time * 100)
    require(abs(time - key / 100) <= TOL, f"Off-grid time {time}")
    return key


def index_rows(rows, key):
    indexed = {key(row): row for row in rows}
    require(len(indexed) == len(rows), "Duplicate CSV key")
    return indexed


def max_abs(matrix):
    return float(np.max(np.abs(matrix)))


def hermitian_part(matrix):
    return (matrix + matrix.conj().T) * 0.5


@dataclass
class State:
    rho: np.ndarray
    sha256: str
    time: float
    spectrum: np.ndarray

    @classmethod
    def read(cls, path, expected_time):
        raw = path.read_bytes()
        require(len(raw) == SIZE, f"Wrong byte count in {path}")
        magic, dimension, time = HEADER.unpack_from(raw)
        require(magic == b"QWNRHO1\0" and dimension == DIM, f"Bad QWNRHO1 header in {path}")
        require(abs(time - expected_time) <= TOL, f"Unexpected timestamp {time} in {path}")
        matrix = np.frombuffer(raw, dtype="<c16", offset=HEADER.size).reshape(DIM, DIM)
        require(np.isfinite(matrix).all(), f"Nonfinite density matrix in {path}")
        spectrum = np.linalg.eigvalsh(hermitian_part(matrix))
        require(np.isfinite(spectrum).all(), f"Nonfinite density spectrum in {path}")
        return cls(matrix, hashlib.sha256(raw).hexdigest().upper(), time, spectrum)

    @property
    def trace_error(self):
        return abs(np.trace(self.rho) - 1)

    @property
    def hermiticity_error(self):
        return max_abs(self.rho - self.rho.conj().T)


class Checks:
    def __init__(self):
        self.rows = []
        self.manifest = []

    def error(self, condition, branch, time, filename, check, value, tolerance=TOL):
        value = float(value)
        self.rows.append({
            "condition": condition, "branch": branch, "time": f"{time:.2f}", "filename": filename,
            "check": check, "observed": value, "bound": tolerance, "rule": "<=",
            "status": "PASS" if math.isfinite(value) and 0 <= value <= tolerance else "FAIL",
        })

    def state(self, state, condition, branch, filename):
        key = (condition, branch, state.time, filename)
        self.error(*key, "trace_error", state.trace_error)
        self.error(*key, "hermiticity_error", state.hermiticity_error)
        self.error(*key, "negative_eigenvalue_magnitude", max(0, -state.spectrum[0]))
        self.error(*key, "eigenspectrum_trace_residual", abs(state.spectrum.sum() - np.trace(state.rho).real), SPECTRUM_TOL)

    def recorded(self, key, derived, row):
        for field, value in derived.items():
            self.error(*key, f"{field}_vs_csv", abs(value - float(row[field])))

    def saved_state(self, directory, filename, condition, branch, time, phase, source):
        relative = PurePosixPath(filename)
        require(relative.parts == ("states", relative.name), f"Invalid state path {filename}")
        state = State.read(directory / relative, time)
        self.state(state, condition, branch, filename)
        physical = (
            state.trace_error <= TOL and state.hermiticity_error <= TOL
            and state.spectrum[0] >= -TOL
        )
        self.manifest.append({
            "filename": filename, "condition": condition, "g": CONDITIONS[condition],
            "time": f"{state.time:.2f}", "branch": branch, "extraction_phase": phase,
            "source_initial_state_file": source[0], "source_initial_state_sha256": source[1].sha256,
            "sha256": state.sha256, "size_bytes": SIZE, "dimension": DIM,
            "subsystem_dims": "2,2,2,2,2,2,2,3", "tensor_order": "|q1,...,q7,load>; load fastest",
            "basis_order": "lexicographic computational; q=0,1; load=0,1,2",
            "layout": "row-major, each entry real f64 then imaginary f64", "endianness": "little-endian",
            "header": "8-byte QWNRHO1+NUL, u64 dimension, f64 time", "format_version": "QWNRHO1/1",
            "trace_error": state.trace_error, "hermiticity_error": state.hermiticity_error,
            "minimum_eigenvalue": state.spectrum[0], "positivity_status": "PASS" if physical else "FAIL",
            "independent_eigensolver": "numpy.linalg.eigvalsh (LAPACK)",
        })
        return state


def load_m17(directory, checks):
    manifest_path = directory / "m17_state_manifest.csv"
    digest = hashlib.sha256(manifest_path.read_bytes()).hexdigest().upper()
    require(digest == M17_HASHES[manifest_path.name], "M17 manifest SHA-256 mismatch")
    manifest = index_rows(read_csv(manifest_path), lambda row: row["filename"])
    checks.error("C5", "official_input", 10, manifest_path.name, "pinned_manifest_sha256_mismatch", 0, 0)
    sources = {}
    for phase in ("before", "after"):
        filename = f"g000_t1000_{phase}.bin"
        state = State.read(directory / filename, 10)
        row = manifest[filename]
        require(state.sha256 == row["sha256"] == M17_HASHES[filename], f"M17 state SHA-256 mismatch for {filename}")
        require(
            row["condition"] == "C5" and float(row["g_after_branch"]) == 0
            and int(row["size_bytes"]) == SIZE and int(row["dimension"]) == DIM
            and row["format_version"] == "QWNRHO1/1" and grid_key(row["time"]) == START
            and row["extraction_phase"] == f"{phase}_single_ideal_load_extraction",
            f"Unexpected M17 manifest metadata for {filename}",
        )
        key = ("C5", "official_input", state.time, filename)
        checks.error(*key, "pinned_and_manifest_sha256_mismatch", 0, 0)
        checks.state(state, "C5", "official_input", filename)
        sources[phase] = (filename, state)
    return sources


def read_m17_ledger(directory, filename, checks):
    path = directory / filename
    digest = hashlib.sha256(path.read_bytes()).hexdigest().upper()
    require(digest == M17_HASHES[filename], f"Historical M17 ledger SHA-256 mismatch for {filename}")
    checks.error("C5", "official_input", 10, filename, "pinned_ledger_sha256_mismatch", 0, 0)
    return index_rows(read_csv(path), lambda row: row["protocol"])["C5"]


def partial_traces(matrix):
    blocks = matrix.reshape(CHAIN, LOAD, CHAIN, LOAD)
    end_blocks = matrix.reshape(CHAIN // 2, 2 * LOAD, CHAIN // 2, 2 * LOAD)
    return (
        np.trace(blocks, axis1=0, axis2=2),
        np.trace(blocks, axis1=1, axis2=3),
        np.trace(end_blocks, axis1=0, axis2=2),
    )


def passive_rotation(load):
    values, vectors = np.linalg.eigh(hermitian_part(load))
    values, vectors = values[::-1], vectors[:, ::-1]
    for vector in vectors.T:
        abs_vector = np.abs(vector)
        pivot = np.flatnonzero(abs_vector == np.max(abs_vector))[-1]
        vector *= vector[pivot].conjugate() / abs_vector[pivot]
    return values, vectors.conj().T


def chain_hopping():
    hopping = np.zeros((CHAIN, CHAIN))
    for basis in range(CHAIN):
        for site in range(N - 1):
            if ((basis >> site) ^ (basis >> (site + 1))) & 1:
                hopping[basis ^ (3 << site), basis] = 1.0
    return hopping


def real_expect(state, operator):
    return float(np.sum(state * operator.T).real)


def entropy(eigenvalues):
    positive = eigenvalues[eigenvalues > 0]
    populations = positive / positive.sum()
    return float(-np.dot(populations, np.log(populations)))


class Model:
    def __init__(self):
        self.onsite = np.diag([basis.bit_count() for basis in range(CHAIN)])
        self.hopping = chain_hopping()
        raise_spin = np.array([[0, 0], [1, 0]])
        lower_load = np.diag(np.sqrt(LEVELS[1:]), k=1)
        term = np.kron(raise_spin, lower_load)
        self.exchange = term + term.T
        end_load_energy = np.diag(np.tile(LEVELS, 2))
        self.current = 1j * (self.exchange @ end_load_energy - end_load_energy @ self.exchange)

    def observables(self, state, coupling):
        load, chain, end = partial_traces(state.rho)
        populations = np.diag(load).real
        spectrum = np.linalg.eigvalsh(hermitian_part(load))
        energy = float(LEVELS @ populations)
        passive_energy = float(LEVELS @ spectrum[::-1])
        population_work = energy - float(LEVELS @ np.sort(populations)[::-1])
        hopping_energy = real_expect(chain, self.hopping)
        chain_energy = real_expect(chain, self.onsite) + hopping_energy
        interaction = coupling * real_expect(end, self.exchange)
        # Exchange coherences differ in one chain bit and nearest-neighbor hopping in two.
        bath_rate = -GAMMA * (2 * hopping_energy + interaction)
        entropy_chain = entropy(np.linalg.eigvalsh(hermitian_part(chain)))
        mutual_info = entropy_chain + entropy(spectrum) - entropy(state.spectrum)
        return {
            "load_energy": energy,
            "load_passive_energy": passive_energy,
            "load_ergotropy": energy - passive_energy,
            "population_ergotropy": population_work,
            "coherent_ergotropy": energy - passive_energy - population_work,
            **{f"load_population_{index}": value for index, value in enumerate(populations)},
            "load_purity": float(np.sum(np.abs(load) ** 2)),
            "chain_energy": chain_energy,
            "interaction_energy": interaction,
            "total_system_energy": chain_energy + energy + interaction,
            "site7_to_load_current": coupling * real_expect(end, self.current),
            "dissipative_energy_change_rate": bath_rate,
            "mutual_information_nats": mutual_info,
            "trace_error": state.trace_error,
            "hermiticity_error": state.hermiticity_error,
            "minimum_eigenvalue": state.spectrum[0],
        }


def check_sample(checks, key, observations, row):
    required = {
        "load_energy", "load_passive_energy", "load_ergotropy", "chain_energy",
        "interaction_energy", "total_system_energy", "minimum_eigenvalue", "site7_to_load_current",
    }
    require(required <= row.keys(), f"Missing fields in timeseries at {key}")
    checks.recorded(key, {name: value for name, value in observations.items() if name in row}, row)


def inspect_pair(checks, before, after, model, coupling, key, archived):
    load_before, chain_before, _ = partial_traces(before.rho)
    load_after, chain_after, _ = partial_traces(after.rho)
    values, unitary = passive_rotation(load_before)
    rotated = np.einsum(
        "ai,xiyj,bj->xayb", unitary, before.rho.reshape(CHAIN, LOAD, CHAIN, LOAD),
        unitary.conj(), optimize=True,
    ).reshape(DIM, DIM)
    checks.error(*key, "full_local_passivation_max_abs_error", max_abs(after.rho - rotated))
    checks.error(*key, "load_passivation_max_abs_error", max_abs(load_after - np.diag(values)))
    checks.error(*key, "chain_preservation_frobenius_error", np.linalg.norm(chain_after - chain_before))
    checks.error(*key, "local_unitarity_frobenius_error", np.linalg.norm(unitary @ unitary.conj().T - np.eye(LOAD)))
    checks.error(*key, "full_spectrum_preservation_max_abs_error", max_abs(before.spectrum - after.spectrum))

    obs_before = model.observables(before, coupling)
    obs_after = model.observables(after, coupling)
    gross = obs_before["load_energy"] - obs_after["load_energy"]
    interaction_jump = obs_after["interaction_energy"] - obs_before["interaction_energy"]
    total_work = obs_before["total_system_energy"] - obs_after["total_system_energy"]
    checks.error(*key, "work_gross_minus_ergotropy_error", abs(gross - obs_before["load_ergotropy"]))
    checks.error(*key, "after_ergotropy_magnitude", abs(obs_after["load_ergotropy"]))
    checks.error(*key, "total_work_identity_residual", abs(total_work - gross + interaction_jump))
    derived = {
        "before_ergotropy": obs_before["load_ergotropy"],
        "bare_load_gross_extracted_work": gross,
        "interaction_energy_jump": interaction_jump,
        "total_hamiltonian_operation_work": total_work,
        "after_ergotropy": obs_after["load_ergotropy"],
    }
    extended = {
        "load_energy_before": obs_before["load_energy"], "load_energy_after": obs_after["load_energy"],
        "interaction_energy_before": obs_before["interaction_energy"],
        "interaction_energy_after": obs_after["interaction_energy"],
        "total_energy_before": obs_before["total_system_energy"], "total_energy_after": obs_after["total_system_energy"],
        "gross_first_ratio": gross / W_FIRST, "total_first_ratio": total_work / W_FIRST,
    }
    derived.update({name: value for name, value in extended.items() if name in archived})
    checks.recorded(key, derived, archived)
    return obs_before, obs_after


def check_switch(directory, checks, model, by_condition):
    rows = index_rows(read_csv(directory / "m18_reconnection_work.csv"), lambda row: row["condition"])
    require(rows.keys() == CONDITIONS.keys(), "Expected one reconnection-work row per condition")
    work = {}
    for code, coupling in CONDITIONS.items():
        row = rows[code]
        require(float(row["g"]) == coupling and float(row["g_before"]) == 0 and grid_key(row["time"]) == START,
                f"Inconsistent switch metadata for {code}")
        filename, state = by_condition[code]
        key = (code, "reconnection", 10, filename)
        before = model.observables(state, 0)
        after = model.observables(state, coupling)
        unscaled_exchange = real_expect(partial_traces(state.rho)[2], model.exchange)
        linear = coupling * unscaled_exchange
        work[code] = linear
        direct = after["total_system_energy"] - before["total_system_energy"]
        linear_fields = {
            "interaction_expectation_v": unscaled_exchange,
            "interaction_before": before["interaction_energy"],
            "interaction_after": after["interaction_energy"],
            "w_switch_on": linear,
            "w_switch_out": -linear,
        }
        for name, value in linear_fields.items():
            checks.error(*key, f"{name}_vs_csv", abs(value - float(row[name])), SWITCH_TOL)
        checks.recorded(key, {"total_before": before["total_system_energy"], "total_after": after["total_system_energy"]}, row)
        checks.error(*key, "direct_total_jump_vs_csv", abs(direct - float(row["direct_total_jump"])), DIRECT_SWITCH_TOL)
        checks.error(*key, "independent_direct_vs_linear", abs(direct - linear), DIRECT_SWITCH_TOL)
        checks.error(*key, "linear_form_residual_magnitude", abs(float(row["linear_form_residual"])), SWITCH_TOL)
        checks.error(*key, "direct_total_residual_magnitude", abs(float(row["direct_total_residual"])), DIRECT_SWITCH_TOL)
        checks.error(*key, "sparse_dense_step_error", float(row["sparse_dense_step_error"]), 1e-13)
        checks.error(*key, "state_invariance_max_abs", float(row["state_invariance_max_abs"]), 0)
    return work


def check_balance(checks, timeseries, measured, first_initial, first_extracted, switches, historical, published):
    for (code, branch, timestamp), (before, after) in measured.items():
        time = timestamp / 100
        key = (code, branch, time, "")
        initial = first_initial["total_system_energy"]
        first = 0 if code == "U4" else initial - first_extracted["total_system_energy"]
        switch = switches[code]
        sample = timeseries[code, timestamp]
        bath = float(sample["dissipative_energy_change_cumulative"])
        inflow = float(sample["cumulative_load_energy_inflow"])
        expected = initial - first + switch + bath
        previous = before["total_system_energy"]
        remaining = after["total_system_energy"]
        second = previous - remaining
        gross = before["load_energy"] - after["load_energy"]
        initial_sample = first_initial if code == "U4" else first_extracted
        historical_switch = float(historical["switch"]["work_on_system"])
        pre_cut = float(historical["switch"]["total_before"])
        post_cut = float(historical["switch"]["total_after"])
        storage = initial - post_cut
        expected_including_cut = pre_cut + historical_switch + storage - first + switch + bath - second
        checks.error(*key, "signed_load_inflow_vs_state_energies", abs(before["load_energy"] - initial_sample["load_energy"] - inflow))
        checks.error(*key, "pre_operation_dissipative_balance_residual", abs(previous - expected))
        checks.error(*key, "post_operation_balance_including_cut_residual", abs(remaining - expected_including_cut))
        if published is not None:
            derived = {
                "first_total_work": first, "w_switch_on": switch, "w_switch_out": -switch,
                "dissipative_energy_change_cumulative": bath,
                "bare_load_gross_extracted_work": gross,
                "total_hamiltonian_operation_work": second, "second_net_work": second - switch,
                "ideal_total_operation_work_out": first + second - switch,
                "total_energy_initial": initial,
                "total_energy_before_reconnection": initial - first,
                "total_energy_after_reconnection": initial - first + switch,
                "total_energy_before_second": previous, "total_energy_after_second": remaining,
                "predicted_total_energy_after_second": expected - second,
                "balance_residual": remaining - expected + second,
                "m17_pre_cut_total_energy": pre_cut, "m17_post_cut_total_energy": post_cut,
                "m17_cut_work_on": historical_switch, "m17_cut_work_out": -historical_switch,
                "m17_cut_direct_total_jump": float(historical["switch"]["direct_total_jump"]),
                "m17_storage_energy_change": storage,
                "ideal_total_operation_work_out_including_cut": first + second - switch - historical_switch,
                "predicted_total_energy_after_second_including_cut": expected_including_cut,
                "balance_residual_including_cut": remaining - expected_including_cut,
            }
            checks.recorded(key, derived, published[code, branch, timestamp])


def verify(directory, sources, historical, checks):
    model = Model()
    timeseries = index_rows(read_csv(directory / "m18_recovery_timeseries.csv"), lambda row: (row["condition"], grid_key(row["time"])))
    require(timeseries.keys() == {(code, t) for code in CONDITIONS for t in range(START, END + 1)}, "Unexpected timeseries grid")
    for (code, _), row in timeseries.items():
        require(float(row["g"]) == CONDITIONS[code], f"Incorrect coupling for {code}")

    by_condition = {code: sources["before" if code == "U4" else "after"] for code in CONDITIONS}
    initial_c5 = model.observables(sources["before"][1], 0)
    extracted_c5 = model.observables(sources["after"][1], 0)
    first_total_work = initial_c5["total_system_energy"] - extracted_c5["total_system_energy"]
    c5_key = ("C5", "official_input", 10, sources["after"][0])
    checks.error(*c5_key, "first_work_vs_fixed_denominator", abs(first_total_work - W_FIRST))
    checks.error(*c5_key, "initial_ergotropy_magnitude", abs(extracted_c5["load_ergotropy"]))
    check_first = {
        "before_ergotropy": "ergotropy_before", "bare_load_gross_extracted_work": "gross",
        "interaction_energy_jump": "interaction_jump", "total_hamiltonian_operation_work": "total_work",
        "after_ergotropy": "ergotropy_after",
    }
    inspect_pair(checks, sources["before"][1], sources["after"][1], model, 0, c5_key,
                 {dst: historical["extraction"][src] for dst, src in check_first.items()})
    switches = check_switch(directory, checks, model, by_condition)

    endpoints = {}
    measured = {}
    for code, coupling in CONDITIONS.items():
        input_file, source = by_condition[code]
        input_key = (code, "input", 10, input_file)
        check_sample(checks, input_key, model.observables(source, coupling), timeseries[code, START])
        filename = f"states/{code}_t2000_endpoint.bin"
        endpoint = checks.saved_state(directory, filename, code, "endpoint", 20, "unintervened", by_condition[code])
        endpoint_key = (code, "endpoint", 20, filename)
        endpoint_obs = model.observables(endpoint, coupling)
        check_sample(checks, endpoint_key, endpoint_obs, timeseries[code, END])
        endpoints[code] = endpoint
        measured[code, "uninterrupted", END] = (endpoint_obs, endpoint_obs)

    rows = index_rows(read_csv(directory / "m18_second_extraction_ledger.csv"),
                      lambda row: (row["condition"], row["branch"], grid_key(row["time"])))
    expected_fixed = {(code, "fixed", t) for code in CONDITIONS if code != "U4" for t in FIXED}
    require({key for key in rows if key[1] == "fixed"} == expected_fixed, "Incorrect fixed extraction branches")
    max_rows = {key for key in rows if key[1] == "observed_max"}
    require(len(rows) == 20 and len(max_rows) == 5 and {key[0] for key in max_rows} == {"R0", "R1", "R2", "R3", "R4"},
            "Incorrect observed maximum extraction branches")
    before_by_time = {(code, END): state for code, state in endpoints.items()}
    before_by_time.update({(code, START): source for code, (_, source) in by_condition.items()})
    after_by_time = {}
    for (code, branch, timestamp), row in rows.items():
        time = timestamp / 100
        coupling = CONDITIONS[code]
        require(float(row["g"]) == coupling, f"Wrong coupling for {code} extraction branch")
        prefix = f"states/{code}_{branch}_t{timestamp}"
        before_file, after_file = row["before_state"], row["after_state"]
        require(before_file == f"{prefix}_before.bin" and after_file == f"{prefix}_after.bin", f"Unexpected ledger state paths for {prefix}")
        before = checks.saved_state(directory, before_file, code, branch, time, "before", by_condition[code])
        after = checks.saved_state(directory, after_file, code, branch, time, "after", by_condition[code])
        key = (code, branch, time, before_file)
        for phase, index, state in (("before", before_by_time, before), ("after", after_by_time, after)):
            previous = index.get((code, timestamp))
            if previous is not None:
                checks.error(*key, f"duplicate_branch_{phase}_state_sha256_mismatch", int(state.sha256 != previous.sha256), 0)
            index[code, timestamp] = state
        if branch == "observed_max":
            selected = float(timeseries[code, timestamp]["load_ergotropy"])
            max_work = max(float(timeseries[code, t]["load_ergotropy"]) for t in range(START, END + 1))
            checks.error(*key, "selected_observed_maximum_error", abs(selected - max_work))
        obs_before, obs_after = inspect_pair(checks, before, after, model, coupling, key, row)
        measured[code, branch, timestamp] = (obs_before, obs_after)
        check_sample(checks, key, obs_before, timeseries[code, timestamp])
        checks.error(*key, "first_operation_work_vs_c5_state_pair", abs(first_total_work - float(row["first_total_work"])))
        second_net = obs_before["total_system_energy"] - obs_after["total_system_energy"] - switches[code]
        checks.error(*key, "second_net_work_vs_state_pair_and_switch", abs(second_net - float(row["second_net_work"])))
        checks.error(*key, "net_first_ratio_vs_state_pair_and_switch", abs(second_net / W_FIRST - float(row["net_first_ratio"])))

    load0, _, _ = partial_traces(by_condition["R0"][1].rho)
    for (code, timestamp), state in before_by_time.items():
        if code == "R0":
            phase = np.exp(-1j * LEVELS * (timestamp - START) / 100)
            analytic = phase[:, None] * load0 * phase[None, :].conj()
            checks.error(code, "free_load", timestamp / 100, "", "analytic_load_matrix_error",
                         max_abs(partial_traces(state.rho)[0] - analytic))

    written = {path.relative_to(directory).as_posix() for path in (directory / "states").glob("*.bin")}
    inventoried = {row["filename"] for row in checks.manifest}
    require(len(checks.manifest) == len(inventoried) == 46 and written == inventoried, "Unexpected saved-state inventory")
    balance_path = directory / "m18_energy_balance.csv"
    published = None
    if balance_path.is_file():
        published = index_rows(read_csv(balance_path), lambda row: (row["condition"], row["branch"], grid_key(row["time"])))
        require(published.keys() == measured.keys(), "Mismatch between energy balance and saved-state branches")
    check_balance(checks, timeseries, measured, initial_c5, extracted_c5, switches, historical, published)


def check_published_manifest(path, recomputed):
    actual = read_csv(path)
    require(len(actual) == len(recomputed), "Published state manifest has the wrong number of rows")
    numerical_fields = {"trace_error", "hermiticity_error", "minimum_eigenvalue"}
    for row, expected in zip(actual, recomputed):
        for field, value in expected.items():
            if field in numerical_fields:
                matches = abs(float(row[field]) - value) <= TOL
            else:
                matches = row[field] == str(value)
            require(matches, f"Published state manifest differs from reopened file {expected['filename']} in {field}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("m17", type=Path, help="directory of official M17 result artifacts")
    parser.add_argument("m18", nargs="?", type=Path, help="directory of M18 results to verify")
    parser.add_argument("--check-existing", action="store_true", help="verify the published manifest without writing files")
    args = parser.parse_args()
    checks = Checks()
    sources = load_m17(args.m17, checks)
    historical = {
        "extraction": read_m17_ledger(args.m17, "m17_extraction_ledger.csv", checks),
        "switch": read_m17_ledger(args.m17, "m17_switching_work.csv", checks),
    }
    if args.m18 is not None:
        verify(args.m18, sources, historical, checks)
        manifest_path = args.m18 / "m18_state_manifest.csv"
        if args.check_existing:
            check_published_manifest(manifest_path, checks.manifest)
        else:
            write_csv(manifest_path, checks.manifest)
            write_csv(args.m18 / "m18_saved_state_crosscheck.csv", checks.rows)
    failed = [row for row in checks.rows if row["status"] == "FAIL"]
    for row in failed:
        print(row)
    print(f"Independent LAPACK audit: {len(checks.rows) - len(failed)}/{len(checks.rows)} checks passed, "
          f"{len(checks.manifest)} M18 states inventoried.")
    return bool(failed)


if __name__ == "__main__":
    raise SystemExit(main())
