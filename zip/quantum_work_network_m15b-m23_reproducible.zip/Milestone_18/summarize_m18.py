"""Build Milestone 18 summaries and report from frozen-run output ledgers."""

import argparse
import csv
import hashlib
import math
from pathlib import Path


TOL = 1e-12
SOLVER_TOL = 1e-10
W_FIRST = 3.385250121299e-3
CONDITIONS = {"R0": 0.0, "R1": 0.01, "R2": 0.05, "R3": 0.125, "R4": 0.25, "U4": 0.25}
EXTRACTION_CONDITIONS = set(CONDITIONS) - {"U4"}
FIXED_TIMES = (10.0, 10.5, 11.0, 12.0, 15.0, 20.0)


def read_csv(path):
    with path.open(newline="", encoding="utf-8-sig") as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows):
    with path.open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def require(ok, description):
    if not ok:
        raise ValueError(description)


def number(row, key):
    value = float(row[key])
    require(math.isfinite(value), f"Nonfinite {key} in {row}")
    return value


def time_tick(value):
    return round(100 * float(value))


def fmt(value, places=6):
    return "—" if value is None else f"{value:.{places}e}"


def time_fmt(value):
    return "—" if value is None else f"{value:.2f}"


def pct(value):
    return "—" if value is None else f"{value:.6f}%"


def markdown_table(headers, rows):
    yield "| " + " | ".join(headers) + " |"
    yield "| " + " | ".join("---" for _ in headers) + " |"
    for row in rows:
        yield "| " + " | ".join(map(str, row)) + " |"


def by_condition(rows, *, series=False):
    grouped = {condition: [] for condition in CONDITIONS}
    for row in rows:
        condition = row["condition"]
        require(condition in grouped, f"Unexpected condition {condition}")
        if "g" in row:
            require(number(row, "g") == CONDITIONS[condition], f"Incorrect coupling for {condition}")
        grouped[condition].append(row)
    if series:
        for condition, samples in grouped.items():
            samples.sort(key=lambda row: number(row, "time"))
            require(len(samples) == 1001, f"Expected 1001 samples for {condition}")
            for tick, row in enumerate(samples, 1000):
                require(abs(number(row, "time") - tick / 100) <= TOL, f"Off-grid sample {condition} {tick}")
    return grouped


def analyze_series(series):
    summaries = []
    windows = {}
    for condition, samples in series.items():
        observed = [number(row, "load_ergotropy") for row in samples]
        active = condition in EXTRACTION_CONDITIONS
        maximum = max(observed)
        absolute_peak_index = observed.index(maximum)
        peak_index = absolute_peak_index if maximum > TOL else 0
        first = next((i for i, work in enumerate(observed) if work > TOL), None) if active else None
        half = next((i for i, work in enumerate(observed) if work >= maximum / 2), None) if first is not None else None
        changes = [after - before for before, after in zip(observed, observed[1:])]
        step_energy_gains_without_work_gain = sum(
            number(after, "load_energy") - number(before, "load_energy") > TOL and work_change <= TOL
            for before, after, work_change in zip(samples, samples[1:], changes)
        )
        end = samples[-1]
        begin = samples[0]
        window = {
            "start_ergotropy": observed[0],
            "reformed": ("YES" if first is not None else "NO") if active else "N/A",
            "first_time_over_tolerance": None if first is None else number(samples[first], "time"),
            "max_ergotropy": maximum,
            "exact_sample_maximum_time": number(samples[absolute_peak_index], "time"),
            "selected_peak_time": number(samples[peak_index], "time"),
            "ergotropy_at_selected_peak": observed[peak_index],
            "max_recovery_ratio": maximum / W_FIRST if active else None,
            "max_ergotropy_gain_from_start": maximum - observed[0],
            "endpoint_ergotropy": observed[-1],
            "endpoint_recovery_ratio": observed[-1] / W_FIRST if active else None,
            "endpoint_load_energy_gain": number(end, "load_energy") - number(begin, "load_energy"),
            "endpoint_passive_energy_gain": number(end, "load_passive_energy") - number(begin, "load_passive_energy"),
            "endpoint_signed_inflow": number(end, "cumulative_load_energy_inflow"),
            "endpoint_gross_inflow": number(end, "cumulative_load_energy_inflow_gross"),
            "endpoint_gross_outflow": number(end, "cumulative_load_energy_outflow_gross"),
            "early_ergotropy_slope_10_to_10_5": (observed[50] - observed[0]) / 0.5,
            "half_peak_time": None if half is None else number(samples[half], "time"),
            "largest_adjacent_ergotropy_decrease": max(0, -min(changes)),
            "adjacent_decreases_over_tolerance": sum(change < -TOL for change in changes),
            "adjacent_energy_gains_without_work_gain": step_energy_gains_without_work_gain,
        }
        windows[condition] = window
        base = {"record_type": "window", "condition": condition, "g": CONDITIONS[condition]}
        fixed_keys = (
            "time", "load_energy", "load_passive_energy", "load_ergotropy", "population_ergotropy",
            "coherent_ergotropy", "site7_to_load_current", "cumulative_load_energy_inflow",
            "dissipative_energy_change_cumulative", "mutual_information_nats",
        )
        summaries.append({**base, **dict.fromkeys(fixed_keys), "recovery_ratio": None, **window})
        for time in FIXED_TIMES:
            sample = samples[time_tick(time) - 1000]
            summaries.append({
                **base,
                "record_type": "fixed",
                **{key: number(sample, key) if sample[key] else None for key in fixed_keys},
                "recovery_ratio": number(sample, "load_ergotropy") / W_FIRST if active else None,
                **dict.fromkeys(window),
            })
    return summaries, windows


def m17_history(m17):
    switch, = (row for row in read_csv(m17 / "m17_switching_work.csv") if row["protocol"] == "C5")
    extraction, = (row for row in read_csv(m17 / "m17_extraction_ledger.csv") if row["protocol"] == "C5")
    work_on = number(switch, "work_on_system")
    before_cut = number(switch, "total_before")
    after_cut = number(switch, "total_after")
    before_first = number(extraction, "total_before")
    return {
        "m17_pre_cut_total_energy": before_cut,
        "m17_cut_work_on": work_on,
        "m17_cut_work_out": -work_on,
        "m17_cut_direct_total_jump": number(switch, "direct_total_jump"),
        "m17_post_cut_total_energy": after_cut,
        "m17_storage_energy_change": before_first - after_cut,
        "m17_pre_first_total_energy": before_first,
        "m17_post_first_total_energy": number(extraction, "total_after"),
        "m17_first_gross_work": number(extraction, "gross"),
        "m17_first_total_work": number(extraction, "total_work"),
    }


def energy_balance(series, switches, extractions, history):
    balance = []
    for condition, samples in series.items():
        switch, = switches[condition]
        initial = history["m17_pre_first_total_energy"]
        first = history["m17_first_total_work"] if condition in EXTRACTION_CONDITIONS else 0.0
        on = number(switch, "w_switch_on")
        for extraction in [None, *extractions[condition]]:
            endpoint = samples[-1] if extraction is None else samples[time_tick(extraction["time"]) - 1000]
            before = number(endpoint, "total_system_energy")
            after = before if extraction is None else number(extraction, "total_energy_after")
            gross = 0.0 if extraction is None else number(extraction, "bare_load_gross_extracted_work")
            second = 0.0 if extraction is None else number(extraction, "total_hamiltonian_operation_work")
            dissipation = number(endpoint, "dissipative_energy_change_cumulative")
            second_net = second - on
            expected = initial - first + on + dissipation - second
            with_cut = (
                history["m17_pre_cut_total_energy"] + history["m17_cut_work_on"]
                + history["m17_storage_energy_change"] - first + on + dissipation - second
            )
            balance.append({
                "condition": condition,
                "branch": "uninterrupted" if extraction is None else extraction["branch"],
                "time": number(endpoint, "time"),
                "g": CONDITIONS[condition],
                "first_total_work": first,
                "w_switch_on": on,
                "w_switch_out": -on,
                "dissipative_energy_change_cumulative": dissipation,
                "bare_load_gross_extracted_work": gross,
                "total_hamiltonian_operation_work": second,
                "second_net_work": second_net,
                "total_extraction_work_out": first + second,
                "ideal_total_operation_work_out": first + second_net,
                "total_energy_initial": initial,
                "total_energy_before_reconnection": number(switch, "total_before"),
                "total_energy_after_reconnection": number(switch, "total_after"),
                "total_energy_before_second": before,
                "total_energy_after_second": after,
                "predicted_total_energy_after_second": expected,
                "balance_residual": after - expected,
                "m17_pre_cut_total_energy": history["m17_pre_cut_total_energy"],
                "m17_cut_work_on": history["m17_cut_work_on"],
                "m17_cut_work_out": history["m17_cut_work_out"],
                "m17_cut_direct_total_jump": history["m17_cut_direct_total_jump"],
                "m17_post_cut_total_energy": history["m17_post_cut_total_energy"],
                "m17_storage_energy_change": history["m17_storage_energy_change"],
                "ideal_total_operation_work_out_including_cut": first + second_net + history["m17_cut_work_out"],
                "predicted_total_energy_after_second_including_cut": with_cut,
                "balance_residual_including_cut": after - with_cut,
            })
    return balance


def numerical_checks(series, switches, extractions, half_step, windows, balance, result, m17):
    checks = []

    def check(name, condition, observed, bound, relation, passed):
        checks.append({
            "check": name, "condition": condition, "observed": observed,
            "bound": bound, "rule": relation, "status": "PASS" if passed else "FAIL",
        })

    def upper(name, condition, observed, bound=TOL):
        check(name, condition, observed, bound, "<=", observed <= bound)

    def lower(name, condition, observed, bound):
        check(name, condition, observed, bound, ">=", observed >= bound)

    def equals(name, condition, observed, expected):
        check(name, condition, observed, expected, "=", observed == expected)

    def magnitude(rows, key):
        return max(abs(number(row, key)) for row in rows)

    historical_states = {row["filename"]: row for row in read_csv(m17 / "m17_state_manifest.csv")}
    input_names = ("g000_t1000_after.bin", "g000_t1000_before.bin")
    for filename in input_names:
        state = historical_states[filename]
        with (m17 / filename).open("rb") as stream:
            sha = hashlib.file_digest(stream, "sha256").hexdigest().upper()
        equals("m17_formal_input_sha256", filename, sha, state["sha256"].upper())
        equals("m17_formal_input_positivity", filename, state["positivity_status"], "PASS")
        equals("m17_formal_input_dimension", filename, int(state["dimension"]), 384)
        equals("m17_formal_input_time", filename, number(state, "time"), 10.0)
        equals("m17_formal_input_g", filename, number(state, "g_after_branch"), 0.0)
    for condition, samples in series.items():
        equals("saved_time_grid_points", condition, len(samples), 1001)
        next_samples = half_step[condition]
        equals("half_step_saved_time_grid_points", condition, len(next_samples), 1001)
        for field in (
            "trace_error", "hermiticity_error", "population_sum_error", "component_energy_residual",
            "current_balance_residual", "dissipation_balance_residual",
        ):
            upper(field, condition, magnitude(samples, field))
        upper("spectrum_trace_error", condition, magnitude(samples, "spectrum_trace_error"), SOLVER_TOL)
        lower("minimum_eigenvalue", condition, min(number(row, "minimum_eigenvalue") for row in samples), -TOL)
        lower("minimum_ergotropy", condition, min(number(row, "load_ergotropy") for row in samples), -TOL)
        lower("minimum_population_ergotropy", condition, min(number(row, "population_ergotropy") for row in samples), -TOL)
        lower("minimum_coherent_ergotropy", condition, min(number(row, "coherent_ergotropy") for row in samples), -TOL)
        lower("minimum_load_purity", condition, min(number(row, "load_purity") for row in samples), 1 / 3 - TOL)
        upper("maximum_load_purity", condition, max(number(row, "load_purity") for row in samples), 1 + TOL)
        upper("negativity_failure_count", condition, sum(row["positivity_status"] != "PASS" for row in samples), 0)
        upper("ergotropy_energy_identity", condition, max(abs(
            number(row, "load_energy") - number(row, "load_passive_energy") - number(row, "load_ergotropy")
        ) for row in samples))
        upper("ergotropy_decomposition_identity", condition, max(abs(
            number(row, "load_ergotropy") - number(row, "population_ergotropy") - number(row, "coherent_ergotropy")
        ) for row in samples))
        upper("signed_current_split_identity", condition, max(abs(
            number(row, "cumulative_load_energy_inflow") - number(row, "cumulative_load_energy_inflow_gross")
            + number(row, "cumulative_load_energy_outflow_gross")
        ) for row in samples))
        switch, = switches[condition]
        equals("switch_g_before", condition, number(switch, "g_before"), 0.0)
        equals("switch_time", condition, number(switch, "time"), 10.0)
        upper("switch_state_invariance", condition, abs(number(switch, "state_invariance_max_abs")), 0)
        upper("switch_linear_form", condition, abs(number(switch, "linear_form_residual")), 1e-18)
        upper("switch_linear_work_independent", condition, abs(
            number(switch, "w_switch_on") - CONDITIONS[condition] * number(switch, "interaction_expectation_v")
        ), 1e-18)
        upper("switch_direct_total_form", condition, abs(number(switch, "direct_total_residual")), 1e-15)
        upper("switch_out_sign", condition, abs(number(switch, "w_switch_on") + number(switch, "w_switch_out")), 0)
        upper("sparse_dense_step", condition, abs(number(switch, "sparse_dense_step_error")), 1e-13)
        upper("initial_total_energy_after_switch", condition, abs(
            number(switch, "total_after") - number(samples[0], "total_system_energy")
        ))
        actual = extractions[condition]
        if condition in EXTRACTION_CONDITIONS:
            upper("initial_ergotropy_after_first_extraction", condition, abs(number(samples[0], "load_ergotropy")))
            fixed_ticks = sorted(time_tick(row["time"]) for row in actual if row["branch"] == "fixed")
            equals("fixed_extraction_grid", condition, "/".join(map(str, fixed_ticks)), "1200/1500/2000")
            exploratory = [time_tick(row["time"]) for row in actual if row["branch"] == "observed_max"]
            equals("peak_extraction_time", condition, "/".join(map(str, exploratory)), str(time_tick(windows[condition]["selected_peak_time"])))
            equals("independent_extraction_branches", condition, len(actual), 4)
            for field in (
                "after_ergotropy", "identity_residual", "gross_ergotropy_residual", "unitarity_error",
                "passive_mapping_error", "load_mapping_error", "chain_invariance_error",
            ):
                upper(field, condition, magnitude(actual, field))
            upper("branch_start_matches_unintervened_ergotropy", condition, max(abs(
                number(row, "before_ergotropy") - number(samples[time_tick(row["time"]) - 1000], "load_ergotropy")
            ) for row in actual))
            upper("branch_start_matches_unintervened_total_energy", condition, max(abs(
                number(row, "total_energy_before") - number(samples[time_tick(row["time"]) - 1000], "total_system_energy")
            ) for row in actual))
            upper("branch_work_net_identity", condition, max(abs(
                number(row, "total_hamiltonian_operation_work") - number(switch, "w_switch_on")
                - number(row, "second_net_work")
            ) for row in actual))
        else:
            equals("unextracted_control_operations", condition, len(actual), 0)
        for field in (
            "load_energy_difference", "load_ergotropy_difference", "total_energy_difference",
            "dissipation_integral_difference", "current_integral_difference",
        ):
            upper(f"half_step_{field}", condition, magnitude(next_samples, field), SOLVER_TOL)
        compared = [row for row in next_samples if row["state_max_abs_difference"] != ""]
        expected = {2000, time_tick(windows[condition]["selected_peak_time"])}
        if condition in EXTRACTION_CONDITIONS:
            expected.update({1200, 1500})
        actual_ticks = {time_tick(row["time"]) for row in compared}
        equals("half_step_checkpoint_coverage", condition, len(actual_ticks & expected), len(expected))
        if compared:
            upper("half_step_full_state_max_abs_difference", condition, magnitude(compared, "state_max_abs_difference"), SOLVER_TOL)
        audit_balance = [row for row in balance if row["condition"] == condition]
        for field in ("balance_residual", "balance_residual_including_cut"):
            upper(field, condition, magnitude(audit_balance, field))
    for field in (
        "load_ergotropy", "site7_to_load_current", "free_load_state_max_abs_error", "free_load_invariant_max_abs_error",
    ):
        upper(f"R0_analytic_{field}", "R0", magnitude(series["R0"], field))
    saved_checks = result / "m18_saved_state_crosscheck.csv"
    if saved_checks.exists():
        saved_rows = read_csv(saved_checks)
        status_column = next((col for col in ("status", "overall_status", "verdict") if col in saved_rows[0]), None)
        if status_column:
            equals("independent_saved_state_verification_failures", "ALL", sum(row[status_column] != "PASS" for row in saved_rows), 0)
    return checks


def report(series, switches, extractions, windows, balance, checks, history, result, benchmark):
    recovered = [condition for condition, row in windows.items() if row["reformed"] == "YES"]
    eligible = [(condition, row) for condition in CONDITIONS for row in extractions[condition]]
    gain = len([row for _, row in eligible if number(row, "bare_load_gross_extracted_work") > TOL])
    total_gain = len([row for _, row in eligible if number(row, "total_hamiltonian_operation_work") > TOL])
    net_gain = len([row for _, row in eligible if number(row, "second_net_work") > TOL])
    best_condition, best_branch = max(eligible, key=lambda entry: number(entry[1], "second_net_work"))
    failed = [row for row in checks if row["status"] != "PASS"]
    lines = [
        "# Milestone 18 仕事抽出後の再接続によるエルゴトロピーの再形成", "",
        f"**再形成の判定**　抽出後の5条件のうち {len(recovered)} 条件で、負荷エルゴトロピーが "
        f"`1e-12` を超えた（{', '.join(recovered) or '該当なし'}）。完全切断 R0 の観測最大値は "
        f"`{fmt(windows['R0']['max_ergotropy'])}`。", "",
        f"**第二回抽出**　独立した {len(eligible)} 枝で、負荷単体の抽出仕事が正だったのは {gain} 枝、"
        f"全ハミルトニアンで正だったのは {total_gain} 枝、再接続を差し引いて正だったのは {net_gain} 枝"
        "（いずれも `1e-12` を超えた件数）。", "",
        f"第二段階の正味仕事が最も大きかった実測枝は {best_condition} の `t={time_fmt(number(best_branch, 'time'))}` "
        f"（`{best_branch['branch']}`）で、`{fmt(number(best_branch, 'second_net_work'))}`。時間窓と保存点を固定して得た比較やで。", "",
        "## 初期状態と手順", "",
        "R0–R4 は M17 C5 の `g000_t1000_after.bin`、U4 は `g000_t1000_before.bin` から開始した。"
        "いずれも 384×384 の全体系状態で、鎖と負荷の残存相関を保持した。"
        "M17 のマニフェストと公開バイナリの SHA-256 を照合した。 [数値監査](m18_numerical_checks.csv)", "",
        "`N=7`、`TOTAL_GAMMA=1.5`、前史の `Omega=0.18748395731510084`。"
        "`t=10.00` で `g=0` から指定値へ瞬時に切り替え、`t=20.00` まで外部駆動ゼロ、"
        "負荷への直接散逸ゼロ、M17 と同じ鎖の局所デフェージングで伝播した。"
        "内部 RK4 刻み `0.0025`、保存間隔 `0.01` で各条件に 1001 点を保存した。 [事前固定](PRECOMMIT_M18.md)", "",
        "## 固定時刻の比較", "",
        "表の値は負荷エルゴトロピー。受動エネルギーは負荷状態の大きい固有値から負荷の低い準位へ割り当てた"
        "エネルギーで、負荷エルゴトロピーはその受動エネルギーを負荷エネルギーから引いた値。"
        "準位占有率エルゴトロピーは負荷のエネルギー基底で非対角要素を除いた状態に同じ定義を適用し、"
        "残りをコヒーレンス・エルゴトロピーとした。 [一次文献](https://arxiv.org/abs/cond-mat/0401574)", "",
    ]
    lines.extend(markdown_table(
        ["時刻", *(f"{condition} g={g:g}" for condition, g in CONDITIONS.items())],
        ([time_fmt(time), *(fmt(number(rows[time_tick(time) - 1000], "load_ergotropy")) for rows in series.values())] for time in FIXED_TIMES),
    ))
    lines += [
        "", "次の表の各セルは負荷エネルギー／受動エネルギー。"
        "固定時刻の数値と全保存点の観測量は CSV に収録した。 [固定時刻と窓内の要約](m18_recovery_summary.csv) "
        "[全時系列](m18_recovery_timeseries.csv)", "",
    ]
    lines.extend(markdown_table(
        ["時刻", *CONDITIONS],
        ([time_fmt(time), *(
            f"{fmt(number(rows[time_tick(time) - 1000], 'load_energy'), 4)} / "
            f"{fmt(number(rows[time_tick(time) - 1000], 'load_passive_energy'), 4)}" for rows in series.values()
        )] for time in FIXED_TIMES),
    ))
    lines += [
        "", "## 回復量・速度・エネルギー流入", "",
        f"回復率は M17 C5 の初回抽出仕事 `W_first={W_FIRST:.12e}` を分母とした。"
        "最初の検出と半値到達は `0.01` 刻みの観測時刻。半値は各条件の窓内最大値の半分に初めて達した時刻。"
        "最大値は `t=10.00–20.00` の保存点での観測値。U4 は初回抽出を省いた対照で、初期エルゴトロピーをすでに持つ。", "",
    ]
    lines.extend(markdown_table(
        ["条件", "検出", "初検出 t", "半値 t", "実測最大 t", "最大 W", "最大回復率", "終点 W",
         "10–10.50 の平均の増加率", "W 減少区間数"],
        ([c, w["reformed"], time_fmt(w["first_time_over_tolerance"]), time_fmt(w["half_peak_time"]),
          time_fmt(w["exact_sample_maximum_time"]), fmt(w["max_ergotropy"]),
          pct(None if w["max_recovery_ratio"] is None else 100 * w["max_recovery_ratio"]),
          fmt(w["endpoint_ergotropy"]), fmt(w["early_ergotropy_slope_10_to_10_5"]),
          w["adjacent_decreases_over_tolerance"]] for c, w in windows.items()),
    ))
    if recovered:
        by_max = sorted(recovered, key=lambda c: windows[c]["max_ergotropy"], reverse=True)
        by_half = {}
        for condition in sorted(recovered, key=lambda c: windows[c]["half_peak_time"]):
            by_half.setdefault(windows[condition]["half_peak_time"], []).append(condition)
        by_half_labels = "、".join("/".join(conditions) for conditions in by_half.values())
        by_slope = sorted(recovered, key=lambda c: windows[c]["early_ergotropy_slope_10_to_10_5"], reverse=True)
        lines += [
            "", f"回復が検出された条件を比べると、窓内の最大値が大きい順に {'、'.join(by_max)}。"
            f"前半 `0.5` の平均増加率が大きい順に {'、'.join(by_slope)}。"
            f"各条件の半値に早く着いた順に {by_half_labels}。速度の評価は測る区間と基準に依存する。", "",
        ]
    else:
        lines.append("")
    lines.extend(markdown_table(
        ["条件", "終点 Δ負荷 E", "終点 Δ受動 E", "累積流入（符号付き）", "累積流入（正部分）", "累積流出（大きさ）",
         "負荷 E 増加・W 増加なしの隣接区間数"],
        ([c, fmt(w["endpoint_load_energy_gain"]), fmt(w["endpoint_passive_energy_gain"]),
          fmt(w["endpoint_signed_inflow"]), fmt(w["endpoint_gross_inflow"]), fmt(w["endpoint_gross_outflow"]),
          w["adjacent_energy_gains_without_work_gain"]]
         for c, w in windows.items()),
    ))
    lines += [
        "",
        f"同じ `g=0.25` で比べると、R4 の開始・終点の W は "
        f"`{fmt(windows['R4']['start_ergotropy'])}` と `{fmt(windows['R4']['endpoint_ergotropy'])}`、"
        f"U4 は `{fmt(windows['U4']['start_ergotropy'])}` と `{fmt(windows['U4']['endpoint_ergotropy'])}`。"
        "隣接区間の集計では、負荷エネルギーの増加が `1e-12` を超え、W の変化が `1e-12` 以下の区間を数えた。",
    ]
    example = None
    for condition in recovered:
        start = series[condition][0]
        for sample in series[condition][1:]:
            de = number(sample, "load_energy") - number(start, "load_energy")
            dw = number(sample, "load_ergotropy") - number(start, "load_ergotropy")
            if de > TOL and (example is None or de - dw > example[0]):
                example = (de - dw, condition, number(sample, "time"), de, dw)
    if example:
        passive_gain, condition, time, energy_gain, work_gain = example
        lines += [
            "", f"たとえば {condition} の `t={time_fmt(time)}` では開始時からの負荷エネルギー変化が "
            f"`{fmt(energy_gain)}`、抽出可能仕事の変化が `{fmt(work_gain)}`、受動エネルギー変化が "
            f"`{fmt(passive_gain)}`。この3量を分けると、受け取ったエネルギーのうち局所ユニタリで回収できる分が見える。", "",
        ]
    else:
        lines.append("")
    unresolved_work_example = next((
        (condition, number(sample, "time"), energy_gain, number(sample, "load_ergotropy"))
        for condition in recovered
        for sample in series[condition][1:]
        if (energy_gain := number(sample, "load_energy") - number(series[condition][0], "load_energy")) > TOL
        and number(sample, "load_ergotropy") <= TOL
    ), None)
    if unresolved_work_example:
        condition, time, energy_gain, work = unresolved_work_example
        lines += [
            f"{condition} の `t={time_fmt(time)}` では開始時からの負荷エネルギー増加が "
            f"`{fmt(energy_gain)}` あり、エルゴトロピーは `{fmt(work)}` と再形成の判定閾値内だった。", "",
        ]
    lines.extend(markdown_table(
        ["条件", "窓内最大時の t", "準位占有率 W", "コヒーレンス W", "累積散逸エネルギー変化 t=20", "相互情報量 t=10 → t=20（nat）"],
        ([c, time_fmt(w["selected_peak_time"]),
          fmt(number(series[c][time_tick(w["selected_peak_time"]) - 1000], "population_ergotropy")),
          fmt(number(series[c][time_tick(w["selected_peak_time"]) - 1000], "coherent_ergotropy")),
          fmt(number(series[c][-1], "dissipative_energy_change_cumulative")),
          (f"{fmt(number(series[c][0], 'mutual_information_nats'))} → {fmt(number(series[c][-1], 'mutual_information_nats'))}"
           if series[c][0]["mutual_information_nats"] else "—")]
         for c, w in windows.items()),
    ))
    lines += [
        "", "R0 の最大値が判定閾値内に収まった場合、探索枝は `t=10.00` を使う。"
        "相互情報量は診断値として扱い、その変化から回復の因果関係を推定するには別の介入実験が必要。", "",
        "この共鳴モデルの未介入伝播では、ハミルトニアンと鎖のデフェージングが総励起数を保存する。"
        "負荷のエネルギー増加に対応して鎖のオンサイト励起エネルギーが減る。"
        "表の鎖エネルギーにはホッピング項も含まれる。", "",
        "## 再接続の切替仕事", "",
        "再接続直前の同じ全体系状態に対して `W_switch,on = Tr[ρ(H_after−H_before)]` を評価した。"
        "正の `W_switch,on` は系への供給、負の値は系からの理想仕事出力に対応する。"
        "直接差 `ΔH` と線形式 `(g_after−g_before)⟨V⟩` を照合した。 [切替台帳](m18_reconnection_work.csv)", "",
    ]
    lines.extend(markdown_table(
        ["条件", "相互作用 前", "相互作用 後", "系への仕事", "系からの仕事", "直接 ΔH", "相互作用の線形式残差", "直接 ΔH と線形式の差"],
        ([c, *(fmt(number(rows[0], key)) for key in (
            "interaction_before", "interaction_after", "w_switch_on", "w_switch_out", "direct_total_jump",
            "linear_form_residual", "direct_total_residual",
        ))] for c, rows in switches.items()),
    ))
    lines += [
        "", "## 独立に分岐した第二回抽出", "",
        "R0–R4 の `t=12.00`、`15.00`、`20.00` と観測最大の探索保存点で、未介入軌道からそれぞれ独立に分岐した。"
        "M17 と同じ局所ユニタリを全体系へ適用した。全操作仕事 `W_second,total` は前後の全ハミルトニアン期待値の差"
        " `E_before−E_after` で、`W_second,gross−ΔE_interaction` と照合した。"
        "第二段階の正味仕事は `W_second,net = W_second,total−W_switch,on`。 [抽出台帳](m18_second_extraction_ledger.csv)", "",
    ]
    lines.extend(markdown_table(
        ["条件", "枝", "t", "抽出前 W", "負荷の仕事 gross", "相互作用ジャンプ", "全操作仕事 total", "第二段階 net", "抽出後 W", "gross／初回"],
        ([c, row["branch"], time_fmt(number(row, "time")), *(fmt(number(row, key)) for key in (
            "before_ergotropy", "bare_load_gross_extracted_work", "interaction_energy_jump", "total_hamiltonian_operation_work",
            "second_net_work", "after_ergotropy",
        )), pct(100 * number(row, "gross_first_ratio"))] for c, row in eligible),
    ))
    lines += [
        "", "各枝の初回に対する `total` と `net` の比率も抽出台帳に記録した。"
        "負荷の固有値を受動配置に並べ替える操作で、相互作用エネルギーは前後で変化し得る。"
        "全操作仕事の評価は、この台帳に記録した M17 と同じユニタリの実装に対応する。", "",
        "## 全体系のエネルギー会計", "",
        f"初回抽出の全操作仕事を M17 の実測台帳から `{fmt(history['m17_first_total_work'], 14)}` とした。"
        "U4 の初回抽出仕事はゼロ。残存エネルギーは初回前の全体系エネルギーから初回仕事を引き、"
        "再接続仕事と符号付き散逸エネルギー変化を足し、第二回の全操作仕事を引いて照合した。"
        "表の未介入 `t=20.00` は第二回抽出の前に伝播を止めた共通比較。"
        "抽出操作2回の仕事の合計は `W_first,total + W_second,total`。"
        "再接続を含めた理想操作仕事の合計は `W_first,total + W_second,net`。"
        "未介入の `uninterrupted` 行では第二回操作の帳簿項目をゼロとした。 [全枝の収支表](m18_energy_balance.csv)", "",
    ]
    lines.extend(markdown_table(
        ["条件", "枝", "t", "初回仕事", "再接続 系へ", "散逸 ΔE", "第二回 total", "初回からの仕事計", "残存 E", "収支残差"],
        ([row["condition"], row["branch"], time_fmt(row["time"]), *(fmt(row[key]) for key in (
            "first_total_work", "w_switch_on", "dissipative_energy_change_cumulative", "total_hamiltonian_operation_work",
            "ideal_total_operation_work_out", "total_energy_after_second", "balance_residual",
        ))] for row in balance),
    ))
    q_pos = [c for c, samples in series.items() if any(number(row, "dissipative_energy_change_rate") > TOL for row in samples)]
    q_neg = [c for c, samples in series.items() if any(number(row, "dissipative_energy_change_rate") < -TOL for row in samples)]
    max_extended = max(abs(row["balance_residual_including_cut"]) for row in balance)
    lines += [
        "", f"M17 の切断から数え直すと、C5 の切断仕事（系へ）は `{fmt(history['m17_cut_work_on'])}`。"
        f"切断直後から `t=10.00` の抽出直前までのエネルギー変化にはアーカイブ両端値の差 "
        f"`{fmt(history['m17_storage_energy_change'])}` を用いた。この区間の差は `1e-12` の許容差内。"
        f"切断込み収支の最大絶対残差は `{fmt(max_extended)}`。切断仕事を含めた理想操作仕事の合計も全枝で記録した。"
        " [全枝の収支表](m18_energy_balance.csv)", "",
        f"散逸パワー `Tr[H D(ρ)]` に正の値（`>1e-12`）が現れた条件は {', '.join(q_pos) or 'なし'}。"
        f"負の値（`<−1e-12`）が現れた条件は {', '.join(q_neg) or 'なし'}。"
        "表の累積値はこのパワーを符号付きで積分した。外部駆動ゼロの区間でも、切替と環境のエネルギー交換は会計に入る。", "",
        "ここでは各鎖サイトのデフェージング率を `γ=1.5/7` とすると、"
        "散逸パワーは `−γ(2⟨H_chain,hopping⟩ + ⟨H_int⟩)`。"
        "鎖の隣接ホッピングは鎖ビットを2つ、末端と負荷の交換は鎖ビットを1つ変えるため、"
        "それぞれの密度行列要素に掛かるデフェージング率が異なる。", "",
        "## 数値監査と保存状態", "",
        f"集計監査は **{len(checks) - len(failed)}/{len(checks)} 合格**。"
        "M17 の用途別許容差を継承し、刻み半減の比較は追加基準 `1e-10` で評価した。"
        "R0 は負荷の解析的自由発展、準位占有率・純度・エネルギー・エルゴトロピーの不変量、"
        "ゼロ電流を照合した。全条件で負荷エネルギー変化と電流積分、全エネルギー変化と散逸積分を照合した。"
        "R0–R4 の抽出後エルゴトロピーも各枝で検査した。 [数値監査](m18_numerical_checks.csv) "
        "[刻み半減](m18_half_step.csv)", "",
    ]
    audited = {
        "R0 解析負荷行列の要素誤差": "R0_analytic_free_load_state_max_abs_error",
        "トレース誤差": "trace_error",
        "エルミート性誤差": "hermiticity_error",
        "電流と負荷エネルギー変化の残差": "current_balance_residual",
        "散逸と全体系エネルギー変化の残差": "dissipation_balance_residual",
        "第二回抽出後の残存エルゴトロピー（絶対値）": "after_ergotropy",
        "刻み半減のエルゴトロピーの差": "half_step_load_ergotropy_difference",
        "刻み半減の全体系状態最大要素差": "half_step_full_state_max_abs_difference",
    }
    lines.extend(markdown_table(
        ["監査量", "最大値", "許容差"],
        ([label, fmt(max(float(row["observed"]) for row in checks if row["check"] == name)),
          fmt(next(float(row["bound"]) for row in checks if row["check"] == name))] for label, name in audited.items()),
    ))
    if failed:
        lines += ["", "要確認項目は " + "、".join(f"{row['condition']} {row['check']}" for row in failed) + "。"]
    lines += [
        "", "エルゴトロピーの固有値計算への引数は M17 と同じ `1e-9`。計算返り値のゼロ丸め前の"
        " `E_load−E_passive` で `1e-12` を横切る時刻を判定し、微小値も CSV に保存した。"
        "終点状態と第二回抽出の各前後状態は QWNRHO1 形式で保存した。 "
        "[状態マニフェスト](m18_state_manifest.csv) [保存状態の独立検証](m18_saved_state_crosscheck.csv)", "",
    ]
    lines.extend(runtime_section(result, benchmark))
    figures = sorted((result / "figures").glob("*.png")) + sorted(result.glob("m18_*.png"))
    if figures:
        lines += ["## 図", ""]
        lines += [f"- [{path.stem}]({path.relative_to(result).as_posix()})" for path in figures]
        lines.append("")
    lines += [
        "## 再現用ファイル", "",
        "同梱の Windows 実行ファイルと正式 M17 入力を使い、成果物フォルダで次を実行すると別の出力先へ再計算できる。"
        "入力・コード・実行ファイルの SHA-256 はランチャーが実行前後に照合する。"
        "保存状態の独立監査には Python と NumPy、図の再描画には Matplotlib を使う。"
        " [固定 SHA-256](m18_precommit_sha256.csv)", "",
        "```powershell",
        "py -3.14 run_m18.py formal ./m18_reconnection.exe rerun_branches rerun_results --workers 3",
        "py -3.14 summarize_m18.py rerun_results m17_inputs --tables-only",
        "py -3.14 verify_m18.py m17_inputs rerun_results",
        "py -3.14 plot_m18.py --data rerun_results",
        "py -3.14 summarize_m18.py rerun_results m17_inputs --report-only",
        "```", "",
        "この結果の範囲は、固定された消散モデル、切替条件、時間窓、および第二回までの理想局所操作における仕事会計。", "",
    ]
    return "\n".join(lines)


def runtime_section(result, benchmark):
    paths = [result / "m18_runtime.csv"]
    if benchmark is not None:
        paths.insert(0, benchmark / "m18_runtime.csv")
    timings = {}
    for path in paths:
        if path.exists():
            for row in read_csv(path):
                timings.setdefault(row["mode"], []).append(number(row, "wall_seconds"))
    if not timings:
        return []
    lines = ["## 実測時間", ""]
    lines.extend(markdown_table(
        ["実行モード", "枝数", "枝別 wall の合計（秒）", "枝別 wall の範囲（秒）"],
        ([mode, len(values), f"{sum(values):.2f}", f"{min(values):.2f}–{max(values):.2f}"] for mode, values in timings.items()),
    ))
    if benchmark is not None and (benchmark / "m18_batch_runtime.csv").exists():
        bench, = read_csv(benchmark / "m18_batch_runtime.csv")
        estimates = [
            sum(number(row, field) for field in ("setup_seconds", "extraction_seconds", "state_write_seconds"))
            + 4000 / 48 * sum(number(row, field) for field in ("propagation_seconds", "half_propagation_seconds"))
            + 1001 / 13 * sum(number(row, field) for field in ("diagnostics_seconds", "half_diagnostics_seconds"))
            for row in read_csv(benchmark / "m18_runtime.csv")
        ]
        eta = max(estimates[:3]) + max(estimates[3:])
        lines += [
            "", f"正式実行前に3並列で全6条件の `t=10.00–10.12` を実測した。"
            f"バッチ経過時間は `{number(bench, 'elapsed_seconds'):.2f}` 秒。"
            f"ステップと保存点の数で拡大した正式実行の事前見積もりは `{eta:.1f}` 秒（約 `{eta / 60:.1f}` 分）。"
            " [ベンチ実測](m18_benchmark_runtime.csv)",
        ]
    if (result / "m18_batch_runtime.csv").exists():
        formal, = read_csv(result / "m18_batch_runtime.csv")
        lines += ["", f"正式計算と出力結合のバッチ実測は `{number(formal, 'elapsed_seconds'):.2f}` 秒。"
                  " [バッチ実測](m18_batch_runtime.csv)"]
    return lines + ["", "枝別 wall の合計は各枝の経過時間を足し合わせた値。 [実行時間台帳](m18_runtime.csv)", ""]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path, help="M18 formal results directory")
    parser.add_argument("m17", type=Path, help="M17 published results directory")
    parser.add_argument("--benchmark", type=Path, help="M18 benchmark results directory")
    phases = parser.add_mutually_exclusive_group()
    phases.add_argument("--tables-only", action="store_true", help="produce summary and balance before the independent audit")
    phases.add_argument("--report-only", action="store_true", help="produce numerical checks and report after the independent audit")
    args = parser.parse_args()
    result, m17 = args.results, args.m17
    series = by_condition(read_csv(result / "m18_recovery_timeseries.csv"), series=True)
    switches = by_condition(read_csv(result / "m18_reconnection_work.csv"))
    extractions = by_condition(read_csv(result / "m18_second_extraction_ledger.csv"))
    half_step = by_condition(read_csv(result / "m18_half_step.csv"), series=True)
    summaries, windows = analyze_series(series)
    history = m17_history(m17)
    balance = energy_balance(series, switches, extractions, history)
    tables = {
        "m18_recovery_summary.csv": summaries,
        "m18_energy_balance.csv": balance,
    }
    checks = []
    outputs = {} if args.report_only else dict(tables)
    if args.report_only:
        require(all((result / name).is_file() for name in tables), "Synthesis tables are missing. Run --tables-only first.")
    if not args.tables_only:
        checks = numerical_checks(series, switches, extractions, half_step, windows, balance, result, m17)
        outputs["m18_numerical_checks.csv"] = checks
        outputs["MILESTONE_18_RECONNECTION_RECOVERY_REPORT.md"] = report(
            series, switches, extractions, windows, balance, checks, history, result, args.benchmark,
        )
    require(not any((result / name).exists() for name in outputs), "An M18 synthesis output already exists")
    for name, contents in outputs.items():
        if isinstance(contents, str):
            with (result / name).open("x", encoding="utf-8", newline="\n") as stream:
                stream.write(contents)
        else:
            write_csv(result / name, contents)
    failed = [check for check in checks if check["status"] != "PASS"]
    print(f"M18 synthesis: {len(summaries)} summary rows, {len(balance)} energy rows")
    if checks:
        print(f"M18 numerical checks: {len(checks) - len(failed)}/{len(checks)} pass")
    if failed:
        for row in failed:
            print(f"FAIL {row['condition']} {row['check']}: {row['observed']} {row['rule']} {row['bound']}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
