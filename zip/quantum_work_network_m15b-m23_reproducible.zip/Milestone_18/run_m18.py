"""Run fixed M18 branches in separate solver processes and merge their outputs."""

import argparse
import csv
import hashlib
import shutil
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path


ROOT = Path(__file__).resolve().parent
CONDITIONS = ("R0", "R1", "R2", "R3", "R4", "U4")
AFTER = "g000_t1000_after.bin"
BEFORE = "g000_t1000_before.bin"
INPUT_HASHES = {
    AFTER: "A88FB15482BFEEE2F122603CEEF4F8A64A761C1D8F6C97185B34107844BB9977",
    BEFORE: "DFD6E1329C4036C198A1435855E1E33BEBD266B75754F76F504F702E738C5571",
    "m17_state_manifest.csv": "D84705717D73D20B3945958A70B167D8D8D50DABBEF41695C49433F326317D6F",
    "m17_extraction_ledger.csv": "60399380377E5DFC7FA9C57C9A358CD09A4D955D63350AF95A27A7AC1529E078",
    "m17_switching_work.csv": "934C490DA35E78969A2DD79E601E9B1A24DD186F88635D5FC5A10C339F8FDACD",
}
LEDGERS = (
    "m18_recovery_timeseries.csv",
    "m18_reconnection_work.csv",
    "m18_second_extraction_ledger.csv",
    "m18_half_step.csv",
    "m18_runtime.csv",
)


def digest(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest().upper()


def verify_inputs():
    inputs = ROOT / "m17_inputs"
    for name, expected in INPUT_HASHES.items():
        if digest(inputs / name) != expected:
            raise ValueError(f"M17 SHA-256 mismatch for {name}")
    with (inputs / "m17_state_manifest.csv").open(encoding="utf-8-sig", newline="") as file:
        manifest = {row["filename"]: row for row in csv.DictReader(file)}
    for name in (AFTER, BEFORE):
        row = manifest[name]
        assert row["sha256"] == INPUT_HASHES[name] and row["condition"] == "C5"
        assert float(row["g_after_branch"]) == 0 and float(row["time"]) == 10
        assert int(row["dimension"]) == 384 and row["format_version"] == "QWNRHO1/1"
        assert int(row["size_bytes"]) == (inputs / name).stat().st_size


def verify_freeze(executable):
    with (ROOT / "m18_precommit_sha256.csv").open(encoding="utf-8-sig", newline="") as file:
        files = {row["filename"]: row["sha256"] for row in csv.DictReader(file)}
    for name, expected in files.items():
        path = executable if name == "m18_reconnection.exe" else ROOT / name
        if digest(path) != expected:
            raise ValueError(f"Frozen SHA-256 mismatch for {name}")
    assert "m18_reconnection.exe" in files and "PRECOMMIT_M18.md" in files


def launch_branch(mode, executable, work, condition):
    state = BEFORE if condition == "U4" else AFTER
    print(f"{mode}: starting {condition}", flush=True)
    with (work / f"{condition}.log").open("xb") as log:
        process = subprocess.run(
            [executable, mode, condition, ROOT / "m17_inputs" / state, work / condition],
            stdout=log, stderr=subprocess.STDOUT, check=False,
        )
    if process.returncode:
        print(f"{mode}: {condition} failed with exit code {process.returncode}", flush=True)
        raise RuntimeError(f"See {work / (condition + '.log')}")
    print(f"{mode}: finished {condition}", flush=True)


def merge(work, destination):
    destination.mkdir()
    (destination / "states").mkdir()
    for name in LEDGERS:
        with (destination / name).open("xb") as output:
            header = None
            for condition in CONDITIONS:
                with (work / condition / name).open("rb") as source:
                    current = source.readline()
                    if header is None:
                        header = current
                        output.write(header)
                    if current != header:
                        raise ValueError(f"Ledger schema mismatch: {condition} {name}")
                    shutil.copyfileobj(source, output)
    for condition in CONDITIONS:
        for state in (work / condition / "states").glob("*.bin"):
            with state.open("rb") as source, (destination / "states" / state.name).open("xb") as target:
                shutil.copyfileobj(source, target)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("benchmark", "formal"))
    parser.add_argument("executable", type=Path)
    parser.add_argument("work", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--workers", type=int, default=3)
    args = parser.parse_args()
    if not 1 <= args.workers <= len(CONDITIONS):
        parser.error("workers must be between 1 and 6")
    executable, work, destination = (p.resolve() for p in (args.executable, args.work, args.destination))
    if destination.exists():
        raise FileExistsError(destination)
    verify_inputs()
    verify_freeze(executable)
    work.mkdir()
    started = time.perf_counter()
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        tasks = [pool.submit(launch_branch, args.mode, executable, work, c) for c in CONDITIONS]
        for task in tasks:
            task.result()
    verify_inputs()
    verify_freeze(executable)
    merge(work, destination)
    elapsed = time.perf_counter() - started
    with (destination / "m18_batch_runtime.csv").open("x", encoding="utf-8", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(("mode", "workers", "elapsed_seconds"))
        writer.writerow((args.mode, args.workers, f"{elapsed:.9f}"))
    print(f"{args.mode}: complete in {elapsed:.3f} s", flush=True)


if __name__ == "__main__":
    main()
