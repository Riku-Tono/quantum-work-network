"""Render the seven M18 figures from the audited CSV files using Matplotlib."""

import argparse
import csv
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parent
CONDITIONS = ("R0", "R1", "R2", "R3", "R4", "U4")
RECOVERY = CONDITIONS[:-1]
FIXED_TIMES = (12.0, 15.0, 20.0)
PLOT_TIMES = (10, 11, 12, 15, 20)
W_FIRST = 3.385250121299e-3

INK = "#152637"
MUTED = "#42586C"
GRID = "#DFE7ED"
AXIS = "#8293A2"
BLUE = "#225886"
TEAL = "#007172"
ORANGE = "#A2441A"
PURPLE = "#704984"
GRAY = "#546579"
GOLD = "#8B6A0B"
CONDITION_STYLES = {
    "R0": (BLUE, ":", "P", "0.00"),
    "R1": (TEAL, "--", "D", "0.01"),
    "R2": (ORANGE, "-", "^", "0.05"),
    "R3": (PURPLE, "-.", "s", "0.125"),
    "R4": (GRAY, "-", "o", "0.25"),
    "U4": (GOLD, "--", "v", "0.25"),
}


def read_csv(data_directory, filename):
    with (data_directory / filename).open(encoding="utf-8-sig", newline="") as source:
        return list(csv.DictReader(source))


def values(rows, name, scale=1.0):
    return [scale * float(row[name]) for row in rows]


def condition_label(condition):
    g = CONDITION_STYLES[condition][3]
    control = " · unextracted" if condition == "U4" else ""
    return f"{condition}  $g$ = {g}{control}"


def arrange(figure, title, subtitle, *, top=0.78, bottom=0.14, **spacing):
    figure.subplots_adjust(left=0.095, right=0.975, bottom=bottom, top=top, **spacing)
    figure.text(0.095, 0.960, title, color=INK, fontsize=19, fontweight="bold", va="top")
    figure.text(0.095, 0.905, subtitle, color=MUTED, fontsize=10.2, va="top")


def style_axis(ax, *, time_axis=False, zero=False):
    ax.set_axisbelow(True)
    ax.yaxis.grid(True, color=GRID, linewidth=0.8)
    ax.spines[["top", "right"]].set_visible(False)
    for edge in ("bottom", "left"):
        ax.spines[edge].set_color(AXIS)
    ax.tick_params(axis="both", color=AXIS, labelcolor=INK, labelsize=9)
    ax.yaxis.offsetText.set_color(MUTED)
    if time_axis:
        ax.set_xticks(PLOT_TIMES)
        ax.set_xlim(9.9, 20.1)
    if zero:
        ax.axhline(0.0, color=AXIS, linewidth=0.85, zorder=1)


def condition_line(ax, series, condition, field, scale=1.0):
    rows = series[condition]
    color, linestyle, marker, _ = CONDITION_STYLES[condition]
    times = values(rows, "time")
    ax.plot(
        times, values(rows, field, scale), color=color, linestyle=linestyle,
        marker=marker, markevery=[i for i, time in enumerate(times) if time in FIXED_TIMES],
        markersize=4.5, markerfacecolor="white", markeredgewidth=1.1,
        linewidth=1.65, label=condition_label(condition),
    )


def top_legend(figure, ax, columns):
    handles, labels = ax.get_legend_handles_labels()
    figure.legend(
        handles, labels, loc="upper left", bbox_to_anchor=(0.090, 0.865), ncols=columns,
        frameon=False, handlelength=2.4, columnspacing=1.6, labelcolor=INK, fontsize=9.2,
    )


def save(plt, figure, directory, filename):
    with (directory / filename).open("xb") as stream:
        figure.savefig(stream, format="png", dpi=200, facecolor="white")
    plt.close(figure)


def plot_ergotropy(plt, series, output):
    figure, axes = plt.subplots(1, 2, figsize=(11.6, 4.9))
    arrange(figure, "Load ergotropy after reconnection",
            "Markers show fixed extraction times. Each panel uses its own vertical scale.", wspace=0.34)
    panels = (("After first extraction", RECOVERY), ("g = 0.25 control comparison", ("R4", "U4")))
    for ax, (title, conditions) in zip(axes, panels):
        for condition in conditions:
            condition_line(ax, series, condition, "load_ergotropy", 1e3)
        style_axis(ax, time_axis=True, zero=True)
        ax.set_title(title, loc="left", color=INK, fontsize=11, pad=10)
        ax.set_xlabel("Time", color=INK)
        ax.set_ylabel(r"Load ergotropy ($\times 10^{-3}$)", color=INK)
        ax.legend(loc="best", frameon=True, framealpha=0.94, edgecolor=GRID,
                  labelcolor=INK, fontsize=8.4)
    save(plt, figure, output, "m18_01_ergotropy_recovery.png")


def scientific_tick(value, _position):
    return "0" if value == 0 else f"{value:.1e}"


def small_multiple(plt, title, subtitle, ylabel, series, fields, *, zero=False, scientific=False):
    figure, axes = plt.subplots(2, 3, figsize=(11.6, 6.4), sharex=True, sharey=not scientific)
    arrange(figure, title, subtitle, top=0.76, bottom=0.115,
            wspace=0.34 if scientific else 0.16, hspace=0.25)
    for ax, condition in zip(axes.flat, CONDITIONS):
        rows = series[condition]
        times = values(rows, "time")
        series_range = 0.0
        for field, label, color, linestyle in fields:
            points = values(rows, field)
            ax.plot(times, points, label=label, color=color, linestyle=linestyle, linewidth=1.65)
            series_range = max(series_range, max(map(abs, points)))
        style_axis(ax, time_axis=True, zero=zero)
        ax.set_title(condition_label(condition), loc="left", color=INK, fontsize=10.8)
        if scientific:
            ax.yaxis.set_major_formatter(scientific_tick)
            if series_range <= 1e-12:
                ax.set_ylim(-1e-12, 1e-12)
    figure.supxlabel("Time", y=0.047, color=INK, fontsize=10)
    figure.supylabel(ylabel, x=0.028, color=INK, fontsize=10)
    top_legend(figure, axes[0, 0], len(fields))
    return figure


def plot_load_energy(plt, series, output):
    figure = small_multiple(
        plt, "Load energy and passive energy",
        "Their vertical separation is the load ergotropy.", "Energy", series,
        (("load_energy", "Load energy", BLUE, "-"),
         ("load_passive_energy", "Passive energy", ORANGE, "--")),
    )
    save(plt, figure, output, "m18_02_load_and_passive_energy.png")


def plot_ergotropy_components(plt, series, output):
    figure = small_multiple(
        plt, "Population and coherent ergotropy",
        "The components sum to the bare-load ergotropy. Each panel uses its own vertical scale.",
        "Ergotropy", series,
        (("population_ergotropy", "Population", TEAL, "-"),
         ("coherent_ergotropy", "Coherent", PURPLE, "--")), zero=True, scientific=True,
    )
    save(plt, figure, output, "m18_03_ergotropy_components.png")


def plot_current(plt, series, output):
    figure, axes = plt.subplots(2, 1, figsize=(11.6, 7.0), sharex=True)
    arrange(figure, "Energy flow from site 7 to the load",
            "Positive current corresponds to energy entering the load.", top=0.79, hspace=0.29)
    for condition in CONDITIONS:
        condition_line(axes[0], series, condition, "site7_to_load_current", 1e3)
        condition_line(axes[1], series, condition, "cumulative_load_energy_inflow", 1e3)
    for ax in axes:
        style_axis(ax, time_axis=True, zero=True)
    axes[0].set_ylabel(r"Current ($\times 10^{-3}$)", color=INK)
    axes[1].set_ylabel(r"Integrated inflow ($\times 10^{-3}$)", color=INK)
    axes[1].set_xlabel("Time", color=INK)
    top_legend(figure, axes[0], len(CONDITIONS))
    save(plt, figure, output, "m18_04_site7_to_load_current.png")


def plot_maxima(plt, percent_formatter, summaries, output):
    figure, ax = plt.subplots(figsize=(9.1, 4.9))
    arrange(figure, "Maximum ergotropy observed after first extraction",
            f"Each recovery ratio uses the M17 first extracted work ({W_FIRST:.6g}) as its denominator.")
    maximum_ratios = [100.0 * float(summaries[condition]["max_recovery_ratio"]) for condition in RECOVERY]
    colors = [CONDITION_STYLES[condition][0] for condition in RECOVERY]
    labels = [f"{condition}\n{CONDITION_STYLES[condition][3]}" for condition in RECOVERY]
    bars = ax.bar(range(len(RECOVERY)), maximum_ratios, color=colors, width=0.53, zorder=3)
    for condition, bar, ratio, color in zip(RECOVERY, bars, maximum_ratios, colors):
        label = "≈0%" if summaries[condition].get("reformed") == "NO" else f"{ratio:.4g}%"
        ax.annotate(label, (bar.get_x() + bar.get_width() / 2, ratio),
                    xytext=(0, 6), textcoords="offset points", ha="center", color=color, fontsize=9.2)
    ax.set_xticks(range(len(RECOVERY)), labels)
    ax.set_xlabel("Condition and post-reconnection coupling, g", color=INK)
    ax.set_ylabel("Maximum recovery ratio", color=INK)
    ax.yaxis.set_major_formatter(percent_formatter(100.0))
    ax.margins(y=0.22)
    style_axis(ax, zero=True)
    save(plt, figure, output, "m18_05_maximum_recovery_ratio.png")


def plot_extraction(plt, ledger, reconnection, output):
    figure = plt.figure(figsize=(11.6, 8.7))
    arrange(figure, "First extraction, second extraction and switching work",
            "Extraction work is positive out of the system. Switching work is positive into the system.",
            top=0.79, bottom=0.085)
    grid = figure.add_gridspec(3, 2, height_ratios=(1, 1, 0.92), hspace=0.43, wspace=0.14)
    reference = figure.add_subplot(grid[0, 0])
    reference.set_yscale("symlog", linthresh=1e-8, linscale=0.65)
    reference.yaxis.set_major_formatter(scientific_tick)
    panels = [(f"Fixed time t = {time:.2f}", "fixed", time) for time in FIXED_TIMES]
    panels.append(("Each condition’s observed maximum", "observed_max", None))
    series = (
        ("bare_load_gross_extracted_work", "Second bare-load", BLUE, "o"),
        ("total_hamiltonian_operation_work", "Second total", TEAL, "s"),
        ("second_net_work", "Second net", PURPLE, "D"),
    )
    for index, (title, branch, time) in enumerate(panels):
        ax = reference if index == 0 else figure.add_subplot(grid[index // 2, index % 2], sharey=reference)
        rows = {row["condition"]: row for row in ledger if row["branch"] == branch
                and (time is None or float(row["time"]) == time)}
        first = float(rows["R0"]["first_total_work"])
        ax.axhline(first, color=GRAY, linestyle="--", linewidth=1.25, label="First total")
        for offset, (field, label, color, marker) in zip((-0.19, 0.0, 0.19), series):
            ax.scatter([i + offset for i in range(len(RECOVERY))],
                       [float(rows[condition][field]) for condition in RECOVERY],
                       label=label, c=color, marker=marker, s=40, zorder=3)
        ax.set_title(title, loc="left", color=INK, fontsize=11)
        ax.set_xticks(range(len(RECOVERY)), RECOVERY)
        ax.set_xlim(-0.48, len(RECOVERY) - 0.52)
        style_axis(ax, zero=True)
        if index % 2 == 0:
            ax.set_ylabel("Extracted work (symlog)", color=INK, fontsize=9)
        else:
            ax.tick_params(labelleft=False)
    top_legend(figure, reference, 4)

    ax = figure.add_subplot(grid[2, :])
    switch = [float(reconnection[condition]["w_switch_on"]) for condition in CONDITIONS]
    ax.bar(range(len(CONDITIONS)), switch, color=[CONDITION_STYLES[c][0] for c in CONDITIONS],
           width=0.50, zorder=3)
    ax.set_title("Reconnection at t = 10.00", loc="left", color=INK, fontsize=11)
    ax.set_ylabel("Switch-on work", color=INK, fontsize=9)
    ax.set_xticks(range(len(CONDITIONS)), CONDITIONS)
    ax.yaxis.set_major_formatter(scientific_tick)
    style_axis(ax, zero=True)
    save(plt, figure, output, "m18_06_extraction_and_switching_work.png")


def plot_balance(plt, trajectories, energy_balance, output):
    figure = plt.figure(figsize=(12.6, 8.7))
    arrange(figure, "Full-system energy balance",
            "Uninterrupted evolution above. Operation and dissipator contributions through t = 20.00 below.",
            top=0.81, bottom=0.085)
    grid = figure.add_gridspec(2, 1, height_ratios=(2.1, 1.4), hspace=0.40)
    trajectories_grid = grid[0].subgridspec(2, 3, hspace=0.43, wspace=0.43)
    ledger_grid = grid[1].subgridspec(1, 3, width_ratios=(1.40, 1.13, 0.95), wspace=0.54)
    trajectory_axis = figure.add_subplot(trajectories_grid[0, 0])
    for i, condition in enumerate(CONDITIONS):
        ax = trajectory_axis if i == 0 else figure.add_subplot(trajectories_grid[i // 3, i % 3], sharey=trajectory_axis)
        rows = trajectories[condition]
        times = values(rows, "time")
        total = values(rows, "total_system_energy")
        ax.plot(times, [energy - total[0] for energy in total], color=BLUE,
                label="Measured total energy change", linewidth=1.8)
        ax.plot(times, values(rows, "dissipative_energy_change_cumulative"), color=ORANGE,
                label="Integrated dissipative change", linestyle="--", linewidth=1.45)
        ax.set_title(condition_label(condition), loc="left", color=INK, fontsize=10.2)
        style_axis(ax, time_axis=True, zero=True)
        ax.set_xticks((10, 15, 20))
        ax.yaxis.set_major_formatter(scientific_tick)
        if i % 3 == 0:
            ax.set_ylabel("Energy change", color=INK, fontsize=9)
        if i >= 3:
            ax.set_xlabel("Time", color=INK, fontsize=9)
    top_legend(figure, trajectory_axis, 2)

    closing_rows = {row["condition"]: row for row in energy_balance if float(row["time"]) == 20.0
                    and ((row["condition"] in RECOVERY and row["branch"] == "fixed")
                         or (row["condition"] == "U4" and row["branch"] == "uninterrupted"))}
    operation_ax = figure.add_subplot(ledger_grid[0, 0])
    exchange_ax = figure.add_subplot(ledger_grid[0, 1])
    residual_ax = figure.add_subplot(ledger_grid[0, 2])
    x = list(range(len(CONDITIONS)))
    signed_terms = (
        (operation_ax, "first_total_work", "First extraction", -1.0, GRAY, -0.14),
        (operation_ax, "total_hamiltonian_operation_work", "Second extraction", -1.0, TEAL, 0.14),
        (exchange_ax, "w_switch_on", "Reconnection", 1.0, GOLD, -0.14),
        (exchange_ax, "dissipative_energy_change_cumulative", "Dissipator", 1.0, ORANGE, 0.14),
    )
    for ax, field, label, sign, color, offset in signed_terms:
        energies = [sign * float(closing_rows[condition][field] or "0") for condition in CONDITIONS]
        ax.bar([i + offset for i in x], energies, label=label, color=color, width=0.25, zorder=3)
    observed_changes = [float(closing_rows[c]["total_energy_after_second"]
                              or closing_rows[c]["total_energy_before_second"])
                        - float(closing_rows[c]["total_energy_initial"]) for c in CONDITIONS]
    operation_ax.scatter(x, observed_changes, color=BLUE, marker="D", s=32,
                         label="Measured net change", zorder=4)
    operation_ax.set_title("Extraction and energy change", loc="left", color=INK, fontsize=11)
    exchange_ax.set_title("Switch and dissipator", loc="left", color=INK, fontsize=11)
    for ax in (operation_ax, exchange_ax):
        ax.legend(loc="best", frameon=True, framealpha=0.94, edgecolor=GRID, labelcolor=INK, fontsize=8.1)

    residuals = [float(closing_rows[c]["balance_residual"]) for c in CONDITIONS]
    residual_ax.scatter(x, residuals, s=35, color=[CONDITION_STYLES[c][0] for c in CONDITIONS], zorder=3)
    residual_ax.set_title("Balance residual", loc="left", color=INK, fontsize=11)
    for ax in (operation_ax, exchange_ax, residual_ax):
        ax.set_xticks(x, CONDITIONS)
        style_axis(ax, zero=True)
        ax.yaxis.set_major_formatter(scientific_tick)
    save(plt, figure, output, "m18_07_full_system_energy_balance.png")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=ROOT, help="directory containing the M18 CSV files")
    parser.add_argument("--output", type=Path, help="figure directory (defaults to figures/ under --data)")
    parser.add_argument("--plot-deps", type=Path, help="directory with Matplotlib and its dependencies")
    args = parser.parse_args()
    if args.plot_deps:
        sys.path.insert(0, str(args.plot_deps.resolve()))

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.ticker import PercentFormatter

    output = args.output or args.data / "figures"
    output.mkdir(parents=True, exist_ok=True)
    rows = read_csv(args.data, "m18_recovery_timeseries.csv")
    trajectories = {c: sorted((r for r in rows if r["condition"] == c), key=lambda r: float(r["time"]))
                    for c in CONDITIONS}
    summaries = {r["condition"]: r for r in read_csv(args.data, "m18_recovery_summary.csv")
                 if r["max_recovery_ratio"]}
    reconnection = {r["condition"]: r for r in read_csv(args.data, "m18_reconnection_work.csv")}
    ledger = read_csv(args.data, "m18_second_extraction_ledger.csv")
    energy_balance = read_csv(args.data, "m18_energy_balance.csv")

    plot_ergotropy(plt, trajectories, output)
    plot_load_energy(plt, trajectories, output)
    plot_ergotropy_components(plt, trajectories, output)
    plot_current(plt, trajectories, output)
    plot_maxima(plt, PercentFormatter, summaries, output)
    plot_extraction(plt, ledger, reconnection, output)
    plot_balance(plt, trajectories, energy_balance, output)


if __name__ == "__main__":
    main()
