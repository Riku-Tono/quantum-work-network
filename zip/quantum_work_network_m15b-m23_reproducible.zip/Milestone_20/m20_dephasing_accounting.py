"""Resolve passive-energy changes on each constant-Hamiltonian M20 segment."""

import argparse
import csv
from pathlib import Path


TOL = 1e-12


def read_rows(path):
    with path.open(encoding="utf-8-sig", newline="") as source:
        return list(csv.DictReader(source))


def segment(cycle, stage, g, start, end, bath_column):
    suffix = "g0" if g == 0 else "g025"
    start_e = float(start[f"global_energy_{suffix}"])
    end_e = float(end[f"global_energy_{suffix}"])
    start_w = float(start[f"global_ergotropy_{suffix}"])
    end_w = float(end[f"global_ergotropy_{suffix}"])
    integral = float(cycle[bath_column])
    delta_passive = (end_e - end_w) - (start_e - start_w)
    delta_energy = end_e - start_e
    residual = delta_energy - integral
    if abs(residual) > TOL or delta_passive < -TOL:
        raise ValueError(f"Constant-H passive-energy audit failed at {cycle['cycle']} / {stage}")
    return {
        "cycle": cycle["cycle"],
        "segment": stage,
        "accepted_cycle": cycle["accepted"],
        "g": g,
        "start_time": start["time"],
        "end_time": end["time"],
        "start_total_energy": start_e,
        "end_total_energy": end_e,
        "start_passive_energy": start_e - start_w,
        "end_passive_energy": end_e - end_w,
        "start_ergotropy": start_w,
        "end_ergotropy": end_w,
        "delta_total_energy": delta_energy,
        "dissipator_integral": integral,
        "delta_passive_energy": delta_passive,
        "delta_ergotropy": end_w - start_w,
        "energy_integral_residual": residual,
        "status": "PASS",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path)
    args = parser.parse_args()
    data = args.results
    basis = read_rows(data / "m20_sector_diagnostics.csv")
    anchor, = (row for row in basis if row["source"] == "M18")
    states = {(row["cycle"], row["phase"]): row for row in basis if row["source"] == "M20"}
    previous = anchor
    rows = []
    for cycle in read_rows(data / "m20_cycle_ledger.csv"):
        key = cycle["cycle"]
        wait = states[key, "wait_end"]
        before = states[key, "before"]
        rows.append(segment(cycle, "disconnected_wait", 0.0, previous, wait, "dissipative_wait"))
        rows.append(segment(cycle, "reconnected_evolution", 0.25, wait, before, "dissipative_connected"))
        if cycle["accepted"] == "YES":
            previous = states[key, "after"]
    with (data / "m20_dephasing_accounting.csv").open("x", encoding="utf-8", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(f"Constant-H dephasing accounting: {len(rows)}/{len(rows)} segments passed.")


if __name__ == "__main__":
    main()
