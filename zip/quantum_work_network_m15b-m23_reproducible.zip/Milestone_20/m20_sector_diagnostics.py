"""Compare unrestricted and excitation-preserving ergotropy on saved states.

Excitation-preserving unitaries act within each number sector. Their passive
energies use the original, subnormalized block spectra. The separate bound on
local unitary work holds at the saved coupling and does not include switches.
"""

import argparse
from pathlib import Path, PurePosixPath

from verify_m20 import (
    ANCHOR_G,
    ANCHOR_NAME,
    CHAIN,
    LOAD,
    LEVELS,
    N,
    TOL,
    Audit,
    Model,
    State,
    expectation,
    file_digest,
    max_abs,
    np,
    partial_traces,
    phase_path,
    read_csv,
    require,
    symmetrize,
    verify_source,
    write_csv,
)


M19_MANIFEST_SHA = "CAB456DE82C9E71F10264FB6175D49DA6034D87684DD7A7AA7DB227A1EBF79A4"
M19_ENDPOINT_SHA = "12ED17C819E4D3835680903BA41F7313E478A3A4A7096A4C343272352D2F9656"
M19_ENDPOINT = "states/c10_after_t6804.bin"
CHAIN_OCCUPATION = np.array([basis.bit_count() for basis in range(CHAIN)])
FULL_OCCUPATION = (CHAIN_OCCUPATION[:, None] + LEVELS[None, :]).ravel()


def sector_spectrum(density, hamiltonian, occupation):
    off_diagonal_sector = occupation[:, None] != occupation[None, :]
    commutator = hamiltonian * (occupation[None, :] - occupation[:, None])
    conservation_error = max_abs(commutator)
    require(conservation_error <= TOL, "Hamiltonian crosses a protected excitation sector")
    population = []
    passive_energy = 0.0
    for number in range(int(occupation.max()) + 1):
        indices = np.flatnonzero(occupation == number)
        block = np.ix_(indices, indices)
        reduced_density = density[block]
        levels = np.linalg.eigvalsh(hamiltonian[block])
        spectrum = np.linalg.eigvalsh(symmetrize(reduced_density))
        population.append(float(np.trace(reduced_density).real))
        passive_energy += float(levels @ spectrum[::-1])
    population = np.array(population)
    require(float(population.min()) >= -TOL, "Negative excitation-sector probability")
    require(abs(float(population.sum()) - 1) <= TOL, "Excitation-sector probabilities do not sum to one")
    ergotropy = expectation(density, hamiltonian) - passive_energy
    require(ergotropy >= -TOL, "Negative excitation-preserving ergotropy")
    coherence = float(np.linalg.norm(density[off_diagonal_sector]))
    return population, passive_energy, ergotropy, conservation_error, coherence


def read_m19_endpoint(directory, anchor_sha):
    manifest = directory / "m19_state_manifest.csv"
    require(file_digest(manifest) == M19_MANIFEST_SHA, "M19 reference manifest SHA-256 mismatch")
    row, = (row for row in read_csv(manifest) if row["filename"] == M19_ENDPOINT)
    require(
        row["cycle"] == "10" and row["phase"] == "after" and float(row["time"]) == 68.04
        and float(row["g"]) == 0.25 and row["source_initial_state_sha256"] == anchor_sha,
        "M19 endpoint metadata mismatch",
    )
    state = State.read(directory / PurePosixPath(M19_ENDPOINT), 68.04)
    require(state.sha256 == row["sha256"] == M19_ENDPOINT_SHA, "M19 endpoint SHA-256 mismatch")
    return state


def overlap(population, reference):
    normalized = population / population.sum()
    normalized_reference = reference / reference.sum()
    return float(1 - 0.5 * np.abs(normalized - normalized_reference).sum())


def diagnostic(model, state, coupling, anchor_probabilities=None):
    require(state.trace_error <= TOL and state.hermiticity_error <= TOL and state.spectrum[0] >= -TOL,
            "Input density matrix fails physicality checks")
    load, chain, terminal = partial_traces(state.matrix)
    load_energy = float(LEVELS @ np.diag(load).real)
    absolute = model.scalars(state, coupling)
    chain_probs, chain_passive, chain_ergotropy, chain_comm, chain_coherence = sector_spectrum(chain, model.chain_h, CHAIN_OCCUPATION)
    full_h = model.base + coupling * model.exchange_full
    full_probs, full_passive, full_ergotropy, full_comm, full_coherence = sector_spectrum(state.matrix, full_h, FULL_OCCUPATION)
    require(chain_ergotropy <= absolute["chain_ergotropy"] + TOL and full_ergotropy <= absolute["global_ergotropy"] + TOL,
            "Sector optimum exceeds unrestricted optimum")
    mean_chain = float(np.arange(N + 1) @ chain_probs)
    mean_full = float(np.arange(N + LOAD) @ full_probs)
    require(abs(mean_full - mean_chain - load_energy) <= TOL, "Full excitation number differs from sum of marginals")
    anchor_chain, anchor_full = (chain_probs, full_probs) if anchor_probabilities is None else anchor_probabilities

    # For any load unitary the terminal cross block C becomes U C U†.
    # Hölder gives |Tr(C b)| <= ||C||_1 ||b||_op; ||b||_op = sqrt(2).
    block = terminal[:LOAD, LOAD:]
    block_trace_norm = float(np.linalg.svd(block, compute_uv=False).sum())
    exchange_bound = 2 * np.sqrt(LOAD - 1) * block_trace_norm
    exchange_expectation = expectation(terminal, model.exchange)
    require(abs(exchange_expectation) <= exchange_bound + TOL, "Terminal exchange exceeds its norm bound")
    local_bound = max(0.0, absolute["load_ergotropy"]) + coupling * (exchange_expectation + exchange_bound)
    energy_g0 = model.energy(state, 0.0)
    energy_g025 = energy_g0 + ANCHOR_G * exchange_expectation
    return {
        "chain_energy": absolute["chain_energy"], "full_energy": absolute["global_energy"],
        "global_energy_g0": energy_g0, "global_ergotropy_g0": energy_g0 - float(model.levels(0.0) @ state.spectrum[::-1]),
        "global_energy_g025": energy_g025, "global_ergotropy_g025": energy_g025 - float(model.levels(ANCHOR_G) @ state.spectrum[::-1]),
        "chain_sector_passive_energy": chain_passive, "full_sector_passive_energy": full_passive,
        "chain_sector_ergotropy": chain_ergotropy, "full_sector_ergotropy": full_ergotropy,
        "chain_unrestricted_ergotropy": absolute["chain_ergotropy"], "full_unrestricted_ergotropy": absolute["global_ergotropy"],
        "load_ergotropy": absolute["load_ergotropy"], "load_number_preserving_ergotropy": 0.0,
        "chain_excitation_mean": mean_chain, "load_excitation_mean": load_energy, "full_excitation_mean": mean_full,
        "chain_excitation_overlap_with_anchor": overlap(chain_probs, anchor_chain),
        "full_excitation_overlap_with_anchor": overlap(full_probs, anchor_full),
        "chain_off_sector_coherence_frobenius": chain_coherence, "full_off_sector_coherence_frobenius": full_coherence,
        "chain_excitation_commutator_max_abs": chain_comm, "full_excitation_commutator_max_abs": full_comm,
        "terminal_exchange_expectation": exchange_expectation,
        "terminal_offdiagonal_block_trace_norm": block_trace_norm,
        "terminal_exchange_absolute_upper_bound": exchange_bound,
        "any_local_unitary_full_work_upper_bound": local_bound,
        "tolerance": TOL,
        **{f"chain_excitation_probability_{number}": p for number, p in enumerate(chain_probs)},
        **{f"full_excitation_probability_{number}": p for number, p in enumerate(full_probs)},
    }, (chain_probs, full_probs)


def sector_rows(m18, m19, m20):
    audit = Audit()
    anchor = verify_source(m18, audit)
    require(all(row["status"] == "PASS" for row in audit.rows), "M18 anchor failed its physical checks")
    model = Model()
    anchor_values, reference = diagnostic(model, anchor, ANCHOR_G)
    archive_anchor = f"states/{ANCHOR_NAME}" if (m18 / "states" / ANCHOR_NAME).is_file() else ANCHOR_NAME
    rows = [{
        "source": "M18", "cycle": 2, "phase": "anchor", "time": f"{anchor.time:.2f}", "g": ANCHOR_G,
        "filename": archive_anchor, "sha256": anchor.sha256, **anchor_values,
    }]
    endpoint = read_m19_endpoint(m19, anchor.sha256)
    endpoint_values, _ = diagnostic(model, endpoint, ANCHOR_G, reference)
    rows.append({
        "source": "M19", "cycle": 10, "phase": "after", "time": f"{endpoint.time:.2f}", "g": ANCHOR_G,
        "filename": M19_ENDPOINT, "sha256": endpoint.sha256, **endpoint_values,
    })
    proposals = {int(row["cycle"]): row for row in read_csv(m20 / "m20_cycle_ledger.csv")}
    for row in read_csv(m20 / "m20_state_metrics.csv"):
        cycle, phase = int(row["cycle"]), row["phase"]
        if phase not in ("wait_end", "before", "after"):
            continue
        name = row["filename"]
        coupling, time = float(row["g"]), float(row["time"])
        state = State.read(m20 / phase_path(cycle, phase, name), time)
        values, _ = diagnostic(model, state, coupling, reference)
        if phase == "before":
            work = float(proposals[cycle]["total_work"])
            require(work <= values["any_local_unitary_full_work_upper_bound"] + TOL,
                    f"Recorded local work exceeds the analytic upper bound in cycle {cycle}")
        rows.append({
            "source": "M20", "cycle": cycle, "phase": phase, "time": f"{state.time:.2f}", "g": coupling,
            "filename": name, "sha256": state.sha256, **values,
        })
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("m18", type=Path, help="published M18 results or packaged m18_inputs")
    parser.add_argument("m19", type=Path, help="published M19 results or packaged m19_reference")
    parser.add_argument("m20", type=Path, help="M20 result directory")
    args = parser.parse_args()
    rows = sector_rows(args.m18, args.m19, args.m20)
    write_csv(args.m20 / "m20_sector_diagnostics.csv", rows)
    print(f"Wrote excitation-sector diagnostics for {len(rows)} archived and new states.")


if __name__ == "__main__":
    main()
