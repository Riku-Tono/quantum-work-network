"""Render comparisons of the M20 fixed protocols and the M19 adopted sequence."""

import argparse
import csv
from math import ceil
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parent
INK = "#152637"
MUTED = "#42586C"
GRID = "#DFE7ED"
AXIS = "#8293A2"
BLUE = "#225886"
TEAL = "#007172"
ORANGE = "#A2441A"
PURPLE = "#704984"
WORK_FLOOR = 1e-12
POLICY_STYLES = ((BLUE, "o", "-"), (TEAL, "s", "--"), (ORANGE, "D", "-."), (PURPLE, "^", ":"))


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as source:
        return list(csv.DictReader(source))


def accepted(row):
    return row["accepted"] == "YES"


def number(row, key):
    return float(row[key])


def cycle_index(row):
    return int(row["cycle"])


def scientific_tick(value, _position):
    return "0" if value == 0.0 else f"{value:.1e}"


def style_axis(ax, title, ylabel, *, x_label=None, scientific=True):
    ax.set_axisbelow(True)
    ax.yaxis.grid(True, color=GRID, linewidth=0.8)
    ax.spines[["top", "right"]].set_visible(False)
    for edge in ("bottom", "left"):
        ax.spines[edge].set_color(AXIS)
    ax.tick_params(axis="both", color=AXIS, labelcolor=INK, labelsize=9)
    if scientific:
        ax.yaxis.set_major_formatter(scientific_tick)
    ax.axhline(0.0, color=AXIS, linewidth=0.82, zorder=1)
    ax.set_title(title, loc="left", color=INK, fontsize=10.8, pad=8)
    ax.set_ylabel(ylabel, color=INK, fontsize=9.3, labelpad=7)
    if x_label:
        ax.set_xlabel(x_label, color=INK, fontsize=9.3)


def title_figure(figure, title, subtitle, *, top=0.81, bottom=0.12, **spacing):
    figure.subplots_adjust(left=0.114, right=0.968, bottom=bottom, top=top, **spacing)
    figure.text(0.114, 0.965, title, color=INK, fontsize=19, fontweight="bold", va="top")
    figure.text(0.114, 0.909, subtitle, color=MUTED, fontsize=10.2, va="top")


def legend_at_top(figure, ax, columns):
    handles, labels = ax.get_legend_handles_labels()
    figure.legend(handles, labels, loc="upper left", bbox_to_anchor=(0.108, 0.870), ncols=columns,
                  frameon=False, handlelength=2.4, columnspacing=1.6, labelcolor=INK, fontsize=9.1)


def policy_line(ax, x, y, label, style, *, drawstyle="default"):
    color, marker, linestyle = style
    ax.plot(x, y, label=label, color=color, marker=marker, linestyle=linestyle, linewidth=1.55,
            markersize=4.8, markerfacecolor="white", markeredgewidth=1.2, drawstyle=drawstyle)


def save(plt, figure, output, filename):
    with (output / filename).open("xb") as stream:
        figure.savefig(stream, format="png", dpi=200, facecolor="white")
    plt.close(figure)


def rates(ordered):
    """Use the complete physical cycle duration, including the disconnected wait."""
    points = []
    cumulative = 0.0
    anchor_time = number(ordered[0], "start_time")
    for row in ordered:
        if accepted(row):
            net = number(row, "net_work")
            cumulative += net
            elapsed = number(row, "time") - anchor_time
            cycle_duration = number(row, "time") - number(row, "start_time")
            points.append((cycle_index(row), elapsed, net, cumulative, net / cycle_duration, cumulative / elapsed))
    return points


def plot_comparison(plt, policies, output):
    figure, axes = plt.subplots(2, 2, figsize=(12.0, 7.7))
    title_figure(figure, "Work and time cost of repeated extraction",
                 "Elapsed protocol time includes disconnected waits and connected evolution.",
                 top=0.79, bottom=0.105, wspace=0.34, hspace=0.40)
    net_ax, cumulative_ax, rate_ax, average_ax = axes.flat
    net_ax.set_yscale("symlog", linthresh=WORK_FLOOR, linscale=0.65)
    rate_ax.set_yscale("symlog", linthresh=WORK_FLOOR / 10, linscale=0.65)
    shows_declined = False
    for (label, rows), style in zip(policies, POLICY_STYLES):
        points = rates(rows)
        cycle = [point[0] for point in points]
        net = [point[2] for point in points]
        policy_line(net_ax, cycle, net, label, style)
        policy_line(cumulative_ax, [0.0, *[point[1] for point in points]],
                    [0.0, *[point[3] for point in points]], label, style, drawstyle="steps-post")
        policy_line(rate_ax, cycle, [point[4] for point in points], label, style)
        policy_line(average_ax, cycle, [point[5] for point in points], label, style)
        declined = [row for row in rows if not accepted(row)]
        if declined:
            net_ax.scatter([cycle_index(row) for row in declined], [number(row, "net_work") for row in declined],
                           color=style[0], marker="X", s=42, zorder=4,
                           label="Declined proposal" if not shows_declined else None)
            shows_declined = True
    net_ax.axhline(WORK_FLOOR, color=AXIS, linewidth=0.9, linestyle=":", label="Work floor")
    for ax, title, ylabel, xlabel in (
        (net_ax, "Net work in each extraction", "Net work (symlog)", "Extraction cycle"),
        (cumulative_ax, "Cumulative accepted work", "Cumulative net work", "Elapsed time from the common state"),
        (rate_ax, "Time-normalized net work per cycle", "Net work / cycle duration (symlog)", "Extraction cycle"),
        (average_ax, "Average rate since the common state", "Cumulative net work / elapsed time", "Extraction cycle"),
    ):
        style_axis(ax, title, ylabel, x_label=xlabel)
        if ax is not cumulative_ax:
            ax.set_xticks(range(3, 11))
    legend_at_top(figure, net_ax, len(policies) + int(shows_declined) + 1)
    save(plt, figure, output, "m20_01_protocol_work_and_rates.png")


def plot_rebound(plt, policies, output):
    figure, (value_ax, rate_ax) = plt.subplots(1, 2, figsize=(11.8, 4.9))
    subtitle = "The endpoints show the recorded choices at each cycle."
    if any(not accepted(row) for _, rows in policies for row in rows if cycle_index(row) in (9, 10)):
        subtitle += " An X marks a declined proposal."
    title_figure(figure, "Net work between cycles 9 and 10", subtitle, top=0.77, bottom=0.15, wspace=0.36)
    value_ax.set_yscale("symlog", linthresh=WORK_FLOOR, linscale=0.65)
    rate_ax.set_yscale("symlog", linthresh=WORK_FLOOR / 10, linscale=0.65)
    n = len(policies)
    for index, ((label, rows), style) in enumerate(zip(policies, POLICY_STYLES)):
        last = [row for row in rows if cycle_index(row) in (9, 10)]
        offset = (index - (n - 1) / 2) * 0.10
        positions = [cycle_index(row) + offset for row in last]
        net = [number(row, "net_work") for row in last]
        per_time = [work / (number(row, "time") - number(row, "start_time")) for row, work in zip(last, net)]
        for ax, y in ((value_ax, net), (rate_ax, per_time)):
            policy_line(ax, positions, y, label, style)
            for x_val, y_val, row in zip(positions, y, last):
                if not accepted(row):
                    ax.scatter(x_val, y_val, color=style[0], marker="X", s=45, zorder=4)
                is_later = cycle_index(row) == 10
                ax.annotate(f"{y_val:.2e}", (x_val, y_val), xytext=(-5 if is_later else 5, 7),
                            textcoords="offset points", ha="right" if is_later else "left",
                            color=style[0], fontsize=8.1,
                            bbox={"facecolor": "white", "edgecolor": "none", "pad": 0.5, "alpha": 0.91})
    style_axis(value_ax, "Net work", "Net work (symlog)", x_label="Extraction cycle")
    style_axis(rate_ax, "Net work per unit cycle time", "Net work / cycle duration (symlog)", x_label="Extraction cycle")
    value_ax.axhline(WORK_FLOOR, color=AXIS, linewidth=0.9, linestyle=":", label="Work floor")
    for ax in (value_ax, rate_ax):
        ax.set_xlim(8.68, 10.32)
        ax.set_xticks((9, 10))
    legend_at_top(figure, value_ax, n + 1)
    save(plt, figure, output, "m20_02_cycle_10_rebound.png")


def plot_extension(plt, candidates, extension, summary, output):
    column_count = min(2, len(summary))
    row_count = ceil(len(summary) / column_count)
    width = 9.2 if column_count == 1 else 11.8
    figure, axes = plt.subplots(row_count, column_count, figsize=(width, 2.5 * row_count + 2.0), squeeze=False)
    title_figure(figure, "Extended search from selected boundary cycles",
                 "The tail continues the unextracted nominal trajectory. Markers show the sampled maxima.",
                 top=0.76 if row_count == 1 else 0.80, bottom=0.15 if row_count == 1 else 0.10,
                 wspace=0.36, hspace=0.49)
    for ax, row in zip(axes.flat, summary):
        cycle = cycle_index(row)
        nominal = sorted((r for r in candidates if cycle_index(r) == cycle), key=lambda r: number(r, "elapsed"))
        tail = sorted((r for r in extension if cycle_index(r) == cycle), key=lambda r: number(r, "elapsed"))
        nominal_times = [number(r, "elapsed") for r in nominal]
        nominal_net = [number(r, "net_work") for r in nominal]
        tail_times = [number(r, "elapsed") for r in tail]
        ax.plot(nominal_times, nominal_net, color=BLUE, linewidth=1.55, label="Nominal window")
        ax.plot([nominal_times[-1], *tail_times], [nominal_net[-1], *[number(r, "net_work") for r in tail]],
                color=TEAL, linewidth=1.55, label="Extended window")
        ax.plot(tail_times, [number(r, "net_half") for r in tail], color=ORANGE, linestyle="--",
                linewidth=1.35, label="Extended half step")
        ax.axvline(nominal_times[-1], color=AXIS, linestyle=":", linewidth=0.9)
        ax.scatter(number(row, "nominal_peak_elapsed"), number(row, "nominal_net"), s=36, marker="o",
                   color=BLUE, facecolors="white", linewidths=1.2, zorder=4)
        ax.scatter(number(row, "extended_peak_elapsed"), number(row, "extended_net"), s=44, marker="D",
                   color=TEAL, facecolors="white", linewidths=1.2, zorder=5)
        peak_time = number(row, "extended_peak_elapsed")
        style_axis(ax, f"Cycle {cycle}  ·  extended peak at {peak_time:.2f}", "Net work",
                   x_label="Elapsed time after reconnection")
        ax.set_xlim(-0.22, 16.22)
        ax.set_xticks((0, 4, 8, 12, 16))
    for ax in list(axes.flat)[len(summary):]:
        ax.set_visible(False)
    legend_at_top(figure, axes[0, 0], 3)
    save(plt, figure, output, "m20_03_extended_search.png")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=ROOT, help="directory containing the M20 CSVs")
    parser.add_argument("--reference", type=Path, help="path to the official M19 cycle ledger")
    parser.add_argument("--output", type=Path, help="figure directory (defaults to figures/ under --data)")
    parser.add_argument("--plot-deps", type=Path, help="directory with Matplotlib and its dependencies")
    args = parser.parse_args()
    if args.plot_deps:
        sys.path.insert(0, str(args.plot_deps.resolve()))

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    reference = args.reference
    if reference is None:
        bundled = args.data / "m19_reference" / "m19_cycle_ledger.csv"
        local_reference = ROOT / "m19_reference" / "m19_cycle_ledger.csv"
        reference = bundled if bundled.is_file() else local_reference
    policies = (
        ("M19 adopted", sorted(read_csv(reference), key=cycle_index)),
        ("M20 wait 2, $g$ = 0.25", sorted(read_csv(args.data / "m20_cycle_ledger.csv"), key=cycle_index)),
    )
    extension_file = args.data / "m20_extension.csv"
    extension = read_csv(extension_file) if extension_file.is_file() else []
    output = args.output or args.data / "figures"
    output.mkdir(parents=True, exist_ok=True)
    plot_comparison(plt, policies, output)
    plot_rebound(plt, policies, output)
    if extension:
        candidates = read_csv(args.data / "m20_candidates.csv")
        summary = sorted(read_csv(args.data / "m20_extension_summary.csv"), key=cycle_index)
        plot_extension(plt, candidates, extension, summary, output)


if __name__ == "__main__":
    main()
