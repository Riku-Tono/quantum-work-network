"""Verify the frozen M20 inputs and solver, then run the selected computation."""

import argparse
import csv
import hashlib
import shutil
import subprocess
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SOURCE = "R4_observed_max_t1590_after.bin"
SOURCE_SHA = "4C9A5EE8172E505592C43A7B522476715D418CAFA0CC677C04B853E72CC6F9ED"
PINNED_INPUTS = {
    SOURCE: SOURCE_SHA,
    "m18_state_manifest.csv": "9F0512D6ED2D85C85A240869D5DEF20C1177D891C7D626F2D5BC37EC9436D8EC",
    "m18_second_extraction_ledger.csv": "6A1C45F25B9B6A5408DF90402342C28F27920B8F7B184B23B086DE0DE8ED043C",
    "m18_energy_balance.csv": "86ACD899249668C6065489DCC1FCC1CD38CCB4AAECFDFF0CF666CB1AD17B60E8",
    "m18_reconnection_work.csv": "A4B5CCE44F279E928E1BDE18057D7E45037269DCA495B619E7E3C7BAF1879CB0",
}
PINNED_REFERENCE = {
    "m19_cycle_ledger.csv": "9A111DC7772CD63E507D9752231FFF1C8CF6EC0295F17D3F46587E169828066B",
    "m19_energy_balance.csv": "A11CA11B990891370712E926A44CF1B1BA1D715DD4EC7B5F257C9249EAE36547",
    "m19_protocol_summary.csv": "5E0001A72AEA6EE7216DEF86E083676FE0D1434FC8F1F4839324F886B84BA5EB",
    "m19_state_manifest.csv": "CAB456DE82C9E71F10264FB6175D49DA6034D87684DD7A7AA7DB227A1EBF79A4",
    "m19_state_metrics.csv": "3AD382C0AA8AA0A88E34A6B5A2D4C1AE436ADFF6E65CE25C89E1B3D54D848E2F",
    "states/c10_after_t6804.bin": "12ED17C819E4D3835680903BA41F7313E478A3A4A7096A4C343272352D2F9656",
}


def digest(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest().upper()


def verify(executable):
    archive = ROOT / "m18_inputs"
    for name, expected in PINNED_INPUTS.items():
        if digest(archive / name) != expected:
            raise ValueError(f"Official M18 SHA-256 mismatch for {name}")
    for name, expected in PINNED_REFERENCE.items():
        if digest(ROOT / "m19_reference" / name) != expected:
            raise ValueError(f"Official M19 SHA-256 mismatch for {name}")
    with (archive / "m18_state_manifest.csv").open(encoding="utf-8-sig", newline="") as file:
        row, = (row for row in csv.DictReader(file) if row["filename"] == f"states/{SOURCE}")
    if (row["sha256"], row["condition"], float(row["time"]), float(row["g"]),
            row["branch"], row["extraction_phase"], int(row["dimension"]), int(row["size_bytes"])) != (
            SOURCE_SHA, "R4", 15.90, 0.25, "observed_max", "after", 384, 2359320):
        raise ValueError("Official manifest metadata mismatch")
    with (ROOT / "m20_precommit_sha256.csv").open(encoding="utf-8-sig", newline="") as file:
        frozen = {row["filename"]: row["sha256"] for row in csv.DictReader(file)}
    for name, expected in frozen.items():
        path = executable if name == "m20_fixed_wait.exe" else ROOT / name
        if digest(path) != expected:
            raise ValueError(f"Frozen file SHA-256 mismatch for {name}")
    if not {"m20_fixed_wait.exe", "PRECOMMIT_M20.md"} <= frozen.keys():
        raise ValueError("Incomplete hash freeze")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("benchmark", "formal"))
    parser.add_argument("executable", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    executable, output = args.executable.resolve(), args.output.resolve()
    if output.exists():
        raise FileExistsError(output)
    verify(executable)
    started = time.perf_counter()
    subprocess.run([executable, args.mode, ROOT / "m18_inputs" / SOURCE, output], check=True)
    verify(executable)
    (output / "m18_inputs").mkdir()
    with (ROOT / "m18_inputs" / SOURCE).open("rb") as original:
        with (output / "m18_inputs" / SOURCE).open("xb") as snapshot:
            shutil.copyfileobj(original, snapshot)
    elapsed = time.perf_counter() - started
    with (output / "m20_batch_runtime.csv").open("x", encoding="utf-8", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(("mode", "elapsed_seconds"))
        writer.writerow((args.mode, f"{elapsed:.9f}"))
    print(f"{args.mode}: complete in {elapsed:.3f} s", flush=True)


if __name__ == "__main__":
    main()
