"""Compare M20's fixed waiting policy with the formal M19 sequence."""

import argparse
import csv
import hashlib
import math
from pathlib import Path


TOL = 1e-12
ANCHOR_TIME = 15.90
SOURCE_STATE = "states/R4_observed_max_t1590_after.bin"
SOURCE_SHA256 = "4C9A5EE8172E505592C43A7B522476715D418CAFA0CC677C04B853E72CC6F9ED"


def read_csv(path):
    with path.open(newline="", encoding="utf-8-sig") as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows):
    with path.open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def number(row, name):
    value = float(row[name])
    if not math.isfinite(value):
        raise ValueError(f"Nonfinite numerical record for {name}")
    return value


def yes(row):
    value = row["accepted"].strip().upper()
    if value not in {"YES", "NO", "TRUE", "FALSE", "1", "0"}:
        raise ValueError(f"Unknown acceptance marker {row['accepted']}")
    return value in {"YES", "TRUE", "1"}


def fmt(value, digits=6):
    return "—" if value is None else f"{value:.{digits}e}"


def t_fmt(value):
    return "—" if value is None else f"{value:.2f}"


def percent(value):
    return "—" if value is None else f"{100 * value:.6f}%"


def table(headers, rows):
    return [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
        *("| " + " | ".join(str(cell) for cell in row) + " |" for row in rows),
    ]


def index_cycles(rows):
    result = {int(row["cycle"]): row for row in rows}
    if not result or set(result) != set(range(3, max(result) + 1)) or len(result) != len(rows):
        raise ValueError("The extraction cycles must be sequential from cycle 3")
    if max(result) > 10 or any(not yes(result[i]) for i in range(3, max(result))):
        raise ValueError("A protocol exceeded cycle 10 or continued after rejection")
    if max(result) != 10 and yes(result[max(result)]):
        raise ValueError("A successful sequence stopped before completing cycle 10")
    return result


def comparison(prior, fixed):
    rows = []
    cumulative = {"m19": 0.0, "m20": 0.0}
    last_time = dict.fromkeys(cumulative, ANCHOR_TIME)
    for cycle in range(3, max(max(prior), max(fixed)) + 1):
        values = {"cycle": cycle}
        for label, protocol in (("m19", prior), ("m20", fixed)):
            step = protocol.get(cycle)
            committed = step is not None and yes(step)
            values[f"{label}_accepted"] = yes(step) if step is not None else None
            for key in ("start_time", "time", "wait", "g", "elapsed", "gross_work", "total_work", "net_work"):
                values[f"{label}_{key}"] = number(step, key) if step is not None else None
            duration = None
            if committed:
                last_time[label] = number(step, "time")
                duration = last_time[label] - number(step, "start_time")
                cumulative[label] += number(step, "net_work")
            total_time = last_time[label] - ANCHOR_TIME
            values[f"{label}_accepted_net_work"] = number(step, "net_work") if committed else None
            values[f"{label}_cycle_duration"] = duration
            values[f"{label}_cycle_net_per_time"] = values[f"{label}_accepted_net_work"] / duration if duration else None
            values[f"{label}_cumulative_net"] = cumulative[label]
            values[f"{label}_cumulative_elapsed"] = total_time
            values[f"{label}_cumulative_net_per_time"] = cumulative[label] / total_time if total_time else None
        for metric in ("accepted_net_work", "cycle_duration", "cycle_net_per_time", "cumulative_net", "cumulative_elapsed", "cumulative_net_per_time"):
            m19, m20 = (values[f"{label}_{metric}"] for label in ("m19", "m20"))
            values[f"delta_{metric}"] = None if m19 is None or m20 is None else m20 - m19
        rows.append(values)
    return rows


def completed_by_time(protocol, elapsed):
    completed = [row for row in protocol.values() if yes(row) and number(row, "time") - ANCHOR_TIME <= elapsed + TOL]
    total = sum(number(row, "net_work") for row in completed)
    return len(completed), total, total / elapsed if elapsed else None


def rebound(protocol):
    if not all(cycle in protocol and yes(protocol[cycle]) for cycle in (9, 10)):
        return None
    c9, c10 = protocol[9], protocol[10]
    first, last = number(c9, "net_work"), number(c10, "net_work")
    delta = last - first
    uncertainty = sum(abs(number(row, "net_work") - number(row, "net_half")) for row in (c9, c10))
    return first, last, delta, last / first, delta - uncertainty


def historical_inputs(m18):
    manifest, = (row for row in read_csv(m18 / "m18_state_manifest.csv") if row["filename"] == SOURCE_STATE)
    path = m18 / SOURCE_STATE
    if not path.is_file():
        path = m18 / Path(SOURCE_STATE).name
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest().upper()
    if digest != SOURCE_SHA256 or digest != manifest["sha256"].upper():
        raise ValueError("The M18 full-system start state failed the manifest SHA-256 check")
    history, = (
        row for row in read_csv(m18 / "m18_energy_balance.csv")
        if row["condition"] == "R4" and row["branch"] == "observed_max" and number(row, "time") == ANCHOR_TIME
    )
    return history


def energy_balance(fixed, history):
    anchor = number(history, "total_energy_after_second")
    prior_total = number(history, "ideal_total_operation_work_out")
    prior_with_cut = number(history, "ideal_total_operation_work_out_including_cut")
    prior_before = number(history, "total_energy_initial")
    bath_m18 = number(history, "dissipative_energy_change_cumulative")
    before_cut = number(history, "m17_pre_cut_total_energy")
    storage = number(history, "m17_storage_energy_change")
    net_sum = bath_sum = 0.0
    rows = []
    for cycle in (2, *fixed):
        row = fixed.get(cycle)
        if row is not None and not yes(row):
            continue
        start = anchor if row is None else number(row, "start_total_energy")
        before = anchor if row is None else number(row, "pre_total_energy")
        after = anchor if row is None else number(row, "post_total_energy")
        gross = 0.0 if row is None else number(row, "gross_work")
        total = 0.0 if row is None else number(row, "total_work")
        jump = 0.0 if row is None else number(row, "interaction_jump")
        cut = 0.0 if row is None else number(row, "cut_on")
        reconnect = 0.0 if row is None else number(row, "reconnect_on")
        q_wait = 0.0 if row is None else number(row, "dissipative_wait")
        q_connected = 0.0 if row is None else number(row, "dissipative_connected")
        net = total - cut - reconnect
        net_sum += net
        bath_sum += q_wait + q_connected
        rows.append({
            "cycle": cycle,
            "time": ANCHOR_TIME if row is None else number(row, "time"),
            "start_total_energy": start, "pre_total_energy": before, "post_total_energy": after,
            "gross_work": gross, "interaction_jump": jump, "total_work": total, "cut_on": cut, "reconnect_on": reconnect,
            "net_work": net, "dissipative_wait": q_wait, "dissipative_connected": q_connected,
            "cycle_residual": after - (start + q_wait + q_connected - net),
            "cumulative_m20_net": net_sum, "cumulative_m20_dissipation": bath_sum,
            "m18_anchor_total_energy": anchor,
            "anchor_balance_residual": after - (anchor + bath_sum - net_sum),
            "historical_m17_first_total_work": number(history, "first_total_work"),
            "historical_m18_second_net_work": number(history, "second_net_work"),
            "net_cumulative_from_first": prior_total + net_sum,
            "net_cumulative_including_m17_cut": prior_with_cut + net_sum,
            "pre_first_balance_residual": after - (prior_before + bath_m18 + bath_sum - prior_total - net_sum),
            "pre_cut_balance_residual": after - (before_cut + storage + bath_m18 + bath_sum - prior_with_cut - net_sum),
        })
    return rows


def numerical_checks(prior, fixed, compared, balance, extension, result, m19):
    checks = []

    def record(name, scope, observed, tolerance, passed):
        checks.append({"check": name, "scope": scope, "observed": observed, "bound": tolerance,
                       "status": "PASS" if passed else "FAIL"})

    def residual(name, scope, value, tolerance=TOL):
        record(name, scope, abs(value), tolerance, abs(value) <= tolerance)

    def logical(name, scope, value):
        record(name, scope, int(value), 1, value)

    logical("m18_start_state_sha256_verified", "ALL", True)
    for key in ("time", "wait", "g", "elapsed", "net_work", "post_total_energy"):
        residual(f"common_C3_{key}", 3, number(fixed[3], key) - number(prior[3], key))
    current_manifest = result / "m20_state_manifest.csv"
    reference_manifest = m19 / "m19_state_manifest.csv"
    if current_manifest.is_file() and reference_manifest.is_file():
        current = {row["phase"]: row["sha256"] for row in read_csv(current_manifest) if row["cycle"] == "3"}
        reference = {row["phase"]: row["sha256"] for row in read_csv(reference_manifest) if row["cycle"] == "3"}
        logical("common_C3_state_sha256_all_phases", 3, current == reference and len(current) == 4)
    if 4 in fixed:
        candidate, = (
            row for row in read_csv(m19 / "m19_protocol_summary.csv")
            if int(row["cycle"]) == 4 and number(row, "wait") == 2.0 and number(row, "g") == 0.25
        )
        for observed, existing in (("net_work", "peak_net_work"), ("elapsed", "peak_elapsed")):
            residual(f"common_start_C4_fixed_sweep_{observed}", 4, number(fixed[4], observed) - number(candidate, existing))
    for cycle, row in fixed.items():
        logical("fixed_wait_and_coupling", cycle, number(row, "wait") == 2.0 and number(row, "g") == 0.25)
        elapsed = number(row, "elapsed")
        logical("main_search_tick", cycle, 0 <= elapsed <= 8.0 and abs(elapsed * 50 - round(elapsed * 50)) <= TOL)
        residual("cycle_timeline", cycle, number(row, "time") - number(row, "start_time") - 2.0 - elapsed)
        previous_time = ANCHOR_TIME if cycle == 3 else number(fixed[cycle - 1], "time")
        residual("sequential_timeline", cycle, number(row, "start_time") - previous_time)
        net = number(row, "net_work")
        residual("net_work_identity", cycle, net - number(row, "total_work") + number(row, "cut_on") + number(row, "reconnect_on"))
        residual("operation_work_identity", cycle, number(row, "total_work") - number(row, "gross_work") + number(row, "interaction_jump"))
        logical("half_step_positive_decision", cycle, yes(row) == (number(row, "resolution_margin") > TOL and net > TOL))
        residual("solver_energy_balance", cycle, number(row, "balance_residual"))
        observed = next(entry["m20_cumulative_net"] for entry in compared if entry["cycle"] == cycle)
        residual("cumulative_work_from_ledger", cycle, observed - number(row, "cumulative_m20_net"))
    for row in balance:
        for field in ("cycle_residual", "anchor_balance_residual", "pre_first_balance_residual", "pre_cut_balance_residual"):
            residual(field, row["cycle"], row[field])
    expected_extensions = {cycle for cycle, row in fixed.items() if number(row, "elapsed") in {0.0, 8.0}}
    logical("all_boundary_optima_have_separate_extension", "ALL", {int(row["cycle"]) for row in extension} == expected_extensions)
    for row in extension:
        cycle = int(row["cycle"])
        residual("extension_nominal_net_matches_main", cycle, number(row, "nominal_net") - number(fixed[cycle], "net_work"))
        residual("extension_half_step_net", cycle, number(row, "max_dt_half_net_difference"), 1e-10)
        change = number(row, "extended_net") - number(row, "nominal_net") - number(row, "max_dt_half_net_difference")
        logical("extension_resolution_decision", cycle, (row["improved"] == "YES") == (change > TOL))
    half = read_csv(result / "m20_half_step.csv")
    sweep = read_csv(result / "m20_candidates.csv")
    for cycle, row in fixed.items():
        fine = [point for point in half if int(point["cycle"]) == cycle]
        coarse = [point for point in sweep if int(point["cycle"]) == cycle]
        for label, points in (("standard", coarse), ("half", fine)):
            logical(f"candidate_grid_{label}", cycle, len(points) == 401 and all(
                abs(number(point, "elapsed") - index / 50) <= TOL for index, point in enumerate(points)
            ))
        chosen = min(coarse, key=lambda point: (-number(point, "net_work"), number(point, "elapsed")))
        residual("observed_selected_grid_maximum_time", cycle, number(row, "elapsed") - number(chosen, "elapsed"))
        residual("selected_grid_work_vs_direct", cycle, number(row, "net_work") - number(chosen, "net_work"))
        residual("maximum_half_step_net_difference", cycle, max(abs(number(point, "net_work") - number(point, "net_half")) for point in fine), 1e-10)
        residual("maximum_half_step_load_work_difference", cycle, max(abs(
            number(point, "load_ergotropy") - number(point, "load_ergotropy_half")
        ) for point in fine), 1e-10)
    audit_path = result / "m20_independent_audit.csv"
    if audit_path.is_file():
        audit = read_csv(audit_path)
        if audit and "status" in audit[0]:
            failures = sum(row["status"].upper() != "PASS" for row in audit)
            record("independent_state_audit_failures", "ALL", failures, 0, failures == 0)
    return checks


def rebound_section(prior, fixed):
    results = {"M19": rebound(prior), "M20": rebound(fixed)}
    lines = ["## C9 から C10 への反発", ""]
    lines.extend(table(
        ["方式", "C9 net", "C10 net", "差 C10−C9", "C10／C9", "刻み差を控除した差", "判定"],
        ([label, *(fmt(value) for value in values[:3]), f"{values[3]:.6f}", fmt(values[4]),
          "増加" if values[4] > TOL else "有意な増加なし"] if values else [label, "—", "—", "—", "—", "—", "両回の採用なし"]
         for label, values in results.items()),
    ))
    return lines + [
        "", "差の判定では、両回の同時刻の本刻み・半刻み差をそれぞれ絶対値で差し引き、`1e-12` と比較した。"
        "数値分解能で識別できる二回間の増加は、その操作履歴の観測窓における結果。", "",
    ]


def extension_section(rows):
    lines = [
        "## 観測窓の境界を延長した診断", "",
        "正式選択が接続後 `0.00` または `8.00` の端点に来た回では、同じ開始状態・待機・結合で `16.00` まで調べた。"
        "延長点は一度も操作列に採用せず、正式各回の時刻、保存状態、累計は事前の窓で確定した。"
        "延長による増分から区間全体の本刻み・半刻み最大差を引き、それでも `1e-12` を超えるかで改善を判定した。"
        " [延長点](m20_extension.csv) [延長要約](m20_extension_summary.csv)", "",
    ]
    if not rows:
        return lines + ["正式選択の端点該当は0回だった。", ""]
    lines.extend(table(
        ["抽出回", "正式最大の位置", "正式接続後 t", "正式 net", "延長最大 t", "延長 net", "増分", "半刻み最大 t", "半刻み最大差", "改善"],
        ([row["cycle"], row["edge"], t_fmt(number(row, "nominal_peak_elapsed")), fmt(number(row, "nominal_net")),
          t_fmt(number(row, "extended_peak_elapsed")), fmt(number(row, "extended_net")),
          fmt(number(row, "extended_net") - number(row, "nominal_net")),
          t_fmt(number(row, "extended_peak_elapsed_half")), fmt(number(row, "max_dt_half_net_difference")), row["improved"]]
         for row in rows),
    ))
    return lines + ["", "延長診断の最大値は `0.00–16.00` の格子内に限られる。", ""]


def mechanism_section(result, fixed):
    states = read_csv(result / "m20_state_metrics.csv")
    by_phase = {(int(row["cycle"]), row["phase"]): row for row in states}
    anchored = by_phase[2, "anchor"]
    wet = [by_phase[cycle, "wait_end"] for cycle in fixed]
    wait_energy_changes = [
        number(wait, "load_energy") - number(by_phase[cycle - 1, "after"] if cycle > 3 else anchored, "load_energy")
        for wait, cycle in zip(wet, fixed)
    ]
    max_wait_work = max(abs(number(wait, "load_ergotropy")) for wait in wet)
    max_wait_energy_change = max(map(abs, wait_energy_changes))
    candidates = read_csv(result / "m20_candidates.csv")
    grouped = {cycle: [] for cycle in fixed}
    for row in candidates:
        grouped[int(row["cycle"])].append(row)
    energy_without_work = 0
    for sweep in grouped.values():
        sweep.sort(key=lambda row: number(row, "elapsed"))
        energy_without_work += sum(
            number(after, "load_energy") - number(before, "load_energy") > TOL
            and number(after, "load_ergotropy") - number(before, "load_ergotropy") <= TOL
            for before, after in zip(sweep, sweep[1:])
        )
    lines = [
        "## 待機中に変わる量と、再接続後の回収", "",
        f"`g=0` の待機終点で負荷エルゴトロピーの最大絶対値は `{fmt(max_wait_work)}`、"
        f"直前の抽出後からの負荷エネルギー変化の最大絶対値は `{fmt(max_wait_energy_change)}`。"
        "切断中は鎖の散逸が負荷に直接作用せず、相関のある状態から始めても負荷縮約状態は自身のハミルトニアンで自由発展する。"
        "鎖状態と鎖・負荷間の相関はこの間も変化し得る。", "",
        f"再接続後に負荷エネルギーが `1e-12` 超増加し、負荷エルゴトロピーの増加が `1e-12` 以下だった"
        f"隣接区間は延べ {energy_without_work}。負荷エネルギー、電流、抽出可能仕事の履歴はそれぞれ独立に記録した。"
        "再接続後にエルゴトロピーが育つ過程には、結合下での状態の回転と鎖のデフェージングが含まれる。"
        "相互情報量は全相関の診断に用い、相関やその量子成分の寄与を一つずつ分離するには個別の介入が要る。"
        " [全候補](m20_candidates.csv) [状態診断](m20_state_metrics.csv)", "",
        "## 全体系の仕事余力と励起数を保存する操作", "",
        "駆動を切った連続発展では交換型ハミルトニアンと鎖のデフェージングが総励起数を保存する。"
        "鎖のデフェージングはユニタルな混合で、準位間のコヒーレンスや状態の受動性を変え得る。"
        "ユニタルな写像では全状態の固有値分布が混合方向に進み、固定ハミルトニアンに対する受動エネルギーは下がらない。"
        "連続発展中の全エネルギー変化は、符号付きの散逸寄与として評価した。デフェージングを外した比較を行っていないため、"
        "観測した仕事差のうち散逸に起因する割合は未同定。 [Li・Busch](https://arxiv.org/abs/1304.7442)", "",
        "抽出に用いる負荷ユニタリは負荷の励起数演算子と可換である必要がなく、操作時の総励起数も変わり得る。", "",
        "励起数を保存する任意ユニタリで到達できる受動エネルギーは、各励起数セクターの未規格化密度行列の固有値を"
        "そのセクターの低いエネルギーから並べて求めた。励起数を跨ぐコヒーレンスは、同制約の操作後のエネルギー期待値に寄与しない。"
        "制約なしの全体系および鎖エルゴトロピーも同じ保存時点で計算した。"
        "いずれも許された操作集合に応じた状態の診断量で、固定待機と負荷局所抽出で到達できる仕事は本実験の台帳で評価した。"
        " [励起セクター診断](m20_sector_diagnostics.csv) [エルゴトロピーの定義](https://arxiv.org/abs/cond-mat/0401574)"
        " [対称性制約下の仕事抽出](https://arxiv.org/abs/2103.06060)", "",
    ]
    sector_path = result / "m20_sector_diagnostics.csv"
    if not sector_path.is_file():
        return lines
    sector = read_csv(sector_path)
    lines.extend(table(
        ["起源", "回", "状態", "g", "鎖 W 制約なし", "鎖 W 励起保存", "全 W 制約なし", "全 W 励起保存", "総励起数期待値"],
        ([row["source"], row["cycle"], row["phase"], f"{number(row, 'g'):g}", *(fmt(number(row, name)) for name in (
            "chain_unrestricted_ergotropy", "chain_sector_ergotropy", "full_unrestricted_ergotropy", "full_sector_ergotropy",
            "full_excitation_mean",
        ))] for row in sector),
    ))
    by_sector = {(row["source"], int(row["cycle"]), row["phase"]): row for row in sector}
    movement = [abs(number(by_sector["M20", cycle, "after"], "full_excitation_mean") - number(by_sector["M20", cycle, "before"], "full_excitation_mean"))
                for cycle, row in fixed.items() if yes(row)]
    if movement:
        lines += ["", f"M20 の局所操作の前後で総励起数期待値が変わった最大幅は `{fmt(max(movement))}`。"
                  "この操作は励起数を固定する診断上のユニタリ集合とは別の条件で実行した。"]
    upper_key = "any_local_unitary_full_work_upper_bound"
    if sector and upper_key in sector[0]:
        latest = max((cycle for cycle in fixed if yes(fixed[cycle])), default=2)
        start_state = by_sector["M18", 2, "anchor"]
        final_state = by_sector["M20", latest, "after"] if latest > 2 else start_state
        prior_final = by_sector["M19", 10, "after"]
        lines += [
            "", f"全体系の励起保存ベンチマークは、全体系の制約なしエルゴトロピーに対して起点で"
            f" `{percent(number(start_state, 'full_sector_ergotropy') / number(start_state, 'full_unrestricted_ergotropy'))}`、"
            f"M19 最終で `{percent(number(prior_final, 'full_sector_ergotropy') / number(prior_final, 'full_unrestricted_ergotropy'))}`、"
            f"M20 最終で `{percent(number(final_state, 'full_sector_ergotropy') / number(final_state, 'full_unrestricted_ergotropy'))}`。",
        ]
        if "full_excitation_probability_0" in prior_final:
            lines += [
                f"M19 最終状態では総励起数0の確率が `{number(prior_final, 'full_excitation_probability_0'):.9f}`。"
                "励起数0のセクターにある唯一の状態はエネルギー0の真空。`g=0.25` の全ハミルトニアンの最低準位は"
                "総励起数2にあり、エネルギーは `−1.268886445`。励起保存操作は真空セクターの重みを保ち、"
                "制約なしの受動配置は固有値をセクターを跨いで低いエネルギーへ割り当てられる。",
            ]
        lines += [
            "", f"固定した `g` で任意の負荷局所ユニタリが取り出せる全体系仕事の上界は、起点で"
            f" `{fmt(number(start_state, upper_key))}`、M19 最終で `{fmt(number(prior_final, upper_key))}`、"
            f"M20 最終で `{fmt(number(final_state, upper_key))}`。"
            "この上界は局所操作で不変な末端交換の非対角ブロックのトレースノルムを用いた。"
            "到達を保証する量や、待機・再接続を含む操作列の上界は別問題。 [励起セクター診断](m20_sector_diagnostics.csv)",
        ]
    dephasing = result / "m20_dephasing_accounting.csv"
    if dephasing.is_file():
        segments = [row for row in read_csv(dephasing) if yes(fixed[int(row["cycle"])])]
        lines += [
            "", "固定ハミルトニアンでの受動エネルギー差を、切断待機は `g=0`、接続は `g=0.25` の同じ結合に"
            "両端を揃えて計算した。表は採用済みの連続発展の和。受動エネルギー増分は状態の混合、"
            "符号付きの散逸積分は環境との全エネルギー交換をそれぞれ測る。固定した `H` では"
            " `ΔW = Q − ΔE_passive`。 [連続発展の会計](m20_dephasing_accounting.csv)", "",
        ]
        lines.extend(table(
            ["区間", "散逸 Q の和", "Δ受動 E の和", "Δ全体系 W の和"],
            ([label, *(fmt(sum(number(row, field) for row in segments if row["segment"] == kind)) for field in (
                "dissipator_integral", "delta_passive_energy", "delta_ergotropy",
            ))] for label, kind in (("切断待機", "disconnected_wait"), ("再接続中", "reconnected_evolution"))),
        ))
    return lines + [""]


def report(prior, fixed, compared, balance, extension, checks, result, m19, benchmark):
    final = compared[-1]
    old_work = final["m19_cumulative_net"]
    new_work = final["m20_cumulative_net"]
    old_rate = final["m19_cumulative_net_per_time"]
    new_rate = final["m20_cumulative_net_per_time"]
    old_accepted = sum(yes(row) for row in prior.values())
    new_accepted = sum(yes(row) for row in fixed.values())
    match_time = min(final["m19_cumulative_elapsed"], final["m20_cumulative_elapsed"])
    old_matched_count, old_matched, old_matched_rate = completed_by_time(prior, match_time)
    new_matched_count, new_matched, new_matched_rate = completed_by_time(fixed, match_time)
    work_gain = (new_work - old_work) / old_work if old_work else None
    rate_gain = (new_rate - old_rate) / old_rate if old_rate and new_rate is not None else None
    lines = [
        "# Milestone 20 毎回2.00待つ固定方策と M19 の逐次選択", "",
        f"**固定待機 M20 は {new_accepted} 回採用。** M18 の第2回抽出直後からの追加正味仕事は"
        f" M20 `{fmt(new_work)}`、M19 `{fmt(old_work)}`。M19 に対する M20 の増減は `{percent(work_gain)}`。"
        f" 待機を含めたモデル時間1単位当たりの累計正味仕事は M20 `{fmt(new_rate)}`、M19 `{fmt(old_rate)}`"
        f"（増減 `{percent(rate_gain)}`）。仕事量と経過時間の両方で比べたで。", "",
        f"所要時間は M20 `{t_fmt(final['m20_cumulative_elapsed'])}`、M19 `{t_fmt(final['m19_cumulative_elapsed'])}`。"
        f" M19 の採用回数は {old_accepted} 回。時間は `t=15.90` から最後に採用した抽出までのモデル時間。", "",
        "## 共通の起点と操作", "",
        "両方式とも M18 R4 の `t=15.90`、`g=0.25` における第2回抽出直後の全体系を引き継いだ。"
        f" 384×384 状態の SHA-256 は `{SOURCE_SHA256}`。"
        "M20 は毎回、完全切断の `g=0` で `2.00` 待機し、`g=0.25` に再接続する。"
        "M19 は同じ開始状態から始め、各回の局所履歴に対して待機2通りと結合3通りを比較した。"
        "両方とも外部駆動やリセットを加えず、抽出後の全状態を次の回へ渡した。 [事前登録](PRECOMMIT_M20.md)", "",
        "M20 の抽出時刻は接続後 `0.00–8.00` の `0.02` 刻みで正味仕事が最大となる保存点を選んだ。"
        "正味は、全ハミルトニアンでの抽出仕事から切断と再接続の符号付き入力仕事を引いた値。"
        "本刻み `dt=0.0025` と半刻み `0.00125` の同時刻差を引いた値と、全エネルギー差の正味が"
        "ともに `1e-12` を超えた回を採用した。上限は第10回。 [逐次台帳](m20_cycle_ledger.csv) [半刻み](m20_half_step.csv)", "",
        "## 各回の比較", "",
        "表には採用済みの仕事を載せた。時間当たりは、その回の正味仕事を直前の抽出からの経過時間で割った値。"
        "累計は第3回以降の実行済み抽出のみを足した。 [全比較項目](m20_m19_comparison.csv)", "",
    ]
    lines.extend(table(
        ["抽出回", "M19 t", "M20 t", "M19 net", "M20 net", "差 M20−M19", "M19 net／時間", "M20 net／時間", "M19 累計", "M20 累計"],
        ([row["cycle"], t_fmt(row["m19_time"] if row["m19_accepted"] else None), t_fmt(row["m20_time"] if row["m20_accepted"] else None),
          *(fmt(row[key]) for key in ("m19_accepted_net_work", "m20_accepted_net_work", "delta_accepted_net_work",
                                     "m19_cycle_net_per_time", "m20_cycle_net_per_time", "m19_cumulative_net", "m20_cumulative_net"))]
         for row in compared),
    ))
    lines += [
        "", f"共通の経過時間 `{t_fmt(match_time)}` までに実行済みの仕事は、M19 の {old_matched_count} 回で"
        f" `{fmt(old_matched)}`（時間当たり `{fmt(old_matched_rate)}`）、M20 の {new_matched_count} 回で"
        f" `{fmt(new_matched)}`（時間当たり `{fmt(new_matched_rate)}`）。物理時刻で比較し、次の抽出の予定値は加えていない。", "",
    ]
    old_c3, new_c3 = prior[3], fixed[3]
    old_saved = m19 / old_c3["after_state"] if old_c3["after_state"] else None
    new_saved = result / new_c3["after_state"] if new_c3["after_state"] else None
    identity = ""
    if old_saved and new_saved and old_saved.is_file() and new_saved.is_file():
        with old_saved.open("rb") as old_stream, new_saved.open("rb") as new_stream:
            matched = hashlib.file_digest(old_stream, "sha256").digest() == hashlib.file_digest(new_stream, "sha256").digest()
        identity = " 抽出後の全体系バイナリは SHA-256 まで一致した。" if matched else " 抽出後バイナリは SHA-256 に差があり、数値照合は監査表に記録した。"
    lines += [f"C3 は M19 でも待機2・`g=0.25` が選ばれた共通区間で、正味差は"
              f" `{fmt(number(new_c3, 'net_work') - number(old_c3, 'net_work'))}`。" + identity, ""]
    if 4 in fixed:
        previous = prior[4]
        current = fixed[4]
        lines += [
            f"C4 は同じ C3 抽出後状態を引き継いだ比較。M19 の待機 `{t_fmt(number(previous, 'wait'))}` での採用 net は"
            f" `{fmt(number(previous, 'net_work'))}`、M20 の待機 `2.00` は `{fmt(number(current, 'net_work'))}`。"
            "C5 以降の差には、それ以前に選んだ抽出時刻と操作の履歴も含まれる。", "",
        ]
    taken = [number(row, "net_work") for row in fixed.values() if yes(row)]
    if len(taken) > 1:
        changes = [right - left for left, right in zip(taken, taken[1:])]
        lines += [
            f"M20 の採用済み正味仕事は前回比で増加 {sum(change > TOL for change in changes)} 回、"
            f"減少 {sum(change < -TOL for change in changes)} 回、許容差内の同値 {sum(abs(change) <= TOL for change in changes)} 回。", "",
        ]
    if not yes(fixed[max(fixed)]):
        stopped = fixed[max(fixed)]
        lines += [f"C{stopped['cycle']} で採用判定を満たさず停止した。最良候補の直接正味は"
                  f" `{fmt(number(stopped, 'net_work'))}`、半刻み差を引いた値は `{fmt(number(stopped, 'resolution_margin'))}`。", ""]
    lines.extend(rebound_section(prior, fixed))
    lines.extend(extension_section(extension))
    lines.extend(mechanism_section(result, fixed))
    lines += [
        "## エネルギー収支と監査", "",
        "局所 gross、相互作用エネルギーのジャンプ、全操作仕事、切断・再接続の仕事を分けた。"
        "待機と接続の散逸エネルギーは実測の符号で加え、M18 起点および M17 前史を含む収支も評価した。"
        " [エネルギー会計](m20_energy_balance.csv)", "",
    ]
    lines.extend(table(
        ["抽出回", "gross", "全操作仕事", "切断 系へ", "再接続 系へ", "散逸 待機", "散逸 接続", "残存全 E", "M18 起点の収支残差"],
        ([row["cycle"], *(fmt(row[key]) for key in ("gross_work", "total_work", "cut_on", "reconnect_on", "dissipative_wait",
                                                  "dissipative_connected", "post_total_energy", "anchor_balance_residual"))] for row in balance),
    ))
    failures = [check for check in checks if check["status"] != "PASS"]
    lines += [
        "", f"初回からの理想正味仕事は M20 を通して `{fmt(balance[-1]['net_cumulative_from_first'])}`、"
        f"M17 保存前の切断まで数えると `{fmt(balance[-1]['net_cumulative_including_m17_cut'])}`。"
        f"集計監査は **{len(checks) - len(failures)}/{len(checks)} 合格**。"
        " [集計監査](m20_numerical_checks.csv) [独立監査](m20_independent_audit.csv) [状態マニフェスト](m20_state_manifest.csv)", "",
    ]
    if failures:
        lines += ["要確認項目は " + "、".join(f"{check['scope']} {check['check']}" for check in failures) + "。", ""]
    control_path = result / "m20_control.csv"
    if control_path.is_file():
        control = read_csv(control_path)
        leading = max(abs(number(row, "load_ergotropy")) for row in control)
        free = max(abs(number(row, "free_error")) for row in control)
        lines += [f"同じ絶対時刻の完全切断対照では、負荷エルゴトロピーの最大絶対値は `{fmt(leading)}`、"
                  f"解析的自由発展との負荷状態最大差は `{fmt(free)}`。 [切断対照](m20_control.csv)", ""]
    timing_paths = [result / "m20_runtime.csv"]
    if benchmark is not None:
        timing_paths.insert(0, benchmark / "m20_runtime.csv")
    timings = [row for path in timing_paths if path.is_file() for row in read_csv(path)]
    if timings:
        modes = sorted({row["mode"] for row in timings})
        measured = [f"{mode} `{sum(number(row, 'wall_seconds') for row in timings if row['mode'] == mode):.2f}` 秒" for mode in modes]
        lines += ["実装の測定時間は " + "、".join(measured) + "（各回の計測合計）。 [実行時間台帳](m20_runtime.csv)", ""]
    if benchmark is not None and (benchmark / "m20_batch_runtime.csv").is_file():
        bench, = read_csv(benchmark / "m20_batch_runtime.csv")
        lines += [f"短縮ベンチのバッチ実測は `{number(bench, 'elapsed_seconds'):.2f}` 秒。"
                  "正式実行前に約10分に加え、端点の延長一件ごとに1分弱を見込んだ。"
                  " [ベンチ台帳](m20_benchmark_runtime.csv)", ""]
    if (result / "m20_batch_runtime.csv").is_file():
        formal, = read_csv(result / "m20_batch_runtime.csv")
        lines += [f"正式バッチの実測は `{number(formal, 'elapsed_seconds'):.2f}` 秒。"
                  " [正式バッチ台帳](m20_batch_runtime.csv)", ""]
    figures = sorted((result / "figures").glob("*.png")) + sorted(result.glob("m20_*.png"))
    if figures:
        lines += ["## 図", "", *(f"- [{figure.stem}]({figure.relative_to(result).as_posix()})" for figure in figures), ""]
    lines += [
        "## 再現用ファイル", "",
        "同梱の Windows 実行ファイルを `py -3.14 -B run_m20.py formal ./m20_fixed_wait.exe rerun` で再実行できる。"
        "出力先には新しいフォルダ名を指定する。ランチャーは同梱の起点とM19参照を実行前後に照合する。"
        " [固定 SHA-256](m20_precommit_sha256.csv)", "",
    ]
    lines += ["結論の範囲は共通の保存状態と事前に設定した有限の時間窓を使った2方策。", ""]
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path, help="formal M20 results directory")
    parser.add_argument("m18", type=Path, help="published M18 results directory")
    parser.add_argument("m19", type=Path, help="published M19 results directory")
    parser.add_argument("--benchmark", type=Path, help="M20 benchmark results directory")
    phase = parser.add_mutually_exclusive_group()
    phase.add_argument("--tables-only", action="store_true", help="write M19 comparison and M20 energy ledger")
    phase.add_argument("--report-only", action="store_true", help="write report and audit after generating tables and figures")
    args = parser.parse_args()
    result = args.results
    prior = index_cycles(read_csv(args.m19 / "m19_cycle_ledger.csv"))
    fixed = index_cycles(read_csv(result / "m20_cycle_ledger.csv"))
    history = historical_inputs(args.m18)
    compared = comparison(prior, fixed)
    balance = energy_balance(fixed, history)
    tables = {"m20_m19_comparison.csv": compared, "m20_energy_balance.csv": balance}
    if args.report_only and not all((result / name).is_file() for name in tables):
        raise FileNotFoundError("Use --tables-only before --report-only")
    checks = []
    outputs = {} if args.report_only else dict(tables)
    if not args.tables_only:
        extension = read_csv(result / "m20_extension_summary.csv")
        checks = numerical_checks(prior, fixed, compared, balance, extension, result, args.m19)
        outputs["m20_numerical_checks.csv"] = checks
        outputs["MILESTONE_20_FIXED_WAIT_RECOVERY_REPORT.md"] = report(
            prior, fixed, compared, balance, extension, checks, result, args.m19, args.benchmark,
        )
    if any((result / name).exists() for name in outputs):
        raise FileExistsError("An M20 synthesis output already exists")
    for name, content in outputs.items():
        path = result / name
        if isinstance(content, str):
            with path.open("x", newline="\n", encoding="utf-8") as stream:
                stream.write(content)
        else:
            write_csv(path, content)
    failures = [entry for entry in checks if entry["status"] != "PASS"]
    print(f"M20 synthesis: {len(compared)} comparison rows, {len(balance)} energy rows")
    if checks:
        print(f"M20 numerical checks: {len(checks) - len(failures)}/{len(checks)} pass")
    if failures:
        for failure in failures:
            print(f"FAIL {failure['scope']} {failure['check']}: {failure['observed']} (bound {failure['bound']})")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
