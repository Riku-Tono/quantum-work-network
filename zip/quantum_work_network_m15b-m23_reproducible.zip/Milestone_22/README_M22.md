# M22 再現手順

結果にはM18起点、M21正式比較CSVと単回診断の代表状態、事前登録、Rustソルバー、Python集計と監査、正式および短縮ベンチのCSV・全状態、比較図を収録した。 [M22実験報告書](MILESTONE_22_CONTINUOUS_CONNECTION_REPORT.md) [事前登録](PRECOMMIT_M22.md) [登録ハッシュ](m22_precommit_sha256.csv)

## 再監査

Windows PowerShellで、このフォルダーをカレントディレクトリにする。配布バイナリとソースはWindows x86_64、Pythonは3.14で実行した。

    py -3.14 -m pip install -r requirements.txt
    $env:OPENBLAS_NUM_THREADS = '1'
    py -3.14 -B verify_m22.py . --read-only
    py -3.14 -B verify_m22.py benchmark --benchmark --window 0.50 --single-window 2.50 --read-only

M21の参照CSVは正式ZIPから同じバイト列を抽出した。M18とM21の元ZIPおよび展開済みの正規フォルダーからの再照合には、未準備の作業コピーで次のコマンドを使う。 [照合記録](m22_source_verification.csv) [単回起点リスト](single_inputs.csv)

    py -3.14 -B prepare_m22_reference.py --m18 ../Milestone_18 --m21 ../Milestone_21

## 短縮ベンチマークと正式再計算

    py -3.14 -B run_m22.py benchmark m22_connected.exe redo_benchmark --jobs 2
    py -3.14 -B run_m22.py formal m22_connected.exe redo_formal --jobs 2
    py -3.14 -B package_m22.py benchmark redo_benchmark --destination redo_benchmark_results
    py -3.14 -B package_m22.py formal redo_formal --destination redo_results
    Copy-Item -LiteralPath m18_inputs,reference,single_inputs.csv -Destination redo_results -Recurse
    py -3.14 -B m22_observables.py redo_results
    py -3.14 -B m22_observables.py redo_results/single --input-root redo_results
    py -3.14 -B verify_m22.py redo_results
    py -3.14 -B summarize_m22.py redo_results
    py -3.14 -B m22_diagnostics.py redo_results
    py -3.14 -B plot_m22.py --data redo_results

短縮ベンチ結果を再監査するには、redo_benchmark_results の主フォルダーと single に対して同様に観測量を生成し、再監査の短縮指定を適用する。

Rustの安定版があればソースから次のコマンドでコンパイルできる。再ビルドした実行ファイルを使う場合は、そのパスと --allow-rebuilt を run_m22.py に渡す。入力とソースの登録ハッシュ照合は維持される。

    $env:RUSTFLAGS = '-C target-cpu=native'
    cargo build --release --locked --manifest-path solver/Cargo.toml --target-dir redo_build --bin m22_connected

## 比較の読み方

[m22_ordinal_comparison.csv](m22_ordinal_comparison.csv) は採択順、[m22_common_time.csv](m22_common_time.csv) は9枝の共通時刻の階段、[m22_pair_horizons.csv](m22_pair_horizons.csv) は各γの独立2枝での共通採択数と共通時間を記録する。[m22_matched_comparison.csv](m22_matched_comparison.csv) はM21正式時刻で照合した採否と仕事の分解。各枝の観測期間全体の実行済み階段は [m22_event_timeline.csv](m22_event_timeline.csv)。単回の主比較時刻と使用した保存状態は [single_inputs.csv](single_inputs.csv) にある。

## 時刻と符号

主台帳の elapsed は今回の試行開始からの経過。独立枝では直前の実抽出直後が開始点。同一時刻枝では直前の予定時刻が開始点で、見送りの有無によって直前の実抽出時刻と異なる。単回台帳の elapsed は保存状態からの総経過で、待機ありの候補は母集団をそろえる2.00〜18.00。絶対モデル時刻は time。window_end は未介入で窓終端まで進めた診断状態。accepted=false の抽出仕事は仮想値で、実行済み累積に加わらない。

切断と再接続の仕事は系への入力正。局所抽出は全ハミルトニアンの減少を出力正とし、相互作用項の変化を含む。電流は第7サイトから負荷への流入が正。相互情報量の単位はナット。保存状態形式 QWNRHO1 は8バイトの識別子、little endianの64ビット次元、64ビット時刻、行優先の複素128ビット行列で構成される。
