"""Stage the M22 outputs and build a checked ZIP archive."""
import argparse
from pathlib import Path
import zipfile

from run_m22 import ROOT, CSVS, digest, link, read, write

RUNTIME_TABLES = ("m22_stage_runtime.csv", "m22_batch_runtime.csv")


def place(source, destination):
    if (destination / "states").exists():
        raise FileExistsError(destination / "states")
    destination.mkdir(exist_ok=True)
    (destination / "states").mkdir()
    for path in sorted((source / "states").glob("*.bin")):
        link(path, destination / "states" / path.name)
    for name in CSVS:
        link(source / name, destination / name)


def copy_tree(source, destination):
    for path in source.rglob("*"):
        if path.is_file():
            target = destination / path.relative_to(source)
            target.parent.mkdir(parents=True, exist_ok=True)
            link(path, target)


def prepare_benchmark(source, destination):
    place(source / "merged", destination)
    place(source / "single_merged", destination / "single")
    for name in (*RUNTIME_TABLES, "m22_runtime_estimate.csv"):
        link(source / name, destination / name)
    for name in ("m18_inputs", "reference"):
        copy_tree(ROOT / name, destination / name)
    anchor, = (row for row in read(ROOT / "single_inputs.csv") if (row["rate"], row["source"]) == ("A", "anchor"))
    anchor["selected_elapsed"] = "2.50"
    write(destination / "single_inputs.csv", tuple(anchor), [anchor.values()])


def collect(source, destination):
    place(source / "merged", destination)
    place(source / "single_merged", destination / "single")
    for name in RUNTIME_TABLES:
        link(source / name, destination / name)
    copy_tree(source / "schedules", destination / "schedules")


def package(root):
    required = (
        "MILESTONE_22_CONTINUOUS_CONNECTION_REPORT.md", "PRECOMMIT_M22.md", "README_M22.md",
        "m22_comparison.csv", "m22_common_time.csv", "m22_event_timeline.csv", "m22_pair_horizons.csv", "m22_matched_comparison.csv", "m22_single_comparison.csv",
        "m22_energy_balance.csv", "m22_independent_audit.csv", "m22_state_manifest.csv",
        "m22_gamma0_conservation.csv", "m22_phase_comparison.csv", "benchmark/m22_independent_audit.csv",
        "benchmark/m22_runtime_estimate.csv", "single/m22_state_metrics.csv",
    )
    for name in required:
        if not (root / name).is_file() or not (root / name).stat().st_size:
            raise FileNotFoundError(root / name)
    if len(list((root / "figures").glob("*.png"))) != 8:
        raise ValueError("Expected eight verified plots")
    if any(row["status"] != "PASS" for row in read(root / "m22_independent_audit.csv")):
        raise ValueError("Formal independent audit has a failed test")
    archive = root / "M22_all_results.zip"
    tmp = root / "M22_all_results.zip.incomplete"
    if archive.exists() or tmp.exists():
        raise FileExistsError(archive)
    exclude = {"__pycache__", "target", ".git"}
    members = {f"Milestone_22/{p.relative_to(root).as_posix()}": p for p in sorted(root.rglob("*"))
               if p.is_file() and exclude.isdisjoint(p.relative_to(root).parts)
               and p.suffix not in {".zip", ".incomplete", ".sha256", ".pyc"}}
    with zipfile.ZipFile(tmp, "x", zipfile.ZIP_DEFLATED, compresslevel=3) as out:
        for name, path in members.items():
            out.write(path, name)
    with zipfile.ZipFile(tmp) as out:
        if set(out.namelist()) != set(members) or out.testzip() is not None:
            raise ValueError("ZIP inventory or CRC check failed")
    tmp.rename(archive)
    actual = digest(archive).lower()
    (root / "M22_all_results.sha256").write_text(f"{actual}  {archive.name}\n", encoding="ascii")
    print(f"M22 ZIP: {len(members)} files, {archive.stat().st_size:,} bytes, SHA-256 {actual}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("step", choices=("benchmark", "formal", "package"))
    parser.add_argument("source", type=Path, nargs="?")
    parser.add_argument("--destination", type=Path)
    args = parser.parse_args()
    if args.step == "package":
        package(args.destination or ROOT)
    elif args.source is None:
        parser.error("source is required")
    elif args.step == "benchmark":
        prepare_benchmark(args.source, args.destination or ROOT / "benchmark")
    else:
        collect(args.source, args.destination or ROOT)
