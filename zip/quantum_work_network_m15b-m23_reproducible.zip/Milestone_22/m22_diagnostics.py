"""Create M22 energy, conservation, phase, and transport diagnostics."""
import argparse
from collections import defaultdict
from itertools import pairwise
from pathlib import Path

import numpy as np

from m21_observables import CHAIN_DIM, LOAD_DIM, Observables, read_state
from run_m22 import read, write

TOL = 1e-12


def emit(path, records):
    fields = list(records[0])
    write(path, fields, ([row[field] for field in fields] for row in records))


def energy(root, audit):
    report = []
    for name, directory in (("repeated", root), ("single", root / "single")):
        states = {(r["protocol"], r["cycle"], r["phase"]): float(r["global_energy"])
                  for r in read(directory / "m22_state_metrics.csv")}
        for r in read(directory / "m22_cycle_ledger.csv"):
            p, c = r["protocol"], r["cycle"]
            accepted = r["accepted"] == "true"
            f = lambda field: float(r[field])
            initial = states[p, c, "start"]
            cut = states.get((p, c, "cut_after"), initial)
            wait = states.get((p, c, "wait_end"), cut)
            reconnected = states.get((p, c, "reconnect_after"), wait)
            pre = states[p, c, "before"]
            post_actual = states.get((p, c, "after"), pre)
            fields = {
                "scope": name, "protocol": p, "gamma": r["gamma"], "cycle": c,
                "accepted": r["accepted"], "outcome": r["stop_reason"],
                "E_start": initial, "W_cut_on": f("cut_on"), "E_after_cut": cut,
                "Q_wait": f("dissipative_wait"), "E_wait_end": wait,
                "W_reconnect_on": f("reconnect_on"), "E_after_reconnect": reconnected,
                "Q_connected": f("dissipative_connected"), "E_before": pre,
                "W_gross": f("gross_work"), "interaction_energy_jump": f("interaction_jump"),
                "W_total_virtual_or_adopted": f("total_work"), "W_net_virtual_or_adopted": f("net_work"),
                "E_after_virtual_or_adopted": f("post_total_energy"), "E_after_actual": post_actual,
                "credited_W_net": f("net_work") if accepted else 0.0,
                "credited_cumulative_work": f("cumulative_m22_net"),
                "credited_cumulative_dephasing_energy": f("cumulative_dephasing_energy"),
                "residual_cut": cut - initial - f("cut_on"),
                "residual_wait": wait - cut - f("dissipative_wait"),
                "residual_reconnect": reconnected - wait - f("reconnect_on"),
                "residual_connected": pre - reconnected - f("dissipative_connected"),
                "residual_candidate_extraction": f("post_total_energy") - pre + f("total_work"),
                "residual_candidate_cycle": f("balance_residual"),
                "residual_actual_cycle": (post_actual - initial - f("dissipative_wait")
                                          - f("dissipative_connected")
                                          + (f("net_work") if accepted else -f("cut_on") - f("reconnect_on"))),
                "residual_cumulative": f("cumulative_balance_residual"),
            }
            for field, value in fields.items():
                if field.startswith("residual_") and abs(value) > TOL:
                    raise ValueError(f"Energy account {name}/{p}/{c}/{field} {value}")
            report.append(fields)
    emit(root / "m22_energy_balance.csv", report)
    conserved = [r for r in audit if r["protocol"].startswith("C_")
                 and (r["check"].startswith("gamma0_") or r["check"] in
                      {"sector_probability_drift", "total_excitation_drift", "full_spectrum_drift"})]
    emit(root / "m22_gamma0_conservation.csv", conserved)


def phase(root, output=None):
    directory = root / "single"
    ledger = {r["protocol"]: r for r in read(directory / "m22_cycle_ledger.csv")}
    candidates = defaultdict(list)
    for row in read(directory / "m22_candidates.csv"):
        candidates[row["protocol"]].append(row)
    obs = Observables()
    h0, _, _ = obs.hamiltonian(0)
    h1, _, _ = obs.hamiltonian(0.25)
    commutator_max = float(np.max(np.abs(h0 @ h1 - h1 @ h0)))
    exchange_direction = np.tril(obs.exchange_h, -1)
    eigensystems = {g: np.linalg.eigh(h) for g, h in ((0.0, h0), (0.25, h1))}
    registry = {r["source"]: r for r in read(root / "single_inputs.csv") if r["rate"] == "C"}
    result = []

    def evolve(density, g, length):
        energies, basis = eigensystems[g]
        operator = (basis * np.exp(-1j * energies * length)) @ basis.conj().T
        return operator @ density @ operator.conj().T

    def load_matrix(matrix):
        return np.trace(matrix.reshape(CHAIN_DIM, LOAD_DIM, CHAIN_DIM, LOAD_DIM), axis1=0, axis2=2)

    for case in ("anchor", "mid", "end"):
        wc = ledger[f"C_{case}_wait"]
        cc = ledger[f"C_{case}_connected"]
        t = float(wc["time"])
        assert cc["time"] == wc["time"]
        rho_w = read_state(directory / wc["before_state"], t)
        rho_c = read_state(directory / cc["before_state"], t)
        delta = rho_w - rho_c
        load_w, load_c = load_matrix(rho_w), load_matrix(rho_c)
        coherence_w, coherence_c = load_w[0, 1], load_c[0, 1]
        trajectory = {}
        for name, p in (("wait", wc["protocol"]), ("connected", cc["protocol"])):
            grid = [r for r in candidates[p] if float(r["elapsed"]) >= 2]
            j = [float(r["load_current"]) for r in grid]
            signs = [1 if x > 0 else -1 for x in j if abs(x) > TOL]
            trajectory[f"current_min_{name}"] = min(j)
            trajectory[f"current_max_{name}"] = max(j)
            trajectory[f"current_sign_reversals_{name}"] = sum(a != b for a, b in pairwise(signs))
            ens = [float(r["load_ergotropy"]) for r in grid]
            trajectory[f"load_ergotropy_interior_peaks_{name}"] = sum(
                ens[i] > ens[i-1] and ens[i] >= ens[i+1] and ens[i] > TOL
                for i in range(1, len(ens)-1))
        # Find a descriptive phase comparison inside the common candidate window.
        # Maximize the smaller current magnitude among points with opposite signs.
        connected_by_time = {r["elapsed"]: r for r in candidates[cc["protocol"]]}
        opposite = []
        for waiting in candidates[wc["protocol"]]:
            elapsed = waiting["elapsed"]
            connected = connected_by_time[elapsed]
            jw, jc = (float(row["load_current"]) for row in (waiting, connected))
            if jw * jc < 0 and min(abs(jw), abs(jc)) > TOL:
                opposite.append((min(abs(jw), abs(jc)), float(elapsed), jw, jc))
        _, elapsed, jw, jc = max(opposite)
        registered = registry[case]
        initial = read_state(root / registered["source_filename"], float(registered["source_time"]))
        rewound_wait = evolve(evolve(initial, 0.0, 2.0), 0.25, elapsed - 2.0)
        whole_connected = evolve(initial, 0.25, elapsed)
        zw, zc = (np.einsum("ij,ji->", rho, exchange_direction) for rho in (rewound_wait, whole_connected))
        if max(abs(jw + 0.5 * zw.imag), abs(jc + 0.5 * zc.imag)) > 1e-10:
            raise ValueError(f"Independent exchange phase current mismatch for {case}")
        trajectory.update({
            "opposite_current_common_samples": len(opposite),
            "exchange_phase_example_elapsed": elapsed,
            "exchange_phase_example_j_wait": jw,
            "exchange_phase_example_j_connected": jc,
            "exchange_coherence_wait_real": zw.real, "exchange_coherence_wait_imag": zw.imag,
            "exchange_coherence_connected_real": zc.real, "exchange_coherence_connected_imag": zc.imag,
            "exchange_coherence_phase_wait_minus_connected_rad": float(np.angle(zw * zc.conjugate())),
        })
        outside_diagonal = load_w - load_c
        np.fill_diagonal(outside_diagonal, 0)
        phase_delta = (float(np.angle(coherence_w * coherence_c.conjugate()))
                       if min(abs(coherence_w), abs(coherence_c)) > TOL else "")
        result.append({
            "source": case, "source_time": wc["start_time"], "comparison_time": wc["time"], "elapsed": wc["elapsed"],
            "Hamiltonian_commutator_max_abs_entry": commutator_max,
            "full_state_frobenius_difference": float(np.linalg.norm(delta)),
            "full_state_trace_distance": float(np.abs(np.linalg.eigvalsh((delta + delta.conj().T) / 2)).sum() / 2),
            "load_population_max_difference": float(np.max(np.abs(np.diag(load_w) - np.diag(load_c)))),
            "load_offdiagonal_frobenius_difference": float(np.linalg.norm(outside_diagonal)),
            "bare_load_coherence01_wait_abs": abs(coherence_w),
            "bare_load_coherence01_connected_abs": abs(coherence_c),
            "bare_load_coherence01_phase_wait_minus_connected_rad": phase_delta,
            "load_current_wait": wc["selected_load_current"], "load_current_connected": cc["selected_load_current"],
            "net_work_wait": wc["net_work"], "net_work_connected": cc["net_work"],
            **trajectory,
        })
    emit(output or root / "m22_phase_comparison.csv", result)


def transport(root):
    output = []
    for scope, directory, prefix in (
        ("repeated", root, "m22"), ("single", root / "single", "m22"), ("M21_reference", root / "reference/m21", "m21"),
    ):
        grids = defaultdict(list)
        for row in read(directory / f"{prefix}_candidates.csv"):
            if scope != "M21_reference" or row["protocol"].endswith("_opt"):
                grids[row["protocol"], row["cycle"]].append(row)
        half = {(r["protocol"], r["cycle"], r["elapsed"]): r for r in read(directory / f"{prefix}_half_step.csv")}
        for (p, cycle), rows in grids.items():
            examples = []
            for left, right in pairwise(rows):
                one, two = (half[p, cycle, point["elapsed"]] for point in (left, right))
                e1, e2 = (float(point["load_ergotropy"]) for point in (left, right))
                error_ergotropy = abs(e1 - float(one["load_ergotropy_half"])) + abs(e2 - float(two["load_ergotropy_half"]))
                flow = float(right["integrated_load_current"]) - float(left["integrated_load_current"])
                flow_error = (abs(float(one.get("integrated_current_difference", 0)))
                              + abs(float(two.get("integrated_current_difference", 0))))
                if flow > TOL + flow_error and e1 - e2 > TOL + error_ergotropy:
                    examples.append((flow, e2 - e1, left["time"], right["time"],
                                     float(right["net_work"]) - float(left["net_work"])))
            strongest = max(examples, default=("", "", "", "", ""))
            output.append({
                "scope": scope, "protocol": p, "cycle": cycle, "candidate_intervals": len(rows)-1,
                "resolved_inflow_increase_with_ergotropy_decrease_intervals": len(examples),
                "max_inflow_example": strongest[0], "load_ergotropy_delta": strongest[1],
                "absolute_time_before": strongest[2], "absolute_time_after": strongest[3],
                "candidate_net_work_delta": strongest[4],
            })
    emit(root / "m22_transport_decoupling.csv", output)



def event_timeline(root):
    """Right-continuous staircases on the full observed clock of each series."""
    by_series = defaultdict(list)
    for row in read(root / "m22_comparison.csv"):
        by_series[row["series"]].append(row)
    records = []
    for series, history in by_series.items():
        initial = float(history[0]["start_time"])
        parts = [(initial, "", "anchor", 0, 0.0)]
        parts.extend((float(r["time"]), r["cycle"], "adoption" if r["accepted"] == "True" else "skip",
                      int(r["adopted_count_to_date"]), float(r["cumulative_net_work"])) for r in history)
        for i, (t, cycle, event, count, work) in enumerate(parts):
            records.append({
                "series": series, "time_absolute": t, "time_since_anchor": round(t - initial, 2), "cycle": cycle,
                "event": event, "adopted_count": count, "cumulative_net_work_after_event": work,
                "next_event_time_absolute": parts[i + 1][0] if i + 1 < len(parts) else "",
            })
    emit(root / "m22_event_timeline.csv", records)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path)
    root = parser.parse_args().results
    energy(root, read(root / "m22_independent_audit.csv"))
    phase(root)
    transport(root)
    event_timeline(root)
    print("M22 energy, conservation, phase, and transport diagnostics are ready.")
