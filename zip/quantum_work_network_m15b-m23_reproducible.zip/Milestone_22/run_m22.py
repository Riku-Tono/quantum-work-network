"""Run the registered M22 benchmark and experiments, then merge branch outputs."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import csv
import hashlib
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
ANCHOR = "m18_inputs/R4_observed_max_t1590_after.bin"
RATES = ("A", "B", "C")
OPTIONS = tuple(f"{rate}_opt" for rate in RATES)
MATCHED = tuple(f"{rate}_matched" for rate in RATES)
CSVS = tuple(f"m22_{stem}.csv" for stem in ("candidates", "cycle_ledger", "state_basic", "state_half",
                                           "half_step", "runtime", "model_checks"))


def read(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def write(path, header, rows):
    with path.open("x", encoding="utf8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(header)
        writer.writerows(rows)


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest().upper()


def register(exe):
    filenames = [
        "PRECOMMIT_M22.md", "prepare_m22_reference.py", "run_m22.py", "single_inputs.csv", "m22_source_verification.csv",
    ]
    for folder in ("solver", "m18_inputs", "reference"):
        filenames.extend(p.relative_to(ROOT).as_posix() for p in sorted((ROOT / folder).rglob("*"))
                         if p.is_file() and "target" not in p.relative_to(ROOT / folder).parts)
    write(ROOT / "m22_precommit_sha256.csv", ("filename", "sha256"),
          [(name, digest(ROOT / name)) for name in filenames] + [("m22_connected.exe", digest(exe))])


def verify(exe, allow_rebuilt):
    frozen = read(ROOT / "m22_precommit_sha256.csv")
    if not {ANCHOR, "PRECOMMIT_M22.md", "m22_connected.exe"} <= {r["filename"] for r in frozen}:
        raise ValueError("Incomplete M22 registration")
    for row in frozen:
        name = row["filename"]
        if allow_rebuilt and name == "m22_connected.exe":
            continue
        if digest(exe if name == "m22_connected.exe" else ROOT / name) != row["sha256"]:
            raise ValueError(f"Registered checksum mismatch: {name}")
    for row in read(ROOT / "single_inputs.csv"):
        if digest(ROOT / row["source_filename"]) != row["source_sha256"]:
            raise ValueError(f"Single-run source changed: {row['source_filename']}")


def ticks(time_model):
    return round(float(time_model) * 100)


def single_protocols(rows):
    return [(f"{r['rate']}_{r['source']}_{method}", r) for r in rows for method in ("connected", "wait")]


def link(src, dst):
    try:
        dst.hardlink_to(src)
    except OSError:
        shutil.copy2(src, dst)


def merge(branches, destination, protocols):
    destination.mkdir()
    (destination / "states").mkdir()
    for protocol in protocols:
        for path in (branches / protocol / "states").glob("*.bin"):
            link(path, destination / "states" / path.name)
    for name in CSVS:
        with (destination / name).open("x", encoding="utf8", newline="") as output:
            header = None
            for protocol in protocols:
                with (branches / protocol / name).open(encoding="utf8", newline="") as part:
                    local = part.readline()
                    if header is None:
                        header = local
                        output.write(header)
                    if local != header:
                        raise ValueError(f"Branch schema mismatch: {protocol} {name}")
                    shutil.copyfileobj(part, output)


def run(mode, exe, directory, jobs, allow_rebuilt):
    verify(exe, allow_rebuilt)
    directory.mkdir()
    branches = directory / "branches"
    branches.mkdir()
    schedules = directory / "schedules"
    schedules.mkdir()
    formal = mode == "formal"
    stages = []
    start_wall = time.perf_counter()

    def invoke(protocol, source=ANCHOR, start=1590, cycle=2, elapsed=()):
        choice = "-"
        if elapsed:
            choice = schedules / f"{protocol}.txt"
            choice.write_text("".join(f"{length}\n" for length in elapsed), encoding="ascii")
        subprocess.run(
            [exe, mode, protocol, ROOT / source, branches / protocol, str(start), str(cycle), source, choice],
            check=True,
        )

    def stage(name, args):
        started = time.perf_counter()
        with ThreadPoolExecutor(max_workers=jobs) as pool:
            pending = [pool.submit(invoke, *args_for_one) for args_for_one in args]
            for job in pending:
                job.result()
        elapsed = time.perf_counter() - started
        stages.append((name, len(args), elapsed))
        print(f"{name}: {len(args)} branches completed in {elapsed:.2f} seconds", flush=True)

    stage("independent", [(p,) for p in OPTIONS])
    if formal:
        m21 = read(ROOT / "reference" / "m21" / "m21_cycle_ledger.csv")
        schedules_matched = []
        for p in OPTIONS:
            times = [1590, *(ticks(r["time"]) for r in m21 if r["protocol"] == p and r["accepted"] == "true")]
            schedules_matched.append(tuple(end - first for first, end in zip(times, times[1:])))
        matched = MATCHED
    else:
        schedules_matched = [(0, 50)]
        matched = ("A_matched",)
    stage("matched", [(p, ANCHOR, 1590, 2, grid) for p, grid in zip(matched, schedules_matched, strict=True)])
    merge(branches, directory / "merged", OPTIONS + matched)

    singles = read(ROOT / "single_inputs.csv")
    if not formal:
        singles = [r for r in singles if (r["rate"], r["source"]) == ("A", "anchor")]
    pairs = single_protocols(singles)
    stage("single", [
        (p, r["source_filename"], ticks(r["source_time"]), int(r["source_cycle"]),
         (ticks(r["selected_elapsed"]) if formal else 250,))
        for p, r in pairs
    ])
    merge(branches, directory / "single_merged", [p for p, _ in pairs])
    verify(exe, allow_rebuilt)
    write(directory / "m22_stage_runtime.csv", ("stage", "protocol_count", "elapsed_seconds"), stages)
    write(directory / "m22_batch_runtime.csv", ("mode", "parallel_protocol_jobs", "elapsed_seconds"),
          [(mode, jobs, time.perf_counter() - start_wall)])
    if not formal:
        estimate(directory, jobs)


def estimate(directory, jobs):
    main = read(directory / "merged" / "m22_runtime.csv")
    singles = read(directory / "single_merged" / "m22_runtime.csv")
    groups = [
        ("independent", [row for row in main if row["protocol"].endswith("_opt")], 0.50, 8, 3),
        ("matched", [row for row in main if row["protocol"].endswith("_matched")], 0.50, 8, 3),
        ("single", singles, 2.50, 1, 18),
    ]
    projection = []
    for name, rows, scan, cycles, branches in groups:
        propagation = [max(float(r["search_seconds"]), float(r["half_seconds"])) for r in rows]
        overhead = [max(float(r["wall_seconds"]) - x, 0.) for r, x in zip(rows, propagation, strict=True)]
        setup = max(float(r["setup_seconds"]) for r in rows)
        per_branch = setup + cycles * (sum(propagation) / len(rows) * 18 / scan + sum(overhead) / len(rows))
        wall = per_branch * ((branches + jobs - 1) // jobs)
        projection.append((name, scan, 18 / scan, branches, cycles, setup, per_branch, wall))
    write(directory / "m22_runtime_estimate.csv",
          ("stage", "bench_window", "window_ratio", "formal_protocols", "cycle_cap", "setup_seconds",
           "projected_branch_seconds", "projected_wall_seconds"), projection)
    print(f"Formal propagation estimate: {sum(r[-1] for r in projection)/60:.1f} minutes at {jobs} protocol jobs.", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("register", "benchmark", "formal"))
    parser.add_argument("solver", type=Path)
    parser.add_argument("directory", type=Path, nargs="?")
    parser.add_argument("--jobs", type=int, default=2, choices=(1, 2, 3))
    parser.add_argument("--allow-rebuilt", action="store_true")
    args = parser.parse_args()
    exe = args.solver.resolve()
    if args.mode == "register":
        register(exe)
    elif args.directory is None:
        parser.error("output directory is required")
    else:
        run(args.mode, exe, args.directory.resolve(), args.jobs, args.allow_rebuilt)
