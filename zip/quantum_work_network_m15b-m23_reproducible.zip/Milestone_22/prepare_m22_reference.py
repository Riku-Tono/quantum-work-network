"""Verify M18 and M21 archives, then export the M22 reference inputs."""
import argparse
import csv
import hashlib
import io
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
ANCHOR = "R4_observed_max_t1590_after.bin"
ANCHOR_SHA = "4C9A5EE8172E505592C43A7B522476715D418CAFA0CC677C04B853E72CC6F9ED"
REFERENCES = (
    "m21_cycle_ledger.csv", "m21_candidates.csv", "m21_half_step.csv", "m21_state_metrics.csv",
    "m21_state_manifest.csv", "m21_energy_balance.csv", "m21_protocol_summary.csv",
    "PRECOMMIT_M21.md", "MILESTONE_21_DEPHASING_REPORT.md",
)


def read(data):
    return list(csv.DictReader(io.StringIO(data.decode("utf-8-sig"))))


def sha(data):
    return hashlib.sha256(data).hexdigest().upper()


def prepare(m18, m21):
    results = ROOT / "reference" / "m21"
    results.mkdir(parents=True, exist_ok=True)
    states = results / "states"
    states.mkdir()
    with (m21 / "M21_all_results.zip").open("rb") as stream:
        archive_sha = hashlib.file_digest(stream, "sha256").hexdigest()
    if archive_sha != (m21 / "M21_all_results.sha256").read_text().split()[0]:
        raise ValueError("M21 archive SHA-256 differs from the formal sidecar")
    checks = []
    with zipfile.ZipFile(m18 / "M18_all_results.zip") as archive18, \
         zipfile.ZipFile(m21 / "M21_all_results.zip") as archive21:
        archived18 = archive18.read(f"Milestone_18/states/{ANCHOR}")
        archived21 = archive21.read(f"Milestone_21/m18_inputs/{ANCHOR}")
        local18 = (m18 / "states" / ANCHOR).read_bytes()
        local21 = (m21 / "m18_inputs" / ANCHOR).read_bytes()
        here = (ROOT / "m18_inputs" / ANCHOR).read_bytes()
        if not archived18 == archived21 == local18 == local21 == here or sha(here) != ANCHOR_SHA:
            raise ValueError("M18/M21 anchor state differs")
        for label in ("M18 archive", "M21 archive", "M18 official file", "M21 official file", "M22 input"):
            checks.append((label, f"m18_inputs/{ANCHOR}", ANCHOR_SHA, len(here), "PASS"))
        for path in sorted((ROOT / "m18_inputs").iterdir()):
            if path.name == ANCHOR:
                continue
            blob = path.read_bytes()
            if blob != archive18.read(f"Milestone_18/{path.name}") or blob != archive21.read(f"Milestone_21/m18_inputs/{path.name}"):
                raise ValueError(f"M18 record mismatch: {path.name}")
            checks.append(("M18/M21 archives", f"m18_inputs/{path.name}", sha(blob), len(blob), "PASS"))
        for name in REFERENCES:
            blob = archive21.read(f"Milestone_21/{name}")
            if blob != (m21 / name).read_bytes():
                raise ValueError(f"M21 archived comparison differs: {name}")
            (results / name).write_bytes(blob)
            checks.append(("M21 archive", f"reference/m21/{name}", sha(blob), len(blob), "PASS"))

        ledgers = {(r["protocol"], int(r["cycle"])): r for r in read((results / "m21_cycle_ledger.csv").read_bytes())}
        manifest = {(r["protocol"], int(r["cycle"])): r for r in read((results / "m21_state_manifest.csv").read_bytes())
                    if r["phase"] == "after" and r["resolution"] == "coarse"}
        singles = []
        for rate, gamma in (("A", 1.5), ("B", 0.75), ("C", 0.0)):
            protocol = f"{rate}_opt"
            for name, cycle in (("anchor", 2), ("mid", 6), ("end", 10)):
                if cycle == 2:
                    file = f"m18_inputs/{ANCHOR}"
                    digest, time = ANCHOR_SHA, 15.90
                else:
                    row = manifest[protocol, cycle]
                    if float(row["g"]) != 0.25 or row["source_initial_state_sha256"] != ANCHOR_SHA:
                        raise ValueError("M21 snapshot origin mismatch")
                    file = f"reference/m21/{row['filename']}"
                    digest, time = row["sha256"], float(row["time"])
                    blob = archive21.read(f"Milestone_21/{row['filename']}")
                    if sha(blob) != digest or blob != (m21 / row["filename"]).read_bytes():
                        raise ValueError(f"Representative state archive mismatch: {row['filename']}")
                    (ROOT / file).write_bytes(blob)
                    checks.append(("M21 archive and manifest", file, sha(blob), len(blob), "PASS"))
                elapsed = float(ledgers[protocol, cycle + 1]["time"]) - time if cycle < 10 else 12.00
                singles.append((rate, gamma, name, cycle, f"{time:.2f}", file, digest, f"{elapsed:.2f}"))
    with (ROOT / "single_inputs.csv").open("x", encoding="utf8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(("rate", "gamma", "source", "source_cycle", "source_time", "source_filename",
                         "source_sha256", "selected_elapsed"))
        writer.writerows(singles)
    with (ROOT / "m22_source_verification.csv").open("x", encoding="utf8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(("archive_or_source", "filename", "sha256", "size_bytes", "status"))
        writer.writerows(checks)
    print(f"Archived M18/M21 inputs: {len(checks)} checks passed; {len(singles)} single-pair cases.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--m18", type=Path, default=ROOT.parent / "Milestone_18")
    parser.add_argument("--m21", type=Path, default=ROOT.parent / "Milestone_21")
    args = parser.parse_args()
    prepare(args.m18, args.m21)
