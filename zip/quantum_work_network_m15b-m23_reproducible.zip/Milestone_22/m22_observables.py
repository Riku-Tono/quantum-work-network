"""Compute M22 snapshot observables using the frozen M21 definitions."""
import argparse
from functools import lru_cache
from pathlib import Path

from m21_observables import Observables, read_state
from run_m22 import read, write


def enrich(directory, input_root):
    model = Observables()
    basic = read(directory / "m22_state_basic.csv")
    if not basic:
        raise ValueError(f"No observations under {directory}")

    @lru_cache(maxsize=5)
    def measure(path, model_time, coupling):
        return model.measure(read_state(path, model_time), coupling)

    enriched = []
    for row in basic:
        relative = Path(row["filename"])
        root = directory if relative.parts[0] == "states" else input_root
        derived = measure(root / relative, float(row["time"]), float(row["g"]))
        enriched.append({**row, **derived})
    fields = list(enriched[0])
    write(directory / "m22_state_metrics.csv", fields, ([row[name] for name in fields] for row in enriched))
    print(f"{directory.name}: recorded M22 observables for {len(enriched)} snapshots.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--input-root", type=Path)
    args = parser.parse_args()
    enrich(args.directory, args.input_root or args.directory)
