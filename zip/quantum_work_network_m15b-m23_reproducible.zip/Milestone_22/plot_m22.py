"""Render the M22 repeated and single-extraction comparisons from their CSVs."""

import argparse
import csv
import math
from collections import defaultdict
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parent
FLOOR = 1e-12
INK = "#152637"
MUTED = "#42586C"
GRID = "#DFE7ED"
AXIS = "#8797A5"
CONDITIONS = {"A": r"A  ·  $\gamma=\gamma_0$", "B": r"B  ·  $\gamma=0.5\gamma_0$", "C": r"C  ·  $\gamma=0$"}
POLICIES = {
    "wait": ("#225886", "o", "-", "M21  ·  disconnect and wait"),
    "connected": ("#A2441A", "D", "-.", "M22  ·  stay connected"),
    "matched": ("#007172", "s", "--", "M22  ·  stay connected at M21 times"),
}
SOURCE_STAGES = {"anchor": "M18 after cycle 2", "mid": "M21 after cycle 6", "end": "M21 after cycle 10"}


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as source:
        return list(csv.DictReader(source))


def group(rows, *columns):
    grouped = defaultdict(list)
    for row in rows:
        grouped[tuple(row[column] for column in columns)].append(row)
    return grouped


def number(row, column):
    value = row[column]
    return float(value) if value else math.nan


def accepted(row):
    return row["accepted"].strip().lower() in {"true", "yes", "1"}


def cycle(row):
    return int(row["cycle"])


def series_id(condition, policy):
    if policy == "wait":
        return f"M21-{condition}"
    suffix = "-matched" if policy == "matched" else ""
    return f"M22-{condition}{suffix}"


def draw_line(ax, policy, x, y, *, markers=True, drawstyle="default"):
    color, marker, linestyle, _ = POLICIES[policy]
    ax.plot(x, y, color=color, linestyle=linestyle, linewidth=1.6, marker=marker if markers else None,
            markersize=4.7, markeredgewidth=1.1, markerfacecolor="white", drawstyle=drawstyle)


def mark(ax, policy, x, y, marker=None):
    color, default_marker, _, _ = POLICIES[policy]
    actual = marker or default_marker
    if actual == "X":
        ax.scatter(x, y, color=color, marker="X", s=36, zorder=4)
    else:
        ax.scatter(x, y, color=color, marker=actual, s=27, facecolors="white", linewidths=1.2, zorder=4)


def style_axis(ax, *, title=None, xlabel=None, ylabel=None, zero=False):
    ax.set_axisbelow(True)
    ax.yaxis.grid(True, color=GRID, linewidth=0.8)
    ax.spines[["top", "right"]].set_visible(False)
    for edge in ("left", "bottom"):
        ax.spines[edge].set_color(AXIS)
    ax.tick_params(axis="both", color=AXIS, labelcolor=INK, labelsize=9)
    if ax.get_yscale() == "linear":
        ax.ticklabel_format(axis="y", style="sci", scilimits=(-3, 3), useMathText=True, useOffset=False)
        ax.yaxis.offsetText.set_color(MUTED)
        ax.yaxis.offsetText.set_fontsize(8)
    if zero:
        ax.axhline(0.0, color=AXIS, linewidth=0.8, zorder=1)
    if title:
        ax.set_title(title, loc="left", color=INK, fontsize=10.4, pad=7)
    if xlabel:
        ax.set_xlabel(xlabel, color=INK, fontsize=10)
    if ylabel:
        ax.set_ylabel(ylabel, color=INK, fontsize=10)


def signed_log_axis(ax):
    ax.set_yscale("symlog", linthresh=FLOOR, linscale=0.85)
    ax.yaxis.get_major_locator().set_params(numticks=9)


def compact_linear_band_ticks(ax):
    from matplotlib.ticker import MaxNLocator, ScalarFormatter

    if max(abs(limit) for limit in ax.get_ylim()) <= FLOOR:
        formatter = ScalarFormatter(useMathText=True, useOffset=False)
        formatter.set_powerlimits((-3, 3))
        ax.yaxis.set_major_locator(MaxNLocator(nbins=4))
        ax.yaxis.set_major_formatter(formatter)
        ax.yaxis.offsetText.set_color(MUTED)
        ax.yaxis.offsetText.set_fontsize(8)


def header(figure, title, subtitle, *, policies=tuple(POLICIES), single=False, extra=(),
           top=0.78, bottom=0.10, left=0.103, **spacing):
    from matplotlib.lines import Line2D

    figure.subplots_adjust(left=left, right=0.976, top=top, bottom=bottom, **spacing)
    figure.text(left, 0.975, title, fontsize=18, color=INK, fontweight="bold", va="top")
    figure.text(left, 0.928, subtitle, fontsize=10, color=MUTED, va="top")
    single_labels = {"wait": "Disconnect and wait 2.00", "connected": "Stay connected"}
    lines = []
    for policy in policies:
        color, marker, linestyle, label = POLICIES[policy]
        lines.append(Line2D([], [], color=color, marker=marker, linestyle=linestyle,
                            markerfacecolor="white", label=single_labels[policy] if single else label))
    for linestyle, marker, label in extra:
        lines.append(Line2D([], [], linestyle=linestyle, color=MUTED, marker=marker, label=label))
    figure.legend(handles=lines, loc="upper left", bbox_to_anchor=(left - 0.005, 0.884),
                  ncols=len(lines), labelcolor=INK, fontsize=9.2, frameon=False, columnspacing=1.6, handlelength=2.5)


def column_titles(figure, axes, titles):
    offset = 18 / (72 * figure.get_figheight())
    for ax, title in zip(axes, titles):
        bounds = ax.get_position()
        figure.text(bounds.x0, bounds.y1 + offset, title, fontsize=11, color=INK, va="bottom")


def save(plt, figure, output, filename):
    figure.savefig(output / filename, dpi=190, facecolor="white")
    plt.close(figure)


def plot_work(plt, comparison, cycle_ticks, output):
    figure, axes = plt.subplots(2, 3, figsize=(13.6, 7.6), sharey="row", sharex=True)
    extras = (("none", "X", "Skipped attempt"),) if any(
        not accepted(row) for rows in comparison.values() for row in rows
    ) else ()
    header(figure, "Net work per extraction attempt",
           "Lines join accepted work. The logarithmic panels show positive values and the dotted acceptance floor.",
           extra=extras, top=0.78, wspace=0.24, hspace=0.30)
    for col, condition in enumerate(CONDITIONS):
        for index, ax in enumerate(axes[:, col]):
            logarithmic = index == 1
            if logarithmic:
                ax.set_yscale("log")
                ax.axhline(FLOOR, color=AXIS, linewidth=0.9, linestyle=":", zorder=1)
            for policy in POLICIES:
                rows = comparison[series_id(condition, policy),]
                values = [number(row, "net_work") for row in rows]
                # NaNs separate accepted values across a skipped attempt without implying an extraction at that cycle.
                draw_line(ax, policy, [cycle(row) for row in rows], [
                    value if accepted(row) and (not logarithmic or value > 0) else math.nan
                    for row, value in zip(rows, values)
                ])
                for row, value in zip(rows, values):
                    if not accepted(row) and (not logarithmic or value > 0):
                        mark(ax, policy, cycle(row), value, "X")
            scale = "log" if logarithmic else "linear"
            style_axis(ax, xlabel="Extraction cycle" if logarithmic else None,
                       ylabel=f"Net work ({scale})" if col == 0 else None, zero=not logarithmic)
            ax.set_xticks(cycle_ticks)
            ax.set_xlim(min(cycle_ticks) - 0.3, max(cycle_ticks) + 0.3)
    column_titles(figure, axes[0], CONDITIONS.values())
    save(plt, figure, output, "m22_01_net_work.png")


def plot_time(plt, timeline, comparison, horizon, output):
    figure, axes = plt.subplots(1, 3, figsize=(13.6, 5.45), sharey=True, sharex=True)
    header(figure, "Cumulative accepted net work over model time",
           f"The dotted line is the common elapsed time used for comparison ({horizon:g}).",
           top=0.75, bottom=0.17, wspace=0.24)
    last_attempt = max(number(row, "elapsed_since_anchor") for rows in comparison.values() for row in rows)
    for col, (ax, condition) in enumerate(zip(axes, CONDITIONS)):
        for policy in POLICIES:
            key = (series_id(condition, policy),)
            rows = timeline[key]
            if not rows:
                continue
            elapsed = [number(row, "elapsed_since_anchor") for row in rows]
            cumulative = [number(row, "adopted_cumulative_net_work") for row in rows]
            for row in comparison[key]:
                time = number(row, "elapsed_since_anchor")
                if accepted(row) and time > horizon:
                    elapsed.append(time)
                    cumulative.append(number(row, "cumulative_net_work"))
            if elapsed[-1] < last_attempt:
                elapsed.append(last_attempt)
                cumulative.append(cumulative[-1])
            draw_line(ax, policy, elapsed, cumulative, markers=False, drawstyle="steps-post")
            previous = 0.0
            for time, value in zip(elapsed, cumulative):
                if value > previous:
                    mark(ax, policy, time, value)
                previous = value
        ax.axvline(horizon, color=AXIS, linewidth=0.9, linestyle=":", zorder=1)
        style_axis(ax, xlabel="Model time since M18 anchor", ylabel="Cumulative net work" if col == 0 else None,
                   zero=True)
    column_titles(figure, axes, CONDITIONS.values())
    save(plt, figure, output, "m22_02_cumulative_over_time.png")


def plot_rate_dependence(plt, summary, horizon, output):
    figure, axes = plt.subplots(2, 2, figsize=(11.7, 7.7), sharex=True, sharey="row")
    header(figure, "Recovered work and time efficiency by dephasing rate",
           f"The common-time columns include only extractions completed by elapsed model time {horizon:g}.",
           top=0.78, wspace=0.26, hspace=0.35)
    columns = (
        ("adopted_cumulative_net_work", "work_per_model_time_at_own_last_adoption"),
        ("work_accumulated_by_common_elapsed", "work_per_model_time_at_common_elapsed"),
    )
    for col, (work_column, rate_column) in enumerate(columns):
        for index, key in enumerate((work_column, rate_column)):
            ax = axes[index, col]
            for policy in POLICIES:
                keys = (series_id(condition, policy) for condition in CONDITIONS)
                rows = sorted((summary[name] for name in keys if name in summary and summary[name].get("attempted_cycles") != "0"),
                              key=lambda row: number(row, "gamma"))
                draw_line(ax, policy, [number(row, "gamma") for row in rows], [number(row, key) for row in rows])
            style_axis(ax, xlabel=r"Dephasing rate $\gamma$" if index == 1 else None, zero=True,
                       ylabel=("Cumulative net work" if index == 0 else "Net work / model time") if col == 0 else None)
            ax.set_xticks([0.0, 0.75, 1.5])
    column_titles(figure, axes[0], ("Each branch at its own last extraction", "All branches at a common time"))
    save(plt, figure, output, "m22_03_gamma_work_and_efficiency.png")


def repeated_inputs(data, reference):
    searches, trials, states = defaultdict(list), {}, defaultdict(dict)
    for policy, directory, prefix in (("wait", reference, "m21"), ("connected", data, "m22")):
        for table, rows in (
            ("trials", read_csv(directory / f"{prefix}_cycle_ledger.csv")),
            ("searches", read_csv(directory / f"{prefix}_candidates.csv")),
            ("states", read_csv(directory / f"{prefix}_state_metrics.csv")),
        ):
            for row in rows:
                protocol = row["protocol"]
                condition, _, timing = protocol.partition("_")
                if condition not in CONDITIONS or timing not in {"opt", "matched"}:
                    continue
                current_policy = "matched" if timing == "matched" else policy
                key = (condition, current_policy, cycle(row))
                if table == "trials":
                    trials[key] = row
                elif table == "searches":
                    searches[key].append(row)
                else:
                    states[condition, current_policy][cycle(row), row["phase"]] = row
    for rows in searches.values():
        rows.sort(key=lambda row: number(row, "time"))
    return searches, trials, states


def plot_signals(plt, searches, trials, cycle_ticks, output):
    nrows = math.ceil(len(cycle_ticks) / 2)
    extent = max(number(rows[-1], "time") - number(trials[key], "start_time") for key, rows in searches.items())
    ticks = (0, 2, 6, 10, 14, 18) if math.isclose(extent, 18.0, abs_tol=1e-9) else None
    for condition, label in CONDITIONS.items():
        figure, axes = plt.subplots(nrows, 4, figsize=(15.2, 3.35 * nrows + 1.0), sharex=True, squeeze=False)
        extras = (("none", "X", "Skipped attempt"),) if any(
            not accepted(row) for key, row in trials.items() if key[0] == condition
        ) else ()
        header(figure, f"Load ergotropy and energy current  ·  {label}",
               "The shaded interval is M21’s disconnected wait. Symbols mark each proposal on the unextracted trajectory.",
               extra=extras, top=0.825 if nrows > 2 else 0.76, bottom=0.075, left=0.083, wspace=0.36, hspace=0.44)
        for index, cycle_id in enumerate(cycle_ticks):
            row_index, pair_index = divmod(index, 2)
            for panel, (metric, unit) in enumerate((("load_ergotropy", "Load ergotropy"), ("load_current", "Current into load"))):
                ax = axes[row_index, pair_index * 2 + panel]
                ax.axvspan(0.0, 2.0, color=POLICIES["wait"][0], alpha=0.075, linewidth=0)
                if metric == "load_ergotropy":
                    signed_log_axis(ax)
                for policy in POLICIES:
                    key = (condition, policy, cycle_id)
                    rows = searches.get(key, ())
                    if not rows:
                        continue
                    trial = trials[key]
                    start = number(trial, "start_time")
                    x = [number(row, "time") - start for row in rows]
                    y = [number(row, metric) for row in rows]
                    draw_line(ax, policy, x, y, markers=False)
                    selected = number(trial, "time") - start
                    match = min(range(len(rows)), key=lambda sample: abs(x[sample] - selected))
                    if abs(x[match] - selected) <= 1e-9:
                        mark(ax, policy, selected, y[match], None if accepted(trial) else "X")
                style_axis(ax, title=f"Cycle {cycle_id}  ·  {unit}", zero=True)
                padding = 0.02 * extent
                ax.set_xlim(-padding, extent + padding)
                if ticks is not None:
                    ax.set_xticks(ticks)
        for index in range(len(cycle_ticks) * 2, axes.size):
            axes.flat[index].set_visible(False)
        figure.supxlabel("Model time since trial start", color=INK, fontsize=10, y=0.025)
        save(plt, figure, output, f"m22_04_load_and_current_{condition}.png")


def plot_reserve(plt, states, trials, cycle_ticks, output):
    figure, axes = plt.subplots(2, 3, figsize=(13.6, 7.75), sharey="row", sharex=True)
    extras = (("none", "X", "Skipped attempt"),) if any(not accepted(row) for row in trials.values()) else ()
    header(figure, "Work remaining in the full system",
           "Each line uses the common anchor and the end of each attempted cycle at g = 0.25.",
           extra=extras, top=0.78, wspace=0.24, hspace=0.30)
    metrics = (("global_ergotropy", "Global ergotropy change"),
               ("sector_ergotropy", "Excitation-preserving ergotropy\n(symlog)"))
    for col, condition in enumerate(CONDITIONS):
        for index, (metric, label) in enumerate(metrics):
            ax = axes[index, col]
            if index == 1:
                signed_log_axis(ax)
            for policy in POLICIES:
                by_stage = states[condition, policy]
                anchor = next((row for (_, phase), row in by_stage.items() if phase == "anchor"),
                              by_stage.get((cycle_ticks[0], "start")))
                if anchor is None:
                    continue
                points = [(anchor, True)]
                for cycle_id in cycle_ticks:
                    key = (condition, policy, cycle_id)
                    if key in trials:
                        adopted = accepted(trials[key])
                        phase = "after" if adopted else "before"
                        points.append((by_stage[cycle_id, phase], adopted))
                baseline = number(anchor, metric) if index == 0 else 0.0
                x = [number(row, "time") - number(anchor, "time") for row, _ in points]
                y = [number(row, metric) - baseline for row, _ in points]
                draw_line(ax, policy, x, y, markers=False)
                for time, value, (_, adopted) in zip(x, y, points):
                    mark(ax, policy, time, value, None if adopted else "X")
            style_axis(ax, xlabel="Model time since M18 anchor" if index == 1 else None,
                       ylabel=label if col == 0 else None, zero=index == 0)
    column_titles(figure, axes[0], CONDITIONS.values())
    save(plt, figure, output, "m22_05_remaining_work.png")


def plot_single(plt, directory, data, output):
    candidates = group(read_csv(directory / "m22_candidates.csv"), "protocol")
    summary = {
        (row["condition"], row["source_stage"], row["mode"]): row
        for row in read_csv(data / "m22_single_summary.csv")
    }
    extras = (("none", "X", "Skipped proposal"),) if any(not accepted(row) for row in summary.values()) else ()
    conditions = [condition for condition in CONDITIONS if any(key[0] == condition for key in summary)]
    stages = [stage for stage in SOURCE_STAGES if any(key[1] == stage for key in summary)]
    figure, axes = plt.subplots(len(conditions), len(stages), figsize=(6.0 + 2.53 * len(stages), 3.0 + 2.53 * len(conditions)),
                                sharex=True, squeeze=False)
    header(figure, "Single-extraction work from identical saved states",
           "Each pair starts from the same state. Symbols mark the registered comparison time.",
           policies=("wait", "connected"), extra=extras,
           single=True, top=0.80 if len(conditions) > 1 else 0.74, bottom=0.10, wspace=0.29, hspace=0.47)
    maximum = max(number(row, "elapsed") for rows in candidates.values() for row in rows)
    for row_index, condition in enumerate(conditions):
        for col, source in enumerate(stages):
            ax = axes[row_index, col]
            signed_log_axis(ax)
            ax.axvspan(0.0, 2.0, color=POLICIES["wait"][0], alpha=0.075, linewidth=0)
            for policy in ("wait", "connected"):
                protocol = f"{condition}_{source}_{policy}"
                rows = sorted(candidates[protocol,], key=lambda row: number(row, "elapsed"))
                x = [number(row, "elapsed") for row in rows]
                y = [number(row, "net_work") for row in rows]
                draw_line(ax, policy, x, y, markers=False)
                result = summary[condition, source, policy]
                mark(ax, policy, number(result, "elapsed"), number(result, "net_work"),
                     None if accepted(result) else "X")
            style_axis(ax, xlabel="Model time since saved state" if row_index == len(conditions) - 1 else None,
                       ylabel=f"{CONDITIONS[condition]}\nCandidate net work (symlog)" if col == 0 else None,
                       zero=True)
            compact_linear_band_ticks(ax)
            ax.set_xlim(-0.02 * maximum, 1.02 * maximum)
            if math.isclose(maximum, 18.0, abs_tol=1e-9):
                ax.set_xticks((0, 2, 6, 10, 14, 18))
    column_titles(figure, axes[0], (SOURCE_STAGES[stage] for stage in stages))
    save(plt, figure, output, "m22_06_single_extraction.png")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=ROOT, help="Directory containing formal M22 CSVs")
    parser.add_argument("--reference", type=Path, help="M21 reference directory, defaulting to reference/m21 under --data")
    parser.add_argument("--single", type=Path, help="Single-extraction raw data, defaulting to single under --data")
    parser.add_argument("--output", type=Path, help="Figure directory, defaulting to figures under --data")
    parser.add_argument("--plot-deps", type=Path, help="Optional directory containing Matplotlib and its dependencies")
    args = parser.parse_args()
    if args.plot_deps:
        sys.path.insert(0, str(args.plot_deps.resolve()))

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    output = args.output or args.data / "figures"
    output.mkdir(parents=True, exist_ok=True)
    comparison = group(read_csv(args.data / "m22_comparison.csv"), "series")
    for rows in comparison.values():
        rows.sort(key=cycle)
    cycle_ticks = sorted({cycle(row) for rows in comparison.values() for row in rows})
    timeline = group(read_csv(args.data / "m22_common_time.csv"), "series")
    for rows in timeline.values():
        rows.sort(key=lambda row: number(row, "elapsed_since_anchor"))
    summary = {row["series"]: row for row in read_csv(args.data / "m22_protocol_summary.csv")}
    horizon = min(number(row, "common_elapsed_since_anchor") for row in summary.values())
    searches, trials, states = repeated_inputs(args.data, args.reference or args.data / "reference" / "m21")
    plot_work(plt, comparison, cycle_ticks, output)
    plot_time(plt, timeline, comparison, horizon, output)
    plot_rate_dependence(plt, summary, horizon, output)
    plot_signals(plt, searches, trials, cycle_ticks, output)
    plot_reserve(plt, states, trials, cycle_ticks, output)
    plot_single(plt, args.single or args.data / "single", args.data, output)


if __name__ == "__main__":
    main()
