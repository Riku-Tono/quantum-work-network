"""Compare M22 executions and single-shot tests with the archived M21 protocol."""

import argparse
from collections import defaultdict
import csv
from pathlib import Path


CONDITIONS = ("A", "B", "C")
SOURCES = ("anchor", "mid", "end")
SERIES = tuple(
    (f"{study}-{condition}{suffix}", study, f"{condition}_{policy}")
    for study, policy, suffix in (("M21", "opt", ""), ("M22", "opt", ""), ("M22", "matched", "-matched"))
    for condition in CONDITIONS
)
OBSERVABLES = (
    "load_energy", "load_ergotropy", "load_passive_energy", "load_purity", "global_energy",
    "global_ergotropy", "global_passive_energy", "global_purity", "sector_ergotropy",
    "sector_passive_energy", "total_excitation", "load_current", "mutual_information",
    "any_local_unitary_full_work_upper_bound",
) + tuple(f"sector_probability_{number}" for number in range(10))
RESOLUTION = 1e-12


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows):
    if not rows:
        return
    with path.open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def tick(value):
    return round(float(value) * 100)


def ratio(numerator, denominator):
    return numerator / denominator if denominator else ""


def resolved(delta, error):
    if delta > error + RESOLUTION:
        return "increase"
    if delta < -error - RESOLUTION:
        return "decrease"
    return "within_resolution"


def is_accepted(row):
    return row["accepted"].lower() == "true"


class Study:
    """Loaded solver and observation tables, indexed by physical clock ticks."""

    def __init__(self, directory, prefix, read_metrics=True):
        self.ledger = defaultdict(dict)
        for row in read_csv(directory / f"{prefix}_cycle_ledger.csv"):
            self.ledger[row["protocol"]][int(row["cycle"])] = row
        self.candidates = defaultdict(dict)
        for row in read_csv(directory / f"{prefix}_candidates.csv"):
            self.candidates[row["protocol"], int(row["cycle"])][tick(row["time"])] = row
        self.half = {
            (r["protocol"], int(r["cycle"]), tick(r["time"])): r
            for r in read_csv(directory / f"{prefix}_half_step.csv")
        }
        self.metrics = {}
        if read_metrics:
            self.metrics = {
                (r["protocol"], int(r["cycle"]), r["phase"]): r
                for r in read_csv(directory / f"{prefix}_state_metrics.csv")
            }

    def net_error(self, protocol, cycle, time):
        sample = self.half[protocol, cycle, time]
        return abs(float(sample["net_work"]) - float(sample["net_half"]))

    def observe(self, protocol, cycle, phase):
        return self.metrics[protocol, cycle, phase]


def switches(row):
    return float(row["cut_on"]) + float(row["reconnect_on"])


def trial_records(studies, benchmark):
    by_series, anchors = {}, {}
    for series, study, protocol in SERIES:
        source = studies[study]
        if benchmark and (protocol, 2, "anchor") not in source.metrics:
            continue
        anchor = source.observe(protocol, 2, "anchor")
        anchors[series] = anchor
        origin = tick(anchor["time"])
        first_work, prior_work, prior_error = None, None, None
        prior_adopted_time = origin
        cumulative, adoption_index = 0.0, 0
        trials = []
        for cycle, row in sorted(source.ledger[protocol].items()):
            accepted = is_accepted(row)
            when, start = tick(row["time"]), tick(row["start_time"])
            net, net_error = float(row["net_work"]), source.net_error(protocol, cycle, when)
            before = source.observe(protocol, cycle, "before")
            after = source.observe(protocol, cycle, "after") if accepted else {}
            elapsed = (when - origin) / 100
            since_prior = (when - prior_adopted_time) / 100
            opportunity = (when - start) / 100
            change = net - prior_work if accepted and prior_work is not None else ""
            if accepted:
                adoption_index += 1
                cumulative += net
                if first_work is None:
                    first_work = net
            grid = source.candidates[protocol, cycle]
            points = sorted(grid)
            peak = max(points, key=lambda point: float(grid[point]["net_work"]))
            peak16 = max((point for point in points if point <= start + 1600),
                         key=lambda point: float(grid[point]["net_work"]))
            gain = float(grid[peak]["net_work"]) - float(grid[peak16]["net_work"])
            gain_error = source.net_error(protocol, cycle, peak) + source.net_error(protocol, cycle, peak16)
            record = {
                "series": series, "study": study, "condition": protocol[0], "protocol": protocol,
                "policy": "matched_M21_clock" if protocol.endswith("_matched") else "independent",
                "gamma": row["gamma"], "cycle": cycle, "accepted": accepted,
                "adoption_index": adoption_index if accepted else "", "adopted_count_to_date": adoption_index,
                "previous_adoption_time": prior_adopted_time / 100, "elapsed_since_prior_adoption": since_prior,
                "start_time": start / 100, "time": when / 100, "elapsed_since_anchor": elapsed,
                "opportunity_elapsed": opportunity, "wait": float(row["wait"]), "g": float(row["g"]),
                "net_work": net, "net_step_error": net_error, "adopted_net_work": net if accepted else 0.0,
                "gross_work": float(row["gross_work"]), "total_work": float(row["total_work"]),
                "interaction_jump": float(row["interaction_jump"]), "cut_on": float(row["cut_on"]),
                "reconnect_on": float(row["reconnect_on"]), "switch_on": switches(row),
                "cumulative_net_work": cumulative,
                "cycle_rate": net / since_prior if since_prior else 0.0,
                "adopted_cycle_rate": net / since_prior if accepted and since_prior else 0.0,
                "opportunity_rate": net / opportunity if opportunity else 0.0,
                "cumulative_rate": cumulative / elapsed if elapsed else 0.0,
                "net_to_prior_adopted_ratio": ratio(net, prior_work) if accepted else "",
                "net_to_first_adopted_ratio": ratio(net, first_work) if accepted else "",
                "net_change_from_prior_adopted": change,
                "net_change_status": resolved(change, net_error + prior_error) if change != "" else "",
                "net_to_anchor_global_ergotropy": ratio(net, float(anchor["global_ergotropy"])) if accepted else "",
                "cumulative_to_anchor_global_ergotropy": ratio(cumulative, float(anchor["global_ergotropy"])),
                "cumulative_to_anchor_sector_ergotropy": ratio(cumulative, float(anchor["sector_ergotropy"])),
                "window_elapsed_start": (points[0] - start) / 100, "window_elapsed_end": (points[-1] - start) / 100,
                "peak_elapsed": (peak - start) / 100, "peak_net_work": float(grid[peak]["net_work"]),
                "peak_at_boundary": peak in (points[0], points[-1]),
                "peak_within_16_elapsed": (peak16 - start) / 100,
                "peak_within_16_net_work": float(grid[peak16]["net_work"]),
                "full_window_minus_16_peak_gain": gain, "window_extension_gain_step_error": gain_error,
                "window_extension_gain_status": resolved(gain, gain_error),
                "stop_reason": row.get("stop_reason", ""), "balance_residual": row["balance_residual"],
                **{f"before_{field}": before[field] for field in OBSERVABLES},
                **{f"after_{field}": after.get(field, "") for field in OBSERVABLES},
            }
            raw_cumulative = float(row["cumulative_m21_net" if study == "M21" else "cumulative_m22_net"])
            if abs(cumulative - raw_cumulative) > RESOLUTION:
                raise ValueError(f"Adopted work mismatch for {series} cycle {cycle}")
            if accepted:
                prior_adopted_time = when
                prior_work, prior_error = net, net_error
            trials.append(record)
        by_series[series] = trials
    return by_series, anchors


def common_time_records(by_series, anchors):
    starts = {tick(anchor["time"]) for anchor in anchors.values()}
    if len(starts) != 1:
        raise ValueError("The M21 and M22 main histories have different start clocks")
    origin, = starts
    horizon = min(tick(rows[-1]["time"]) if rows else origin for rows in by_series.values())
    events = {
        series: [row for row in trials if row["accepted"] and tick(row["time"]) <= horizon]
        for series, trials in by_series.items()
    }
    timeline = sorted({origin, horizon} | {tick(row["time"]) for trials in events.values() for row in trials})
    records = []
    for series, trials in events.items():
        count = 0
        for point in timeline:
            while count < len(trials) and tick(trials[count]["time"]) <= point:
                count += 1
            elapsed = (point - origin) / 100
            work = float(trials[count - 1]["cumulative_net_work"]) if count else 0.0
            records.append({
                "series": series, "time": point / 100, "elapsed_since_anchor": elapsed,
                "adopted_count": count, "adopted_cumulative_net_work": work,
                "work_per_model_time": work / elapsed if elapsed else 0.0,
            })
    return records


def protocol_summaries(by_series, anchors, clock_records, studies):
    by_clock = {row["series"]: row for row in clock_records}
    common_count = min(sum(row["accepted"] for row in trials) for trials in by_series.values())
    summary = []
    for series, study, protocol in SERIES:
        if series not in by_series:
            continue
        trials = by_series[series]
        adopted = [row for row in trials if row["accepted"]]
        last = trials[-1] if trials else None
        last_adopted = adopted[-1] if adopted else None
        anchor = anchors[series]
        end = studies[study].observe(protocol, last["cycle"], "after" if last["accepted"] else "before") if last else anchor
        last_actual = (studies[study].observe(protocol, last_adopted["cycle"], "after") if last_adopted else anchor)
        elapsed = last_adopted["elapsed_since_anchor"] if last_adopted else 0.0
        work = last_adopted["cumulative_net_work"] if last_adopted else 0.0
        if not last:
            termination = "no_scheduled_trial"
        elif last["cycle"] == 10:
            termination = "matched_schedule_end" if protocol.endswith("_matched") else (
                "cycle_cap" if last["accepted"] else "adoption_rule_failure")
        elif not last["accepted"] and not protocol.endswith("_matched"):
            termination = "adoption_rule_failure"
        else:
            termination = "end_of_scope_or_schedule"
        summary.append({
            "series": series, "study": study, "condition": protocol[0], "protocol": protocol,
            "gamma": anchor["gamma"], "attempted_cycles": len(trials), "adopted_cycles": len(adopted),
            "last_attempted_cycle": last["cycle"] if last else "",
            "last_adopted_cycle": last_adopted["cycle"] if last_adopted else "", "termination": termination,
            "terminal_solver_stop_reason": last["stop_reason"] if last else "",
            "endpoint_time": end["time"], "endpoint_phase": end["phase"],
            "own_attempted_elapsed_since_anchor": last["elapsed_since_anchor"] if last else 0.0,
            "own_adopted_elapsed_since_anchor": elapsed, "adopted_cumulative_net_work": work,
            "work_per_model_time_at_own_last_adoption": work / elapsed if elapsed else 0.0,
            "work_per_model_time_at_endpoint": work / last["elapsed_since_anchor"] if last and last["elapsed_since_anchor"] else 0.0,
            "first_adopted_net_work": adopted[0]["net_work"] if adopted else "",
            "last_adopted_net_work": last_adopted["net_work"] if last_adopted else "",
            "last_to_first_net_ratio": last_adopted["net_to_first_adopted_ratio"] if last_adopted else "",
            "numerically_resolved_increase_cycles": " ".join(str(r["cycle"]) for r in adopted if r["net_change_status"] == "increase"),
            "common_adoption_count": common_count,
            "cumulative_net_at_common_adoption_count": adopted[common_count - 1]["cumulative_net_work"] if common_count else 0.0,
            "common_elapsed_since_anchor": by_clock[series]["elapsed_since_anchor"],
            "adopted_count_by_common_elapsed": by_clock[series]["adopted_count"],
            "work_accumulated_by_common_elapsed": by_clock[series]["adopted_cumulative_net_work"],
            "work_per_model_time_at_common_elapsed": by_clock[series]["work_per_model_time"],
            "cumulative_to_anchor_global_ergotropy": ratio(work, float(anchor["global_ergotropy"])),
            "cumulative_to_anchor_sector_ergotropy": ratio(work, float(anchor["sector_ergotropy"])),
            **{f"endpoint_{field}": end[field] for field in OBSERVABLES},
            **{f"last_adoption_{field}": last_actual[field] for field in OBSERVABLES},
        })
    return summary


def ordinal_records(by_series):
    return [
        {key: row[key] for key in (
            "series", "condition", "gamma", "policy", "adoption_index", "cycle", "time",
            "elapsed_since_anchor", "elapsed_since_prior_adoption", "net_work", "cumulative_net_work",
            "cycle_rate", "cumulative_rate", "net_to_prior_adopted_ratio", "net_to_first_adopted_ratio",
        )}
        for trials in by_series.values() for row in trials if row["accepted"]
    ]


def pair_horizons(by_series, anchors):
    records = []
    for condition in CONDITIONS:
        m21, m22 = f"M21-{condition}", f"M22-{condition}"
        if m22 not in by_series:
            continue
        origin = tick(anchors[m21]["time"])
        pair = (by_series[m21], by_series[m22])
        horizon = min(tick(rows[-1]["time"]) if rows else origin for rows in pair)
        duration = (horizon - origin) / 100
        adopted = [[row for row in rows if row["accepted"]] for rows in pair]
        count = min(map(len, adopted))
        by_horizon = [[row for row in rows if tick(row["time"]) <= horizon] for rows in adopted]
        by_count_works = [rows[count - 1]["cumulative_net_work"] if count else 0.0 for rows in adopted]
        horizon_works = [rows[-1]["cumulative_net_work"] if rows else 0.0 for rows in by_horizon]
        records.append({
            "condition": condition, "gamma": anchors[m21]["gamma"],
            "common_end_time": horizon / 100, "common_elapsed_since_anchor": duration,
            "m21_adopted_count_by_common_elapsed": len(by_horizon[0]),
            "m22_adopted_count_by_common_elapsed": len(by_horizon[1]),
            "m21_work_accumulated_by_common_elapsed": horizon_works[0],
            "m22_work_accumulated_by_common_elapsed": horizon_works[1],
            "work_delta_m22_minus_m21_by_common_elapsed": horizon_works[1] - horizon_works[0],
            "m21_work_per_model_time_at_common_elapsed": horizon_works[0] / duration if duration else 0.0,
            "m22_work_per_model_time_at_common_elapsed": horizon_works[1] / duration if duration else 0.0,
            "common_adoption_count": count,
            "m21_work_at_common_adoption_count": by_count_works[0],
            "m22_work_at_common_adoption_count": by_count_works[1],
            "work_delta_m22_minus_m21_at_common_adoption_count": by_count_works[1] - by_count_works[0],
            "m21_elapsed_at_common_adoption_count": adopted[0][count - 1]["elapsed_since_anchor"] if count else 0.0,
            "m22_elapsed_at_common_adoption_count": adopted[1][count - 1]["elapsed_since_anchor"] if count else 0.0,
        })
    return records


def independent_records(by_series):
    records = []
    for condition in CONDITIONS:
        old = {r["cycle"]: r for r in by_series[f"M21-{condition}"]}
        new = {r["cycle"]: r for r in by_series.get(f"M22-{condition}", [])}
        for cycle in sorted(old.keys() & new.keys()):
            earlier, later = old[cycle], new[cycle]
            delta = later["net_work"] - earlier["net_work"]
            error = later["net_step_error"] + earlier["net_step_error"]
            both_adopted = earlier["accepted"] and later["accepted"]
            records.append({
                "condition": condition, "gamma": later["gamma"], "cycle": cycle,
                "m21_accepted": earlier["accepted"], "m22_accepted": later["accepted"],
                "m21_time": earlier["time"], "m22_time": later["time"],
                "m21_adoption_index": earlier["adoption_index"], "m22_adoption_index": later["adoption_index"],
                "m21_net_work": earlier["net_work"], "m22_net_work": later["net_work"],
                "attempted_net_delta_m22_minus_m21": delta, "net_step_error": error,
                "candidate_difference_status": resolved(delta, error),
                "adopted_net_delta_m22_minus_m21": later["adopted_net_work"] - earlier["adopted_net_work"],
                "net_ratio_m22_over_m21": ratio(later["net_work"], earlier["net_work"]) if both_adopted else "",
                "m21_cumulative_net_work": earlier["cumulative_net_work"], "m22_cumulative_net_work": later["cumulative_net_work"],
                "m21_cycle_rate": earlier["cycle_rate"], "m22_cycle_rate": later["cycle_rate"],
            })
    return records


def work_comparison(connected, wait, connected_switch, wait_switch, numerical_error):
    wc, ww = float(connected["net_work"]), float(wait["net_work"])
    gc, gw = float(connected["gross_work"]), float(wait["gross_work"])
    tc, tw = float(connected["total_work"]), float(wait["total_work"])
    interaction_c, interaction_w = gc - tc, gw - tw
    delta, switch_advantage = wc - ww, wait_switch - connected_switch
    balance = delta - (tc - tw) - switch_advantage
    if abs(balance) > RESOLUTION:
        raise ValueError(f"Comparison work decomposition imbalance: {balance}")
    return {
        "connected_net_work": wc, "wait_net_work": ww, "net_delta_connected_minus_wait": delta,
        "net_step_error": numerical_error, "net_difference_status": resolved(delta, numerical_error),
        "connected_gross_work": gc, "wait_gross_work": gw, "gross_delta_connected_minus_wait": gc - gw,
        "connected_total_work": tc, "wait_total_work": tw, "total_delta_connected_minus_wait": tc - tw,
        "connected_interaction_jump": interaction_c, "wait_interaction_jump": interaction_w,
        "interaction_correction_connected_minus_wait": interaction_w - interaction_c,
        "connected_switch_on": connected_switch, "wait_switch_on": wait_switch,
        "net_delta_from_switch_avoidance": switch_advantage, "decomposition_residual": balance,
    }


def matched_records(by_series, benchmark):
    rows = []
    for condition in CONDITIONS:
        archived = {tick(r["time"]): r for r in by_series[f"M21-{condition}"] if r["accepted"]}
        for connected in by_series.get(f"M22-{condition}-matched", []):
            wait = archived.get(tick(connected["time"]))
            if wait is None:
                if benchmark:
                    continue
                raise ValueError(f"Unmatched M22 trial time: {condition}, {connected['time']}")
            rows.append({
                "condition": condition, "gamma": connected["gamma"], "time": connected["time"],
                "elapsed_since_anchor": connected["elapsed_since_anchor"], "m21_cycle": wait["cycle"], "m22_cycle": connected["cycle"],
                "m22_accepted": connected["accepted"], "m22_adoption_index": connected["adoption_index"],
                "m22_adopted_net_work": connected["adopted_net_work"], "m21_adopted_net_work": wait["adopted_net_work"],
                "adopted_net_delta_connected_minus_wait": connected["adopted_net_work"] - wait["adopted_net_work"],
                "m22_cumulative_net_work": connected["cumulative_net_work"], "m21_cumulative_net_work": wait["cumulative_net_work"],
                **work_comparison(connected, wait, connected["switch_on"], wait["switch_on"],
                                  connected["net_step_error"] + wait["net_step_error"]),
            })
    return rows


def candidate_comparison(first, first_protocol, first_cycle, second, second_protocol, second_cycle, point):
    a = first.candidates[first_protocol, first_cycle][point]
    b = second.candidates[second_protocol, second_cycle][point]
    error = first.net_error(first_protocol, first_cycle, point) + second.net_error(second_protocol, second_cycle, point)
    signals = ("load_ergotropy", "load_energy", "load_current", "integrated_load_current")
    return {
        **work_comparison(a, b, switches(first.ledger[first_protocol][first_cycle]),
                          switches(second.ledger[second_protocol][second_cycle]), error),
        **{f"{label}_{field}": float(row[field]) for label, row in (("connected", a), ("wait", b))
           for field in signals},
        **{f"{field}_delta_connected_minus_wait": float(a[field]) - float(b[field]) for field in signals},
    }


def common_candidate_records(old, new):
    records = []
    for condition in CONDITIONS:
        baseline = f"{condition}_opt"
        for protocol in (baseline, f"{condition}_matched"):
            shared_cycles = sorted(old.ledger[baseline].keys() & new.ledger[protocol].keys())
            for cycle in shared_cycles:
                old_start = tick(old.ledger[baseline][cycle]["start_time"])
                new_start = tick(new.ledger[protocol][cycle]["start_time"])
                common = old.candidates[baseline, cycle].keys() & new.candidates[protocol, cycle].keys()
                for point in sorted(common):
                    records.append({
                        "condition": condition, "gamma": new.ledger[protocol][cycle]["gamma"], "cycle": cycle,
                        "connected_protocol": protocol, "wait_protocol": baseline, "time": point / 100,
                        "connected_start_time": new_start / 100, "wait_start_time": old_start / 100,
                        "connected_elapsed": (point - new_start) / 100, "wait_elapsed": (point - old_start) / 100,
                        "same_cycle_start_time": new_start == old_start,
                        "same_anchor_state": cycle == 3 and new_start == old_start,
                        **candidate_comparison(new, protocol, cycle, old, baseline, cycle, point),
                    })
    return records


def single_records(data, registrations, reference, benchmark):
    study = Study(data, "m22", read_metrics=False)
    registry = {(row["rate"], row["source"]): row for row in read_csv(registrations)}
    curves, summary = [], []
    for condition in CONDITIONS:
        for stage in SOURCES:
            record = registry.get((condition, stage))
            if record is None:
                if benchmark:
                    continue
                raise ValueError(f"Missing single-source registration for {condition}/{stage}")
            source_cycle = int(record["source_cycle"])
            source_time = tick(record["source_time"])
            cycle = source_cycle + 1
            connected, wait = (f"{condition}_{stage}_{mode}" for mode in ("connected", "wait"))
            paths = {p: study.candidates[p, cycle] for p in (connected, wait)}
            common = sorted(paths[connected].keys() & paths[wait].keys())
            if not common:
                if benchmark:
                    continue
                raise ValueError(f"No common single-shot candidates for {condition}/{stage}")
            metadata = {
                "condition": condition, "gamma": record["gamma"], "source_stage": stage,
                "source_cycle": source_cycle, "source_time": source_time / 100,
                "source_sha256": record["source_sha256"],
            }
            for point in common:
                curves.append({
                    **metadata, "time": point / 100, "elapsed": (point - source_time) / 100,
                    "at_registered_sample": point == source_time + tick(record["selected_elapsed"]),
                    **candidate_comparison(study, connected, cycle, study, wait, cycle, point),
                })
            for mode, protocol in (("connected", connected), ("wait", wait)):
                path, trial = paths[protocol], study.ledger[protocol][cycle]
                peak = lambda point: float(path[point]["net_work"])
                native_peak = max(sorted(path), key=peak)
                common_peak = max(common, key=peak)
                selection = tick(trial["time"])
                if selection != source_time + tick(record["selected_elapsed"]):
                    raise ValueError(f"Single-shot trial misses registered clock: {protocol}")
                archived = reference.ledger[f"{condition}_opt"].get(cycle)
                same_archive_time = archived is not None and selection == tick(archived["time"])
                archive_net = float(archived["net_work"]) if same_archive_time else ""
                trial_net = float(trial["net_work"])
                summary.append({
                    **metadata, "mode": mode, "protocol": protocol, "cycle": cycle, "accepted": is_accepted(trial),
                    "time": selection / 100, "elapsed": (selection - source_time) / 100,
                    "net_work": trial_net, "adopted_net_work": trial_net if is_accepted(trial) else 0.0,
                    "archived_m21_same_time_net_work": archive_net,
                    "trial_minus_archived_m21_net_work": trial_net - archive_net if same_archive_time else "",
                    "cut_on": float(trial["cut_on"]), "reconnect_on": float(trial["reconnect_on"]),
                    "gross_work": float(trial["gross_work"]), "total_work": float(trial["total_work"]),
                    "interaction_jump": float(trial["interaction_jump"]),
                    "net_step_error": study.net_error(protocol, cycle, selection),
                    "common_window_start": (common[0] - source_time) / 100,
                    "common_window_end": (common[-1] - source_time) / 100,
                    "common_window_peak_elapsed": (common_peak - source_time) / 100, "common_window_peak_net_work": peak(common_peak),
                    "native_window_start": (min(path) - source_time) / 100,
                    "native_window_peak_elapsed": (native_peak - source_time) / 100, "native_window_peak_net_work": peak(native_peak),
                })
    return curves, summary


def summarize(results, reference, single_inputs, benchmark=False):
    studies = {"M21": Study(reference, "m21"), "M22": Study(results, "m22")}
    by_series, anchors = trial_records(studies, benchmark)
    by_time = common_time_records(by_series, anchors)
    tables = {
        "m22_comparison.csv": [row for trials in by_series.values() for row in trials],
        "m22_common_time.csv": by_time,
        "m22_protocol_summary.csv": protocol_summaries(by_series, anchors, by_time, studies),
        "m22_ordinal_comparison.csv": ordinal_records(by_series),
        "m22_pair_horizons.csv": pair_horizons(by_series, anchors),
        "m22_independent_comparison.csv": independent_records(by_series),
        "m22_matched_comparison.csv": matched_records(by_series, benchmark),
        "m22_common_candidates.csv": common_candidate_records(studies["M21"], studies["M22"]),
    }
    if (results / "single" / "m22_cycle_ledger.csv").is_file():
        curves, summary = single_records(results / "single", single_inputs, studies["M21"], benchmark)
        tables["m22_single_comparison.csv"] = curves
        tables["m22_single_summary.csv"] = summary
    for name, rows in tables.items():
        write_csv(results / name, rows)
        print(f"{name}: {len(rows)} rows")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path)
    parser.add_argument("--reference", type=Path, help="Path to the read-only archived M21 solver CSVs")
    parser.add_argument("--single-inputs", type=Path, help="Path to the registered M22 single-shot input CSV")
    parser.add_argument("--benchmark", action="store_true", help="Allow shortened M22 branches and synthetic benchmark replay times")
    args = parser.parse_args()
    summarize(args.results, args.reference or args.results / "reference" / "m21",
              args.single_inputs or args.results / "single_inputs.csv", args.benchmark)
