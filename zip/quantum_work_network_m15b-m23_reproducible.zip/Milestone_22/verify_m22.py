"""Independently audit the M22 fixed-coupling and single-extraction experiments."""

import argparse
from dataclasses import dataclass
import hashlib
import math
from pathlib import Path, PurePosixPath

from verify_m21 import (
    ANCHOR_SHA,
    ANCHOR_TIME,
    DIM,
    G,
    HALF_TOL,
    HISTORY,
    OCCUPATION,
    SIZE,
    TOL,
    Audit,
    Model,
    State,
    keyed,
    load_grid,
    max_abs,
    ranked,
    read_csv,
    require,
    ticks,
    verify_anchor,
    verify_candidate_state,
    verify_dynamics,
    verify_extraction,
    verify_switch,
    verify_unitary_grid,
    write_csv,
)


RATES = {"A": 1.5, "B": 0.75, "C": 0.0}
PROTOCOLS = {f"{label}_{policy}": rate for label, rate in RATES.items() for policy in ("opt", "matched")}
M21_LEDGER_SHA = "A1CEAEE96C0A1403FEC3F3F5A7C12C767F6D72D5A14E75B66B64BDBFBCB69003"
M21_MANIFEST_SHA = "48223D23E92903367361BE63CE10BFD8ABC9378C7E56F16924188CA0659D298E"
SOURCE_CYCLES = {"anchor": 2, "mid": 6, "end": 10}
WINDOW = 1800
ALTERNATE_WINDOW = 1600
WAIT = 200
BENCH_WINDOW = 50
BENCH_SINGLE_WINDOW = 250
FIRST_CYCLE = 3
LAST_CYCLE = 10


def archive_path(root, name, allowed):
    relative = PurePosixPath(name)
    require(relative.parts and not relative.is_absolute() and ".." not in relative.parts
            and "\\" not in name and ":" not in name and relative.parts[0] in allowed,
            f"Unexpected archive path {name}")
    return root / relative


def accepted(row):
    value = row["accepted"]
    require(value in ("true", "false"), f"Invalid accepted flag: {value}")
    return value == "true"


def number(row, field):
    value = float(row[field])
    require(math.isfinite(value), f"Non-finite {field}")
    return value


def compare_fields(audit, key, phase, row, values, bound=TOL):
    audit.compare(*key, phase, row, {name: value for name, value in values.items() if name in row}, bound)


@dataclass
class Snapshot:
    state: State
    filename: str
    coupling: float
    metrics: dict


class SnapshotArchive:
    def __init__(self, root, directory, audit, model, source_hashes):
        self.root = root
        self.directory = directory
        self.audit = audit
        self.model = model
        self.source_hashes = source_hashes
        self.states = {}
        self.files = {}
        self.used = set()
        self.read("coarse", "m22_state_metrics.csv")
        self.read("half", "m22_state_half.csv")

    def file(self, filename, time):
        if filename.startswith("m18_inputs/") or filename.startswith("reference/") or filename.startswith("single_inputs/"):
            path = archive_path(self.root, filename, {"m18_inputs", "reference", "single_inputs"})
        else:
            path = archive_path(self.directory, filename, {"states"})
        if filename not in self.files:
            self.files[filename] = State.from_file(path, time)
        state = self.files[filename]
        require(abs(state.time - time) <= TOL, f"Inconsistent time for {path}")
        return path, state

    def read(self, resolution, filename):
        path = self.directory / filename
        table = keyed(read_csv(path), ("protocol", "cycle", "phase"), filename)
        for key, row in table.items():
            protocol, cycle, phase = key
            require(protocol in self.source_hashes, f"Unknown protocol {protocol} in {filename}")
            coupling = number(row, "g")
            gamma = number(row, "gamma")
            require(gamma == RATES[protocol[0]] and coupling in (0.0, G), f"Invalid gamma or coupling for {key}")
            state_path, state = self.file(row["filename"], number(row, "time"))
            metrics = self.model.scalars(state, coupling) if resolution == "coarse" else {}
            self.audit.physical(protocol, cycle, f"{resolution}/{phase}", state)
            if metrics:
                self.audit.compare(protocol, cycle, phase, row, metrics)
                sector_probabilities = [metrics[f"sector_probability_{n}"] for n in range(10)]
                self.audit.check(protocol, cycle, phase, "sector_probabilities_sum", sum(sector_probabilities) - 1)
                self.audit.check(protocol, cycle, phase, "negative_sector_probability", min(0.0, min(sector_probabilities)))
                self.audit.check(protocol, cycle, phase, "sector_ergotropy_outside_global_bound",
                                 max(0.0, -metrics["sector_ergotropy"],
                                     metrics["sector_ergotropy"] - metrics["global_ergotropy"]))
            self.audit.manifest.append({
                "protocol": protocol, "cycle": cycle, "phase": phase, "resolution": resolution,
                "time": row["time"], "g": row["g"], "filename": state_path.relative_to(self.root).as_posix(),
                "sha256": state.sha256, "source_initial_state_sha256": self.source_hashes[protocol],
                "size_bytes": SIZE, "dimension": DIM, "format_version": "QWNRHO1/1",
                "tensor_order": "|q1,...,q7,load>; load fastest", "layout": "row-major little-endian complex f64",
            })
            self.states[(*key, resolution)] = Snapshot(state, row["filename"], coupling, metrics)

    def retrieve(self, key, phase, time, coupling=G, resolution="coarse"):
        record = (*key, phase, resolution)
        snapshot = self.states[record]
        require(snapshot.coupling == coupling and ticks(snapshot.state.time) == time,
                f"Unexpected Hamiltonian/time for {record}")
        self.used.add(record)
        return snapshot

    def finish(self):
        require(self.used == self.states.keys(), f"Unexpected snapshots in {self.directory}")
        inventory = {path.relative_to(self.root).as_posix() for path in (self.directory / "states").rglob("*.bin")}
        archived = {row["filename"] for row in self.audit.manifest
                    if row["protocol"] in self.source_hashes
                    and row["filename"].startswith((self.directory / "states").relative_to(self.root).as_posix() + "/")}
        require(inventory == archived, f"Snapshot archive files do not match manifest in {self.directory}")


def verify_grid(audit, key, row, main, half, window, selected, first=0):
    grid = set(range(first, window + 1, 2))
    require(main.keys() == half.keys() == grid, f"Candidate or half-step grid differs for {key}")
    start = ticks(row["start_time"])
    gamma = RATES[key[0][0]]
    for point in grid:
        nominal, fine = main[point], half[point]
        require(ticks(nominal["time"]) == ticks(fine["time"]) == start + point and
                number(nominal, "gamma") == number(fine, "gamma") == gamma and
                number(nominal, "g") == G and ticks(nominal["wait"]) == first,
                f"Candidate clock, coupling or gamma differs for {key}/{point}")
    own_peak = ranked(main, "net_work")
    half_peak = ranked(half, "net_half")
    peak16 = ranked({point: main[point] for point in grid if point <= ALTERNATE_WINDOW}, "net_work")
    expected = own_peak if selected is None else selected
    require(ticks(row["elapsed"]) == expected and ticks(row["time"]) == start + expected,
            f"Candidate selection/timestamp differs for {key}")
    require(row["peak_at_boundary"] == ("true" if own_peak in (first, window) else "false"),
            f"Peak boundary flag differs for {key}")
    for nominal_field, fine_field in (("net_work", "net_half"), ("load_ergotropy", "load_ergotropy_half")):
        audit.check(*key, "half_step", f"{nominal_field}_nominal_column",
                    max(abs(number(main[point], nominal_field) - number(half[point], nominal_field)) for point in grid))
        audit.check(*key, "half_step", f"{nominal_field}_grid_convergence",
                    max(abs(number(main[point], nominal_field) - number(half[point], fine_field)) for point in grid),
                    HALF_TOL)
    for field in ("load_energy_difference", "dissipative_energy_difference", "integrated_current_difference",
                  "global_energy_difference"):
        if field in half[first]:
            audit.check(*key, "half_step", f"{field}_grid_max", max(abs(number(entry, field)) for entry in half.values()),
                        HALF_TOL)
    start_energy = number(main[first], "global_energy")
    start_load = number(main[first], "load_energy")
    first_bath = number(main[first], "dissipative_energy")
    first_current = number(main[first], "integrated_load_current")
    audit.check(*key, "candidate_grid", "energy_bath_balance_max",
                max(abs(number(entry, "global_energy") - start_energy -
                        number(entry, "dissipative_energy") + first_bath) for entry in main.values()))
    audit.check(*key, "candidate_grid", "load_integrated_current_balance_max",
                max(abs(number(entry, "load_energy") - start_load -
                        number(entry, "integrated_load_current") + first_current) for entry in main.values()))
    candidate = main[expected]
    coarse_net, fine_net = number(candidate, "net_work"), number(half[expected], "net_half")
    margin = coarse_net - abs(coarse_net - fine_net)
    compare_fields(audit, key, "selection", row, {
        "selected_candidate_net": coarse_net, "net_half": fine_net, "resolution_margin": margin,
        "half_peak_net": number(half[half_peak], "net_half"), "half_peak_elapsed": half_peak / 100,
        "own_peak_net": number(main[own_peak], "net_work"), "own_peak_elapsed": own_peak / 100,
        "peak16_net": number(main[peak16], "net_work"), "peak16_elapsed": peak16 / 100,
    })
    return candidate, margin, half[expected]


def verify_half_snapshot(audit, model, key, phase, coarse, fine, reported=None):
    difference = max_abs(coarse.state.matrix - fine.state.matrix)
    audit.check(*key, "half_step", f"{phase}_matrix_max_error", difference, HALF_TOL)
    if reported is not None:
        audit.check(*key, "half_step", f"{phase}_matrix_error_cross_check", difference - float(reported))
    metrics = model.scalars(fine.state, fine.coupling)
    for field in ("load_energy", "load_ergotropy", "chain_energy", "global_energy", "global_ergotropy",
                  "sector_ergotropy", "global_purity", "load_purity", "load_current", "mutual_information",
                  "total_excitation", "global_passive_energy", "sector_passive_energy"):
        audit.check(*key, "half_step", f"{phase}_{field}_error", coarse.metrics[field] - metrics[field], HALF_TOL)


def verify_m21_schedule(root, audit):
    path = root / "reference" / "m21" / "m21_cycle_ledger.csv"
    require(hashlib.sha256(path.read_bytes()).hexdigest().upper() == M21_LEDGER_SHA,
            "Published M21 cycle ledger SHA-256 differs")
    audit.check("reference", 2, "m21", "m21_cycle_ledger_sha256_mismatch", 0, 0)
    schedule = {label: {} for label in RATES}
    for row in read_csv(path):
        protocol = row["protocol"]
        if protocol.endswith("_opt") and accepted(row):
            schedule[protocol[0]][int(row["cycle"])] = ticks(row["time"])
    return schedule


@dataclass
class Trial:
    adopted: bool
    next_state: State
    next_half: State
    work: float
    bath: float


def verify_trial(audit, model, archive, key, row, main, half, initial, initial_half, selected, window,
                 wait=0, replay=False):
    gamma = RATES[key[0][0]]
    require(number(row, "gamma") == gamma and number(row, "g") == G and ticks(row["wait"]) == wait,
            f"Trial gamma, coupling or wait differs for {key}")
    start, time = ticks(row["start_time"]), ticks(row["time"])
    require(ticks(initial.time) == ticks(initial_half.time) == start, f"Trial starts at the wrong time for {key}")
    candidate, margin, candidate_half = verify_grid(audit, key, row, main, half, window, selected, first=wait)
    connected, connected_half = initial, initial_half
    cut = reconnect = cut_half = reconnect_half = wait_bath = wait_bath_half = 0.0
    if wait:
        cut_state = archive.retrieve(key, "cut_after", start, 0.0).state
        wait_end = archive.retrieve(key, "wait_end", start + wait, 0.0)
        wait_half = archive.retrieve(key, "wait_end", start + wait, 0.0, "half")
        reconnected = archive.retrieve(key, "reconnect_after", start + wait)
        audit.check(*key, "cut", "instantaneous_state_continuity", max_abs(cut_state.matrix - initial.matrix), 0)
        audit.check(*key, "reconnect", "instantaneous_state_continuity",
                    max_abs(wait_end.state.matrix - reconnected.state.matrix), 0)
        cut = verify_switch(audit, model, key, "cut", cut_state, G, 0.0, row["cut_on"])
        cut_half = verify_switch(audit, model, key, "cut_half", initial_half, G, 0.0, row["cut_half"])
        reconnect = verify_switch(audit, model, key, "reconnect", wait_end.state, 0.0, G, row["reconnect_on"])
        reconnect_half = verify_switch(audit, model, key, "reconnect_half", wait_half.state, 0.0, G, row["reconnect_half"])
        verify_dynamics(audit, model, key, "wait", cut_state, wait_end.state, 0.0, gamma, False)
        verify_dynamics(audit, model, key, "wait_half", initial_half, wait_half.state, 0.0, gamma, False)
        verify_half_snapshot(audit, model, key, "wait_end", wait_end, wait_half, row.get("wait_state_max_abs_difference"))
        wait_bath = model.energy(wait_end.state, 0.0) - model.energy(cut_state, 0.0)
        wait_bath_half = model.energy(wait_half.state, 0.0) - model.energy(initial_half, 0.0)
        connected, connected_half = reconnected.state, wait_half.state
    else:
        for field in ("cut_on", "reconnect_on", "cut_half", "reconnect_half",
                      "dissipative_wait", "dissipative_wait_half"):
            audit.check(*key, "fixed_coupling", f"zero_{field}", number(row, field), 0)

    before = archive.retrieve(key, "before", time)
    before_half = archive.retrieve(key, "before", time, resolution="half")
    end = archive.retrieve(key, "window_end", start + window)
    end_half = archive.retrieve(key, "window_end", start + window, resolution="half")
    require(before.filename == row["before_state"], f"Before-state ledger link differs for {key}")
    verify_half_snapshot(audit, model, key, "before", before, before_half,
                         candidate_half.get("state_max_abs_difference") or None)
    verify_half_snapshot(audit, model, key, "window_end", end, end_half, row.get("window_end_state_max_abs_difference"))
    verify_dynamics(audit, model, key, "continuous_selected", connected, before.state, G, gamma, replay)
    verify_dynamics(audit, model, key, "continuous_window", connected, end.state, G, gamma, False)
    verify_dynamics(audit, model, key, "continuous_selected_half", connected_half, before_half.state, G, gamma, False)
    verify_dynamics(audit, model, key, "continuous_window_half", connected_half, end_half.state, G, gamma, False)
    if gamma == 0:
        verify_unitary_grid(audit, model, key, {point - wait: entry for point, entry in main.items()},
                            connected, cut, reconnect)
        audit.check(*key, "candidate_grid", "gamma0_dissipative_energy_max",
                    max(abs(number(entry, "dissipative_energy")) for entry in main.values()), 0)
        for field in ("dissipative_wait", "dissipative_wait_half", "dissipative_connected", "dissipative_connected_half"):
            audit.check(*key, "continuous_selected", f"gamma0_{field}", number(row, field), 0)

    connected_bath = model.energy(before.state, G) - model.energy(connected, G)
    connected_bath_half = model.energy(before_half.state, G) - model.energy(connected_half, G)
    terminal_bath = model.energy(end.state, G) - model.energy(connected, G)
    verify_candidate_state(audit, model, key, "selected_candidate", candidate, before.state, cut, reconnect, connected_bath)
    verify_candidate_state(audit, model, key, "window_end_candidate", main[window], end.state, cut, reconnect, terminal_bath)
    verify_candidate_state(audit, model, key, "first_candidate", main[wait], connected, cut, reconnect, 0.0)

    adopted = accepted(row)
    after = archive.retrieve(key, "after", time) if adopted else None
    after_half = archive.retrieve(key, "after", time, resolution="half") if adopted else None
    require(row["after_state"] == (after.filename if after is not None else ""), f"After-state ledger link differs for {key}")
    gross, jump, work, virtual = verify_extraction(audit, model, key, before.state, after.state if after else None)
    _, _, work_half, _ = verify_extraction(audit, model, key, before_half.state, after_half.state if after_half else None)
    net, net_half = work - cut - reconnect, work_half - cut_half - reconnect_half
    audit.check(*key, "extraction", "local_work_exceeds_analytic_bound",
                max(0.0, work - before.metrics["any_local_unitary_full_work_upper_bound"]))
    require(adopted == (margin > TOL and net > TOL), f"M20 numerical adoption rule differs for {key}")
    if adopted:
        verify_half_snapshot(audit, model, key, "after", after, after_half, row.get("after_state_max_abs_difference"))

    first_energy = model.energy(initial, G)
    final_energy = model.energy(virtual, G)
    outcome = first_energy + number(row, "dissipative_wait") + number(row, "dissipative_connected") - net
    audit.check(*key, "extraction", "all_hamiltonian_cycle_energy_balance", final_energy - outcome)
    compare_fields(audit, key, "ledger", row, {
        "start_total_energy": first_energy, "pre_total_energy": model.energy(before.state, G),
        "post_total_energy": final_energy, "gross_work": gross, "interaction_jump": jump,
        "total_work": work, "net_work": net, "dissipative_wait": wait_bath,
        "dissipative_connected": connected_bath, "balance_residual": final_energy - outcome,
        "net_half_direct": net_half, "dissipative_wait_half": wait_bath_half, "dissipative_connected_half": connected_bath_half,
        "selected_load_current": before.metrics["load_current"],
        "selected_integrated_load_current": before.metrics["load_energy"] - model.local_scalars(connected.matrix, G)["load_energy"],
        "continuous_post_energy": final_energy if adopted else model.energy(before.state, G),
    })
    return Trial(
        adopted, after.state if adopted else before.state, after_half.state if adopted else before_half.state,
        net, number(row, "dissipative_wait") + number(row, "dissipative_connected"),
    )


def verify_repeated(root, audit, model, anchor, schedule, window, benchmark):
    ledger = keyed(read_csv(root / "m22_cycle_ledger.csv"), ("protocol", "cycle"), "repeated cycle ledger")
    candidates = load_grid(root / "m22_candidates.csv")
    half = load_grid(root / "m22_half_step.csv")
    names = {key[0] for key in ledger}
    require(names <= PROTOCOLS.keys() and (benchmark or names == PROTOCOLS.keys()), "Unexpected repeated protocols")
    archive = SnapshotArchive(root, root, audit, model, dict.fromkeys(names, anchor.sha256))
    require(ledger.keys() == candidates.keys() == half.keys(), "Repeated ledger/candidate coverage differs")
    origin = ticks(anchor.time)
    anchor_energy = model.energy(anchor, G)
    anchor_ergotropy = model.scalars(anchor, G)["global_ergotropy"]
    for protocol in sorted(names):
        gamma = RATES[protocol[0]]
        matched = protocol.endswith("_matched")
        snapshot = archive.retrieve((protocol, "2"), "anchor", origin)
        require(snapshot.state.sha256 == ANCHOR_SHA, f"Incorrect M18 anchor for {protocol}")
        existing = sorted(int(key[1]) for key in ledger if key[0] == protocol)
        require(existing == list(range(FIRST_CYCLE, existing[-1] + 1)) and existing[-1] <= LAST_CYCLE,
                f"Non-contiguous cycle list for {protocol}")
        partner = schedule[protocol[0]]
        if benchmark and matched:
            require(protocol == "A_matched" and existing == [3, 4], "Wrong registered skip benchmark schedule")
            partner = {3: origin, 4: origin + BENCH_WINDOW}
        if matched and not benchmark:
            require(existing == sorted(partner), f"M21 schedule coverage differs for {protocol}")
        expected_start = anchor
        expected_half = anchor
        last_adopted, count, cumulative, cumulative_bath = origin, 0, 0.0, 0.0
        failed = False
        for cycle in existing:
            key = protocol, str(cycle)
            row = ledger[key]
            require(not failed, f"Optimization continues after rejected trial for {key}")
            start, time = ticks(row["start_time"]), ticks(row["time"])
            require(ticks(expected_start.time) == start, f"Previous trial timestamp differs for {key}")
            start_snapshot = archive.retrieve(key, "start", start)
            audit.check(*key, "sequence", "previous_state_reused_exactly",
                        max_abs(start_snapshot.state.matrix - expected_start.matrix), 0)
            selected = partner[cycle] - start if matched else None
            trial = verify_trial(audit, model, archive, key, row, candidates[key], half[key],
                                 start_snapshot.state, expected_half, selected, window,
                                 replay=cycle == FIRST_CYCLE and protocol in ("A_opt", "B_opt"))
            compare_fields(audit, key, "sequence", row, {
                "anchor_model_time": ANCHOR_TIME, "last_adopted_time_before": last_adopted / 100,
                "cycle_rate": trial.work * 100 / (time - last_adopted) if time != last_adopted else 0.0,
                "opportunity_rate": trial.work * 100 / (time - start) if time != start else 0.0,
            })
            if trial.adopted:
                last_adopted = time
                count += 1
                cumulative += trial.work
            observed_bath = cumulative_bath + trial.bath
            if trial.adopted or matched:
                cumulative_bath = observed_bath
            expected_start, expected_half = trial.next_state, trial.next_half
            limit = existing[-1] if benchmark or matched else LAST_CYCLE
            reason = ("cycle_cap" if cycle == limit else "adopted") if trial.adopted else (
                "scheduled_skip" if matched else "adoption_failure")
            require(row["stop_reason"] == reason, f"Stop reason differs for {key}: {row['stop_reason']}")
            compare_fields(audit, key, "sequence", row, {
                "attempted_elapsed_since_anchor": (time - origin) / 100,
                "accepted_elapsed_since_anchor": (last_adopted - origin) / 100,
                "cumulative_m22_net": cumulative, "net_plus_history": cumulative + HISTORY,
                "cumulative_rate": cumulative * 100 / (time - origin) if time != origin else 0.0,
                "adopted_count": count, "cumulative_dephasing_energy": cumulative_bath,
            })
            balance = model.energy(expected_start, G) - anchor_energy - observed_bath + cumulative
            audit.check(*key, "sequence", "actual_cumulative_energy_balance", balance)
            if trial.adopted or matched:
                compare_fields(audit, key, "sequence", row, {"cumulative_balance_residual": balance})
            if gamma == 0:
                metrics = model.scalars(expected_start, G)
                audit.check(*key, "sequence", "gamma0_cumulative_global_ergotropy_work_identity",
                            metrics["global_ergotropy"] - anchor_ergotropy + cumulative)
                audit.check(*key, "sequence", "gamma0_anchor_spectrum_max_drift",
                            max_abs(expected_start.eigenvalues - anchor.eigenvalues))
            failed = not matched and not trial.adopted
        require(benchmark or matched or failed or existing[-1] == LAST_CYCLE,
                f"Repeated optimized protocol ends early: {protocol}")
    archive.finish()


def verify_single_inputs(root, audit, schedule, benchmark):
    path = root / "reference" / "m21" / "m21_state_manifest.csv"
    require(hashlib.sha256(path.read_bytes()).hexdigest().upper() == M21_MANIFEST_SHA,
            "Published M21 state manifest SHA-256 differs")
    audit.check("reference", 2, "m21", "m21_state_manifest_sha256_mismatch", 0, 0)
    old_rows = [row for row in read_csv(path)
                if row["resolution"] == "coarse" and row["protocol"].endswith("_opt")]
    old = keyed(old_rows, ("protocol", "cycle", "phase"), "M21 snapshot provenance")
    inputs = keyed(read_csv(root / "single_inputs.csv"), ("rate", "source"), "single-source registration")
    expected = {(label, source) for label in RATES for source in SOURCE_CYCLES}
    require(inputs.keys() <= expected and (benchmark or inputs.keys() == expected), "Single-source registration is incomplete")
    for (rate, source), row in inputs.items():
        source_cycle = SOURCE_CYCLES[source]
        require(number(row, "gamma") == RATES[rate] and int(row["source_cycle"]) == source_cycle,
                f"Wrong source cycle or gamma for {rate}/{source}")
        original = old[rate + "_opt", str(source_cycle), "anchor" if source_cycle == 2 else "after"]
        require(original["source_initial_state_sha256"] == ANCHOR_SHA and number(original, "g") == G,
                f"Wrong M21 source history for {rate}/{source}")
        origin = ticks(original["time"])
        require(ticks(row["source_time"]) == origin, f"Single-source time differs from M21 for {rate}/{source}")
        registered = archive_path(root, row["source_filename"], {"m18_inputs", "reference", "single_inputs"})
        saved = State.from_file(registered, origin / 100)
        require(saved.sha256 == row["source_sha256"].upper() == original["sha256"].upper(),
                f"Single-source hash differs from M21 for {rate}/{source}")
        if not benchmark:
            target = 1200 if source == "end" else schedule[rate][source_cycle + 1] - origin
            require(ticks(row["selected_elapsed"]) == target, f"Single-source primary time differs for {rate}/{source}")
        audit.check(f"{rate}_{source}", source_cycle, "single_source", "m21_input_snapshot_sha256_mismatch", 0, 0)
    return inputs


def verify_single(root, audit, model, schedule, window, benchmark):
    single = root / "single"
    inputs = verify_single_inputs(root, audit, schedule, benchmark)
    ledger = keyed(read_csv(single / "m22_cycle_ledger.csv"), ("protocol", "cycle"), "single cycle ledger")
    candidates = load_grid(single / "m22_candidates.csv")
    half = load_grid(single / "m22_half_step.csv")
    require(ledger.keys() == candidates.keys() == half.keys(), "Single ledger/candidate coverage differs")
    expected = {f"{label}_{source}_{strategy}": row for (label, source), row in inputs.items()
                for strategy in ("connected", "wait")}
    names = {key[0] for key in ledger}
    require(len(names) == len(ledger) and names <= expected.keys() and (benchmark or names == expected.keys()),
            "Single-extraction protocols do not match registration")
    archive = SnapshotArchive(root, single, audit, model, {name: expected[name]["source_sha256"].upper() for name in names})
    for key, row in ledger.items():
        protocol, cycle = key
        registered = expected[protocol]
        source_cycle = int(registered["source_cycle"])
        require(int(cycle) == source_cycle + 1, f"Single cycle ID differs for {key}")
        origin = ticks(registered["source_time"])
        primary = BENCH_SINGLE_WINDOW if benchmark else ticks(registered["selected_elapsed"])
        snapshot = archive.retrieve((protocol, str(source_cycle)), "anchor", origin)
        require(snapshot.state.sha256 == registered["source_sha256"].upper(), f"Single archive source hash differs for {key}")
        require(snapshot.filename == registered["source_filename"], f"Single archive source path differs for {key}")
        if (*key, "start", "coarse") in archive.states:
            start_snapshot = archive.retrieve(key, "start", origin)
            audit.check(*key, "sequence", "source_state_reused_exactly", max_abs(start_snapshot.state.matrix - snapshot.state.matrix), 0)
        wait = WAIT if protocol.endswith("_wait") else 0
        trial = verify_trial(audit, model, archive, key, row, candidates[key], half[key],
                             snapshot.state, snapshot.state, primary, window, wait)
        reason = "diagnostic_adopted" if trial.adopted else "diagnostic_below_floor"
        require(row["stop_reason"] == reason, f"Wrong single-extraction status for {key}")
        credited_work = trial.work if trial.adopted else 0.0
        compare_fields(audit, key, "sequence", row, {
            "anchor_model_time": origin / 100, "last_adopted_time_before": origin / 100,
            "attempted_elapsed_since_anchor": primary / 100, "accepted_elapsed_since_anchor": primary / 100 if trial.adopted else 0.0,
            "cycle_rate": trial.work * 100 / primary if primary else 0.0,
            "opportunity_rate": trial.work * 100 / primary if primary else 0.0,
            "cumulative_m22_net": credited_work, "cumulative_rate": credited_work * 100 / primary if primary else 0.0,
            "net_plus_history": credited_work, "adopted_count": int(trial.adopted),
            "cumulative_dephasing_energy": trial.bath if trial.adopted else 0.0,
        })
        if trial.adopted:
            balance = model.energy(trial.next_state, G) - model.energy(snapshot.state, G) - trial.bath + trial.work
            audit.check(*key, "sequence", "single_cumulative_energy_balance", balance)
            compare_fields(audit, key, "sequence", row, {"cumulative_balance_residual": balance})
            if RATES[protocol[0]] == 0.0:
                after_ergotropy = model.scalars(trial.next_state, G)["global_ergotropy"]
                audit.check(*key, "sequence", "gamma0_single_global_ergotropy_work_identity",
                            after_ergotropy - snapshot.metrics["global_ergotropy"] + trial.work)
    archive.finish()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path)
    parser.add_argument("--benchmark", action="store_true", help="Allow the preregistered subsets of shortened runs")
    parser.add_argument("--window", help="Explicit repeated-run search window")
    parser.add_argument("--single-window", help="Explicit single-extraction search window")
    parser.add_argument("--read-only", action="store_true", help="Run without writing the audit tables")
    args = parser.parse_args()
    root = args.results.resolve()
    window = ticks(args.window) if args.window is not None else BENCH_WINDOW if args.benchmark else WINDOW
    single_window = ticks(args.single_window) if args.single_window is not None else BENCH_SINGLE_WINDOW if args.benchmark else WINDOW
    for length in (window, single_window):
        require(length % 2 == 0 and 0 <= length <= WINDOW and (args.benchmark or length == WINDOW),
                "Invalid registered search window")
    audit, model = Audit(), Model()
    for g in (0, G):
        number_commutator = model.h[g] * (OCCUPATION[None, :] - OCCUPATION[:, None])
        audit.check("all", 2, "model", f"hamiltonian_excitation_commutator_g{g}", max_abs(number_commutator), 0)
    anchor = verify_anchor(root / "m18_inputs", audit, model)
    schedule = verify_m21_schedule(root, audit)
    verify_repeated(root, audit, model, anchor, schedule, window, args.benchmark)
    if not args.benchmark or (root / "single" / "m22_cycle_ledger.csv").is_file():
        verify_single(root, audit, model, schedule, single_window, args.benchmark)
    if not args.read_only:
        write_csv(root / "m22_independent_audit.csv", audit.rows)
        write_csv(root / "m22_state_manifest.csv", audit.manifest)
    failed = [row for row in audit.rows if row["status"] == "FAIL"]
    for row in failed[:30]:
        print(row)
    print(f"Independent M22 verification: {len(audit.rows) - len(failed)}/{len(audit.rows)} passed.")
    return bool(failed)


if __name__ == "__main__":
    raise SystemExit(main())
