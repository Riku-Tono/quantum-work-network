"""Independent exponentiation, provenance, and ledger checks for M23."""

import argparse
from dataclasses import dataclass
from functools import cached_property
import hashlib
import math
from pathlib import Path, PurePosixPath

from verify_m21 import (
    ANCHOR_SHA,
    DIM,
    G,
    HALF_TOL,
    OCCUPATION,
    SIZE,
    TOL,
    Audit,
    Model,
    State,
    apply_to_load,
    keyed,
    marginals,
    max_abs,
    np,
    passivating_unitary,
    read_csv,
    require,
    verify_dynamics,
    verify_extraction,
    write_csv,
)


M22_SOURCES = {
    "S0": (2, 15900, ANCHOR_SHA, "anchor"),
    "S1": (6, 55760, "A4BF4D0453CD5BAC3EFD192409EEF8CCE7FDC64862D783621B39314E107B7640", "mid"),
    "S2": (10, 93380, "EC8CAF75EE5FBF75BFA354F068B38BBEA2349B4E3D0F19272266766B95D88B8F", "end"),
}
REFERENCE_HASHES = {
    "single_inputs.csv": "2395FBFD5CE114AB95792FD79579360B77EBB2E4A310E7E13BBF91CBF03C9097",
    "m22_candidates.csv": "590A8BA17EDEB002AF65B23C4B2AF242952F82A516580B97A24318200A4B8090",
    "m22_half_step.csv": "4D8A76D5EDA2A7C85683C75329DA8A64A11F5141AAE33A7A5006B00F78E272F7",
}
REPEAT_REFERENCE = {
    "A": ("m22", "C_opt", "C01E2A89A44969F0B5F7CF3DEBF784822E8FB2AEB00949E3EDB852E9A74EBDBF"),
    "B": ("m21", "C_opt", "A1CEAEE96C0A1403FEC3F3F5A7C12C767F6D72D5A14E75B66B64BDBFBCB69003"),
}
TOTAL = 18000
SAMPLE = 20
WAIT_STEP = 250
WAIT_FINE_STEP = 25
MAX_WAIT = 6000
SWITCH_TOL = 1e-15


def ticks(value):
    time = float(value)
    require(math.isfinite(time), f"Non-finite clock: {value}")
    tick = round(time * 1000)
    require(abs(time - tick / 1000) <= TOL, f"Clock outside millisecond lattice: {value}")
    return tick


def number(row, name):
    value = float(row[name])
    require(math.isfinite(value), f"Non-finite {name}")
    return value


def boolean(row, field):
    value = str(row[field]).lower()
    require(value in ("true", "false"), f"Invalid boolean flag: {field}={row[field]}")
    return value == "true"


def digest(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest().upper()


def path_in(root, name):
    relative = PurePosixPath(name)
    require(relative.parts and not relative.is_absolute() and ".." not in relative.parts
            and "\\" not in name and ":" not in name, f"Invalid archive path {name}")
    return root / relative


def compare_present(audit, key, phase, row, expected, bound=TOL):
    audit.compare(*key, phase, row, {name: value for name, value in expected.items() if name in row}, bound)


@dataclass
class Source:
    label: str
    cycle: int
    state: State
    filename: str


class SnapshotArchive:
    def __init__(self, root, audit, prefix=""):
        self.root, self.audit = root, audit
        self.prefix = prefix
        self.states = {}

    def read(self, filename, expected_time, source_sha, key, phase, resolution="coarse", g=G):
        if filename not in self.states:
            state = State.from_file(path_in(self.root, filename), expected_time / 1000)
            self.states[filename] = state
        state = self.states[filename]
        require(ticks(state.time) == expected_time, f"Inconsistent state time: {filename}")
        self.audit.physical(*key, f"{resolution}/{phase}", state)
        self.audit.manifest.append({
            "protocol": key[0], "cycle": key[1], "phase": phase, "resolution": resolution,
            "time": state.time, "g": g, "filename": self.prefix + filename, "sha256": state.sha256,
            "source_initial_state_sha256": source_sha, "size_bytes": SIZE, "dimension": DIM,
            "format_version": "QWNRHO1/1", "tensor_order": "|q1,...,q7,load>; load fastest",
            "layout": "row-major little-endian complex f64",
        })
        return state


class Snapshots:
    def __init__(self, root, archive):
        rows = read_csv(root / "m23_state_manifest.csv")
        self.rows = {(*scan_key(row), row["phase"], row["resolution"]): row for row in rows}
        require(len(self.rows) == len(rows), "Duplicate M23 saved-state key")
        require(all(row["resolution"] in ("coarse", "half") for row in rows), "Invalid state resolution tag")
        self.archive = archive
        self.used = set()
        self.metrics = {}
        path = root / "m23_state_metrics.csv"
        if path.is_file():
            measured = read_csv(path)
            self.metrics = {(*scan_key(row), row["phase"], row["resolution"]): row for row in measured}
            require(self.rows.keys() == self.metrics.keys() and len(measured) == len(self.metrics),
                    "Saved-state metrics and manifest coverage differ")

    def has(self, key, phase, resolution):
        return (*key, phase, resolution) in self.rows

    def load(self, key, phase, resolution, time, source, model, g=G):
        full_key = (*key, phase, resolution)
        row = self.rows[full_key]
        require(ticks(row["time"]) == time, f"Mis-timed state at {full_key}")
        if "g" in row:
            require(number(row, "g") == g, f"Wrong Hamiltonian tag at {full_key}")
        label = scan_label(key)
        state = self.archive.read(row["filename"], time, source.state.sha256, label, phase, resolution, g)
        require(state.sha256 == row["sha256"].upper(), f"M23 snapshot SHA-256 mismatch: {row['filename']}")
        if self.metrics:
            diagnostics = self.metrics[full_key]
            require(all(diagnostics[field] == row[field] for field in ("time", "filename", "sha256", "g")),
                    f"Saved-state metrics metadata differs for {full_key}")
            compare_present(self.archive.audit, label, f"{resolution}/{phase}", diagnostics, model.scalars(state, g))
        self.used.add(full_key)
        return state

    def finish(self):
        require(self.used == self.rows.keys(), f"Unchecked saved-state keys: {self.rows.keys() - self.used}")
        root = self.archive.root
        written = {path.relative_to(root).as_posix() for path in (root / "states").rglob("*.bin")}
        require(written == {row["filename"] for row in self.rows.values() if row["filename"].startswith("states/")},
                "State inventory and M23 manifest differ")


@dataclass
class ExactAttempt:
    """Full-Hamiltonian exponentiation independent of the projected RK4 solver."""

    model: Model
    start: State
    wait_tick: int

    @cached_property
    def waited(self):
        return self.model.evolve(self.start, 0.0, 0.0, self.wait_tick / 1000)

    @cached_property
    def cut_and_reconnect(self):
        if self.wait_tick == 0:
            return 0.0, 0.0
        return -G * self.model.exchange_expectation(self.start), G * self.model.exchange_expectation(self.waited)

    @cached_property
    def waited_load_energy(self):
        return self.model.local_scalars(self.waited.matrix, G)["load_energy"]

    def before(self, connected_tick):
        return self.model.evolve(self.waited, G, 0.0, connected_tick / 1000)

    def observations(self, connected_tick):
        before = self.before(connected_tick)
        work = terminal_observations(self.model, before)
        cut, reconnect = self.cut_and_reconnect
        return {
            **work, "net_work": work["total_work"] - cut - reconnect,
            "cut_on": cut, "reconnect_on": reconnect, "global_energy": self.model.energy(before, G),
            "integrated_load_current": work["load_energy"] - self.waited_load_energy,
            "dissipative_energy": 0.0,
        }


def terminal_observations(model, state):
    load, _, terminal = marginals(state.matrix)
    work = model.terminal_scalars(terminal, G)
    # <sigma_7^+ a> uses the lowering load operator. Its real part determines
    # the exchange work and its imaginary part sets the signed load current.
    c = terminal[1, 3] + np.sqrt(2) * terminal[2, 4]
    coherence = load - np.diag(np.diag(load))
    return {
        **work, "c_real": c.real, "c_imag": c.imag, "c_abs": abs(c),
        "terminal_population": np.trace(terminal[3:, 3:]).real,
        "load_coherence_frobenius": float(np.linalg.norm(coherence)),
        **{f"load_p{level}": load[level, level].real for level in range(3)},
        **{f"load_coherence_{row}{col}_{component}": getattr(load[row, col], component)
           for row, col in ((0, 1), (0, 2), (1, 2)) for component in ("real", "imag")},
    }


def verify_work(audit, model, key, initial, waited, before, after, row, tau):
    if tau:
        cut = verify_switch(audit, model, key, "cut", initial, G, 0.0, number(row, "cut_on"))
        reconnect = verify_switch(audit, model, key, "reconnect", waited, 0.0, G, number(row, "reconnect_on"))
        verify_dynamics(audit, model, key, "wait", initial, waited, 0.0, 0.0, False)
    else:
        cut = reconnect = 0.0
        audit.check(*key, "continuous", "zero_cut_work", number(row, "cut_on"), 0)
        audit.check(*key, "continuous", "zero_reconnect_work", number(row, "reconnect_on"), 0)
        audit.check(*key, "continuous", "no_wait_state_change", max_abs(initial.matrix - waited.matrix), 0)
    verify_dynamics(audit, model, key, "connected", waited, before, G, 0.0, False)
    gross, jump, extracted, virtual = verify_extraction(audit, model, key, before, after)
    net = extracted - cut - reconnect
    energy_initial, energy_final = model.energy(initial, G), model.energy(virtual, G)
    initial_metrics = model.scalars(initial, G)
    final_metrics = model.scalars(virtual, G)
    audit.check(*key, "work", "full_hamiltonian_energy_balance", energy_final - energy_initial + net)
    audit.check(*key, "work", "global_ergotropy_net_work_identity",
                final_metrics["global_ergotropy"] - initial_metrics["global_ergotropy"] + net)
    audit.check(*key, "extraction", "total_excitation_drop_equals_bare_load_work",
                np.dot(OCCUPATION, np.diag(virtual.matrix - before.matrix).real) + gross)
    compare_present(audit, key, "work", row, {
        "gross_work": gross, "interaction_jump": jump, "total_work": extracted, "net_work": net,
        "start_total_energy": energy_initial, "pre_total_energy": model.energy(before, G),
        "post_total_energy": energy_final, "balance_residual": energy_final - energy_initial + net,
    })
    return net, virtual


def verify_switch(audit, model, key, phase, state, before_g, after_g, recorded):
    work = (after_g - before_g) * model.exchange_expectation(state)
    direct = model.energy(state, after_g) - model.energy(state, before_g)
    audit.check(*key, phase, "switch_work_linear_cross_check", recorded - work, SWITCH_TOL)
    audit.check(*key, phase, "switch_work_direct_cross_check", recorded - direct, SWITCH_TOL)
    return work


def verify_convergence(audit, model, key, phase, nominal, half, g, reported=None):
    error = max_abs(nominal.matrix - half.matrix)
    audit.check(*key, "half_step", f"{phase}_density_error", error, HALF_TOL)
    if reported is not None:
        audit.check(*key, "half_step", f"{phase}_reported_density_error", error - reported)
    left, right = model.scalars(nominal, g), model.scalars(half, g)
    for field in ("load_energy", "load_ergotropy", "load_current", "global_energy", "global_ergotropy",
                  "global_purity", "sector_ergotropy", "global_passive_energy", "sector_passive_energy",
                  "total_excitation", "mutual_information", "load_purity"):
        audit.check(*key, "half_step", f"{phase}_{field}_error", left[field] - right[field], HALF_TOL)


def load_reference(reference, audit):
    tables = {}
    for filename, sha256 in REFERENCE_HASHES.items():
        nested = reference / "single" / filename
        path = nested if nested.is_file() else reference / filename
        require(digest(path) == sha256, f"M22 reference SHA-256 differs for {filename}")
        audit.check("reference", 0, "m22_provenance", f"{filename}_sha256_mismatch", 0, 0)
        tables[filename] = read_csv(path)
    registered = {row["source"]: row for row in tables["single_inputs.csv"] if row["rate"] == "C"}
    for source, (cycle, clock, sha256, stage) in M22_SOURCES.items():
        row = registered[stage]
        require((int(row["source_cycle"]), ticks(row["source_time"]), row["source_sha256"].upper(), number(row, "gamma"))
                == (cycle, clock, sha256, 0.0), f"Published rate-zero M22 source metadata differs for {source}")
    grids = {}
    for field, filename in (("nominal", "m22_candidates.csv"), ("half", "m22_half_step.csv")):
        for row in tables[filename]:
            protocol = row["protocol"]
            if not protocol.startswith("C_"):
                continue
            grid = grids.setdefault((field, protocol), {})
            point = ticks(row["elapsed"])
            require(point not in grid, f"Duplicate reference candidate {protocol}/{point}")
            grid[point] = row
    return grids


def load_sources(root, archive, audit):
    rows = read_csv(root / "m23_sources.csv")
    require({row["source"] for row in rows} == M22_SOURCES.keys() and len(rows) == len(M22_SOURCES),
            "M23 source registry differs from preregistered sources")
    result = {}
    for row in rows:
        label = row["source"]
        cycle, clock, sha256, _ = M22_SOURCES[label]
        require((int(row["source_cycle"]), ticks(row["source_time"]), row["sha256"].upper()) == (cycle, clock, sha256),
                f"M23 registered metadata differs for {label}")
        state = archive.read(row["filename"], clock, sha256, ("source/" + label, cycle), "anchor")
        require(state.sha256 == sha256, f"M23 source SHA-256 differs for {label}")
        audit.check("source/" + label, cycle, "provenance", "published_source_sha256_mismatch", 0, 0)
        result[label] = Source(label, cycle, state, row["filename"])
    return result


def verify_reference_grid(audit, key, source, tau, grid, half_grid, reference, total):
    stage = M22_SOURCES[source][3]
    method = {0: "connected", 2000: "wait"}[tau]
    protocol = f"C_{stage}_{method}"
    for resolution, entries, fields in (
        ("nominal", grid, ("net_work", "total_work", "gross_work", "load_ergotropy", "load_energy",
                           "load_purity", "global_energy", "load_current", "integrated_load_current")),
        ("half", half_grid, ("net_half", "load_ergotropy_half")),
    ):
        expected = reference[resolution, protocol]
        clock = {point for point in expected if point <= total}
        require(entries.keys() == clock, f"M23 shared grid differs from archived M22 for {key}/{tau}/{resolution}")
        for field in fields:
            if field in entries[min(clock)]:
                error = max(abs(number(entries[point], field) - number(expected[point], field)) for point in clock)
                audit.check(*key, f"m22_reference_{resolution}", f"tau{tau}_{field}_max_error", error, HALF_TOL)


def peak_at(grid, field="net_work"):
    return min(grid, key=lambda time: (-number(grid[time], field), time))


def verify_exact_samples(audit, key, attempt, tau, grid):
    """Audit the endpoints and selected time of a projected candidate scan."""
    first, last, peak = min(grid), max(grid), peak_at(grid)
    interior = min(grid, key=lambda time: abs(2 * time - first - last))
    phases = ("first", "interior", "peak", "last")
    for phase, elapsed in zip(phases, (first, interior, peak, last)):
        expected = attempt.observations(elapsed - tau)
        compare_present(audit, key, f"exact_gamma0/{phase}", grid[elapsed], expected, HALF_TOL)


def verify_scan_balances(audit, key, grid):
    """Check physical balances at every stored candidate, before any extraction."""
    start = grid[min(grid)]
    if "global_energy" in start:
        energy = number(start, "global_energy")
        audit.check(*key, "candidate_grid", "global_energy_max_drift",
                    max(abs(number(row, "global_energy") - energy) for row in grid.values()))
    if {"load_energy", "integrated_load_current"} <= start.keys():
        load = number(start, "load_energy") - number(start, "integrated_load_current")
        audit.check(*key, "candidate_grid", "load_integrated_current_balance_max",
                    max(abs(number(row, "load_energy") - number(row, "integrated_load_current") - load)
                        for row in grid.values()))
    if {"total_work", "cut_on", "reconnect_on"} <= start.keys():
        audit.check(*key, "candidate_grid", "net_switch_accounting_max",
                    max(abs(number(row, "net_work") - number(row, "total_work") +
                            number(row, "cut_on") + number(row, "reconnect_on")) for row in grid.values()))
    if {"gross_work", "load_ergotropy"} <= start.keys():
        audit.check(*key, "candidate_grid", "gross_work_matches_load_ergotropy_max",
                    max(abs(number(row, "gross_work") - number(row, "load_ergotropy")) for row in grid.values()))
    if "dissipative_energy" in start:
        audit.check(*key, "candidate_grid", "zero_dissipative_energy",
                    max(abs(number(row, "dissipative_energy")) for row in grid.values()), 0)
    if "net_half" in start:
        audit.check(*key, "candidate_grid", "net_timestep_difference_max",
                    max(abs(number(row, "net_work") - number(row, "net_half")) for row in grid.values()), HALF_TOL)
    if {"load_ergotropy", "load_ergotropy_half"} <= start.keys():
        audit.check(*key, "candidate_grid", "load_ergotropy_timestep_difference_max",
                    max(abs(number(row, "load_ergotropy") - number(row, "load_ergotropy_half"))
                        for row in grid.values()), HALF_TOL)


def scan_key(row):
    return row["scan"], row["source"], int(row["cycle"]), ticks(row["tau"])


def scan_label(key):
    scan, source, cycle, tau = key
    return f"{scan}/{source}/tau={tau / 1000:.3f}", cycle


def read_candidates(path):
    grids = {}
    for row in read_csv(path):
        key = scan_key(row)
        elapsed = ticks(row["elapsed_total"])
        require(ticks(row["elapsed_connected"]) == elapsed - key[3], f"Candidate clock differs for {key}/{elapsed}")
        grid = grids.setdefault(key, {})
        require(elapsed not in grid, f"Duplicate candidate for {key}/{elapsed}")
        grid[elapsed] = row
    return grids


def read_wait_summary(path):
    rows = read_csv(path)
    summaries = {scan_key(row): row for row in rows}
    require(len(rows) == len(summaries), "Duplicate wait-summary key")
    return summaries


def expected_grid(tau, total):
    return set(range(tau, total + 1, SAMPLE))


def verify_candidate_grid(audit, model, key, grid, summary, initial, total):
    tau = key[3]
    label = scan_label(key)
    require(grid.keys() == expected_grid(tau, total), f"Reconnect-relative candidate grid differs for {key}")
    peak = peak_at(grid)
    fine_peak = peak_at(grid, "net_half")
    ergo_peak = peak_at(grid, "load_ergotropy")
    require(ticks(summary["best_elapsed_total"]) == peak and ticks(summary["best_elapsed_connected"]) == peak - tau,
            f"Candidate ranking or peak clock differs for {key}")
    compare_present(audit, label, "ranking", summary, {
        "max_net": number(grid[peak], "net_work"),
        "max_net_half": number(grid[peak], "net_half"),
        "max_net_half_own": number(grid[fine_peak], "net_half"),
        "selected_net_half": number(grid[peak], "net_half"),
        "best_elapsed_total_half": fine_peak / 1000,
        "best_elapsed_connected_half": (fine_peak - tau) / 1000,
        "best_half_elapsed_connected": (fine_peak - tau) / 1000,
        "candidate_count": len(grid),
        "max_load_ergotropy_elapsed_total": ergo_peak / 1000,
        "max_load_ergotropy": number(grid[ergo_peak], "load_ergotropy"),
        "selected_net_timestep_difference": abs(number(grid[peak], "net_work") - number(grid[peak], "net_half")),
    })
    verify_scan_balances(audit, label, grid)
    for field in ("load_energy", "load_current"):
        audit.check(*label, "candidate_grid", f"{field}_timestep_difference_max",
                    max(abs(number(row, field) - number(row, field + "_half")) for row in grid.values()), HALF_TOL)
    attempt = ExactAttempt(model, initial, tau)
    verify_exact_samples(audit, label, attempt, tau, grid)
    waited = attempt.waited
    reconnect = {**model.scalars(waited, G), **terminal_observations(model, waited)}
    compare_present(audit, label, "reconnection_observables", summary, {
        **{f"reconnect_{field}": value for field, value in reconnect.items()},
        "reconnect_current": reconnect["load_current"],
        "max_load_ergotropy": max(number(row, "load_ergotropy") for row in grid.values()),
        "integrated_current_at_best": number(grid[peak], "load_energy") - number(grid[tau], "load_energy"),
    }, HALF_TOL)
    require(ticks(summary["anchor_time"]) == ticks(initial.time), f"Wrong initial time in wait summary {key}")
    if "best_net_at_grid_endpoint" in summary:
        require(boolean(summary, "best_net_at_grid_endpoint") == (peak in (min(grid), max(grid))),
                f"Mislabeled search endpoint for {key}")
    if "best_rate" in summary:
        usable = [time for time, row in grid.items() if time > 0 and candidate_admissible(row)]
        if usable:
            best_rate = min(usable, key=lambda time: (-number(grid[time], "net_work") * 1000 / time, time))
            compare_present(audit, label, "ranking", summary, {
                "best_rate": number(grid[best_rate], "net_work") * 1000 / best_rate,
                "best_rate_elapsed_total": best_rate / 1000,
                "best_rate_net": number(grid[best_rate], "net_work"),
            })
        else:
            require(summary["best_rate"] == "", f"Unresolved candidates credited for time efficiency: {key}")
    if "direct_net" in summary:
        verify_trial_summary(audit, model, label, summary, attempt, peak - tau, total - tau, grid[peak])
    return peak


def verify_trial_summary(audit, model, label, summary, attempt, delay, horizon_delay, candidate):
    before, horizon = attempt.before(delay), attempt.before(horizon_delay)
    load, _, _ = marginals(before.matrix)
    _, op = passivating_unitary(load)
    after = State(apply_to_load(before.matrix, op), before.time)
    checkpoints = (("best", before), ("horizon", horizon), ("virtual_after", after))
    for phase, state in checkpoints:
        metrics = model.scalars(state, G)
        compare_present(audit, label, "exact_checkpoints", summary,
                        {f"{phase}_{name}": value for name, value in metrics.items()}, HALF_TOL)
    cut, reconnect = attempt.cut_and_reconnect
    extracted = model.energy(before, G) - model.energy(after, G)
    net = extracted - cut - reconnect
    compare_present(audit, label, "exact_work", summary, {
        "start_global_energy": model.energy(attempt.start, G), "pre_global_energy": model.energy(before, G),
        "post_global_energy": model.energy(after, G), "direct_total_work": extracted, "direct_net": net,
        "integrated_current_horizon": model.local_scalars(horizon.matrix, G)["load_energy"] - attempt.waited_load_energy,
    }, HALF_TOL)
    trial_floor = number(candidate, "net_work") - abs(number(candidate, "net_work") - number(candidate, "net_half"))
    require(boolean(summary, "accepted_best") == (trial_floor > TOL and number(summary, "direct_net") > TOL),
            f"Single-shot acceptance decision differs for {label}")
    for field in ("waiting_energy_drift", "connected_energy_drift", "balance_residual"):
        audit.check(*label, "energy_account", field, number(summary, field))
    for field in ("cut_linear_residual", "reconnect_linear_residual"):
        audit.check(*label, "energy_account", field, number(summary, field), 1e-15)
    for field in ("best_matrix_half_error", "reconnect_matrix_half_error", "horizon_matrix_half_error"):
        audit.check(*label, "half_step", field, number(summary, field), HALF_TOL)


def candidate_rank(entry):
    key, row = entry
    return -number(row, "max_net"), ticks(row["best_elapsed_total"]), key[3]


def step_error(row):
    return abs(number(row, "max_net") - number(row, "max_net_half"))


def resolved_improvement(left, right):
    return number(left, "max_net") - number(right, "max_net") > step_error(left) + step_error(right) + TOL


def refinement_range(coarse):
    by_tau = {key[3]: (key, row) for key, row in coarse.items()}
    points = sorted(by_tau)
    maxima = []
    for index, tau in enumerate(points):
        entry = by_tau[tau]
        work = number(entry[1], "max_net")
        if index and work <= number(by_tau[points[index - 1]][1], "max_net"):
            continue
        if index + 1 < len(points) and work < number(by_tau[points[index + 1]][1], "max_net"):
            continue
        maxima.append(entry)
    centers = sorted(maxima, key=lambda entry: (-number(entry[1], "max_net"), entry[0][3]))[:3]
    waits = set()
    for key, row in centers:
        tau = key[3]
        upper = MAX_WAIT
        if tau == MAX_WAIT and resolved_improvement(row, by_tau[tau - WAIT_STEP][1]):
            upper += WAIT_STEP
        waits.update(range(max(0, tau - WAIT_STEP), min(upper, tau + WAIT_STEP) + 1, WAIT_FINE_STEP))
    return centers, waits


def verify_saved_path(audit, model, key, source, snapshots, initial, initial_half, grid, peak, total, required=False,
                      final_phase="virtual_after"):
    tau = key[3]
    label = scan_label(key)
    if not snapshots.has(key, "reconnect", "coarse"):
        require(not required, f"Missing required saved trajectory for {key}")
        return None
    origin = ticks(initial.time)
    stored = {}
    for resolution, start in (("coarse", initial), ("half", initial_half)):
        if not snapshots.has(key, "reconnect", resolution):
            require(not required, f"Missing paired saved trajectory for {key}/{resolution}")
            continue
        reconnect = snapshots.load(key, "reconnect", resolution, origin + tau, source, model)
        before = snapshots.load(key, "before", resolution, origin + peak, source, model)
        horizon = snapshots.load(key, "horizon", resolution, origin + total, source, model)
        after = (snapshots.load(key, final_phase, resolution, origin + peak, source, model)
                 if snapshots.has(key, final_phase, resolution) else None)
        if required and final_phase == "virtual_after":
            require(after is not None, f"Missing single-shot virtual extraction for {key}/{resolution}")
        candidate = grid[peak]
        if resolution == "coarse":
            net, _ = verify_work(audit, model, label, start, reconnect, before, after, candidate, tau)
        else:
            cut, switch = 0.0, 0.0
            if tau:
                cut = -G * model.exchange_expectation(start)
                switch = G * model.exchange_expectation(reconnect)
                verify_dynamics(audit, model, label, "wait_half", start, reconnect, 0.0, 0.0, False)
            else:
                audit.check(*label, "continuous_half", "no_wait_state_change", max_abs(start.matrix - reconnect.matrix), 0)
            verify_dynamics(audit, model, label, "connected_half", reconnect, before, G, 0.0, False)
            _, _, extracted, _ = verify_extraction(audit, model, label, before, after)
            net = extracted - cut - switch
            audit.check(*label, "work_half", "selected_net_half", net - number(candidate, "net_half"))
        verify_dynamics(audit, model, label, f"horizon_{resolution}", reconnect, horizon, G, 0.0, False)
        stored[resolution] = (reconnect, before, horizon, after, net)
    if "half" in stored:
        nominal, fine = stored["coarse"], stored["half"]
        for phase, left, right in zip(("reconnect", "before", "horizon", final_phase), nominal[:4], fine[:4]):
            require((left is None) == (right is None), f"Unpaired saved state for {key}/{phase}")
            if left is not None:
                verify_convergence(audit, model, label, phase, left, right, G)
    return stored


def verify_single(audit, model, sources, candidates, summaries, snapshots, reference, total, max_wait, mode):
    single = {key: row for key, row in summaries.items() if key[0] in ("A", "C")}
    single_grids = {key: grid for key, grid in candidates.items() if key[0] in ("A", "C")}
    require(single.keys() == single_grids.keys(), "Single-shot candidate and wait-summary coverage differ")
    winners = {}
    available_sources = {key[1] for key in single}
    require(available_sources <= sources.keys() and (mode == "benchmark" or available_sources == sources.keys()),
            "Single-shot source coverage differs")
    for label in sorted(available_sources):
        source = sources[label]
        related = {key: row for key, row in single.items() if key[1] == label}
        require(all(key[2] == source.cycle + 1 for key in related), f"Wrong single-shot cycle index for {label}")
        coarse = {key: row for key, row in related.items() if key[0] == "A"}
        requested = set(range(0, max_wait + 1, WAIT_STEP)) if mode == "formal" else {0, 250, 2000}
        require({key[3] for key in coarse} == requested,
                f"Coarse wait-grid coverage differs for {label}")
        refined = {key[3] for key in related if key[0] == "C"}
        if mode == "formal":
            _, required_refinement = refinement_range(coarse)
            require(refined == required_refinement, f"Refined wait-grid coverage differs for {label}")
        highest, best = min(related.items(), key=candidate_rank)
        winners[label] = (highest, best)
        for key, row in related.items():
            grid = single_grids[key]
            peak = verify_candidate_grid(audit, model, key, grid, row, source.state, total)
            if key[0] == "A" and key[3] in (0, 2000):
                verify_reference_grid(audit, scan_label(key), label, key[3], grid, grid, reference, total)
            required = mode == "formal" and (key == highest or key[0] == "A" and key[3] in (0, 2000))
            if snapshots is not None:
                verify_saved_path(audit, model, key, source, snapshots, source.state, source.state, grid, peak, total, required)
    return winners


def verify_single_decisions(root, audit, winners, summaries):
    rows = keyed(read_csv(root / "m23_policy_comparison.csv"), ("source", "strategy"), "single-shot policy comparison")
    require(rows.keys() == {(source, policy) for source in winners for policy in ("A", "B", "C")},
            "Single-shot policy comparison coverage differs")
    center_table = keyed(read_csv(root / "m23_refinement_centers.csv"), ("source", "rank"), "M23 refinement centers")
    verified_centers = set()
    improved = []
    for label, (best_key, best) in winners.items():
        cycle = best_key[2]
        options = (summaries["A", label, cycle, 0], summaries["A", label, cycle, 2000], best)
        status = all(resolved_improvement(best, base) for base in options[:2])
        if status:
            improved.append(label)
        coarse = {key: row for key, row in summaries.items() if key[:3] == ("A", label, cycle)}
        centers, _ = refinement_range(coarse)
        for index, (key, original) in enumerate(centers, 1):
            record = label, str(index)
            row = center_table[record]
            require(ticks(row["center_tau"]) == key[3] and int(row["cycle"]) == cycle,
                    f"Refinement seed differs for {record}")
            audit.check(f"refinement/{label}", cycle, "selection", f"center_{index}_work",
                        number(row, "coarse_max_net") - number(original, "max_net"))
            require(boolean(row, "edge") == (key[3] in (0, MAX_WAIT)), f"Wrong refinement edge flag for {record}")
            verified_centers.add(record)
        for strategy, summary in zip(("A", "B", "C"), options, strict=True):
            evaluated = rows[label, strategy]
            require(ticks(evaluated["tau"]) == ticks(summary["tau"])
                    and ticks(evaluated["best_elapsed_total"]) == ticks(summary["best_elapsed_total"])
                    and evaluated["registered_stage"] == summary["scan"],
                    f"Single-shot policy choice differs for {label}/{strategy}")
            require(boolean(evaluated, "optimal_exceeds_both_resolved") == status, f"Wrong repetition gate for {label}")
            audit.compare(f"gate/{label}/{strategy}", cycle, "selection", evaluated, {
                "max_net": number(summary, "max_net"), "net_half_error": step_error(summary),
                "cut_on": number(summary, "cut_on"), "reconnect_on": number(summary, "reconnect_on"),
            })
    require(verified_centers == center_table.keys(), "Unexpected reported refinement centers")
    return improved


def candidate_admissible(row):
    net = number(row, "net_work")
    direct = number(row, "total_work") - number(row, "cut_on") - number(row, "reconnect_on")
    return net - abs(net - number(row, "net_half")) > TOL and direct > TOL


def verify_prediction(root, audit, sources, grids, summaries):
    rows = read_csv(root / "m23_prediction.csv")
    gates = read_csv(root / "m23_prediction_gate.csv")
    grouped = {}
    folds = set()
    for row in rows:
        held, policy = row["held_out_source"], row["policy"]
        require(held in sources and set(row["train_sources"].split()) == sources.keys() - {held},
                f"Training sources differ from the held-out fold for {policy}/{held}")
        require((held, policy) not in folds, f"Duplicate held-out prediction for {policy}/{held}")
        folds.add((held, policy))
        cycle = sources[held].cycle + 1
        key = "A", held, cycle, ticks(row["selected_tau"])
        elapsed = ticks(row["selected_elapsed_total"])
        require(elapsed == key[3] + ticks(row["selected_elapsed_connected"]),
                f"Prediction clock differs for {policy}/{held}")
        candidate = grids[key][elapsed]
        adopted = candidate_admissible(candidate)
        require(adopted == boolean(row, "admissible"), f"Candidate eligibility mismatch for {policy}/{held}")
        oracle_key, oracle_summary = min(((k, summary) for k, summary in summaries.items() if k[:3] == key[:3]),
                                         key=candidate_rank)
        oracle_elapsed = ticks(oracle_summary["best_elapsed_total"])
        eligible = candidate_admissible(grids[oracle_key][oracle_elapsed])
        require(eligible == boolean(row, "oracle_is_admissible"), f"Oracle eligibility differs for {policy}/{held}")
        denominator = number(oracle_summary, "max_net")
        base_work = number(candidate, "net_work")
        actual_work = base_work if adopted else 0.0
        select_summary = summaries[key]
        tag = f"prediction/{held}/{policy}", cycle
        compare_present(audit, tag, "held_out", row, {
            "oracle_tau": oracle_key[3] / 1000, "oracle_elapsed_connected": (oracle_elapsed - oracle_key[3]) / 1000,
            "oracle_max_net": denominator, "proposed_net_work": base_work, "adopted_net_work": actual_work,
            "selected_wait_max_net": number(select_summary, "max_net"),
            "selected_wait_oracle_elapsed_connected": number(select_summary, "best_elapsed_connected"),
        })
        if boolean(row, "is_joint"):
            value = actual_work / denominator if eligible else None
            if eligible:
                audit.check(*tag, "held_out", "joint_attainment", number(row, "joint_attainment") - value)
            else:
                require(row["joint_attainment"] == "", f"Unresolved oracle credited for {policy}/{held}")
            grouped.setdefault(policy, []).append((held, value, boolean(row, "is_fixed_baseline")))
        else:
            require(row["joint_attainment"] == "", f"Wait-only oracle credited as joint for {policy}/{held}")

    require({row["policy"] for row in gates} == grouped.keys() and len(gates) == len(grouped),
            "Prediction gate policy coverage differs")
    complete = {}
    baseline_names = set()
    for policy, scores in grouped.items():
        flags = {baseline for _, _, baseline in scores}
        require(len(flags) == 1, f"Inconsistent baseline classification across folds for {policy}")
        is_baseline = flags.pop()
        if is_baseline:
            baseline_names.add(policy)
        valid = [score for _, score, _ in scores if score is not None]
        if len(valid) == len(sources):
            complete[policy] = sum(valid) / len(valid), min(valid)
    fixed = {policy: value for policy, value in complete.items() if policy in baseline_names}
    require(fixed, "No complete fixed baseline for prediction gate")
    strongest = max(fixed, key=lambda policy: fixed[policy][0])
    eligible = {}
    for row in gates:
        policy = row["policy"]
        require(row["strongest_fixed_baseline"] == strongest, f"Wrong fixed baseline in gate for {policy}")
        require(boolean(row, "all_folds_scored") == (policy in complete), f"Incomplete fold gate metadata for {policy}")
        passed = False
        if policy in complete:
            average, minimum = complete[policy]
            gain = average - fixed[strongest][0]
            audit.compare(f"prediction_gate/{policy}", 0, "folds", row, {
                "mean_joint_attainment": average, "minimum_joint_attainment": minimum,
                "mean_gain_over_strongest_fixed": gain,
            })
            passed = policy not in baseline_names and average >= 0.8 and minimum >= 0.5 and gain >= 0.05
            if passed:
                eligible[policy] = average
        require(boolean(row, "gate_valid") == passed, f"Wrong prediction gate decision for {policy}")
    winner = max(eligible, key=eligible.get, default=None)
    selected = [row["policy"] for row in gates if boolean(row, "selected_for_phase_e")]
    require(selected == ([winner] if winner is not None else []), "Prediction model selection differs from held-out gate")
    audit.check("prediction_gate", 0, "folds", "held_out_gate_mismatch", 0, 0)
    return winner


def verify_legacy_repeats(inputs, audit, ledger):
    for strategy, (milestone, protocol, sha256) in REPEAT_REFERENCE.items():
        path = inputs / "reference" / milestone / f"{milestone}_cycle_ledger.csv"
        require(digest(path) == sha256, f"Published {milestone.upper()} repeated ledger SHA-256 differs")
        old = {row["cycle"]: row for row in read_csv(path) if row["protocol"] == protocol}
        new = {cycle: row for (branch, cycle), row in ledger.items() if branch == strategy}
        require(old.keys() == new.keys(), f"Repeated baseline cycle coverage differs for strategy {strategy}")
        for cycle, left in new.items():
            right = old[cycle]
            require(ticks(left["time"]) == ticks(right["time"]) and boolean(left, "accepted") == boolean(right, "accepted"),
                    f"Archived {milestone.upper()} operation choice differs for {strategy}/{cycle}")
            key = f"m23_repeat_{strategy}_vs_{milestone}", cycle
            audit.compare(*key, "legacy_rk4", left, {
                "net_work": number(right, "net_work"),
                "cumulative_net": number(right, f"cumulative_{milestone}_net"),
                "cut_on": number(right, "cut_on"), "reconnect_on": number(right, "reconnect_on"),
            })


def verify_repeated(directory, inputs, audit, model, sources, improved, prediction):
    if not improved:
        require(not (directory / "m23_repeated.csv").is_file(), "Repetition was run without passing the single-shot gate")
        audit.check("repetition", 0, "gate", "closed_single_shot_gate_honored", 0, 0)
        return
    ledger = keyed(read_csv(directory / "m23_repeated.csv"), ("strategy", "cycle"), "repeated ledger")
    candidates = read_candidates(directory / "m23_repeated_candidates.csv")
    searches = read_wait_summary(directory / "m23_repeated_search.csv")
    snapshots = Snapshots(directory, SnapshotArchive(directory, audit, prefix="repeat/"))
    expected = {"A", "B", "C"} | ({"D"} if prediction is not None else set())
    require({strategy for strategy, _ in ledger} == expected, "Repeated strategies differ from repetition/prediction gates")
    used_grids = set()
    used_searches = set()
    source = sources["S0"]
    initial = source.state
    origin = ticks(initial.time)
    anchor_metrics = model.scalars(initial, G)
    for strategy in sorted(expected):
        previous, previous_half = initial, initial
        cumulative = 0.0
        adopted_count = 0
        rejected = False
        cycles = sorted(int(cycle) for branch, cycle in ledger if branch == strategy)
        require(cycles == list(range(3, cycles[-1] + 1)) and cycles[-1] <= 10, f"Invalid repeated cycles for {strategy}")
        for cycle in cycles:
            label = f"repeat/{strategy}", cycle
            row = ledger[strategy, str(cycle)]
            require(not rejected, f"Repeated strategy {strategy} continues after failure")
            nominal = {key: value for key, value in searches.items()
                       if key[0].split("_")[1] == strategy and key[1:3] == ("S0", cycle)}
            require(nominal, f"Repeated search is missing for {strategy}/{cycle}")
            used_searches.update(nominal)
            if strategy in ("A", "B"):
                target_tau = {"A": 0, "B": 2000}[strategy]
                require(len(nominal) == 1 and next(iter(nominal))[3] == target_tau,
                        f"Incorrect fixed waiting time for {strategy}/{cycle}")
            elif strategy == "C":
                coarse = {key: value for key, value in nominal.items() if key[0].endswith("_coarse")}
                fine = {key[3] for key in nominal if key[0].endswith("_refined")}
                require({key[3] for key in coarse} == set(range(0, MAX_WAIT + 1, WAIT_STEP)),
                        f"Incorrect coarse repeated grid for {strategy}/{cycle}")
                _, expected_refinement = refinement_range(coarse)
                require(fine == expected_refinement, f"Incorrect repeated refinement windows for {strategy}/{cycle}")
            else:
                require({key[3] for key in nominal} == set(range(0, MAX_WAIT + 1, WAIT_STEP)),
                        f"Incorrect predictive wait grid for {strategy}/{cycle}")

            current = [key for key in candidates
                       if key[0].split("_")[1] == strategy and key[1:3] == ("S0", cycle)]
            require(len(current) == 1, f"Repeated candidate table has no unique selected scan for {strategy}/{cycle}")
            key = current[0]
            selected_elapsed = ticks(row["elapsed_total"])
            selected_tau = ticks(row["tau"])
            require(selected_tau == key[3] and ticks(row["elapsed_connected"]) == selected_elapsed - selected_tau,
                    f"Repeated clock/tau mismatch for {strategy}/{cycle}")
            used_grids.add(key)
            nominal_peak = verify_candidate_grid(audit, model, key, candidates[key], nominal[key], previous, TOTAL)
            time = ticks(row["time"])
            require(time == ticks(previous.time) + selected_elapsed, f"Repeated state clock mismatch for {strategy}/{cycle}")
            if strategy != "D":
                winner, _ = min(nominal.items(), key=candidate_rank)
                require(key == winner and selected_elapsed == nominal_peak,
                        f"Repeated strategy did not select the registered grid maximum for {strategy}/{cycle}")
            else:
                require(selected_elapsed in candidates[key], f"Predictive choice is off the registered execution grid for {strategy}/{cycle}")
            picked = candidates[key][selected_elapsed]
            adopted = boolean(row, "accepted")
            phase = "after" if adopted else "virtual_after"
            stored = verify_saved_path(audit, model, key, source, snapshots, previous, previous_half,
                                       candidates[key], selected_elapsed, TOTAL, True, phase)
            nominal_states, half_states = stored["coarse"], stored["half"]
            require(nominal_states[3] is not None and half_states[3] is not None,
                    f"Repeated virtual/real after-state is missing for {strategy}/{cycle}")
            net, fine = nominal_states[-1], half_states[-1]
            margin = number(picked, "net_work") - abs(number(picked, "net_work") - number(picked, "net_half"))
            require(adopted == (net > TOL and margin > TOL), f"Repeated adoption decision differs for {strategy}/{cycle}")
            before_manifest = snapshots.rows[(*key, "before", "coarse")]
            after_manifest = snapshots.rows[(*key, phase, "coarse")]
            require(PurePosixPath(row["before_state"]).name == PurePosixPath(before_manifest["filename"]).name,
                    f"Repeated before-state ledger mismatch for {strategy}/{cycle}")
            expected_after = PurePosixPath(after_manifest["filename"]).name if adopted else ""
            require(PurePosixPath(row["after_state"]).name == expected_after,
                    f"Repeated after-state ledger mismatch for {strategy}/{cycle}")
            if adopted:
                previous, previous_half = nominal_states[3], half_states[3]
                cumulative += net
                adopted_count += 1
            else:
                rejected = True
            compare_present(audit, label, "sequence", row, {
                "net_work": net, "net_half": fine, "direct_net": net, "direct_net_half": fine,
                "selected_candidate_net": number(picked, "net_work"), "resolution_margin": margin,
                "cumulative_net": cumulative, "elapsed_since_anchor": (time - origin) / 1000,
                "cut_on": number(picked, "cut_on"), "reconnect_on": number(picked, "reconnect_on"),
                "gross_work": number(picked, "gross_work"), "total_work": number(picked, "total_work"),
                "interaction_jump": number(picked, "interaction_jump"), "adopted_count": adopted_count,
            })
            current_metrics = model.scalars(previous, G)
            audit.check(*label, "sequence", "gamma0_cumulative_energy_work_identity",
                        current_metrics["global_energy"] - anchor_metrics["global_energy"] + cumulative)
            audit.check(*label, "sequence", "gamma0_cumulative_ergotropy_work_identity",
                        current_metrics["global_ergotropy"] - anchor_metrics["global_ergotropy"] + cumulative)
            audit.check(*label, "sequence", "gamma0_anchor_spectrum_max_drift", max_abs(previous.eigenvalues - initial.eigenvalues))
        require(rejected or cycles[-1] == 10, f"Repeated strategy {strategy} ends early")
    require(used_searches == searches.keys() and used_grids == candidates.keys(), "Extra repeated search/candidate rows")
    snapshots.finish()
    verify_legacy_repeats(inputs, audit, ledger)


def resume_single_audit(root, audit):
    prefixes = ("E_", "repeat/", "m23_repeat_", "repetition")
    rows = [row for row in read_csv(root / "m23_independent_audit.csv") if not row["protocol"].startswith(prefixes)]
    require(rows and all(row["status"] == "PASS" for row in rows),
            "The prior single-shot audit must be complete and passing")
    require(any(row["check"] == "held_out_gate_mismatch" for row in rows),
            "The prior single-shot audit is missing the prediction gate")
    manifest = [row for row in read_csv(root / "m23_state_audit_manifest.csv")
                if not row["filename"].startswith("repeat/")]
    for row in manifest:
        path = path_in(root, row["filename"])
        if row["filename"].startswith("states/"):
            require(digest(path) == row["sha256"], f"Previously audited single-shot archive changed: {row['filename']}")
    audit.rows, audit.manifest = rows, manifest
    comparison = read_csv(root / "m23_policy_comparison.csv")
    improved = sorted(row["source"] for row in comparison
                      if row["strategy"] == "C" and boolean(row, "optimal_exceeds_both_resolved"))
    prediction_rows = read_csv(root / "m23_prediction_gate.csv")
    selected = [row["policy"] for row in prediction_rows if boolean(row, "selected_for_phase_e")]
    require(len(selected) <= 1, "Prediction gate selects multiple repeated policies")
    return improved, selected[0] if selected else None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path)
    parser.add_argument("--inputs", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--benchmark", action="store_true", help="Verify the registered 2.50-time benchmark")
    parser.add_argument("--single-only", action="store_true", help="Audit before the repeated trajectories are written")
    parser.add_argument("--repeat-only", action="store_true", help="Add repeated checks to a completed single-shot audit")
    parser.add_argument("--repeat-directory", type=Path, help="Directory for separate repeated output staging")
    parser.add_argument("--read-only", action="store_true", help="Run without writing verification tables")
    args = parser.parse_args()
    root = args.results.resolve()
    inputs = args.inputs.resolve()
    require(not args.repeat_only or not (args.benchmark or args.single_only), "Conflicting audit modes")
    repeated = args.repeat_directory.resolve() if args.repeat_directory else root / "repeat"
    audit, model = Audit(), Model()
    for g in (0.0, G):
        commutator = model.h[g] * (OCCUPATION[None, :] - OCCUPATION[:, None])
        audit.check("all", 0, "model", f"gamma0_number_commutator_g{g}", max_abs(commutator), 0)
    reference = load_reference(inputs / "reference" / "m22", audit)
    sources = load_sources(inputs, SnapshotArchive(inputs, audit), audit)
    if args.repeat_only:
        improved, prediction = resume_single_audit(root, audit)
        verify_repeated(repeated, inputs, audit, model, sources, improved, prediction)
    else:
        candidates = read_candidates(root / "m23_candidates.csv")
        summaries = read_wait_summary(root / "m23_wait_summary.csv")
        manifest = root / "m23_state_manifest.csv"
        snapshots = Snapshots(root, SnapshotArchive(root, audit)) if manifest.is_file() else None
        require(args.benchmark or snapshots is not None, "Missing formal saved-state manifest")
        winners = verify_single(audit, model, sources, candidates, summaries, snapshots, reference,
                                2500 if args.benchmark else TOTAL, MAX_WAIT, "benchmark" if args.benchmark else "formal")
        if not args.benchmark:
            improved = verify_single_decisions(root, audit, winners, summaries)
            prediction = verify_prediction(root, audit, sources, candidates, summaries)
            if not args.single_only:
                verify_repeated(repeated, inputs, audit, model, sources, improved, prediction)
        if snapshots is not None:
            snapshots.finish()
    if not args.read_only:
        write_csv(root / "m23_independent_audit.csv", audit.rows)
        write_csv(root / "m23_state_audit_manifest.csv", audit.manifest)
    failures = [row for row in audit.rows if row["status"] == "FAIL"]
    for row in failures[:30]:
        print(row)
    print(f"Independent M23 verification: {len(audit.rows) - len(failures)}/{len(audit.rows)} passed.")
    return bool(failures)


if __name__ == "__main__":
    raise SystemExit(main())
