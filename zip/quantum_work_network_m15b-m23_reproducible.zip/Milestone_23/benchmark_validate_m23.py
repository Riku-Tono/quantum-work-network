"""Compare the short M23 trajectories with the archived M22 RK4 implementation."""
import argparse
import csv
from pathlib import Path

from package_m23 import ROOT,csv_rows


def emit(path, header, rows):
    with path.open("x", newline="", encoding="utf8") as f:
        w=csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


def validate(bench, root):
    baseline=root/"reference/m22/single"
    previous={(r["protocol"],r["time"]):r for r in csv_rows(baseline/"m22_candidates.csv")}
    fine={(r["protocol"],r["time"]):r for r in csv_rows(baseline/"m22_half_step.csv")}
    label={"S0":"anchor","S1":"mid","S2":"end"}
    fields=("net_work","load_ergotropy","load_current","load_energy","integrated_load_current")
    errors={name:0. for name in (*fields,"net_half")}
    count=0
    for row in csv_rows(bench/"m23_candidates.csv"):
        tau=float(row["tau"])
        if tau not in (0.,2.):
            continue
        arm=f"C_{label[row['source']]}_{'wait' if tau else 'connected'}"
        key=arm,f"{float(row['time']):.2f}"
        for name in fields:
            errors[name]=max(errors[name],abs(float(row[name])-float(previous[key][name])))
        errors["net_half"]=max(errors["net_half"],abs(float(row["net_half"])-float(fine[key]["net_half"])))
        count+=1
    if count!=456 or max(errors.values())>1e-12:
        raise ValueError("Short benchmark differs from archived M22")
    emit(bench/"m23_m22_short_crosscheck.csv",("field","count","max_error","limit"),
         ((name,count,error,1e-12) for name,error in errors.items()))
    wall=float(csv_rows(bench/"m23_runtime.csv")[-1]["elapsed_seconds"])
    multiplier=18/2.5
    emit(bench/"m23_runtime_estimate.csv",("scope","measured_seconds","measured_waits","formal_max_waits","window_ratio","projected_seconds"),
         ((name,wall,9,n,multiplier,wall*n*multiplier/9) for name,n in (("A_C",264),("E",720))))
    print(f"Short benchmark {count} comparisons; max absolute difference {max(errors.values()):.3e}.")


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("benchmark",type=Path)
    p.add_argument("--inputs",type=Path,default=ROOT)
    opts=p.parse_args()
    validate(opts.benchmark,opts.inputs)
