"""Extract and independently hash the M23 reference states and audited baselines."""
import argparse
import csv
import hashlib
import io
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
M18_STATE = "R4_observed_max_t1590_after.bin"
PIN = (
    "4C9A5EE8172E505592C43A7B522476715D418CAFA0CC677C04B853E72CC6F9ED",
    "A4BF4D0453CD5BAC3EFD192409EEF8CCE7FDC64862D783621B39314E107B7640",
    "EC8CAF75EE5FBF75BFA354F068B38BBEA2349B4E3D0F19272266766B95D88B8F",
)


def digest(data):
    return hashlib.sha256(data).hexdigest().upper()


def dump(path, fields, rows):
    with path.open("x", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(fields)
        writer.writerows(rows)


def unpack(archive, home, name):
    blob = archive.read(f"{home.name}/{name}")
    if blob != (home / name).read_bytes():
        raise ValueError(f"Archive and official file disagree: {home.name}/{name}")
    return blob


def prepare(home):
    dirs = {n: home / f"Milestone_{n}" for n in (18, 21, 22)}
    for n in (21, 22):
        with (dirs[n] / f"M{n}_all_results.zip").open("rb") as f:
            obtained = hashlib.file_digest(f, "sha256").hexdigest()
        if obtained != (dirs[n] / f"M{n}_all_results.sha256").read_text().split()[0]:
            raise ValueError(f"Formal M{n} ZIP hash mismatch")
    with ZipFile(dirs[18] / "M18_all_results.zip") as a18, \
         ZipFile(dirs[21] / "M21_all_results.zip") as a21, \
         ZipFile(dirs[22] / "M22_all_results.zip") as a22:
        def save(name, blob):
            path = ROOT / name
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("xb") as f:
                f.write(blob)
            return (name, digest(blob), len(blob))
        outputs = []
        for name in ("single_inputs.csv", "single/m22_candidates.csv", "single/m22_half_step.csv",
                     "m22_cycle_ledger.csv", "m22_protocol_summary.csv", "m22_phase_comparison.csv",
                     "m22_state_manifest.csv", "PRECOMMIT_M22.md"):
            outputs.append(save(f"reference/m22/{name}", unpack(a22, dirs[22], name)))
        for name in ("m21_cycle_ledger.csv","m21_state_manifest.csv", "m21_protocol_summary.csv"):
            outputs.append(save(f"reference/m21/{name}", unpack(a21, dirs[21], name)))
        for name in ("m18_state_manifest.csv", "m18_second_extraction_ledger.csv"):
            blob = unpack(a18, dirs[18], name)
            if blob != unpack(a22, dirs[22], f"m18_inputs/{name}"):
                raise ValueError(f"M18 provenance difference: {name}")
            outputs.append(save(f"reference/m18/{name}", blob))
        inputs = csv.DictReader(io.StringIO((ROOT / "reference/m22/single_inputs.csv").read_text(encoding="utf-8-sig")))
        selections = [r for r in inputs if r["rate"] == "C"]
        registry = []
        for i, (row, expected_case, pinned) in enumerate(zip(selections, ("anchor", "mid", "end"), PIN, strict=True)):
            if row["source"] != expected_case or row["source_sha256"].upper() != pinned:
                raise ValueError(f"M22 C input mismatch: {row['source_filename']}")
            name22 = row["source_filename"]
            from_m22 = unpack(a22, dirs[22], name22)
            if i == 0:
                upstream = unpack(a18, dirs[18], f"states/{M18_STATE}")
                if upstream != unpack(a21, dirs[21], f"m18_inputs/{M18_STATE}"):
                    raise ValueError("M21 M18 source mismatch")
            else:
                upstream = unpack(a21, dirs[21], name22.removeprefix("reference/m21/"))
            if upstream != from_m22 or digest(upstream) != pinned:
                raise ValueError(f"Upstream state checksum mismatch for S{i}")
            path = f"reference/sources/S{i}_{Path(name22).name}"
            outputs.append(save(path, upstream))
            registry.append((f"S{i}", row["source_cycle"], row["source_time"], path, pinned, name22))
    dump(ROOT / "m23_sources.csv", ("source", "source_cycle", "source_time", "filename", "sha256", "m22_filename"), registry)
    dump(ROOT / "m23_archive_checks.csv", ("filename", "sha256", "size_bytes", "status"),
         [(*row, "PASS") for row in outputs])
    print(f"M23 reference verified: {len(outputs)} archived files, {len(registry)} origins")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--history", type=Path, default=ROOT.parent)
    prepare(p.parse_args().history)
