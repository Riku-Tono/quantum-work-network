"""Validate registered inputs, stage M23 outputs, and create the checked ZIP."""
import argparse
import csv
import hashlib
from pathlib import Path
import shutil
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parent


def csv_rows(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest().upper()


def verify(root):
    for registry in ("m23_precommit_sha256.csv","m23_phase_E_code_sha256.csv","m23_sources.csv"):
        for row in csv_rows(root / registry):
            if sha(root / row["filename"]) != row["sha256"]:
                raise ValueError(f"Registered SHA-256 mismatch: {row['filename']}")
    print("Registered M23 code and input hashes verified.")


def copy_tree(source, destination):
    for item in sorted(source.rglob("*")):
        if item.is_file():
            target=destination/item.relative_to(source)
            target.parent.mkdir(exist_ok=True,parents=True)
            if target.exists():
                if target.samefile(item) or sha(target)==sha(item):
                    continue
                raise FileExistsError(target)
            try:
                target.hardlink_to(item)
            except OSError:
                shutil.copy2(item,target)


def collect(sweep, benchmark, repeated, root):
    copy_tree(sweep,root)
    copy_tree(benchmark,root/"benchmark")
    if repeated is not None:
        copy_tree(repeated,root/"repeat")


def package(root):
    verify(root)
    required=("MILESTONE_23_PHASE_CONTROL_REPORT.md","README_M23.md","PRECOMMIT_M23.md",
              "m23_candidates.csv","m23_wait_summary.csv","m23_policy_comparison.csv","m23_prediction.csv",
              "m23_prediction_gate.csv","m23_energy_balance.csv","m23_independent_audit.csv","m23_state_manifest.csv",
              "benchmark/m23_independent_audit.csv","benchmark/m23_runtime_estimate.csv")
    for name in required:
        if not (root/name).is_file() or not (root/name).stat().st_size:
            raise FileNotFoundError(root/name)
    has_repeated=(root/"repeat/m23_repeated.csv").is_file()
    figures=list((root/"figures").glob("*.png"))
    if len(figures)!=(10 if has_repeated else 8):
        raise ValueError(f"Unexpected figure count: {len(figures)}")
    if any(r["status"]!="PASS" for r in csv_rows(root/"m23_independent_audit.csv")):
        raise ValueError("Audit has failures")
    target=root/"M23_all_results.zip"
    temporary=root/"M23_all_results.zip.incomplete"
    if target.exists() or temporary.exists():
        raise FileExistsError(target)
    exclude={"__pycache__",".git","target"}
    members={f"Milestone_23/{p.relative_to(root).as_posix()}":p for p in sorted(root.rglob("*"))
             if p.is_file() and exclude.isdisjoint(p.relative_to(root).parts)
             and p.suffix not in {".zip",".pyc",".incomplete",".sha256"}}
    with ZipFile(temporary,"x",ZIP_DEFLATED,compresslevel=3) as archive:
        for name,path in members.items():
            archive.write(path,name)
    with ZipFile(temporary) as archive:
        if set(archive.namelist())!=set(members) or archive.testzip() is not None:
            raise ValueError("Archive filename/CRC verification failed")
    temporary.rename(target)
    digest=sha(target).lower()
    (root/"M23_all_results.sha256").write_text(f"{digest}  {target.name}\n",encoding="ascii")
    print(f"M23 archive: {len(members)} members, {target.stat().st_size:,} bytes, SHA-256 {digest}")


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("step",choices=("verify-inputs","collect","package"))
    p.add_argument("--root",type=Path,default=ROOT)
    p.add_argument("--single",type=Path)
    p.add_argument("--benchmark",type=Path)
    p.add_argument("--repeated",type=Path)
    opts=p.parse_args()
    if opts.step=="verify-inputs":
        verify(opts.root)
    elif opts.step=="collect":
        if opts.single is None or opts.benchmark is None:
            p.error("collect requires --single and --benchmark")
        collect(opts.single,opts.benchmark,opts.repeated,opts.root)
    else:
        package(opts.root)
