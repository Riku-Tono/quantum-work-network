# M23 再現手順

γ=0の切断待機時間掃引、状態量による予測の起点外評価、反復抽出を収録した。コード、登録と入力ハッシュ、M18/M21/M22正式アーカイブから照合した共通起点、粗・半刻みのチェック点および抽出状態、全掃引候補、独立監査、図を同梱した。 [報告書](MILESTONE_23_PHASE_CONTROL_REPORT.md) [事前登録](PRECOMMIT_M23.md) [Phase D補記](PRECOMMIT_M23_D.md) [起点一覧](m23_sources.csv)

## 配布データの監査

Windows PowerShellで、このフォルダーをカレントディレクトリにする。配布環境はPython 3.14、NumPy 2.5.5、SciPy 1.18.1、Matplotlib 3.10.9。

    py -3.14 -m pip install -r requirements.txt
    py -3.14 -B package_m23.py verify-inputs
    $env:OPENBLAS_NUM_THREADS = '1'
    py -3.14 -B verify_m23.py benchmark --inputs . --benchmark --read-only
    py -3.14 -B verify_m23.py . --inputs . --read-only

旧正式ZIPや展開済みアーカイブとの照合を再実行する場合、未準備の作業コピーで次を実行する。過去の正式成果物は読み取り専用。

    py -3.14 -B prepare_m23.py --history ..

## 再計算

    $env:OPENBLAS_NUM_THREADS = '4'
    py -3.14 -B run_m23.py benchmark redo_benchmark --inputs .
    py -3.14 -B benchmark_validate_m23.py redo_benchmark --inputs .
    py -3.14 -B run_m23.py single redo_single --inputs .
    py -3.14 -B analyze_m23.py redo_single
    py -3.14 -B repeat_m23.py redo_single redo_repeat --inputs .

repeat_m23.pyは単回の事前登録ゲートを確認し、合格した場合に反復を進める。予測規則は独立の起点外評価を通過した場合に限って反復に組み込まれる。今回の正式データは単回ゲート通過、予測ゲート不通過だった。

    py -3.14 -B package_m23.py collect --single redo_single --benchmark redo_benchmark --repeated redo_repeat --root redo_results
    $env:OPENBLAS_NUM_THREADS = '1'
    py -3.14 -B verify_m23.py redo_results --inputs .
    py -3.14 -B diagnostics_m23.py redo_results
    py -3.14 -B plot_m23.py --data redo_results --repeated redo_results/repeat/m23_repeated.csv

## CSV・時間・仕事

m23_candidates.csv の elapsed_connected は再接続後、elapsed_total は同じ起点からの待機込み経過、time は絶対モデル時刻。τ=0は常時接続。18.00が候補格子から外れた軌道では horizon が18.00の未操作診断点。基準の0.02格子は維持した。m23_wait_summary.csv は全τの再接続直後、正味最大、窓終端、仮想抽出について観測量を含む。τ=0、2および各起点の粗精最大の全密度は states/ の両刻みを参照。展開後はマニフェストのファイル名が相対に解決される。反復の台帳、全待機候補の要約、選んだτの時間格子、全保存状態は repeat/ 配下。

切断と再接続は系への入力を正、全抽出仕事は系からの出力を正とする。正味は全抽出仕事から両切替入力を引く。交換コヒーレンス C は Tr[ρ σ⁺₇ b]、電流は負荷に向かう流入を正とし J=−2g Im C。位相は振幅が10⁻¹²以下の場合に未定義。相互情報量はナット。

保存状態はQWNRHO1形式。8バイト識別子、little endianの64ビット次元、64ビット時刻、行優先の複素128ビット格納。基底は鎖の占有ビットの後に負荷準位が最も速く変わる。
