"""Record the M23 whole-energy closure and per-origin mechanism indicators."""
import argparse
import csv
from pathlib import Path

import numpy as np

from package_m23 import csv_rows


def write(path, records):
    with path.open("x",newline="",encoding="utf8") as f:
        w=csv.DictWriter(f,fieldnames=list(records[0]))
        w.writeheader()
        w.writerows(records)


def account(root):
    rows=[]
    for file, tag in (("m23_wait_summary.csv","single"),("repeat/m23_repeated.csv","repeat")):
        if not (root/file).is_file():
            continue
        for row in csv_rows(root/file):
            fields={
                "scope":tag,"scan":row["scan"],"source":row["source"],"cycle":row["cycle"],"tau":row["tau"],
                "accepted":row.get("accepted",row.get("accepted_best")),
                "applied_on_history":tag=="repeat" and row.get("accepted")=="True",
                "cut_on":row["cut_on"],"reconnect_on":row["reconnect_on"],
                "start_global_energy":row["start_global_energy"],"pre_global_energy":row["pre_global_energy"],
                "post_global_energy":row["post_global_energy"],"direct_total_work":row["direct_total_work"],
                "direct_net":row["direct_net"],"direct_net_half":row.get("direct_net_half",row.get("net_half_direct")),
                "waiting_energy_drift":row["waiting_energy_drift"],"connected_energy_drift":row["connected_energy_drift"],
                "cut_linear_residual":row["cut_linear_residual"],"reconnect_linear_residual":row["reconnect_linear_residual"],
                "balance_residual":row["balance_residual"],
                "cumulative_net":row.get("cumulative_net",""),
                "cumulative_balance_residual":row.get("cumulative_balance_residual",""),
                "cumulative_ergotropy_residual":row.get("cumulative_ergotropy_residual",""),
            }
            rows.append(fields)
    write(root/"m23_energy_balance.csv",rows)


def mechanism(root):
    waits=csv_rows(root/"m23_wait_summary.csv")
    choices={r["source"]:r for r in csv_rows(root/"m23_policy_comparison.csv") if r["strategy"]=="C"}
    relation={(r["source"],r["predictor"],r["outcome"]):r for r in csv_rows(root/"m23_relationships.csv")}
    rows=[]
    for source,choice in choices.items():
        path=[r for r in waits if r["source"]==source and r["scan"]=="A"]
        all_waits=[r for r in waits if r["source"]==source]
        optimum=next(r for r in waits if (r["source"],r["scan"],r["tau"])==(source,choice["registered_stage"],choice["tau"]))
        greatest=lambda name:max(path,key=lambda r:float(r[name]))
        values=lambda name:np.array([float(r[name]) for r in path])
        span=lambda name:float(np.ptp(values(name)))
        corr=lambda lhs,rhs:float(np.corrcoef(values(lhs),values(rhs))[0,1])
        current=values("reconnect_current")
        signs=np.sign(current[abs(current)>1e-12])
        rows.append({
            "source":source,"coarse_waits":len(path),
            "phase_defined_count":sum(bool(r["reconnect_c_phase"]) for r in path),
            "positive_phase_count":sum(float(r["reconnect_c_phase"])>0 for r in path if r["reconnect_c_phase"]),
            "negative_phase_count":sum(float(r["reconnect_c_phase"])<0 for r in path if r["reconnect_c_phase"]),
            "initial_current_sign_reversals_across_wait":int(np.count_nonzero(signs[1:]!=signs[:-1])),
            "max_abs_real_c":float(max(abs(values("reconnect_c_real")))),
            "min_c_abs":float(min(values("reconnect_c_abs"))),
            "min_j0":float(min(current)),"max_j0":float(max(current)),
            "tau_of_max_j0_coarse":greatest("reconnect_current")["tau"],
            "tau_of_max_signed_inflow_horizon_coarse":greatest("integrated_current_horizon")["tau"],
            "tau_of_max_w_coarse_refined":choice["tau"],
            "j0_at_optimum":optimum["reconnect_current"],
            "phase_at_optimum":optimum["reconnect_c_phase"],
            "pearson_j0_signed_inflow_horizon":corr("reconnect_current","integrated_current_horizon"),
            "pearson_j0_signed_inflow_at_peak":corr("reconnect_current","integrated_current_at_best"),
            "pearson_j0_max_w":relation[source,"reconnect_current","max_net"]["pearson"],
            "pearson_amplitude_max_w":relation[source,"reconnect_c_abs","max_net"]["pearson"],
            "pearson_signed_inflow_at_peak_max_w":relation[source,"integrated_current_at_best","max_net"]["pearson"],
            "circular_r2_phase_max_w":relation[source,"phase_angle","max_net"]["circular_r2"],
            "wait_span_load_energy":span("reconnect_load_energy"),"wait_span_load_passive_energy":span("reconnect_load_passive_energy"),
            "wait_span_mutual_information":span("reconnect_mutual_information"),"wait_span_terminal_population":span("reconnect_terminal_population"),
            "max_abs_switch_sum":max(abs(float(r["cut_on"])+float(r["reconnect_on"])) for r in all_waits),
        })
    write(root/"m23_mechanism_summary.csv",rows)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("results",type=Path)
    root=p.parse_args().results
    account(root)
    mechanism(root)
