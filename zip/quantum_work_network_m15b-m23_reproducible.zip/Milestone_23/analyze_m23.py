"""Analyze the registered M23 wait grid and validate state-only scheduling."""

import argparse
import csv
import json
import math
import os
from pathlib import Path

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import numpy as np


SOURCES = ("S0", "S1", "S2")
WAIT_GRID = tuple(range(0, 6001, 250))
PHASE_FLOOR = 1e-12
NUMERICAL_FLOOR = 1e-12
PHASE_BASIS_RCOND = 1e-8
RIDGE = 1e-2
TRAIN_FIXED_DELAY_LIMIT = 12_000
PREDICTION_COHORT = "A"
MULTI_FEATURES = (
    "tau", "reconnect_c_real", "reconnect_c_imag", "reconnect_c_abs",
    "reconnect_load_energy", "reconnect_load_purity", "reconnect_load_ergotropy",
    "reconnect_load_passive_energy", "reconnect_global_energy", "reconnect_global_ergotropy",
    "reconnect_sector_ergotropy", "reconnect_mutual_information", "reconnect_total_excitation",
    "reconnect_terminal_population",
)
FEATURES = {
    "current_ridge": ("reconnect_current",),
    "imag_ridge": ("reconnect_c_imag",),
    "phase_ridge": ("phase_sin", "phase_cos"),
    "phase_amplitude_ridge": ("phase_sin", "phase_cos", "reconnect_c_abs"),
    "multi_ridge": MULTI_FEATURES,
}
RELATIONSHIPS = (
    "tau", "phase_angle", "reconnect_c_abs", "reconnect_c_real", "reconnect_c_imag", "reconnect_current",
    "reconnect_terminal_population", "reconnect_load_energy", "reconnect_load_ergotropy",
    "reconnect_load_p0", "reconnect_load_p1", "reconnect_load_p2", "reconnect_load_coherence_frobenius",
    "reconnect_load_passive_energy", "reconnect_load_purity", "reconnect_global_energy", "reconnect_global_purity",
    "reconnect_global_passive_energy", "reconnect_global_ergotropy", "reconnect_sector_ergotropy", "reconnect_mutual_information",
    "reconnect_total_excitation", "integrated_current_at_best", "integrated_current_horizon",
    "positive_inflow_at_best", "positive_inflow_horizon", "max_load_ergotropy",
)
OUTCOMES = ("max_net", "max_load_ergotropy", "integrated_current_at_best")
FEATURE_METHODS = tuple(FEATURES)
BASELINES = ("tau0_fixed", "tau2_fixed", "train_best_fixed_pair")


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows):
    if not rows:
        return
    with path.open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def ticks(number):
    return round(float(number) * 1000)


def wait_key(row):
    return row["scan"], row["source"], int(row["cycle"]), ticks(row["tau"])


def phase_fields(row):
    real, imag = float(row["reconnect_c_real"]), float(row["reconnect_c_imag"])
    amplitude = math.hypot(real, imag)
    current = float(row["reconnect_current"])
    if abs(amplitude - float(row["reconnect_c_abs"])) > NUMERICAL_FLOOR or abs(current + 0.5 * imag) > NUMERICAL_FLOOR:
        raise ValueError(f"Exchange coherence or current inconsistent at {wait_key(row)}")
    identified = amplitude > PHASE_FLOOR
    return {
        "phase_identified": identified,
        "phase_angle": math.atan2(imag, real) if identified else "",
        "phase_sin": imag / amplitude if identified else "",
        "phase_cos": real / amplitude if identified else "",
    }


def grid_and_probes(directory):
    paths = {}
    for row in read_csv(directory / "m23_candidates.csv"):
        key, point = wait_key(row), ticks(row["elapsed_connected"])
        path = paths.setdefault(key, {})
        if point in path:
            raise ValueError(f"Duplicate candidate {key}/{point}")
        path[point] = row

    probes = []
    for original in read_csv(directory / "m23_wait_summary.csv"):
        key = wait_key(original)
        path = paths[key]
        best = ticks(original["best_elapsed_connected"])
        grid_best = max(sorted(path), key=lambda point: float(path[point]["net_work"]))
        if best != grid_best or abs(float(path[best]["net_work"]) - float(original["max_net"])) > NUMERICAL_FLOOR:
            raise ValueError(f"Summary maximum differs from candidate at {key}/{best}")
        peak_sample = path[best]
        horizons = sorted(path)
        positive, negative = 0.0, 0.0
        best_positive, best_negative = 0.0, 0.0
        for previous, point in zip(horizons, horizons[1:]):
            left, right = float(path[previous]["load_current"]), float(path[point]["load_current"])
            half_dt = (point - previous) * 0.0005
            positive += half_dt * (max(0.0, left) + max(0.0, right))
            negative += half_dt * (max(0.0, -left) + max(0.0, -right))
            if point == best:
                best_positive, best_negative = positive, negative
        probe = {
            **original, **phase_fields(original),
            "positive_inflow_at_best": best_positive, "gross_outflow_at_best": best_negative,
            "positive_inflow_horizon": positive, "gross_outflow_horizon": negative,
            "net_inflow_trapezoid_at_best": best_positive - best_negative,
            "net_inflow_trapezoid_horizon": positive - negative,
            "trapezoid_last_elapsed_total": (key[-1] + horizons[-1]) / 1000,
            "peak_net_step_error_same_time": abs(float(peak_sample["net_work"]) - half_work(peak_sample)),
            "peak_admissible": admissible(peak_sample, original.get("direct_net")),
        }
        # Preserve a raw spectral diagnostic while leaving non-identifiable
        # phase angles empty in the analysis and predictor inputs.
        probe["reconnect_c_phase_raw"] = original.get("reconnect_c_phase", "")
        probe["reconnect_c_phase"] = probe["phase_angle"]
        probes.append(probe)
    if {wait_key(row) for row in probes} != paths.keys():
        raise ValueError("Summary and candidate wait grids differ")
    return paths, probes


def half_work(row):
    field = "net_work_half" if "net_work_half" in row else "net_half"
    return float(row[field])


def admissible(row, selected_full_energy_work=None):
    net = float(row["net_work"])
    direct = (float(row["total_work"]) - float(row["cut_on"]) - float(row["reconnect_on"])
              if selected_full_energy_work is None else float(selected_full_energy_work))
    return net - abs(net - half_work(row)) > NUMERICAL_FLOOR and direct > NUMERICAL_FLOOR


def credited(row):
    return float(row["net_work"]) if admissible(row) else 0.0


def ranks(values):
    order = np.argsort(values, kind="stable")
    sorted_values = values[order]
    output = np.empty(len(values))
    boundaries = np.r_[0, np.flatnonzero(np.diff(sorted_values)) + 1, len(values)]
    for first, stop in zip(boundaries, boundaries[1:]):
        output[order[first:stop]] = (first + stop - 1) * 0.5
    return output


def correlation(first, second):
    x, y = first - first.mean(), second - second.mean()
    return float(x @ y / (np.linalg.norm(x) * np.linalg.norm(y)))


def relationships(probes):
    rows = []
    for source in SOURCES:
        data = [r for r in probes if r["source"] == source and r["scan"] == PREDICTION_COHORT]
        if not data:
            continue
        for outcome in OUTCOMES:
            for predictor in RELATIONSHIPS:
                if predictor == outcome:
                    continue
                valid = [r for r in data if r.get(predictor, "") != "" and r.get(outcome, "") != ""]
                x = np.array([float(r[predictor]) for r in valid])
                y = np.array([float(r[outcome]) for r in valid])
                px, py = (float(np.ptp(x)), float(np.ptp(y))) if len(x) else (0.0, 0.0)
                row = {
                    "source": source, "predictor": predictor, "outcome": outcome, "n": len(valid),
                    "n_wait_points": len(data), "predictor_span": px, "outcome_span": py,
                    "pearson": "", "spearman": "", "circular_r2": "", "circular_basis_rank": "",
                    "status": "insufficient_variation",
                }
                if predictor == "phase_angle" and len(valid) >= 3 and py > NUMERICAL_FLOOR:
                    basis = np.array([[r["phase_sin"], r["phase_cos"]] for r in valid])
                    basis -= basis.mean(axis=0)
                    if np.linalg.norm(basis) > PHASE_BASIS_RCOND:
                        centered = y - y.mean()
                        weights, _, rank, _ = np.linalg.lstsq(basis, centered, rcond=PHASE_BASIS_RCOND)
                        error = centered - basis @ weights
                        row.update(circular_r2=max(0.0, 1 - float(error @ error / (centered @ centered))),
                                   circular_basis_rank=int(rank), status="descriptive")
                if predictor != "phase_angle" and len(valid) >= 3 and min(px, py) > NUMERICAL_FLOOR:
                    row.update(pearson=correlation(x, y), spearman=correlation(ranks(x), ranks(y)), status="descriptive")
                rows.append(row)
    return rows


def feature_values(row, names):
    values = [row.get(field, "") for field in names]
    if any(value == "" for value in values):
        return None
    return [float(value) for value in values]


def fit_ridge(rows, features, response):
    samples = [(v, response(r)) for r in rows if (v := feature_values(r, features)) is not None]
    if not samples:
        return None
    x = np.array([v for v, _ in samples])
    y = np.array([value for _, value in samples])
    x_mean, y_mean = x.mean(axis=0), float(y.mean())
    keep = np.ptp(x, axis=0) > NUMERICAL_FLOOR
    # Preserve the common scale of the unit-circle basis. Independently
    # rescaling its coordinates would amplify an almost constant direction.
    phase_columns = np.array([name in ("phase_sin", "phase_cos") for name in features])
    scales = np.where(phase_columns[keep], 1.0, x[:, keep].std(axis=0))
    x_standard = (x[:, keep] - x_mean[keep]) / scales
    gram = x_standard.T @ x_standard / len(samples)
    weights = np.linalg.solve(gram + RIDGE * np.eye(sum(keep)), x_standard.T @ (y - y_mean) / len(samples))
    return {
        "features": list(features), "active": keep.tolist(), "means": x_mean[keep].tolist(),
        "scales": scales.tolist(), "weights": weights.tolist(), "intercept": y_mean,
    }


def ridge_value(row, model):
    if model is None:
        return None
    values = feature_values(row, model["features"])
    if values is None:
        return None
    active_values = np.array(values)[np.array(model["active"], dtype=bool)]
    standardized = (active_values - np.array(model["means"])) / np.array(model["scales"])
    return model["intercept"] + float(standardized @ np.array(model["weights"]))


def best_probe(data):
    return max(data, key=lambda r: (float(r["max_net"]), -ticks(r["best_elapsed_total"]), -ticks(r["tau"])))


def choose_wait(data, rule, scorer=None):
    scores = {
        "max_current": lambda r: float(r["reconnect_current"]),
        "max_amplitude": lambda r: float(r["reconnect_c_abs"]),
    }
    score = scores.get(rule, lambda r: ridge_value(r, scorer))
    scored = [(value, -ticks(r["tau"]), r) for r in data if (value := score(r)) is not None]
    if not scored:
        return min(data, key=lambda r: ticks(r["tau"])), "", "no_identifiable_feature"
    value, _, choice = max(scored, key=lambda item: item[:2])
    return choice, value, "scored"


def fixed_delay(training, paths):
    points = set.intersection(*(set(paths[wait_key(r)]) for r in training))
    feasible = sorted(step for step in points if step <= TRAIN_FIXED_DELAY_LIMIT)
    admissible_paths = [(paths[wait_key(r)], float(r["max_net"])) for r in training if r["peak_admissible"]]
    if not feasible or not admissible_paths:
        raise ValueError("No training-only fixed delay comparison is available")
    return max(feasible, key=lambda step: sum(credited(path[step]) / upper for path, upper in admissible_paths))


def fixed_pair(training, source_oracle, paths, waits):
    best = None
    for tau in waits:
        subset = [r for r in training if ticks(r["tau"]) == tau and source_oracle[r["source"]]["peak_admissible"]]
        if not subset:
            continue
        points = set.intersection(*(set(paths[wait_key(r)]) for r in subset))
        for step in sorted(d for d in points if d <= TRAIN_FIXED_DELAY_LIMIT):
            score = sum(credited(paths[wait_key(r)][step]) / float(source_oracle[r["source"]]["max_net"]) for r in subset) / len(subset)
            item = (score, -tau, -step)
            if best is None or item > best:
                best = item
    if best is None:
        raise ValueError("No training-only fixed wait/extraction pair is available")
    return -best[1], -best[2]


def nearest_step(proposed_seconds, available_steps):
    target = proposed_seconds * 1000
    return min(available_steps, key=lambda step: (round(abs(step - target), 10), step))


def train_models(training, source_oracle):
    peak_models, delay_models = {}, {}
    work_training = [r for r in training if source_oracle[r["source"]]["peak_admissible"]]
    timing_training = [r for r in work_training if r["peak_admissible"]]
    for method, features in FEATURES.items():
        peak_models[method] = fit_ridge(work_training, features,
            lambda r: float(r["max_net"]) / float(source_oracle[r["source"]]["max_net"]))
        delay_models[method] = fit_ridge(timing_training, features, lambda r: float(r["best_elapsed_connected"]))
    return peak_models, delay_models


def outcome_record(held, training_sources, policy, wait_rule, delay_rule, probe, oracle, paths, delay,
                   predicted_delay, model_score="", status="scored", baseline=False):
    row = paths[wait_key(probe)][delay]
    eligible = oracle["peak_admissible"]
    denominator = float(oracle["max_net"])
    net = float(row["net_work"])
    wait_peak = float(probe["max_net"])
    wait_oracle = float(probe["best_elapsed_connected"])
    adopted = credited(row)
    is_joint = delay_rule != "wait_oracle_diagnostic"
    return {
        "held_out_source": held, "train_sources": " ".join(training_sources), "policy": policy,
        "wait_rule": wait_rule, "delay_rule": delay_rule, "is_fixed_baseline": baseline, "is_joint": is_joint,
        "prediction_status": status, "selected_tau": float(probe["tau"]), "selection_score": model_score,
        "proposed_elapsed_connected": predicted_delay, "selected_elapsed_connected": delay / 1000,
        "selected_elapsed_total": (ticks(probe["tau"]) + delay) / 1000,
        "oracle_tau": float(oracle["tau"]), "oracle_elapsed_connected": float(oracle["best_elapsed_connected"]),
        "oracle_max_net": denominator, "oracle_is_admissible": eligible,
        "selected_wait_max_net": wait_peak, "selected_wait_oracle_elapsed_connected": wait_oracle,
        "wait_only_attainment": (wait_peak if probe["peak_admissible"] else 0.0) / denominator if eligible else "",
        "proposed_net_work": net, "proposed_net_half_same_time": half_work(row),
        "proposed_net_step_error": abs(net - half_work(row)), "admissible": admissible(row), "adopted_net_work": adopted,
        "joint_attainment": adopted / denominator if eligible and is_joint else "",
        "time_error_from_wait_oracle": abs(delay / 1000 - wait_oracle),
    }


def predict_loso(probes, paths):
    data = {
        source: sorted((r for r in probes if r["scan"] == PREDICTION_COHORT and r["source"] == source),
                       key=lambda r: ticks(r["tau"])) for source in SOURCES
    }
    if any(tuple(ticks(r["tau"]) for r in rows) != WAIT_GRID for rows in data.values()):
        raise ValueError("Phase D needs all three preregistered coarse wait grids")
    source_oracle = {source: best_probe(rows) for source, rows in data.items()}
    results = []
    for held, held_out in data.items():
        training_sources = [name for name in SOURCES if name != held]
        training = [r for source in training_sources for r in data[source]]
        if not any(source_oracle[source]["peak_admissible"] for source in training_sources):
            raise ValueError(f"No resolved training-work reference when holding out {held}")
        test_oracle = source_oracle[held]
        peak_models, delay_models = train_models(training, source_oracle)
        common_delay = fixed_delay(training, paths)
        for rule, options in zip(BASELINES, ((0,), (2000,), WAIT_GRID), strict=True):
            wait, delay = fixed_pair(training, source_oracle, paths, options)
            probe = next(r for r in held_out if ticks(r["tau"]) == wait)
            results.append(outcome_record(held, training_sources, rule, rule, "train_fixed_pair", probe,
                                          test_oracle, paths, delay, delay / 1000, baseline=True))
        for rule in ("max_current", "max_amplitude", *FEATURE_METHODS):
            probe, score, status = choose_wait(held_out, rule, peak_models.get(rule))
            steps = paths[wait_key(probe)]
            estimator_delay = ridge_value(probe, delay_models.get(rule))
            for delay_rule, target in (
                ("wait_oracle_diagnostic", float(probe["best_elapsed_connected"])),
                ("train_fixed_delay", common_delay / 1000),
                ("learned_delay", estimator_delay),
            ):
                if target is None:
                    continue
                delay = nearest_step(target, steps)
                results.append(outcome_record(held, training_sources, f"{rule}+{delay_rule}", rule, delay_rule,
                                              probe, test_oracle, paths, delay, target, score, status))
    return results, data, source_oracle


def prediction_gate(rows):
    aggregated = []
    for policy in dict.fromkeys(r["policy"] for r in rows if r["is_joint"]):
        group = [r for r in rows if r["policy"] == policy]
        values = [r["joint_attainment"] for r in group if r["joint_attainment"] != ""]
        complete = len(values) == len(SOURCES)
        aggregated.append({
            "policy": policy, "wait_rule": group[0]["wait_rule"], "delay_rule": group[0]["delay_rule"],
            "is_fixed_baseline": group[0]["is_fixed_baseline"], "scored_folds": len(values), "all_folds_scored": complete,
            "mean_joint_attainment": float(np.mean(values)) if complete else "",
            "minimum_joint_attainment": min(values) if complete else "",
        })
    scored_fixed = [r for r in aggregated if r["is_fixed_baseline"] and r["all_folds_scored"]]
    baseline = max(scored_fixed, key=lambda r: r["mean_joint_attainment"], default=None)
    for row in aggregated:
        complete = row["all_folds_scored"] and baseline is not None
        over_fixed = row["mean_joint_attainment"] - baseline["mean_joint_attainment"] if complete else ""
        row.update(strongest_fixed_baseline=baseline["policy"] if baseline else "",
                   mean_gain_over_strongest_fixed=over_fixed,
                   gate_valid=(complete and not row["is_fixed_baseline"] and row["mean_joint_attainment"] >= 0.8
                               and row["minimum_joint_attainment"] >= 0.5 and over_fixed >= 0.05))
    winner = max((r for r in aggregated if r["gate_valid"]), key=lambda r: r["mean_joint_attainment"], default=None)
    for row in aggregated:
        row["selected_for_phase_e"] = row is winner
    return aggregated, winner


def refit_for_phase_e(winner, data, source_oracle, paths):
    training = [r for source in SOURCES for r in data[source]]
    peak_models, timing_models = train_models(training, source_oracle)
    return {
        "policy": winner["policy"], "wait_rule": winner["wait_rule"], "delay_rule": winner["delay_rule"],
        "training_sources": list(SOURCES), "coarse_wait_grid_ticks": list(WAIT_GRID),
        "phase_floor": PHASE_FLOOR, "ridge_penalty": RIDGE,
        "peak_model": peak_models.get(winner["wait_rule"]),
        "delay_model": timing_models.get(winner["wait_rule"]) if winner["delay_rule"] == "learned_delay" else None,
        "fixed_delay_ticks": fixed_delay(training, paths),
    }


def recommend(model, rows, horizon=18_000, step_size=20):
    """Return the selected wait and connected duration in milliseconds from reconnection observations."""
    if tuple(sorted(ticks(row["tau"]) for row in rows)) != tuple(model["coarse_wait_grid_ticks"]):
        raise ValueError("Phase E prediction needs the preregistered coarse wait grid")
    observations = [{**row, **phase_fields(row)} for row in rows]
    chosen, _, status = choose_wait(observations, model["wait_rule"], model["peak_model"])
    delay = ridge_value(chosen, model["delay_model"])
    if delay is None:
        delay = model["fixed_delay_ticks"] / 1000
    tau = ticks(chosen["tau"])
    return tau, nearest_step(delay, range(0, horizon - tau + 1, step_size)), status


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path, help="Directory with merged M23 candidates and wait summaries")
    parser.add_argument("--output", type=Path, help="Write analysis products to this directory")
    parser.add_argument("--benchmark", action="store_true", help="Analyze abbreviated data without running Phase D")
    args = parser.parse_args()
    out = args.output or args.directory
    out.mkdir(parents=True, exist_ok=True)
    paths, probes = grid_and_probes(args.directory)
    write_csv(out / "m23_phase_b.csv", probes)
    write_csv(out / "m23_relationships.csv", relationships(probes))
    if not args.benchmark:
        predictions, data, oracle = predict_loso(probes, paths)
        gates, winner = prediction_gate(predictions)
        write_csv(out / "m23_prediction.csv", predictions)
        write_csv(out / "m23_prediction_gate.csv", gates)
        if winner is not None:
            frozen = refit_for_phase_e(winner, data, oracle, paths)
            with (out / "m23_prediction_model.json").open("x", encoding="utf-8") as stream:
                json.dump(frozen, stream, indent=2, allow_nan=False)
                stream.write("\n")


if __name__ == "__main__":
    main()
