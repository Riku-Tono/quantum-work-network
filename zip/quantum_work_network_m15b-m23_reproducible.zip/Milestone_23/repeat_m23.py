"""M23 repeated policies, run only when the registered single-extraction gate passes."""
import argparse
import json
from pathlib import Path
import time

import numpy as np

from analyze_m23 import recommend
from m21_observables import read_state, expectation
from m23_spectral import Dynamics, DT, FLOOR, G, GRID, HORIZON, SOURCE_TIME, local_diagnostics, partial
from run_m23 import ROOT, COARSE_TAUS, Tables, account, csv_rows, emit_candidates, largest, ms, refine_trials, save_selection, scan, selected_snapshots


def present_controls(model, initial):
    basis=model.bases[0]
    origin=basis.to_basis(initial)
    for tau in COARSE_TAUS:
        rho=basis.from_basis(basis.step_spectral(origin,tau,DT[0])) if tau else initial
        values=local_diagnostics(partial(rho))
        diagnostics=model.metrics(rho,G)
        yield {
            "tau":tau/1000,
            **{f"reconnect_{k}":values[k] for k in (
                "c_real","c_imag","c_abs","load_energy","load_purity","load_ergotropy","load_passive_energy","terminal_population")},
            "reconnect_current": values["load_current"],
            "reconnect_global_energy":diagnostics["global_energy"],
            **{f"reconnect_{k}":diagnostics[k] for k in (
                "global_ergotropy","sector_ergotropy","mutual_information","total_excitation")},
        }


def summary(data, tables):
    accepted={p:[r for r in rows if r["accepted"]] for p,rows in data.items()}
    common_count=min(map(len,accepted.values()))
    common_time=min(ms(rows[-1]["time"]) for rows in data.values())
    events=sorted({SOURCE_TIME,common_time} | {ms(r["time"]) for rows in data.values() for r in rows})
    for p, trials in data.items():
        actions=accepted[p]
        terminal=trials[-1]
        common_credit=0.0
        count_at_common=0
        for now in events:
            past=[r for r in actions if ms(r["time"])<=now]
            w=past[-1]["cumulative_net"] if past else 0.
            if now==common_time:
                common_credit=w
                count_at_common=len(past)
            tables.add("m23_repeated_time",{
                "strategy":p,"time":now/1000,"elapsed_since_anchor":(now-SOURCE_TIME)/1000,
                "adopted_count":len(past),"cumulative_net":w,"within_observed_time":now<=ms(terminal["time"]),
            })
        duration=(ms(terminal["time"])-SOURCE_TIME)/1000
        end_work=terminal["cumulative_net"]
        tables.add("m23_repeated_summary",{
            "strategy":p,"adopted_count":len(actions),"last_attempted_cycle":terminal["cycle"],
            "last_adopted_cycle":actions[-1]["cycle"] if actions else "",
            "elapsed_at_endpoint":duration,"cumulative_net":end_work,"cumulative_rate":end_work/duration if duration else 0.,
            "common_adoption_count":common_count,"cumulative_at_common_count":actions[common_count-1]["cumulative_net"] if common_count else 0.,
            "elapsed_at_common_count":actions[common_count-1]["elapsed_since_anchor"] if common_count else 0.,
            "common_elapsed":(common_time-SOURCE_TIME)/1000,
            "adopted_count_at_common_time":count_at_common,"cumulative_at_common_time":common_credit,
            "after_global_ergotropy":terminal["after_global_ergotropy"],"after_sector_ergotropy":terminal["after_sector_ergotropy"],
            "resolved_increase_cycles":" ".join(str(r["cycle"]) for r in trials if r["resolved_increase"]),
            "recovered_initial_fraction":end_work/trials[0]["initial_global_ergotropy"],
        })


def run(root, single, destination):
    opt=csv_rows(single/"m23_policy_comparison.csv")
    if not any(row["strategy"]=="C" and row["optimal_exceeds_both_resolved"]=="True" for row in opt):
        raise ValueError("Registered Phase E gate did not pass")
    gate=single/"m23_prediction_model.json"
    policies=["A","B","C"]
    prediction=None
    if gate.is_file():
        prediction=json.loads(gate.read_text(encoding="utf8"))
        policies.append("D")
    src=next(r for r in csv_rows(root/"m23_sources.csv") if r["source"]=="S0")
    origin=read_state(root/src["filename"],float(src["source_time"]))
    model=Dynamics(HORIZON)
    anchor_metrics=model.metrics(origin,G)
    tables=Tables(destination)
    begin=time.perf_counter()
    results={}
    for strategy in policies:
        initial=(origin,origin)
        tick=SOURCE_TIME
        cumulative=0.
        data=[]
        previous=None
        for cycle in range(3,11):
            started=time.perf_counter()
            label=f"E_{strategy}"
            policy_status="registered_optimization"
            selected_by_policy=None
            if strategy == "D":
                tau, delay, policy_status=recommend(prediction,list(present_controls(model, initial[0])))
                taus=(tau,)
                selected_by_policy=delay//GRID
            else:
                taus={"A":(0,), "B":(2000,), "C":COARSE_TAUS}[strategy]
            coarse=scan(model,tables,label+"_coarse" if strategy=="C" else label,"S0",cycle,tick,initial,taus,False)
            if strategy=="C":
                refined, tau_lattice=refine_trials(coarse)
                refined_results=scan(model,tables,label+"_refined","S0",cycle,tick,initial,tau_lattice,False)
                for rank, center in enumerate(refined,1):
                    tables.add("m23_repeated_refinement",{"strategy":strategy,"cycle":cycle,"rank":rank,"tau":center.tau/1000})
                trial=largest(coarse+refined_results)
            else:
                trial=coarse[0]
            i=trial.selection_index if selected_by_policy is None else selected_by_policy
            coarse_result, half_result=(record["net_work"][i] for record in (trial.coarse,trial.half))
            reached=trial.tau+i*GRID
            now=tick+reached
            selected=selected_snapshots(model,trial.rho_wait,trial.spectra,i*GRID)
            meta=trial.data
            accounting, _=account(model,initial[0],trial.rho_wait[0],selected[0],coarse_result,trial.tau,
                                  meta["cut_on"],meta["reconnect_on"])
            accounting_half,_=account(model,initial[1],trial.rho_wait[1],selected[1],half_result,trial.tau,
                                      meta["cut_on_half"],meta["reconnect_on_half"])
            direct=accounting["direct_net"]
            error=abs(coarse_result-half_result)
            accepted=coarse_result-error>FLOOR and direct>FLOOR
            _,after,names,after_error=save_selection(model,tables,trial,initial,i,accepted)
            measurements=model.metrics(after[0] if accepted else selected[0],G)
            start_features=model.metrics(initial[0],G)
            if accepted:
                cumulative += direct
            closure=measurements["global_energy"]-(anchor_metrics["global_energy"]-cumulative)
            ergotropy_balance=measurements["global_ergotropy"]-(anchor_metrics["global_ergotropy"]-cumulative)
            if max(abs(closure),abs(ergotropy_balance))>FLOOR:
                raise ValueError(f"Cumulative balance failed {strategy} cycle {cycle}")
            row={
                "strategy":strategy,"scan":meta["scan"],"source":"S0","cycle":cycle,"accepted":accepted,
                "tau":trial.tau/1000,"elapsed_connected":i*GRID/1000,"elapsed_total":reached/1000,
                "start_time":tick/1000,"time":now/1000,"elapsed_since_anchor":(now-SOURCE_TIME)/1000,
                "pre_candidate_net":coarse_result,"net_work":direct,"net_half":half_result,"net_half_direct":accounting_half["direct_net"],
                "resolution_margin":coarse_result-error,"cumulative_net":cumulative,
                "cycle_rate":direct/(reached/1000) if reached else "",
                "cumulative_rate":cumulative/((now-SOURCE_TIME)/1000) if now!=SOURCE_TIME else "",
                "net_to_previous":direct/previous["net_work"] if previous is not None and accepted else "",
                "resolved_increase":bool(previous is not None and accepted and
                                         direct-previous["net_work"]>error+previous["net_half_error"]+FLOOR),
                "net_half_error":error,"cumulative_balance_residual":closure,"cumulative_ergotropy_residual":ergotropy_balance,
                "cut_on":meta["cut_on"],"reconnect_on":meta["reconnect_on"],
                "gross_work":trial.coarse["gross_work"][i],"total_work":trial.coarse["total_work"][i],
                "interaction_jump":trial.coarse["interaction_jump"][i],
                **{k:meta[k] for k in ("reconnect_c_real","reconnect_c_imag","reconnect_c_abs","reconnect_c_phase","reconnect_current")},
                "initial_global_ergotropy":start_features["global_ergotropy"],
                "initial_sector_ergotropy":start_features["sector_ergotropy"],
                **{f"after_{k}":measurements[k] for k in (
                    "global_ergotropy","sector_ergotropy","global_passive_energy","global_purity","total_excitation",
                    "any_local_unitary_full_work_upper_bound")},
                "before_state":names["before","coarse"],
                "after_state":names["after","coarse"] if accepted else "",
                "after_state_max_abs_difference":after_error,
                "policy_status":policy_status,**accounting,
            }
            tables.add("m23_repeated",row)
            emit_candidates(tables,"m23_repeated_candidates",trial)
            data.append(row)
            tables.add("m23_repeated_runtime",{
                "strategy":strategy,"cycle":cycle,"seconds":time.perf_counter()-started,
            })
            tables.flush()
            print(f"{strategy} #{cycle} accepted={accepted} wait={trial.tau/1000:.3f} "
                  f"t={now/1000:.3f} net={direct:.8e} ({time.perf_counter()-started:.2f}s)",flush=True)
            if not accepted:
                break
            initial=after
            tick=now
            previous=row
        results[strategy]=data
    summary(results,tables)
    tables.close()
    print(f"Phase E total {time.perf_counter()-begin:.2f} seconds",flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("single",type=Path)
    parser.add_argument("destination",type=Path)
    parser.add_argument("--inputs",type=Path,default=ROOT)
    args=parser.parse_args()
    args.destination.mkdir()
    run(args.inputs,args.single,args.destination)
