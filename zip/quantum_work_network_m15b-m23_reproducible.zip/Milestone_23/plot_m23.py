"""Render the M23 wait-time, coherence, and repeated-extraction results."""

import argparse
import csv
from collections import defaultdict
import math
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parent
INK = "#152637"
MUTED = "#42586C"
GRID = "#DFE7ED"
AXIS = "#8797A5"
BLUE = "#225886"
TEAL = "#007172"
ORANGE = "#A2441A"
PURPLE = "#704984"
PANEL_LABELS = {"S0": "S0 · M18 after cycle 2", "S1": "S1 · M21-C after cycle 6", "S2": "S2 · M21-C after cycle 10"}
WAIT_STYLES = {
    "optimum": (TEAL, "D", "-", r"Work-optimal wait $\tau_\mathrm{opt}$"),
    "two": (BLUE, "s", "--", r"Fixed wait $\tau=2$"),
    "zero": (ORANGE, "o", "-.", r"Stay connected $\tau=0$"),
}
COARSE = (BLUE, "o", "-", "Coarse grid")
FINE = (TEAL, "s", "none", "Refined samples")
OPTIMUM = (ORANGE, "D", "none", "Highest recorded work")
POLICY_STYLES = {
    "A": (ORANGE, "o", "-.", "A · Stay connected"),
    "B": (BLUE, "s", "--", "B · Fixed wait 2"),
    "C": (TEAL, "D", "-", "C · Optimize wait and extraction"),
    "D": (PURPLE, "^", ":", "D · Phase-based rule"),
}


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))


def group(rows, *columns):
    result = defaultdict(list)
    for row in rows:
        result[tuple(row[column] for column in columns)].append(row)
    return result


def value(row, column):
    text = row[column]
    return float(text) if text else math.nan


def adopted(row):
    return row["accepted"].strip().lower() in {"true", "yes", "1"}


def style_axis(ax, *, title=None, xlabel=None, ylabel=None, zero=False, grid=True, scientific=True):
    ax.set_axisbelow(True)
    if grid:
        ax.yaxis.grid(True, color=GRID, linewidth=0.8)
    ax.spines[["top", "right"]].set_visible(False)
    for edge in ("left", "bottom"):
        ax.spines[edge].set_color(AXIS)
    ax.tick_params(axis="both", color=AXIS, labelcolor=INK, labelsize=9)
    if scientific and ax.get_yscale() == "linear":
        ax.ticklabel_format(axis="y", style="sci", scilimits=(-3, 3), useMathText=True, useOffset=False)
        ax.yaxis.offsetText.set_color(MUTED)
        ax.yaxis.offsetText.set_fontsize(8)
    if zero:
        ax.axhline(0, color=AXIS, linewidth=0.8, zorder=1)
    if title:
        ax.set_title(title, loc="left", color=INK, fontsize=10.5, pad=8)
    if xlabel:
        ax.set_xlabel(xlabel, color=INK, fontsize=10)
    if ylabel:
        ax.set_ylabel(ylabel, color=INK, fontsize=10)


def header(fig, title, detail, *, styles=(), top=0.78, bottom=0.13, left=0.10, right=0.973,
           heading_left=None, **spacing):
    from matplotlib.lines import Line2D

    fig.subplots_adjust(left=left, right=right, top=top, bottom=bottom, **spacing)
    text_left = left if heading_left is None else heading_left
    fig.text(text_left, 0.975, title, fontsize=18, color=INK, fontweight="bold", va="top")
    fig.text(text_left, 0.91, detail, fontsize=10, color=MUTED, va="top")
    if styles:
        handles = [Line2D([], [], color=color, marker=marker, linestyle=line,
                          markerfacecolor="white", label=label) for color, marker, line, label in styles]
        fig.legend(handles=handles, loc="upper left", bbox_to_anchor=(text_left - 0.004, 0.862),
                   ncols=len(handles), frameon=False, labelcolor=INK, fontsize=9.1, columnspacing=1.6, handlelength=2.4)


def panel_headers(fig, axes, labels):
    gap = 16 / (72 * fig.get_figheight())
    for ax, label in zip(axes, labels):
        bounds = ax.get_position()
        fig.text(bounds.x0, bounds.y1 + gap, label, color=INK, fontsize=10.6, va="bottom")


def line(ax, x, y, style, *, marker=False, drawstyle="default"):
    color, symbol, pattern, _ = style
    ax.plot(x, y, color=color, linestyle=pattern, marker=symbol if marker else None,
            markersize=4.6, markeredgewidth=1.15, markerfacecolor="white", linewidth=1.55, drawstyle=drawstyle)


def mark(ax, x, y, style, *, area=39):
    color, symbol, _, _ = style
    ax.scatter(x, y, color=color, marker=symbol, s=area, facecolors="white", linewidths=1.25, zorder=4)


def scientific_colorbar(fig, ax, image, label):
    from matplotlib.ticker import ScalarFormatter

    formatter = ScalarFormatter(useMathText=True, useOffset=False)
    formatter.set_powerlimits((-3, 3))
    key = fig.colorbar(image, ax=ax, pad=0.03, fraction=0.05, format=formatter)
    key.set_label(label, color=INK, fontsize=9)
    key.ax.tick_params(labelsize=8, labelcolor=INK, color=AXIS)
    offset = key.ax.yaxis.offsetText
    offset.set_fontsize(8)
    offset.set_x(0)
    offset.set_horizontalalignment("left")
    return key


def phase_ticks(ax):
    ax.set_xticks((-math.pi, -math.pi / 2, 0, math.pi / 2, math.pi),
                  (r"$-\pi$", r"$-\pi/2$", "0", r"$\pi/2$", r"$\pi$"))
    ax.set_xlim(-math.pi - 0.14, math.pi + 0.14)


def finish(plt, fig, output, filename):
    fig.savefig(output / filename, dpi=190, facecolor="white")
    plt.close(fig)


def wait_key(row):
    return row["scan"], row["source"], value(row, "tau")


def read_paths(path):
    columns = ("elapsed_total", "net_work", "load_ergotropy", "load_energy", "load_current")
    paths = defaultdict(list)
    with path.open(encoding="utf-8-sig", newline="") as file:
        for row in csv.DictReader(file):
            if row["scan"] in {"A", "C"}:
                paths[wait_key(row)].append({column: row[column] for column in columns})
    for rows in paths.values():
        rows.sort(key=lambda row: value(row, "elapsed_total"))
    return paths


def distinct_waits(coarse, refined):
    by_wait = {value(row, "tau"): row for row in refined}
    by_wait.update({value(row, "tau"): row for row in coarse})
    return [by_wait[tau] for tau in sorted(by_wait)]


def wait_choices(coarse, refined):
    peak = max(
        (*coarse, *refined),
        key=lambda row: (value(row, "max_net"), -value(row, "best_elapsed_total"), -value(row, "tau")),
    )
    by_wait = {value(row, "tau"): row for row in coarse}
    return {"zero": by_wait[0.0], "two": by_wait[2.0], "optimum": peak}


def cell_edges(centers, step):
    if len(centers) == 1:
        return [centers[0] - step / 2, centers[0] + step / 2]
    return [
        centers[0] - (centers[1] - centers[0]) / 2,
        *[(a + b) / 2 for a, b in zip(centers, centers[1:])],
        centers[-1] + (centers[-1] - centers[-2]) / 2,
    ]


def plot_heatmap(plt, waits, paths, choices, output):
    from matplotlib.colors import Normalize

    fig, axes = plt.subplots(1, 3, figsize=(14.7, 5.65), sharey=True)
    header(fig, "Net work across wait and extraction times",
           "Each strip uses its recorded time grid. Colors scale separately for each saved state. Stars mark the sampled maxima.",
           top=0.79, bottom=0.17, right=0.937, wspace=0.45)
    last = max(value(rows[-1], "elapsed_total") for rows in paths.values())
    maximum_wait = max(value(row, "tau") for rows in waits.values() for row in rows)
    wait_padding = 0.026 * maximum_wait
    for col, (ax, source) in enumerate(zip(axes, PANEL_LABELS)):
        trajectories = [paths[wait_key(row)] for row in waits[source]]
        all_work = [value(row, "net_work") for rows in trajectories for row in rows]
        norm = Normalize(min(0.0, min(all_work)), max(all_work))
        tau = [value(row, "tau") for row in waits[source]]
        y_edges = cell_edges(tau, 0.25)
        for index, rows in enumerate(trajectories):
            x_edges = cell_edges([value(row, "elapsed_total") for row in rows], 0.02)
            z = [[value(row, "net_work") for row in rows]]
            mesh = ax.pcolormesh(x_edges, y_edges[index:index + 2], z, cmap="viridis", norm=norm, shading="flat")
        peak = choices[source]["optimum"]
        ax.scatter(value(peak, "best_elapsed_total"), value(peak, "tau"), s=115, marker="*",
                   color="white", edgecolors=INK, linewidths=0.85, zorder=5)
        ax.set_xlim(-0.018 * last, 1.018 * last)
        if math.isclose(last, 18.0, abs_tol=1e-9):
            ax.set_xticks((0, 3, 6, 9, 12, 15, 18))
        ax.set_ylim(-wait_padding, maximum_wait + wait_padding)
        style_axis(ax, xlabel=r"Total elapsed time $T$", ylabel=r"Disconnected wait $\tau$" if col == 0 else None,
                   grid=False)
        scientific_colorbar(fig, ax, mesh, "Net work")
    panel_headers(fig, axes, PANEL_LABELS.values())
    finish(plt, fig, output, "m23_01_wait_time_work_map.png")


def plot_wait_work(plt, coarse, refined, choices, output):
    fig, axes = plt.subplots(1, 3, figsize=(13.8, 5.35))
    styles = (COARSE, FINE, OPTIMUM) if any(refined.values()) else (COARSE, OPTIMUM)
    header(fig, "Maximum net work by disconnected wait",
           "Each point is the best recorded extraction time at that wait. The diamond identifies the overall grid maximum.",
           styles=styles, top=0.72, bottom=0.18, wspace=0.34)
    for col, (ax, source) in enumerate(zip(axes, PANEL_LABELS)):
        rows = coarse[source]
        refined_rows = refined[source]
        line(ax, [value(row, "tau") for row in rows], [value(row, "max_net") for row in rows], COARSE, marker=True)
        ax.scatter([value(row, "tau") for row in refined_rows], [value(row, "max_net") for row in refined_rows],
                   s=17, marker=FINE[1], color=FINE[0], alpha=0.8, zorder=3)
        opt = choices[source]["optimum"]
        mark(ax, value(opt, "tau"), value(opt, "max_net"), OPTIMUM, area=70)
        ax.axvline(2.0, color=AXIS, linestyle=":", linewidth=0.8)
        style_axis(ax, xlabel=r"Disconnected wait $\tau$", ylabel="Maximum net work" if col == 0 else None)
    panel_headers(fig, axes, PANEL_LABELS.values())
    finish(plt, fig, output, "m23_02_wait_vs_maximum_work.png")


def plot_wait_rate(plt, coarse, refined, output):
    styles = (
        (TEAL, "D", "-", "Maximum sampled rate", "best_rate"),
        (BLUE, "o", "--", "Rate at the work-optimal time", "rate_at_best_net"),
    )
    fig, axes = plt.subplots(1, 3, figsize=(13.8, 5.35))
    detail = "Rate is net work divided by total elapsed time, including the wait."
    if any(refined.values()):
        detail += " Filled markers show refined samples."
    header(fig, "Time efficiency by disconnected wait", detail,
           styles=[style[:4] for style in styles], top=0.72, bottom=0.18, wspace=0.34)
    for col, (ax, source) in enumerate(zip(axes, PANEL_LABELS)):
        rows = coarse[source]
        refined_rows = refined[source]
        for color, marker, pattern, label, column in styles:
            line(ax, [value(row, "tau") for row in rows], [value(row, column) for row in rows],
                 (color, marker, pattern, label), marker=True)
            ax.scatter([value(row, "tau") for row in refined_rows], [value(row, column) for row in refined_rows],
                       s=16, marker=marker, color=color, alpha=0.7, zorder=3)
        ax.axvline(2, color=AXIS, linestyle=":", linewidth=0.8)
        style_axis(ax, xlabel=r"Disconnected wait $\tau$", ylabel="Net work / model time" if col == 0 else None)
    panel_headers(fig, axes, PANEL_LABELS.values())
    finish(plt, fig, output, "m23_03_wait_vs_time_efficiency.png")


def phase_defined(row):
    flag = row.get("phase_identified", "true")
    return flag.strip().lower() in {"true", "yes", "1"} and math.isfinite(value(row, "reconnect_c_phase"))


def plot_complex_path(plt, waits, choices, output):
    from matplotlib.colors import Normalize

    fig, axes = plt.subplots(1, 3, figsize=(14.4, 5.55))
    header(fig, "Terminal–load coherence during the disconnected wait",
           r"The path traces $C(\tau)=\mathrm{Tr}[\rho(\tau)\,\sigma^+_7 b]$ at each candidate wait endpoint.",
           styles=tuple(WAIT_STYLES.values()), top=0.73, bottom=0.18, wspace=0.37)
    norm = Normalize(0, max(value(row, "tau") for rows in waits.values() for row in rows))
    for col, (ax, source) in enumerate(zip(axes, PANEL_LABELS)):
        rows = waits[source]
        x = [value(row, "reconnect_c_real") for row in rows]
        y = [value(row, "reconnect_c_imag") for row in rows]
        ax.plot(x, y, color=AXIS, linewidth=1.0, zorder=2)
        points = ax.scatter(x, y, c=[value(row, "tau") for row in rows], cmap="viridis", norm=norm, s=20, zorder=3)
        for key in WAIT_STYLES:
            row = choices[source][key]
            mark(ax, value(row, "reconnect_c_real"), value(row, "reconnect_c_imag"), WAIT_STYLES[key],
                 area=80 if key == "optimum" else 47)
        ax.axvline(0, color=AXIS, linewidth=0.8, zorder=1)
        ax.set_aspect("equal", adjustable="datalim")
        ax.ticklabel_format(axis="x", style="sci", scilimits=(-3, 3), useMathText=True, useOffset=False)
        ax.xaxis.offsetText.set_fontsize(8)
        style_axis(ax, xlabel=r"$\mathrm{Re}\,C$", ylabel=r"$\mathrm{Im}\,C$" if col == 0 else None, zero=True)
        maximum_real = max(map(abs, x))
        if maximum_real < 1e-4 * max(map(abs, y)):
            real_label = f"{maximum_real:.2e}".replace("-", "−")
            ax.text(0.975, 0.92, rf"$\max|\mathrm{{Re}}\,C|$ = {real_label}",
                    ha="right", va="top", transform=ax.transAxes, color=MUTED, fontsize=8.6)
    key = fig.colorbar(points, ax=list(axes), pad=0.032, fraction=0.028)
    key.set_label(r"Disconnected wait $\tau$", color=INK, fontsize=9)
    key.ax.tick_params(labelsize=8, labelcolor=INK, color=AXIS)
    panel_headers(fig, axes, PANEL_LABELS.values())
    finish(plt, fig, output, "m23_04_complex_coherence_path.png")


def plot_phase_current(plt, waits, output):
    fig, axes = plt.subplots(1, 3, figsize=(14.7, 5.50))
    header(fig, "Phase at reconnection and initial energy current",
           r"Positive current enters the load. At $g=0.25$, $J(0^+)=-2g\,|C|\sin(\arg C)$.",
           top=0.78, bottom=0.18, right=0.937, wspace=0.46)
    for col, (ax, source) in enumerate(zip(axes, PANEL_LABELS)):
        rows = [row for row in waits[source] if phase_defined(row)]
        scatter = ax.scatter([value(row, "reconnect_c_phase") for row in rows],
                             [value(row, "reconnect_current") for row in rows],
                             c=[value(row, "reconnect_c_abs") for row in rows], cmap="viridis",
                             s=31, edgecolors=INK, linewidths=0.35, zorder=3)
        phase_ticks(ax)
        style_axis(ax, xlabel=r"Coherence phase $\arg C$", ylabel=r"Current into load $J(0^+)$" if col == 0 else None, zero=True)
        scientific_colorbar(fig, ax, scatter, r"Amplitude $|C|$")
    panel_headers(fig, axes, PANEL_LABELS.values())
    finish(plt, fig, output, "m23_05_phase_and_initial_current.png")


def plot_phase_work(plt, waits, choices, output):
    fig, axes = plt.subplots(1, 3, figsize=(14.7, 5.50))
    header(fig, "Phase, amplitude, and extractable net work",
           "Each color represents the best net work at that wait. Diamonds outline the overall grid maxima.",
           top=0.78, bottom=0.18, right=0.937, wspace=0.46)
    for col, (ax, source) in enumerate(zip(axes, PANEL_LABELS)):
        rows = [row for row in waits[source] if phase_defined(row)]
        scatter = ax.scatter([value(row, "reconnect_c_phase") for row in rows],
                             [value(row, "reconnect_c_abs") for row in rows],
                             c=[value(row, "max_net") for row in rows], cmap="viridis",
                             s=32, edgecolors=INK, linewidths=0.34, zorder=3)
        opt = choices[source]["optimum"]
        if phase_defined(opt):
            ax.scatter(value(opt, "reconnect_c_phase"), value(opt, "reconnect_c_abs"),
                       marker="D", s=77, facecolors="none", edgecolors=ORANGE, linewidths=1.6, zorder=4)
        phase_ticks(ax)
        style_axis(ax, xlabel=r"Coherence phase $\arg C$", ylabel=r"Coherence amplitude $|C|$" if col == 0 else None)
        scientific_colorbar(fig, ax, scatter, "Maximum net work")
    panel_headers(fig, axes, PANEL_LABELS.values())
    finish(plt, fig, output, "m23_06_phase_amplitude_and_work.png")


def plot_selected_paths(plt, paths, choices, output):
    metrics = (
        ("net_work", "Candidate net work", True),
        ("load_ergotropy", "Load ergotropy", True),
        ("load_energy", "Load energy", False),
        ("load_current", "Current into load", True),
    )
    fig, axes = plt.subplots(4, 3, figsize=(14.1, 12.3), sharex=True)
    header(fig, "Evolution at the work-optimal and reference waits",
           "Curves start when the load is connected. Symbols mark the work-optimal extraction time along each curve.",
           styles=tuple(WAIT_STYLES.values()), top=0.80, bottom=0.09, wspace=0.31, hspace=0.42)
    last = max(value(rows[-1], "elapsed_total") for rows in paths.values())
    padding = 0.015 * last
    labels = []
    for col, source in enumerate(PANEL_LABELS):
        opt_tau = value(choices[source]["optimum"], "tau")
        labels.append(f"{source}  ·  " + rf"$\tau_\mathrm{{opt}}={opt_tau:g}$")
        for index, (metric, ylabel, zero) in enumerate(metrics):
            ax = axes[index, col]
            for key in WAIT_STYLES:
                summary = choices[source][key]
                rows = paths[wait_key(summary)]
                x = [value(row, "elapsed_total") for row in rows]
                y = [value(row, metric) for row in rows]
                style = WAIT_STYLES[key]
                line(ax, x, y, style)
                selected = value(summary, "best_elapsed_total")
                match = min(range(len(x)), key=lambda sample: abs(x[sample] - selected))
                if abs(x[match] - selected) > 1e-9:
                    raise ValueError(f"Missing work-optimal sample for {source} at {selected}")
                mark(ax, selected, y[match], style, area=47 if key == "optimum" else 27)
            ax.set_xlim(-padding, last + padding)
            if math.isclose(last, 18, abs_tol=1e-9):
                ax.set_xticks((0, 2, 6, 10, 14, 18))
            style_axis(ax, ylabel=ylabel if col == 0 else None, zero=zero,
                       xlabel=r"Total elapsed time $T$" if index == len(metrics) - 1 else None)
    panel_headers(fig, axes[0], labels)
    finish(plt, fig, output, "m23_07_selected_wait_trajectories.png")


PREDICTORS = {
    "tau0_fixed": r"Fixed $\tau=0$",
    "tau2_fixed": r"Fixed $\tau=2$",
    "train_best_fixed_pair": "Training-selected fixed pair",
    "max_current": "Maximum initial current",
    "max_amplitude": "Maximum coherence magnitude",
    "current_ridge": "Current ridge model",
    "imag_ridge": "Imaginary coherence ridge model",
    "phase_ridge": "Phase ridge model",
    "phase_amplitude_ridge": "Phase and amplitude ridge model",
    "multi_ridge": "Combined ridge model",
}
DELAYS = {
    "train_fixed_delay": "fixed delay",
    "learned_delay": "learned delay",
    "wait_oracle_diagnostic": "oracle delay",
}


def prediction_label(policy):
    wait, _, delay = policy.partition("+")
    label = PREDICTORS.get(wait, wait.replace("_", " "))
    return f"{label} · {DELAYS.get(delay, delay.replace('_', ' '))}" if delay else label


def plot_prediction(plt, rows, output):
    by_pair = {(row["held_out_source"], row["policy"]): row for row in rows}
    seen = {row["policy"] for row in rows}
    ordered = [name for name in PREDICTORS if name in seen]
    ordered.extend(f"{name}+{delay}" for name in PREDICTORS for delay in DELAYS if f"{name}+{delay}" in seen)
    ordered.extend(sorted(seen.difference(ordered)))
    comparisons = (
        (TEAL, "o", "none", "Selected wait with its best sampled time", "wait_only_attainment", -0.14),
        (ORANGE, "D", "none", "Selected wait and time together", "joint_attainment", 0.14),
    )
    fig, axes = plt.subplots(1, 3, figsize=(15.6, max(6.4, len(ordered) * 0.35 + 2.65)), sharex=True, sharey=True)
    header(fig, "Held-out predictions against the exhaustive search",
           "Attainment is normalized to the highest net work on the held-out state’s coarse grid.",
           styles=[style[:4] for style in comparisons], top=0.77, bottom=0.13, left=0.265, heading_left=0.10, wspace=0.17)
    for col, (ax, source) in enumerate(zip(axes, PANEL_LABELS)):
        ax.axvline(1, color=AXIS, linestyle=":", linewidth=1, zorder=1)
        for index, policy in enumerate(ordered):
            row = by_pair.get((source, policy))
            if row is None:
                continue
            for color, marker, _, _, column, offset in comparisons:
                score = value(row, column)
                if math.isfinite(score):
                    ax.scatter(score, index + offset, color=color, marker=marker, s=31,
                               facecolors="white", linewidths=1.2, zorder=3)
        ax.set_yticks(range(len(ordered)), [prediction_label(policy) for policy in ordered])
        ax.set_ylim(len(ordered) - 0.5, -0.5)
        ax.set_xlim(-0.045, 1.075)
        ax.set_xticks([0, 0.25, 0.50, 0.75, 1.00])
        style_axis(ax, xlabel="Fraction of exhaustive maximum", scientific=False)
        if col == 0:
            ax.tick_params(axis="y", labelsize=8.3, length=0)
    panel_headers(fig, axes, PANEL_LABELS.values())
    finish(plt, fig, output, "m23_08_prediction_vs_exhaustive.png")


def repeated_groups(rows):
    groups = {strategy: part for (strategy,), part in group(rows, "strategy").items()}
    for part in groups.values():
        part.sort(key=lambda row: int(row["cycle"]))
    return {strategy: groups[strategy] for strategy in POLICY_STYLES if strategy in groups}


def plot_repeated_work(plt, groups, output):
    styles = tuple(POLICY_STYLES[strategy] for strategy in groups)
    final_times = [value(rows[-1], "elapsed_since_anchor") for rows in groups.values()]
    common_time, horizon = min(final_times), max(final_times)
    fig, ax = plt.subplots(figsize=(12.5, 5.8))
    header(fig, "Cumulative net work from repeated extraction",
           f"The dotted line marks the common elapsed time ({common_time:g}). Markers show accepted extractions.",
           styles=styles, top=0.77, bottom=0.17)
    for strategy, rows in groups.items():
        accepted = [row for row in rows if adopted(row)]
        x = [0.0, *[value(row, "elapsed_since_anchor") for row in accepted]]
        y = [0.0, *[value(row, "cumulative_net") for row in accepted]]
        plotted_x = [*x, horizon] if x[-1] < horizon else x
        plotted_y = [*y, y[-1]] if x[-1] < horizon else y
        line(ax, plotted_x, plotted_y, POLICY_STYLES[strategy], drawstyle="steps-post")
        for time, amount in zip(x[1:], y[1:]):
            mark(ax, time, amount, POLICY_STYLES[strategy], area=34)
    ax.axvline(common_time, color=AXIS, linestyle=":", linewidth=1)
    style_axis(ax, xlabel="Model time since S0", ylabel="Cumulative net work", zero=True)
    finish(plt, fig, output, "m23_09_repeated_cumulative_work.png")


def plot_repeated_reserve(plt, groups, output):
    columns = (
        ("after_global_ergotropy", "Global ergotropy", "initial_global_ergotropy"),
        ("after_sector_ergotropy", "Excitation-preserving ergotropy", "initial_sector_ergotropy"),
    )
    fig, axes = plt.subplots(1, 2, figsize=(13.2, 5.55), sharex=True)
    header(fig, "Work remaining after repeated extraction",
           "Each marker after time zero uses the accepted post-extraction state at g = 0.25.",
           styles=tuple(POLICY_STYLES[strategy] for strategy in groups), top=0.73, bottom=0.19, wspace=0.30)
    for ax, (column, label, start_column) in zip(axes, columns):
        for strategy, rows in groups.items():
            accepted = [row for row in rows if adopted(row)]
            x = [value(row, "elapsed_since_anchor") for row in accepted]
            y = [value(row, column) for row in accepted]
            if rows[0].get(start_column):
                x.insert(0, 0)
                y.insert(0, value(rows[0], start_column))
            line(ax, x, y, POLICY_STYLES[strategy], marker=True)
        style_axis(ax, xlabel="Model time since S0", ylabel=label)
    finish(plt, fig, output, "m23_10_repeated_remaining_work.png")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=ROOT, help="Directory containing the M23 CSVs")
    parser.add_argument("--output", type=Path, help="Figure directory, defaulting to figures under --data")
    parser.add_argument("--repeated", type=Path, help="Separate repeated-trial CSV, if stored outside --data")
    parser.add_argument("--plot-deps", type=Path, help="Optional directory containing Matplotlib and its dependencies")
    args = parser.parse_args()
    if args.plot_deps:
        sys.path.insert(0, str(args.plot_deps.resolve()))

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    output = args.output or args.data / "figures"
    output.mkdir(parents=True, exist_ok=True)
    summaries = group(read_csv(args.data / "m23_wait_summary.csv"), "scan", "source")
    coarse = {source: sorted(summaries["A", source], key=lambda row: value(row, "tau")) for source in PANEL_LABELS}
    refined = {source: sorted(summaries["C", source], key=lambda row: value(row, "tau")) for source in PANEL_LABELS}
    waits = {source: distinct_waits(coarse[source], refined[source]) for source in PANEL_LABELS}
    choices = {source: wait_choices(coarse[source], refined[source]) for source in PANEL_LABELS}
    paths = read_paths(args.data / "m23_candidates.csv")
    phase_csv = args.data / "m23_phase_b.csv"
    phase = {wait_key(row): row for row in read_csv(phase_csv)} if phase_csv.is_file() else {}
    phase_waits = {source: [phase.get(wait_key(row), row) for row in rows] for source, rows in waits.items()}
    phase_choices = {
        source: {name: phase.get(wait_key(row), row) for name, row in rows.items()}
        for source, rows in choices.items()
    }
    plot_heatmap(plt, waits, paths, choices, output)
    plot_wait_work(plt, coarse, refined, choices, output)
    plot_wait_rate(plt, coarse, refined, output)
    plot_complex_path(plt, waits, choices, output)
    plot_phase_current(plt, phase_waits, output)
    plot_phase_work(plt, phase_waits, phase_choices, output)
    plot_selected_paths(plt, paths, choices, output)
    prediction_csv = args.data / "m23_prediction.csv"
    if prediction_csv.is_file():
        plot_prediction(plt, read_csv(prediction_csv), output)
    repeated_csv = args.repeated or args.data / "m23_repeated.csv"
    if repeated_csv.is_file():
        groups = repeated_groups(read_csv(repeated_csv))
        if groups:
            plot_repeated_work(plt, groups, output)
            plot_repeated_reserve(plt, groups, output)


if __name__ == "__main__":
    main()
