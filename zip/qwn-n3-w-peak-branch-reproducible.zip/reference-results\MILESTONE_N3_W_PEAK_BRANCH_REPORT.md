# MILESTONE N3 W PEAK BRANCH REPORT

## Scope and stop condition

Only the three stored N=3, Omega=0.2 trajectories at eta=0, 1.5, 3.0 were read. No new time evolution, smoothing, peak fit, exponential refit, mode analysis, or mechanism analysis was performed.

The official peak values are saved-grid values. Quadratic estimates are auxiliary diagnostics only.

## Fixed extraction rules

- time grid: 0.00 to 10.00 in steps of 0.01 (1001 points)
- local maximum: plateau-grouped interior maximum above both exterior neighbors
- prominence baseline: nearest local minimum on each side, or analysis boundary if none exists
- resolved threshold: relative_prominence >= 1.0e-04
- early window: 5.0 <= t <= 6.0
- late window: 9.0 <= t <= 10.0

## Input integrity

| eta | rows | SHA-256 | source |
|---:|---:|---|---|
| 0 | 1001 | `cc4d4cd2779f29bd1570055a597c79643536b1f3cdb4bee09ffe28f508fe55d6` | `C:\Users\yauki\Documents\Codex\2026-07-14\codex-codex-a-b-2-a\work\quantum_work_network\chain_length_reachability_timeseries.csv` |
| 1.5 | 1001 | `aa582f956aa8942bc886c537d02bbd6eadd2c75984cce10190079a81d917f3f5` | `C:\Users\yauki\Documents\Codex\2026-07-15\milestone-10a\work\quantum_work_network\fixed_total_gamma_1_5_xgamma_timeseries.csv` |
| 3 | 1001 | `7753116415567415330e3186ffa3008c78394b880eb7ff0ac1f909d897f5eb73` | `C:\Users\yauki\Documents\Codex\2026-07-15\milestone-10a\work\quantum_work_network\fixed_total_gamma_3_timeseries.csv` |


## Peak counts

| eta | all candidates | resolved | subthreshold |
|---:|---:|---:|---:|
| 0 | 1 | 1 | 0 |
| 1.5 | 1 | 1 | 0 |
| 3 | 1 | 1 | 0 |

## Window representatives

| eta | early representative | late representative |
|---:|---|---|
| 0 | no_resolved_peak_in_window | t=9.48, W=5.5424064638002993e-02, rank=1 |
| 1.5 | t=5.63, W=3.0302005931286463e-03, rank=1 | no_resolved_peak_in_window |
| 3 | t=5.39, W=5.4644529219776382e-04, rank=1 | no_resolved_peak_in_window |

## Branch ratios

Global maxima and branch-specific ratios are kept separate in `n3_W_peak_branch_comparison.csv`.

- global: eta 0->1.5 ratio=5.4673012759351255e-02; eta 1.5->3 ratio=1.8033304245167661e-01; status=comparable
- early: eta 0->1.5 ratio=not_available; eta 1.5->3 ratio=1.8033304245167661e-01; status=incomplete_no_ratio_imputation
- late: eta 0->1.5 ratio=not_available; eta 1.5->3 ratio=not_available; status=incomplete_no_ratio_imputation


## Verdict

- primary verdict: **`peak_branch_correspondence_incomplete`**
- secondary verdict: **`none`**

Case A is not supported on the stored grid. Case B is not supported on the stored grid.

Case D (`peak_branch_grid_resolution_inconclusive`) is not selected: each detected peak is unique on the saved grid and exceeds the fixed prominence threshold. The incompleteness comes from absent local peaks in the predefined windows, not from promoting shoulders or monotone segments.

The correspondence is descriptive and time-window based. It does not establish that peaks are identical physical modes or processes.

## Interpretation limits

No claim is made about eigenmodes, phase transitions, exponential-law validity, causal noise selection, or identity of the underlying physical process.
