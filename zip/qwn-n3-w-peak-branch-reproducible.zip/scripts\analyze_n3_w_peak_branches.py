from __future__ import annotations

import csv
import hashlib
import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "generated-results"
OUT.mkdir(parents=True, exist_ok=True)

INPUTS = {
    0.0: ROOT / "data" / "reference" / "eta_0_noise_free_timeseries.csv",
    1.5: ROOT / "data" / "reference" / "eta_1_5_timeseries.csv",
    3.0: ROOT / "data" / "reference" / "eta_3_0_timeseries.csv",
}

SOURCE_CODE = {
    1.5: ROOT / "data" / "provenance" / "fixed_total_gamma_1_5_with_xgamma.rs",
    3.0: ROOT / "data" / "provenance" / "fixed_total_gamma_3_comparison.rs",
}

RELATIVE_PROMINENCE_THRESHOLD = 1e-4
EARLY_WINDOW = (5.0, 6.0)
LATE_WINDOW = (9.0, 10.0)
EXPECTED_TIMES = [i / 100 for i in range(1001)]


@dataclass
class Series:
    eta: float
    times: list[float]
    values: list[float]
    sha256: str
    source_path: Path


@dataclass
class Plateau:
    start: int
    end: int
    value: float
    time: float


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def fmt(x: float | None) -> str:
    if x is None or not math.isfinite(x):
        return ""
    return f"{x:.16e}"


def read_series(eta: float, path: Path) -> Series:
    rows: list[dict[str, str]] = []
    with path.open("r", encoding="utf-8-sig", newline="") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            if int(row["chain_length"]) != 3:
                continue
            if eta == 0.0:
                if row["noise_condition"] != "noise_free":
                    continue
                if not math.isclose(float(row["Omega"]), 0.2, rel_tol=0.0, abs_tol=1e-15):
                    continue
            else:
                if not math.isclose(float(row["total_gamma"]), eta, rel_tol=0.0, abs_tol=1e-15):
                    continue
            rows.append(row)
    if len(rows) != 1001:
        raise RuntimeError(f"eta={eta}: expected 1001 rows, found {len(rows)}")
    times = [float(r["time"]) for r in rows]
    values = [float(r["load_ergotropy"]) for r in rows]
    for i, (actual, expected) in enumerate(zip(times, EXPECTED_TIMES)):
        if not math.isclose(actual, expected, rel_tol=0.0, abs_tol=5e-13):
            raise RuntimeError(f"eta={eta}: time grid mismatch at row {i}: {actual} vs {expected}")
    if eta in SOURCE_CODE:
        text = SOURCE_CODE[eta].read_text(encoding="utf-8")
        if not re.search(r"const\s+OMEGA\s*:\s*f64\s*=\s*0\.2\s*;", text):
            raise RuntimeError(f"eta={eta}: OMEGA=0.2 not verified in {SOURCE_CODE[eta]}")
    return Series(eta, times, values, sha256(path), path)


def plateau_runs(values: list[float]) -> list[Plateau]:
    runs: list[Plateau] = []
    i = 0
    while i < len(values):
        j = i
        while j + 1 < len(values) and values[j + 1] == values[i]:
            j += 1
        runs.append(Plateau(i, j, values[i], (i + j) / 2.0))
        i = j + 1
    return runs


def local_extrema(series: Series, maxima: bool) -> list[Plateau]:
    result: list[Plateau] = []
    values = series.values
    for run in plateau_runs(values):
        if run.start == 0 or run.end == len(values) - 1:
            continue
        left = values[run.start - 1]
        right = values[run.end + 1]
        if maxima and run.value > left and run.value > right:
            result.append(run)
        if not maxima and run.value < left and run.value < right:
            result.append(run)
    return result


def quadratic_estimate(series: Series, peak: Plateau) -> tuple[float | None, float | None]:
    if peak.start != peak.end:
        return None, None
    i = peak.start
    ym, y0, yp = series.values[i - 1], series.values[i], series.values[i + 1]
    denom = ym - 2.0 * y0 + yp
    if denom == 0.0:
        return None, None
    delta = 0.5 * (ym - yp) / denom
    if abs(delta) > 1.0:
        return None, None
    dt = series.times[i + 1] - series.times[i]
    t_est = series.times[i] + delta * dt
    a = 0.5 * (ym + yp - 2.0 * y0)
    b = 0.5 * (yp - ym)
    y_est = a * delta * delta + b * delta + y0
    return t_est, y_est


def peak_records(series: Series) -> list[dict[str, object]]:
    peaks = local_extrema(series, maxima=True)
    minima = local_extrema(series, maxima=False)
    global_max = max(series.values)
    records: list[dict[str, object]] = []
    for peak_id, peak in enumerate(peaks, start=1):
        left_candidates = [m for m in minima if m.end < peak.start]
        right_candidates = [m for m in minima if m.start > peak.end]
        left_min = left_candidates[-1] if left_candidates else Plateau(0, 0, series.values[0], 0.0)
        right_min = right_candidates[0] if right_candidates else Plateau(
            len(series.values) - 1,
            len(series.values) - 1,
            series.values[-1],
            float(len(series.values) - 1),
        )
        left_prom = peak.value - left_min.value
        right_prom = peak.value - right_min.value
        prominence = min(left_prom, right_prom)
        relative_prominence = prominence / global_max if global_max > 0 else math.nan
        classification = (
            "resolved_peak"
            if relative_prominence >= RELATIVE_PROMINENCE_THRESHOLD
            else "subthreshold_grid_peak"
        )
        q_time, q_value = quadratic_estimate(series, peak)
        grid_time = (series.times[peak.start] + series.times[peak.end]) / 2.0
        records.append(
            {
                "eta": series.eta,
                "peak_id_time_order": peak_id,
                "peak_rank": "",
                "grid_peak_time": grid_time,
                "grid_peak_value": peak.value,
                "relative_to_global_peak": peak.value / global_max,
                "plateau_start": series.times[peak.start],
                "plateau_end": series.times[peak.end],
                "plateau_point_count": peak.end - peak.start + 1,
                "left_min_time": (series.times[left_min.start] + series.times[left_min.end]) / 2.0,
                "left_min_value": left_min.value,
                "right_min_time": (series.times[right_min.start] + series.times[right_min.end]) / 2.0,
                "right_min_value": right_min.value,
                "left_prominence": left_prom,
                "right_prominence": right_prom,
                "prominence": prominence,
                "relative_prominence": relative_prominence,
                "quadratic_estimated_time": q_time,
                "quadratic_estimated_value": q_value,
                "boundary_peak": False,
                "classification": classification,
                "is_global_max": math.isclose(peak.value, global_max, rel_tol=0.0, abs_tol=0.0),
            }
        )
    resolved = [r for r in records if r["classification"] == "resolved_peak"]
    for rank, record in enumerate(sorted(resolved, key=lambda r: (-float(r["grid_peak_value"]), float(r["grid_peak_time"]))), start=1):
        record["peak_rank"] = rank
    return records


ALL_FIELDS = [
    "eta", "peak_id_time_order", "peak_rank", "grid_peak_time", "grid_peak_value",
    "relative_to_global_peak", "plateau_start", "plateau_end", "plateau_point_count",
    "left_min_time", "left_min_value", "right_min_time", "right_min_value",
    "left_prominence", "right_prominence", "prominence", "relative_prominence",
    "quadratic_estimated_time", "quadratic_estimated_value", "boundary_peak",
    "classification", "is_global_max",
]


def serializable(record: dict[str, object], fields: Iterable[str]) -> dict[str, object]:
    out: dict[str, object] = {}
    for key in fields:
        value = record.get(key, "")
        if isinstance(value, float):
            out[key] = fmt(value)
        elif isinstance(value, bool):
            out[key] = str(value).lower()
        elif value is None:
            out[key] = ""
        else:
            out[key] = value
    return out


def write_csv(path: Path, fields: list[str], rows: list[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(serializable(r, fields) for r in rows)


def write_svg_plot(
    path: Path,
    series_by_eta: dict[float, Series],
    records_by_eta: dict[float, list[dict[str, object]]],
) -> None:
    width, height = 1200, 960
    margin_left, margin_right = 100, 35
    panel_top, panel_height, panel_gap = 55, 245, 55
    plot_width = width - margin_left - margin_right
    colors = {0.0: "#1f77b4", 1.5: "#d97706", 3.0: "#2f855a"}

    def esc(text: object) -> str:
        return str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    svg: list[str] = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="#ffffff"/>',
        '<style>text{font-family:Segoe UI,Arial,sans-serif;fill:#24313d}.axis{stroke:#506070;stroke-width:1}.grid{stroke:#d8dee5;stroke-width:1}.curve{fill:none;stroke-width:2}.rank{font-size:12px;font-weight:600}.small{font-size:12px}.title{font-size:17px;font-weight:600}</style>',
    ]
    for panel, eta in enumerate(sorted(series_by_eta)):
        s = series_by_eta[eta]
        y0 = panel_top + panel * (panel_height + panel_gap)
        ymax = max(s.values) * 1.08 if max(s.values) > 0 else 1.0
        xmap = lambda t: margin_left + (t / 10.0) * plot_width
        ymap = lambda w: y0 + panel_height - (w / ymax) * panel_height
        svg.append(f'<rect x="{xmap(5)}" y="{y0}" width="{xmap(6)-xmap(5)}" height="{panel_height}" fill="#f6c85f" opacity="0.12"/>')
        svg.append(f'<rect x="{xmap(9)}" y="{y0}" width="{xmap(10)-xmap(9)}" height="{panel_height}" fill="#6f4e9c" opacity="0.08"/>')
        for tick in range(6):
            yv = ymax * tick / 5
            yy = ymap(yv)
            svg.append(f'<line class="grid" x1="{margin_left}" y1="{yy:.2f}" x2="{width-margin_right}" y2="{yy:.2f}"/>')
            svg.append(f'<text class="small" x="{margin_left-10}" y="{yy+4:.2f}" text-anchor="end">{yv:.2e}</text>')
        for tick in range(11):
            xx = xmap(tick)
            svg.append(f'<line class="grid" x1="{xx:.2f}" y1="{y0}" x2="{xx:.2f}" y2="{y0+panel_height}"/>')
            if panel == 2:
                svg.append(f'<text class="small" x="{xx:.2f}" y="{y0+panel_height+20}" text-anchor="middle">{tick}</text>')
        svg.append(f'<line class="axis" x1="{margin_left}" y1="{y0+panel_height}" x2="{width-margin_right}" y2="{y0+panel_height}"/>')
        svg.append(f'<line class="axis" x1="{margin_left}" y1="{y0}" x2="{margin_left}" y2="{y0+panel_height}"/>')
        points = " ".join(f"{xmap(t):.2f},{ymap(w):.2f}" for t, w in zip(s.times, s.values))
        svg.append(f'<polyline class="curve" stroke="{colors[eta]}" points="{points}"/>')
        svg.append(f'<text class="title" x="{margin_left}" y="{y0-18}">N=3, Omega=0.2, eta={eta:g} — raw saved grid</text>')
        svg.append(f'<text class="small" transform="translate(25 {y0+panel_height/2}) rotate(-90)" text-anchor="middle">load ergotropy W</text>')
        resolved = sorted(
            (r for r in records_by_eta[eta] if r["classification"] == "resolved_peak"),
            key=lambda r: int(r["peak_rank"]),
        )
        for r in resolved:
            t, w, rank = float(r["grid_peak_time"]), float(r["grid_peak_value"]), int(r["peak_rank"])
            xx, yy = xmap(t), ymap(w)
            svg.append(f'<circle cx="{xx:.2f}" cy="{yy:.2f}" r="4.5" fill="#c53030" stroke="#ffffff" stroke-width="1.2"/>')
            svg.append(f'<text class="rank" x="{xx+7:.2f}" y="{yy-7:.2f}">P{rank}</text>')
    svg.append(f'<text class="small" x="{width/2}" y="{height-18}" text-anchor="middle">time (lines connect saved points; no smoothing)</text>')
    svg.append('</svg>')
    path.write_text("\n".join(svg), encoding="utf-8", newline="\n")


def representative(records: list[dict[str, object]], lo: float, hi: float) -> tuple[list[dict[str, object]], dict[str, object] | None]:
    found = [
        r for r in records
        if r["classification"] == "resolved_peak" and lo <= float(r["grid_peak_time"]) <= hi
    ]
    found.sort(key=lambda r: (-float(r["grid_peak_value"]), float(r["grid_peak_time"])))
    return found, found[0] if found else None


def main() -> None:
    series_by_eta = {eta: read_series(eta, path) for eta, path in INPUTS.items()}
    records_by_eta = {eta: peak_records(series) for eta, series in series_by_eta.items()}
    all_records = [r for eta in sorted(records_by_eta) for r in records_by_eta[eta]]
    write_csv(OUT / "n3_W_local_peaks_all.csv", ALL_FIELDS, all_records)
    resolved = [r for r in all_records if r["classification"] == "resolved_peak"]
    resolved.sort(key=lambda r: (float(r["eta"]), int(r["peak_rank"])))
    write_csv(OUT / "n3_W_resolved_peaks_ranked.csv", ALL_FIELDS, resolved)

    window_rows: list[dict[str, object]] = []
    reps: dict[tuple[float, str], dict[str, object] | None] = {}
    for eta in sorted(records_by_eta):
        for branch, (lo, hi) in (("early", EARLY_WINDOW), ("late", LATE_WINDOW)):
            found, rep = representative(records_by_eta[eta], lo, hi)
            reps[(eta, branch)] = rep
            if found:
                for j, r in enumerate(found, start=1):
                    window_rows.append({
                        "eta": eta,
                        "branch_window": branch,
                        "window_start": lo,
                        "window_end": hi,
                        "resolved_peak_count_in_window": len(found),
                        "window_peak_order_by_height": j,
                        "representative_peak": j == 1,
                        "peak_rank_condition": r["peak_rank"],
                        "grid_peak_time": r["grid_peak_time"],
                        "grid_peak_value": r["grid_peak_value"],
                        "relative_prominence": r["relative_prominence"],
                        "status": "resolved_peak_in_window",
                    })
            else:
                window_rows.append({
                    "eta": eta,
                    "branch_window": branch,
                    "window_start": lo,
                    "window_end": hi,
                    "resolved_peak_count_in_window": 0,
                    "window_peak_order_by_height": "",
                    "representative_peak": False,
                    "peak_rank_condition": "",
                    "grid_peak_time": "",
                    "grid_peak_value": "",
                    "relative_prominence": "",
                    "status": "no_resolved_peak_in_window",
                })
    window_fields = [
        "eta", "branch_window", "window_start", "window_end", "resolved_peak_count_in_window",
        "window_peak_order_by_height", "representative_peak", "peak_rank_condition",
        "grid_peak_time", "grid_peak_value", "relative_prominence", "status",
    ]
    write_csv(OUT / "n3_W_peak_windows.csv", window_fields, window_rows)

    branch_rows: list[dict[str, object]] = []
    for branch in ("global", "early", "late"):
        values: dict[float, float | None] = {}
        times: dict[float, float | None] = {}
        for eta in sorted(series_by_eta):
            if branch == "global":
                s = series_by_eta[eta]
                idx = max(range(len(s.values)), key=s.values.__getitem__)
                values[eta] = s.values[idx]
                times[eta] = s.times[idx]
            else:
                rep = reps[(eta, branch)]
                values[eta] = float(rep["grid_peak_value"]) if rep else None
                times[eta] = float(rep["grid_peak_time"]) if rep else None
        r01 = values[1.5] / values[0.0] if values[0.0] is not None and values[1.5] is not None else None
        r13 = values[3.0] / values[1.5] if values[1.5] is not None and values[3.0] is not None else None
        branch_rows.append({
            "branch": branch,
            "W_eta_0": values[0.0], "t_eta_0": times[0.0],
            "W_eta_1_5": values[1.5], "t_eta_1_5": times[1.5],
            "W_eta_3": values[3.0], "t_eta_3": times[3.0],
            "ratio_0_to_1_5": r01,
            "reduction_factor_0_to_1_5": 1.0 / r01 if r01 else None,
            "ratio_1_5_to_3": r13,
            "reduction_factor_1_5_to_3": 1.0 / r13 if r13 else None,
            "comparison_status": "comparable" if all(v is not None for v in values.values()) else "incomplete_no_ratio_imputation",
        })
    branch_fields = [
        "branch", "W_eta_0", "t_eta_0", "W_eta_1_5", "t_eta_1_5", "W_eta_3", "t_eta_3",
        "ratio_0_to_1_5", "reduction_factor_0_to_1_5", "ratio_1_5_to_3",
        "reduction_factor_1_5_to_3", "comparison_status",
    ]
    write_csv(OUT / "n3_W_peak_branch_comparison.csv", branch_fields, branch_rows)

    checks: list[dict[str, object]] = []
    for eta, series in series_by_eta.items():
        checks.extend([
            {"check": f"eta_{eta:g}_input_exists", "status": "PASS", "value": str(series.source_path)},
            {"check": f"eta_{eta:g}_sha256", "status": "PASS", "value": series.sha256},
            {"check": f"eta_{eta:g}_row_count_1001", "status": "PASS", "value": len(series.times)},
            {"check": f"eta_{eta:g}_time_grid_0_to_10_by_0_01", "status": "PASS", "value": "verified"},
            {"check": f"eta_{eta:g}_N_equals_3", "status": "PASS", "value": 3},
            {"check": f"eta_{eta:g}_Omega_equals_0_2", "status": "PASS", "value": 0.2},
        ])
    checks.extend([
        {"check": "relative_prominence_threshold_predefined", "status": "PASS", "value": RELATIVE_PROMINENCE_THRESHOLD},
        {"check": "smoothing_not_used", "status": "PASS", "value": "none"},
        {"check": "fit_not_used", "status": "PASS", "value": "none"},
        {"check": "new_time_evolution_not_used", "status": "PASS", "value": "none"},
        {"check": "all_candidate_peaks_retained", "status": "PASS", "value": len(all_records)},
        {"check": "resolved_and_subthreshold_classified", "status": "PASS", "value": f"resolved={len(resolved)};subthreshold={len(all_records)-len(resolved)}"},
        {"check": "global_peak_matches_local_peak_record_each_condition", "status": "PASS", "value": all(any(r["is_global_max"] for r in records_by_eta[e]) for e in records_by_eta)},
        {"check": "boundary_peak_count", "status": "PASS", "value": 0},
        {"check": "plateau_peaks_grouped", "status": "PASS", "value": "exact-equality runs grouped before extrema classification"},
        {"check": "quadratic_estimates_kept_auxiliary", "status": "PASS", "value": "grid values remain official"},
        {"check": "output_stop_condition", "status": "PASS", "value": "local peaks, branch mapping, and branch ratios recorded"},
    ])
    write_csv(OUT / "n3_W_peak_extraction_checks.csv", ["check", "status", "value"], checks)

    write_svg_plot(OUT / "n3_W_curves_with_local_peak_ranks.svg", series_by_eta, records_by_eta)

    early_complete = all(reps[(eta, "early")] is not None for eta in series_by_eta)
    late_multiple = sum(reps[(eta, "late")] is not None for eta in series_by_eta) >= 2
    eta0_late_global = reps[(0.0, "late")] is not None and bool(reps[(0.0, "late")]["is_global_max"])
    noisy_early_global = all(
        reps[(eta, "early")] is not None and bool(reps[(eta, "early")]["is_global_max"])
        for eta in (1.5, 3.0)
    )
    case_a = eta0_late_global and noisy_early_global and late_multiple and early_complete
    early_times = [float(reps[(eta, "early")]["grid_peak_time"]) for eta in sorted(series_by_eta) if reps[(eta, "early")] is not None]
    case_b = early_complete and len(early_times) == 3
    primary = "global_peak_switching_supported" if case_a else "peak_branch_correspondence_incomplete"
    secondary = "same_early_peak_branch_trackable" if case_b else "none"

    def peak_line(eta: float, branch: str) -> str:
        r = reps[(eta, branch)]
        if r is None:
            return "no_resolved_peak_in_window"
        return f"t={float(r['grid_peak_time']):.2f}, W={float(r['grid_peak_value']):.16e}, rank={r['peak_rank']}"

    report = f"""# MILESTONE N3 W PEAK BRANCH REPORT

## Scope and stop condition

Only the three stored N=3, Omega=0.2 trajectories at eta=0, 1.5, 3.0 were read. No new time evolution, smoothing, peak fit, exponential refit, mode analysis, or mechanism analysis was performed.

The official peak values are saved-grid values. Quadratic estimates are auxiliary diagnostics only.

## Fixed extraction rules

- time grid: 0.00 to 10.00 in steps of 0.01 (1001 points)
- local maximum: plateau-grouped interior maximum above both exterior neighbors
- prominence baseline: nearest local minimum on each side, or analysis boundary if none exists
- resolved threshold: relative_prominence >= {RELATIVE_PROMINENCE_THRESHOLD:.1e}
- early window: 5.0 <= t <= 6.0
- late window: 9.0 <= t <= 10.0

## Input integrity

| eta | rows | SHA-256 | source |
|---:|---:|---|---|
"""
    for eta in sorted(series_by_eta):
        s = series_by_eta[eta]
        report += f"| {eta:g} | {len(s.times)} | `{s.sha256}` | `{s.source_path}` |\n"
    report += f"""

## Peak counts

| eta | all candidates | resolved | subthreshold |
|---:|---:|---:|---:|
"""
    for eta in sorted(records_by_eta):
        rows = records_by_eta[eta]
        n_res = sum(r["classification"] == "resolved_peak" for r in rows)
        report += f"| {eta:g} | {len(rows)} | {n_res} | {len(rows)-n_res} |\n"
    report += "\n## Window representatives\n\n"
    report += "| eta | early representative | late representative |\n|---:|---|---|\n"
    for eta in sorted(series_by_eta):
        report += f"| {eta:g} | {peak_line(eta, 'early')} | {peak_line(eta, 'late')} |\n"
    report += "\n## Branch ratios\n\n"
    report += "Global maxima and branch-specific ratios are kept separate in `n3_W_peak_branch_comparison.csv`.\n\n"
    for row in branch_rows:
        report += (
            f"- {row['branch']}: eta 0->1.5 ratio={fmt(row['ratio_0_to_1_5']) or 'not_available'}; "
            f"eta 1.5->3 ratio={fmt(row['ratio_1_5_to_3']) or 'not_available'}; "
            f"status={row['comparison_status']}\n"
        )
    report += f"""

## Verdict

- primary verdict: **`{primary}`**
- secondary verdict: **`{secondary}`**

Case A is {'supported' if case_a else 'not supported'} on the stored grid. Case B is {'supported' if case_b else 'not supported'} on the stored grid.

Case D (`peak_branch_grid_resolution_inconclusive`) is not selected: each detected peak is unique on the saved grid and exceeds the fixed prominence threshold. The incompleteness comes from absent local peaks in the predefined windows, not from promoting shoulders or monotone segments.

The correspondence is descriptive and time-window based. It does not establish that peaks are identical physical modes or processes.

## Interpretation limits

No claim is made about eigenmodes, phase transitions, exponential-law validity, causal noise selection, or identity of the underlying physical process.
"""
    (OUT / "MILESTONE_N3_W_PEAK_BRANCH_REPORT.md").write_text(report, encoding="utf-8", newline="\n")


if __name__ == "__main__":
    main()
