#!/usr/bin/env python3
"""Check portable N=3 peak-branch inputs and regenerated key results."""
from __future__ import annotations

import csv
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FILES = {
    "eta_0_noise_free_timeseries.csv": "cc4d4cd2779f29bd1570055a597c79643536b1f3cdb4bee09ffe28f508fe55d6",
    "eta_1_5_timeseries.csv": "aa582f956aa8942bc886c537d02bbd6eadd2c75984cce10190079a81d917f3f5",
    "eta_3_0_timeseries.csv": "7753116415567415330e3186ffa3008c78394b880eb7ff0ac1f909d897f5eb73",
}
EXPECTED = {
    "global": ["9.4800000000000004e+00", "5.5424064638002993e-02", "5.6299999999999999e+00", "3.0302005931286463e-03", "5.3899999999999997e+00", "5.4644529219776382e-04"],
    "early": ["", "", "5.6299999999999999e+00", "3.0302005931286463e-03", "5.3899999999999997e+00", "5.4644529219776382e-04"],
    "late": ["9.4800000000000004e+00", "5.5424064638002993e-02", "", "", "", ""],
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    reference = ROOT / "data" / "reference"
    for name, expected_hash in FILES.items():
        actual = sha256(reference / name)
        if actual != expected_hash:
            raise SystemExit(f"FAIL {name}: hash mismatch")
        print(f"PASS {name}: hash")
    result = ROOT / "generated-results" / "n3_W_peak_branch_comparison.csv"
    if not result.exists():
        raise SystemExit("generated results missing; run analyze_n3_w_peak_branches.py first")
    with result.open(encoding="utf-8", newline="") as handle:
        rows = {row["branch"]: row for row in csv.DictReader(handle)}
    for branch, expected in EXPECTED.items():
        row = rows.get(branch)
        actual = [row[k] for k in ("t_eta_0", "W_eta_0", "t_eta_1_5", "W_eta_1_5", "t_eta_3", "W_eta_3")] if row else None
        if actual != expected:
            raise SystemExit(f"FAIL {branch}: regenerated peak table differs")
    report = (ROOT / "generated-results" / "MILESTONE_N3_W_PEAK_BRANCH_REPORT.md").read_text(encoding="utf-8")
    if "primary verdict: **`peak_branch_correspondence_incomplete`**" not in report:
        raise SystemExit("FAIL final verdict differs")
    print("PASS regenerated peak table and verdict")


if __name__ == "__main__":
    main()
