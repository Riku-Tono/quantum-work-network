# N=3 W-peak branch correspondence audit

This package is a reproducible, data-only audit of whether the W peaks used in the N=7 phase-noise
comparison can be followed as the same time-window branch for `N=3`.

It reads exactly three stored trajectories at `N=3`, `Omega=0.2`, and total phase noise
`eta = 0, 1.5, 3.0`. It performs no new time evolution, smoothing, peak fitting, exponential refit,
mode analysis, or mechanism analysis.

## Fixed audit rule

- Saved grid: `t = 0..10` at 0.01 spacing (1001 points).
- A peak is an interior, plateau-grouped local maximum.
- Prominence uses the nearest local minimum on each side, or the time boundary.
- A resolved peak needs relative prominence at least `1e-4`.
- The predeclared early window is `5 <= t <= 6`; the late window is `9 <= t <= 10`.

## Result

| eta | global saved-grid W peak |
| ---: | --- |
| 0.0 | `t=9.48`, `W=5.5424064638002993e-02` |
| 1.5 | `t=5.63`, `W=3.0302005931286463e-03` |
| 3.0 | `t=5.39`, `W=5.4644529219776382e-04` |

The `eta=0` resolved peak is late, while the two noisy peaks are early. No branch ratio is imputed
across missing window peaks. The recorded verdict is:

```text
peak_branch_correspondence_incomplete
```

This does not establish different physical modes, reject the N=7 finite-condition candidate, or prove
any noise mechanism. It only prevents treating these three N=3 global peaks as a verified common
time-window branch.

## Run

Requirements: Python 3.10+; no third-party packages.

```bash
python scripts/analyze_n3_w_peak_branches.py
python scripts/verify.py
```

The first command writes a fresh `generated-results/` directory. The second confirms input hashes,
the key regenerated peak table, and the final verdict against the supplied reference results.

## Package contents

- `data/reference/`: original complete CSV inputs. The eta=1.5 and eta=3.0 files contain other chain
  lengths too; the script filters `chain_length == 3` before analysis.
- `data/provenance/`: the two original Rust source files used to verify `Omega = 0.2` for noisy cases.
- `reference-results/`: original report, CSV tables, and SVG figure.
- `scripts/analyze_n3_w_peak_branches.py`: the original analysis logic, altered only to use portable
  package-relative paths and `generated-results/`.

## Integrity and license

`scripts/verify.py` retains the SHA-256 hashes of the three original input files. Add a repository-level
license with the confirmed copyright holder before public release.
