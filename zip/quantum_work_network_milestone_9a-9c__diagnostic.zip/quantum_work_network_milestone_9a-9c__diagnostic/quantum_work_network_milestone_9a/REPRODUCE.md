# Milestone 9a reproduction

Run from this folder:

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo build --release --offline
cargo run --release --offline --bin n7_noise_free_full
```

The required Milestone 8a comparison files are under `inputs/milestone_8a`.
The original machine-specific absolute path was changed only in this copied
binary source to that relative path. Stored reference outputs are in `results`.
Runtime and memory figures are machine-dependent. See `MILESTONE_9A_REPORT.md`.
