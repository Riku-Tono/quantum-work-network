# Milestone 9b reproduction

Run from this folder:

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo build --release --offline
cargo run --release --offline --bin n7_all_site_noisy_full
```

Milestone 8a inputs are under `inputs/milestone_8a`; required Milestone 8c and
9a comparison files are in this folder. The original absolute path was changed
only in this copied binary source to the relative input path. Stored reference
outputs are in `results`. See `MILESTONE_9B_REPORT.md`.
