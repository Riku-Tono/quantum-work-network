# Milestone 9c diagnostic reproduction

Run from this folder:

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo build --release --offline
cargo run --release --offline --bin n7_t002_eigen_diagnostic
```

The saved Milestone 9c time series required for comparison is included as
`fixed_total_noise_timeseries.csv`. Stored diagnostic outputs are in `results`.
This set diagnoses the t=0.02 eigenvalue NaN; it is not the later 9c validation
set. See `MILESTONE_9C_DIAGNOSTIC.md`.
