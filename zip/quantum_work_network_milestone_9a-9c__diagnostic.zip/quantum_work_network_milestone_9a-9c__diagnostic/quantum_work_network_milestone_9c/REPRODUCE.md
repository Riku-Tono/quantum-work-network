# Milestone 9c reproduction

Run from this folder:

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo build --release --offline
cargo run --release --offline --bin fixed_total_noise_comparison
```

Milestone 8a inputs are under `inputs/milestone_8a`; required Milestone 8c,
9a, and 9b comparison files are in this folder. The original absolute path was
changed only in this copied binary source to the relative input path. Stored
reference outputs are in `results`.

`MILESTONE_9C_REPORT.md` records `numerical_issue_stop`; it is the historical
9c run record and should not be confused with the later validation result.
