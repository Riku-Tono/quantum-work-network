"""Join M29 trials, certified archive controls, and full-control composites."""

import argparse
from bisect import bisect_right
from collections import defaultdict
import csv
from pathlib import Path
from statistics import mean
import sys


ROOT = Path(__file__).resolve().parent
M28 = ROOT.parent / "Milestone_28"
M27 = ROOT.parent / "Milestone_27"
sys.path.insert(0, str(M28))
from collect_m28 import (
    CLOCK, COMMON, FLOOR, ORIGINS, PRECISIONS, Timeline, accepted,
    csv_rows, flag, lane, tags, ticks, write_csv,
)


LEGACY = ("F2-R", "F1")
UNSEEN = tuple(f"U{i:02d}" for i in range(1, 7))
COHORTS = (*LEGACY, "unseen")
CANDIDATES = ("P1", "P2", "P3", "P4")
GATES = ("RP", *CANDIDATES)
ARCHIVED = ("RP", "R0", "R1", "R3", "RH", "E")
UNSEEN_POLICIES = (*GATES, "R3", "RH")
COMPOSITES = {
    **{f"F2-R+{method}": ("F2-R", method) for method in CANDIDATES},
    "M3": ("F1", "P3"),
    "M4": ("F1", "P4"),
    "M-F3": ("F1", "R3"),
}
MAIN = ("F2-R", "F1", *COMPOSITES)
AVERAGE_MIN = 0.95
STATE_MIN = 0.90
NEAR_ZERO = 1e-10
WAIT_CAP = 6000


INFO = {
    "RP": (4, 2, 2, "Re(c), q, |c|, arg(c)", "Re(c0), |c0|", "hypot, atan2, multiplication, comparisons"),
    "P1": (2, 2, 2, "|c|, q", "|c0|", "hypot, multiplication, comparisons"),
    "P2": (1, 2, 1, "q and pre-cut |c0|", "|c0|", "pre-cut hypot, multiplication and comparison at poll"),
    "P3": (1, 1, 1, "q", "q0", "abs(q0), multiplication, max and comparison at poll"),
    "P4": (1, 0, 1, "q", "none", "comparison"),
    "R0": (0, 0, 0, "none", "none", "no wait"),
    "R1": (0, 0, 0, "none", "fixed delay", "timer"),
    "R3": (0, 0, 0, "none", "fixed delay", "timer"),
    "RH": (0, 0, 0, "none", "past wait, signed work and duration", "empirical rate comparisons and timer"),
    "E": (None, None, None, "retrospective state trajectories", "candidate search records", "work search per trial"),
}


def gate_for(policy):
    if policy == "F2-R":
        return "RP"
    if policy == "F1":
        return "RH"
    return COMPOSITES[policy][1] if policy in COMPOSITES else policy


def information():
    rows = []
    for policy in (*INFO, *MAIN):
        gate = gate_for(policy)
        count, before, during, values, memory, operations = INFO[gate]
        initial_rule = ("rate and coherence" if policy.startswith("F2-R") else "executed work rate"
                        if policy in ("F1", "M3", "M4", "M-F3") else "matched anchor")
        rows.append({
            "policy": policy, "wait_rule": gate, "initial_switch_information": initial_rule,
            "reconnect_conditions": count, "precut_primitive_coherence_components": before,
            "waiting_primitive_coherence_components": during, "reconnect_observed_quantities": values,
            "reconnect_memory": memory, "reconnect_operations": operations,
            "timer_required": gate not in ("R0", "E"), "online": gate != "E",
            "connected_extraction_information": "A connected stop observations" if gate != "E" else "retrospective search",
            "accounting_information": "physical cut/reconnect input, local passivation, energy differences",
        })
    return rows


def archive(path, accepted_rows):
    if not path.is_file():
        raise FileNotFoundError(path)
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return [row for row in csv.DictReader(stream) if accepted_rows(row)]


def published_paths(folders, filename):
    return [folder / filename for folder in folders if (folder / filename).is_file()]


def merge(folders, filename):
    return [row for path in published_paths(folders, filename) for row in csv_rows(path)]


def stream_artifact(folders, filename, target):
    paths = published_paths(folders, filename)
    fields = ["group", "origin", "policy", "precision"]
    for path in paths:
        with path.open(encoding="utf-8-sig", newline="") as stream:
            fields.extend(field for field in (csv.DictReader(stream).fieldnames or ()) if field not in fields)
    with target.open("w", encoding="utf-8", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=fields)
        writer.writeheader()
        for path in paths:
            with path.open(encoding="utf-8-sig", newline="") as stream:
                writer.writerows(csv.DictReader(stream))


def archive_tables(m28, m27):
    def m28_selected(row):
        group, policy = row["group"], row["policy"]
        return group in LEGACY and policy in ARCHIVED or group == "main" and policy == "F2-R"

    result = {}
    for stem in ("history", "decisions", "checkpoints"):
        rows = archive(m28 / f"m28_{stem}.csv", m28_selected)
        result[stem] = [{**row, "ledger_source": "M28 audited archive"} for row in rows]
        previous = archive(m27 / f"m27_{stem}.csv", lambda row: row["policy"] == "F1")
        result[stem].extend({**row, "group": "main", "fork_elapsed": 0, "phase_observations": 0,
                             "initial_phase_observations": 0, "wait_phase_observations": 0,
                             "ledger_source": "M27 audited F1 archive"} for row in previous)
    return result


def by_lane(rows):
    result = defaultdict(list)
    for row in rows:
        result[lane(row)].append(row)
    return result


def compose(history, decisions, checkpoints):
    """Join only an archived matching prefix and the registered same-state tail."""
    histories, log, boundaries = map(by_lane, (history, decisions, checkpoints))
    h, d, c, seams = [], [], [], []
    for label, (source, tail_method) in COMPOSITES.items():
        for origin in ORIGINS:
            for step in PRECISIONS:
                base_key, tail_key = ("main", origin, source, step), (source, origin, tail_method, step)
                tail = sorted(histories[tail_key], key=lambda row: int(row["attempt"]))
                if not tail:
                    continue
                fork = ticks(tail[0]["fork_elapsed"])
                prefix = sorted((row for row in histories[base_key] if ticks(row["elapsed_total"]) <= fork),
                                key=lambda row: int(row["attempt"]))
                if not prefix or ticks(prefix[-1]["elapsed_total"]) != fork:
                    raise ValueError(f"Composite {label}/{origin}/{step} has no matching prefix boundary")
                anchor = prefix[-1]
                tail_first = tail[0]
                for precision in PRECISIONS:
                    if anchor[f"post_{precision}_sha256"] != tail_first[f"start_{precision}_sha256"]:
                        raise ValueError(f"Composite {label}/{origin}/{step} state hash mismatch ({precision})")
                offset, count = int(anchor["attempt"]), int(anchor["count"])
                carry = float(anchor["cumulative_net"])
                prefix_decisions = [row for row in log[base_key] if ticks(row["elapsed_total"]) < fork]
                source_switch = [row for row in log[base_key] if ticks(row["elapsed_total"]) == fork and flag(row["switched"])]
                if len(source_switch) != 1:
                    raise ValueError(f"Composite {label}/{origin}/{step} needs one certified switch at the seam")
                if any(float(row["tau"]) for row in prefix):
                    raise ValueError("Initial forecast prefix contains a cut wait")
                meta = {"group": "main", "origin": origin, "policy": label, "precision": step, "fork_elapsed": 0,
                        "initial_switch_elapsed": fork / CLOCK, "prefix_policy": source, "tail_policy": tail_method}
                prefix_meta = {**meta, "ledger_source": f"{source} audited prefix"}
                tail_meta = {**meta, "ledger_source": f"{source}/{tail_method} same-state continuation"}
                h.extend({**row, **prefix_meta} for row in prefix)
                for row in tail:
                    value = carry + float(row["cumulative_net"])
                    h.append({**row, **tail_meta, "attempt": int(row["attempt"]) + offset, "count": int(row["count"]) + count,
                              "cumulative_net": value, "cumulative_rate": value / float(row["elapsed_total"]),
                              "segment_fork_elapsed": fork / CLOCK})
                d.extend({**row, **prefix_meta} for row in prefix_decisions)
                d.append({**source_switch[0], **prefix_meta, "attempt": offset + 1})
                d.extend({**row, **tail_meta, "attempt": int(row["attempt"]) + offset}
                         for row in log[tail_key] if int(row["attempt"]) > 1)
                for row in boundaries[tail_key]:
                    c.append({**row, **tail_meta, "attempts": int(row["attempts"]) + offset, "count": int(row["count"]) + count,
                              "cumulative_net": carry + float(row["cumulative_net"]), "segment_fork_elapsed": fork / CLOCK})
                seams.append({**meta, "prefix_attempts": offset, "prefix_count": count, "prefix_work": carry,
                              "matched_coarse_sha256": anchor["post_coarse_sha256"], "matched_half_sha256": anchor["post_half_sha256"]})
    return h, d, c, seams


class SummaryTimeline(Timeline):
    """Add the coherence inputs and wait cap metrics to M28's work timeline."""

    def __init__(self, rows, checkpoint, cutoff, certified_through):
        super().__init__(rows, checkpoint, cutoff, certified_through)
        policy = self.events[0]["policy"] if self.events else checkpoint["policy"]
        gate = gate_for(policy)
        _, before, during, *_ = INFO[gate]
        self.scalar, self.positive_wait, self.capped_wait, self.timed_out = [0], [0], [0], [0]
        self.connected, self.history_records = [0], [0]
        self.switch_net, self.passivation_net = [0.0], [0.0]
        prior_arms = defaultdict(int)
        for row in self.events:
            tau = ticks(row.get("tau") or 0)
            sample_count = int(row.get("phase_observations") or 0)
            initial = int(row.get("initial_phase_observations") or (bool(sample_count) and bool(before)))
            during_count = sample_count - initial
            if during_count < 0 or initial and not before:
                raise ValueError(f"Disallowed pre-cut observation in {lane(row)} attempt {row['attempt']}")
            primitive = (before or 0) * initial + (during or 0) * during_count
            observed_scalars = row.get("observed_scalars")
            if observed_scalars not in (None, "") and primitive != int(observed_scalars):
                raise ValueError(f"Coherence accounting disagrees with input width in {lane(row)} attempt {row['attempt']}")
            self.scalar.append(self.scalar[-1] + primitive)
            self.positive_wait.append(self.positive_wait[-1] + int(tau > 0))
            self.capped_wait.append(self.capped_wait[-1] + int(tau == WAIT_CAP))
            reason = str(row.get("wait_reason", "")).casefold()
            time_limit = flag(row.get("fallback_limit")) or reason in ("phase_limit", "q_limit", "wait_limit", "timeout")
            self.timed_out.append(self.timed_out[-1] + int(tau > 0 and time_limit))
            connected = ticks(row.get("elapsed_connected") or 0) // 20 + 1 if gate != "E" else 0
            self.connected.append(self.connected[-1] + connected)
            if gate == "RH" and reason == "empirical_exploit":
                records_read = sum(min(3, count) for arm, count in prior_arms.items() if arm + 20 <= ticks(row["window"]))
            else:
                records_read = 0
            self.history_records.append(self.history_records[-1] + records_read)
            if gate == "RH" and tau > 0:
                prior_arms[tau] += 1
            signed = -float(row.get("cut_on") or 0) - float(row.get("reconnect_on") or 0)
            recovered = float(row["net_work"]) - signed
            if not accepted(row) and abs(recovered) > FLOOR:
                raise ValueError(f"Unaccepted event carries passivation work in {lane(row)} attempt {row['attempt']}")
            self.switch_net.append(self.switch_net[-1] + signed)
            self.passivation_net.append(self.passivation_net[-1] + (recovered if accepted(row) else 0))

    def at(self, tick, start):
        result = super().at(tick, start)
        now = bisect_right(self.times, tick)
        before = bisect_right(self.times, max(self.fork, start))
        waited = self.positive_wait[now]
        return {**result, "coherence_observations": result["phase_observations"],
                "primitive_coherence_component_values": self.scalar[now],
                "a_connected_observation_points": self.connected[now],
                "rh_records_used_in_empirical_scores": self.history_records[now],
                "cumulative_cut_reconnect_net": self.switch_net[now],
                "cumulative_passivation_work": self.passivation_net[now],
                "interval_cut_reconnect_net": self.switch_net[now] - self.switch_net[before],
                "interval_passivation_work": self.passivation_net[now] - self.passivation_net[before],
                "positive_wait_attempts": waited, "max_wait_attempts": self.capped_wait[now],
                "max_wait_fraction": self.capped_wait[now] / waited if waited else "",
                "timeout_attempts": self.timed_out[now],
                "timeout_fraction": self.timed_out[now] / waited if waited else ""}


def comparison(timelines, decisions, cutoff):
    changes, initial_phase = {}, defaultdict(list)
    for row in sorted(decisions, key=lambda record: ticks(record["elapsed_total"])):
        key = lane(row)
        if key[0] == "main" and key[2].startswith("F2-R") and row.get("mode_before") == "forecast":
            initial_phase[key].append(ticks(row["elapsed_total"]))
        if flag(row.get("switched")):
            changes.setdefault(key, ticks(row["elapsed_total"]) / CLOCK)
    common, terminus, late = [], [], []
    clocks = sorted({cutoff, *(t * CLOCK for t in COMMON if t * CLOCK <= cutoff)})
    for key, series in timelines.items():
        if series.covered_through <= series.fork:
            continue
        last, earlier = series.covered_through, series.fork
        meta = tags(key)
        for tick in clocks:
            if tick > last:
                break
            if tick > series.fork:
                common.append({**meta, **series.at(tick, earlier),
                               "initial_switch_coherence_decision_points": bisect_right(initial_phase[key], tick)})
                earlier = tick
        terminus.append({**meta, **series.at(last, series.fork),
                         "initial_switch_coherence_decision_points": bisect_right(initial_phase[key], last),
                         "first_switch_elapsed": changes.get(key, ""),
                         "attempts": len(series.events),
                         "last_extraction": series.action_times[-1] / CLOCK if series.actions else "",
                         "target_elapsed": cutoff / CLOCK, "target_covered": last == cutoff,
                         "terminal_checkpoint": bool(series.checkpoint), "ending": series.checkpoint.get("ending", "")})
        if last == cutoff and cutoff > max(300 * CLOCK, series.fork):
            late.append({**meta, **series.at(cutoff, 300 * CLOCK)})
    return common, terminus, late


def schedule(timeline):
    return [(ticks(row["elapsed_start"]), ticks(row["elapsed_total"]), ticks(row.get("tau") or 0), accepted(row))
            for row in timeline.events]


def mismatch(left, right):
    shared = list(zip(left, right))
    different = [i for i, (a, b) in enumerate(shared, 1) if a != b]
    unmatched = abs(len(left) - len(right))
    initial = different[0] if different else (len(shared) + 1 if unmatched else "")
    return len(different) + unmatched, initial


def condition_comparisons(endpoints, late, timelines):
    ends = {lane(row): row for row in endpoints if row["target_covered"]}
    recent = {lane(row): row for row in late}
    comparisons = []
    for key, row in ends.items():
        group, origin, policy, precision = key
        if group not in COHORTS or policy == "RP":
            continue
        baseline = group, origin, "RP", precision
        if baseline not in ends:
            continue
        rp = ends[baseline]
        net, ref = row["cumulative_net"], rp["cumulative_net"]
        ratio = net / ref if ref > NEAR_ZERO else ""
        difference, first_difference = mismatch(schedule(timelines[baseline]), schedule(timelines[key]))
        _, pb, pw, *_ = INFO[policy]
        _, rb, rw, *_ = INFO["RP"]
        first = timelines[key].events[0] if timelines[key].events else {}
        rp_first = timelines[baseline].events[0] if timelines[baseline].events else {}
        first_wait = float(first["tau"]) if first else ""
        rp_wait = float(rp_first["tau"]) if rp_first else ""
        comparisons.append({
            **tags(key), "fork_elapsed": row["fork_elapsed"], "elapsed_total": row["elapsed_total"],
            "net_work": net, "rp_net_work": ref, "delta_net_from_rp": net - ref, "ratio_to_rp": ratio,
            "delta_cut_reconnect_net_from_rp": row["cumulative_cut_reconnect_net"] - rp["cumulative_cut_reconnect_net"],
            "delta_passivation_work_from_rp": row["cumulative_passivation_work"] - rp["cumulative_passivation_work"],
            "absolute_rule_used": ratio == "", "retains_state_minimum": ratio >= STATE_MIN if ratio != "" else ref - net <= NEAR_ZERO,
            "different_attempts_vs_rp": difference, "first_different_attempt": first_difference,
            "first_wait_elapsed": first_wait, "rp_first_wait_elapsed": rp_wait,
            "first_reconnection_delta": first_wait - rp_wait if first and rp_first else "",
            "first_wait_reason": first.get("wait_reason", ""), "rp_first_wait_reason": rp_first.get("wait_reason", ""),
            "coherence_observations": row["coherence_observations"],
            "rp_coherence_observations": rp["coherence_observations"],
            "primitive_coherence_component_values": row["primitive_coherence_component_values"],
            "rp_primitive_coherence_component_values": rp["primitive_coherence_component_values"],
            "precut_primitive_component_reduction": rb - pb if pb is not None else "",
            "waiting_primitive_component_reduction": rw - pw if pw is not None else "",
            "late_rate": recent[key]["interval_rate"] if key in recent else "",
            "rp_late_rate": recent[baseline]["interval_rate"] if baseline in recent else "",
        })
    return comparisons


def maintenance(comparisons):
    grouped = defaultdict(list)
    for row in comparisons:
        if row["policy"] in CANDIDATES:
            grouped[row["group"], row["policy"], row["precision"]].append(row)
    verdicts = []
    for (group, method, step), rows in grouped.items():
        expected = len(UNSEEN if group == "unseen" else ORIGINS)
        if len(rows) != expected:
            continue
        average, reference = (mean(row[col] for row in rows) for col in ("net_work", "rp_net_work"))
        ratio = average / reference if reference > NEAR_ZERO else ""
        valid = [row["ratio_to_rp"] for row in rows if row["ratio_to_rp"] != ""]
        limits = [row["origin"] for row in rows if not row["retains_state_minimum"]]
        mean_ok = ratio >= AVERAGE_MIN if ratio != "" else reference - average <= NEAR_ZERO
        verdicts.append({
            "group": group, "policy": method, "precision": step, "origins": len(rows),
            "mean_net_work": average, "rp_mean_net_work": reference, "delta_mean_net_work": average - reference,
            "ratio_of_means": ratio, "mean_of_defined_state_ratios": mean(valid) if valid else "",
            "minimum_defined_state_ratio": min(valid) if valid else "",
            "near_zero_reference_states": expected - len(valid), "below_state_minimum_origins": " ".join(limits),
            "mean_95_pass": mean_ok, "all_states_90_pass": not limits, "reconnection_burden_reduced": True,
            "step_criterion_pass": mean_ok and not limits,
        })
    lookup = {(r["group"], r["policy"], r["precision"]): r["step_criterion_pass"] for r in verdicts}
    for row in verdicts:
        group, policy, step = row["group"], row["policy"], row["precision"]
        other = lookup.get((group, policy, "half" if step == "coarse" else "coarse"))
        row["coarse_half_judgment_agrees"] = (other == row["step_criterion_pass"]) if other is not None else ""
        row["simplification_accepted"] = (other and row["step_criterion_pass"]) if other is not None else ""
    return verdicts


def fixed_comparisons(endpoints, late):
    endpoint = {lane(row): row for row in endpoints if row["target_covered"]}
    recent = {lane(row): row for row in late}
    comparisons = []
    for key, row in endpoint.items():
        group, origin, policy, precision = key
        if group == "main":
            if policy not in ("F1", "F2-R", "M3", "M4"):
                continue
            method = "M-F3"
        else:
            if policy == "R3":
                continue
            method = "R3"
        anchor = group, origin, method, precision
        if anchor not in endpoint:
            continue
        baseline = endpoint[anchor]
        comparisons.append({
            **tags(key), "fixed_method": method, "elapsed_total": row["elapsed_total"],
            "net_work": row["cumulative_net"], "fixed_net_work": baseline["cumulative_net"],
            "net_minus_fixed": row["cumulative_net"] - baseline["cumulative_net"],
            "late_rate_minus_fixed": recent[key]["interval_rate"] - recent[anchor]["interval_rate"]
            if key in recent and anchor in recent else "",
        })
    return comparisons


def end_to_end(common, endpoints, late):
    early = {lane(row): row for row in common if row["group"] == "main" and row["elapsed_total"] == 50}
    recent = {lane(row): row for row in late if row["group"] == "main"}
    summary = []
    for row in endpoints:
        key = lane(row)
        if row["group"] != "main" or not row["target_covered"] or key not in early:
            continue
        _, origin, _, step = key
        control = early.get(("main", origin, "F2-R", step), {})
        observed = early[key]["cumulative_net"]
        summary.append({
            **tags(key), "first_switch_elapsed": row["first_switch_elapsed"], "net_work_at_50": observed,
            "delta_from_f2r_at_50": observed - control["cumulative_net"] if control else "",
            "net_work_at_target": row["cumulative_net"], "elapsed_target": row["elapsed_total"],
            "late_rate": recent[key]["interval_rate"] if key in recent else "",
            "coherence_observations": row["coherence_observations"],
            "initial_switch_coherence_decision_points": row["initial_switch_coherence_decision_points"],
        })
    return summary


def chronology(timelines, decisions, selector):
    log, q_log = map(by_lane, (decisions, selector))
    rows = []
    for key, coarse in timelines.items():
        group, origin, policy, step = key
        half_key = group, origin, policy, "half"
        if step != "coarse" or half_key not in timelines:
            continue
        half = timelines[half_key]
        until = min(coarse.covered_through, half.covered_through)
        c_s, h_s = ([entry for entry in schedule(series) if entry[1] <= until] for series in (coarse, half))
        count, first = mismatch(c_s, h_s)
        c_dec, h_dec = ([(ticks(row["elapsed_total"]), row.get("mode_after", ""), flag(row.get("switched")))
                         for row in sorted(log[k], key=lambda item: int(item["attempt"]))
                         if ticks(row["elapsed_total"]) <= until] for k in (key, half_key))
        dc, _ = mismatch(c_dec, h_dec)
        q_samples = [
            [(int(row["attempt"]), ticks(row["elapsed_total"]), flag(row["gate"]), flag(row["reconnect"]), flag(row["limit"]))
             for row in sorted(q_log[k], key=lambda item: (int(item["attempt"]), ticks(item["elapsed_total"])))
             if ticks(row["elapsed_total"]) <= until]
            for k in (key, half_key)
        ]
        qc, q_first = mismatch(*q_samples)
        c_work, h_work = (series.work[len(s)] for series, s in ((coarse, c_s), (half, h_s)))
        rows.append({
            "group": group, "origin": origin, "policy": policy, "compared_through": until / CLOCK,
            "coarse_attempts": len(c_s), "half_attempts": len(h_s), "operation_clock_mismatches": count,
            "first_different_operation": first, "mode_decision_mismatches": dc,
            "coarse_selector_samples": len(q_samples[0]), "half_selector_samples": len(q_samples[1]),
            "selector_mismatches": qc if any(q_samples) else "", "first_different_selector": q_first,
            "coarse_net_work": c_work, "half_net_work": h_work, "half_minus_coarse": h_work - c_work,
        })
    return rows


def selector_tables(folders, m28, composite_seams, cutoff):
    def rp_poll(row, source):
        gate = flag(row["phase_gate"])
        reconnect = flag(row["reconnect"])
        return {**tags(lane(row)), "attempt": row["attempt"], "elapsed_total": row["elapsed_total"],
                "observed_until": row.get("observed_until", row["elapsed_total"]), "wait_elapsed": row["wait_elapsed"],
                "q": -float(row["c_imag"]), "gate": gate, "reconnect": reconnect, "limit": reconnect and not gate,
                "selector_source": source}

    rows = [{**row, "selector_source": "M29 native or equivalent-policy replay"}
            for row in merge(folders, "m29_selector.csv") if ticks(row["elapsed_total"]) <= cutoff]
    old = archive(m28 / "m28_wait_checks.csv", lambda row: (
        row["group"] in LEGACY and row["policy"] == "RP" or row["group"] == "main" and row["policy"] == "F2-R"
    ) and ticks(row["elapsed_total"]) <= cutoff)
    rows.extend(rp_poll(row, "M28 audited archive") for row in old)
    for path in published_paths(folders, "m29_wait_checks.csv"):
        rows.extend(rp_poll(row, "M29 formal RP") for row in archive(path, lambda item: item["policy"] == "RP"
                                                                    and ticks(item["elapsed_total"]) <= cutoff))
    indexed = by_lane(rows)
    for seam in composite_seams:
        _, origin, _, step = lane(seam)
        key = seam["prefix_policy"], origin, seam["tail_policy"], step
        rows.extend({**row, **tags(lane(seam)), "attempt": int(row["attempt"]) + seam["prefix_attempts"],
                     "selector_source": "M29 certified composite tail"} for row in indexed[key])
    return rows


def pareto(endpoints):
    source = [row for row in endpoints if row["target_covered"] and row["group"] in COHORTS and row["policy"] != "E"]
    grouped = defaultdict(list)
    for row in source:
        grouped[row["group"], row["precision"], row["policy"]].append(row)
    summary = []
    for (group, step, policy), dataset in grouped.items():
        if len(dataset) != len(UNSEEN if group == "unseen" else ORIGINS):
            continue
        ref = grouped[group, step, "RP"]
        if len(ref) != len(dataset):
            continue
        reference = mean(r["cumulative_net"] for r in ref)
        work = mean(r["cumulative_net"] for r in dataset)
        gates, pre, wait, *_ = INFO[policy]
        summary.append({
            "group": group, "precision": step, "policy": policy, "origins": len(dataset),
            "mean_work": work, "ratio_to_rp": work / reference if reference > NEAR_ZERO else "",
            "mean_coherence_observations": mean(row["coherence_observations"] for row in dataset),
            "mean_primitive_coherence_component_values": mean(row["primitive_coherence_component_values"] for row in dataset),
            "wait_controller_predicates": gates, "precut_primitive_channels": pre, "waiting_primitive_channels": wait,
        })
    for row in summary:
        same = [other for other in summary if (row["group"], row["precision"]) == (other["group"], other["precision"])]
        cost, value = row["mean_primitive_coherence_component_values"], row["mean_work"]
        count = row["wait_controller_predicates"]
        row["pareto_nondominated"] = not any(
            alt["mean_primitive_coherence_component_values"] <= cost
            and alt["wait_controller_predicates"] <= count
            and alt["mean_work"] >= value - FLOOR
            and (alt["mean_primitive_coherence_component_values"] < cost
                 or alt["wait_controller_predicates"] < count or alt["mean_work"] > value + FLOOR)
            for alt in same
        )
    return summary


def expected_lanes():
    cohorts = [(group, ORIGINS, (*ARCHIVED, *CANDIDATES)) for group in LEGACY]
    cohorts += [("unseen", UNSEEN, UNSEEN_POLICIES), ("main", ORIGINS, MAIN)]
    return [(group, origin, policy, step) for group, origins, policies in cohorts
            for origin in origins for policy in policies for step in PRECISIONS]


def collect(stages, output, m28, m27, cutoff):
    folders = sorted(path.parent for path in stages.glob("t*/*/*/*/*/checkpoint.npz"))
    tables = archive_tables(m28, m27)
    for stem, old in tables.items():
        old.extend({**row, "ledger_source": "M29 formal"} for row in merge(folders, f"m29_{stem}.csv"))
    history, decisions, checkpoints = (tables[name] for name in ("history", "decisions", "checkpoints"))
    h, d, c, seams = compose(history, decisions, checkpoints)
    history.extend(h)
    decisions.extend(row for row in d if ticks(row["elapsed_total"]) <= cutoff)
    decisions = [row for row in decisions if ticks(row["elapsed_total"]) <= cutoff]
    checkpoints.extend(c)
    final = {lane(row): row for row in checkpoints if ticks(row["elapsed_total"]) == cutoff}
    certified = defaultdict(int)
    for row in checkpoints:
        key = lane(row)
        certified[key] = max(certified[key], ticks(row["elapsed_total"]))
    all_history = by_lane(history)
    for key in final:
        all_history.setdefault(key, [])
    starts = defaultdict(set)
    for key, rows in all_history.items():
        group, origin, _, step = key
        if group in COHORTS and rows:
            first = min(rows, key=lambda row: int(row["attempt"]))
            starts[group, origin, step].add((ticks(first["fork_elapsed"]), first["start_coarse_sha256"], first["start_half_sha256"]))
    if any(len(states) != 1 for states in starts.values()):
        raise ValueError("Comparison contains different starting clocks or density pairs in a matched cohort")
    timelines = {key: SummaryTimeline(rows, final.get(key, {}), cutoff, certified[key]) for key, rows in all_history.items()}
    common, endpoints, late = comparison(timelines, decisions, cutoff)
    selector = selector_tables(folders, m28, seams, cutoff)
    comparisons = condition_comparisons(endpoints, late, timelines)
    output.mkdir(parents=True, exist_ok=True)
    core = ("group", "origin", "policy", "precision")
    outputs = {
        "history": [row for rows in timelines.values() for row in rows.events],
        "decisions": decisions, "checkpoints": checkpoints, "time_comparison": common, "endpoints": endpoints, "late_work": late,
        "condition_comparison": comparisons, "maintenance": maintenance(comparisons),
        "fixed_comparison": fixed_comparisons(endpoints, late), "end_to_end": end_to_end(common, endpoints, late),
        "chronology": chronology(timelines, decisions, selector), "information": information(),
        "pareto": pareto(endpoints), "composite_seams": seams, "selector": selector,
        "coverage": [{**tags(key), "recorded": key in timelines, "terminal_checkpoint": key in final,
                      "target_covered": key in timelines and timelines[key].covered_through == cutoff,
                      "target_elapsed": cutoff / CLOCK} for key in expected_lanes()],
    }
    for name, records in outputs.items():
        fields = {"information": ("policy",), "chronology": ("group", "origin", "policy"),
                  "pareto": ("group", "policy", "precision"), "maintenance": ("group", "policy", "precision")}.get(name, core)
        write_csv(output / f"m29_{name}.csv", records, fields=fields)
    for stem in ("waits", "wait_checks", "observations"):
        name = f"m29_{stem}.csv"
        stream_artifact(folders, name, output / name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stages", type=Path, default=ROOT / "stages")
    parser.add_argument("--output", type=Path, default=ROOT / "results")
    parser.add_argument("--m28", type=Path, default=M28 / "results")
    parser.add_argument("--m27", type=Path, default=M27 / "results")
    parser.add_argument("--horizon", type=int, default=540)
    args = parser.parse_args()
    if not 0 < args.horizon <= 540:
        parser.error("Horizon must be between 1 and 540.")
    collect(args.stages, args.output, args.m28, args.m27, args.horizon * CLOCK)


if __name__ == "__main__":
    main()
