"""Generate the six M29 held-out density pairs from the frozen preparations."""

import argparse
import csv
from dataclasses import dataclass
from decimal import Decimal
import hashlib
from io import BytesIO, StringIO
from itertools import combinations
import json
import math
import os
from pathlib import Path
import sys
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parent
M28 = ROOT.parent / "Milestone_28"
sys.path.insert(0, str(M28))
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import numpy as np

from run_m28 import publish_stage
from run_m26 import M23, model, source_pair
from run_m25 import fingerprint
from m21_observables import CHAIN_DIM, CHAIN_SITES, LOAD_DIM, LOAD_LEVELS, expectation, spectrum
from m23_spectral import DT, EXCHANGE_LOWER, FLOOR, G, GRID, extraction, partial, rk_steps
from m25_diagnostics import state_metrics


RECIPES = ROOT / "UNSEEN_RECIPES_M29.json"
FROZEN_RECIPE = "ad621e01ecb2a5afa2f664db332dcc9d180ad94f8ec8125aff00dfc4dcd551db"
SOURCE_TABLE = ROOT.parent / "Milestone_26" / "results" / "m26_sources.csv"
M28_ANCHORS = M28 / "anchors"
PRECISIONS = ("coarse", "half")
TICKS_PER_UNIT = 1000


@dataclass(frozen=True)
class Prepared:
    pair: tuple
    clock: int
    coupling: float
    history: tuple


@dataclass(frozen=True)
class SelectedClock:
    tick: int
    q: float
    count: int
    threshold_met: bool


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_rows(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def write_once(path, data):
    """Publish complete bytes, preserving a previously verified identical artifact."""
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != data:
            raise ValueError(f"Existing preparation artifact differs: {path}")
        return
    with TemporaryDirectory(prefix=".unseen-", dir=path.parent) as temporary:
        prepared = Path(temporary) / path.name
        prepared.write_bytes(data)
        publish_stage(prepared, path)


def write_table(path, rows):
    contents = StringIO(newline="")
    fields = list(dict.fromkeys(key for row in rows for key in row))
    writer = csv.DictWriter(contents, fieldnames=fields)
    writer.writeheader()
    writer.writerows(rows)
    write_once(path, contents.getvalue().encode("utf-8"))


def archive_bytes(prepared, source_time):
    contents = BytesIO()
    np.savez_compressed(contents, coarse=prepared.pair[0], half=prepared.pair[1], tick=0,
                        records="[]", source_time=source_time)
    return contents.getvalue()


def coherence(rho):
    return complex(np.einsum("ij,ji->", partial(rho), EXCHANGE_LOWER))


def record_step(dynamics, before, pair, elapsed, coupling, name, *, factor=1.0 + 0.0j):
    rows = []
    for label, start, end in zip(PRECISIONS, before.pair, pair, strict=True):
        energy_in = expectation(start, dynamics.h[before.coupling])
        energy_out = expectation(end, dynamics.h[coupling])
        delta = energy_out - energy_in
        if elapsed and abs(delta) > FLOOR:
            raise ValueError(f"Energy drifts during frozen preparation {name}: {delta:g}")
        rows.append({"precision": label, "operation": name,
                     "prep_elapsed_start": before.clock / 1000, "prep_elapsed_end": (before.clock + elapsed) / 1000,
                     "coupling_start": before.coupling, "coupling_end": coupling,
                     "energy_before": energy_in, "energy_after": energy_out,
                     "signed_external_work_on_system": delta if not elapsed else 0.0,
                     "propagation_energy_drift": delta if elapsed else 0.0,
                     "c_imag_before": coherence(start).imag, "c_imag_after": coherence(end).imag,
                     "load_phase_angle": float(np.angle(factor)) if name == "load_number_phase" else "",
                     "input_rho_sha256": fingerprint(start), "output_rho_sha256": fingerprint(end)})
    return Prepared(pair, before.clock + elapsed, coupling, before.history + tuple(rows))


def propagate(dynamics, state, ticks):
    if ticks == 0:
        return state
    pair = tuple(dynamics.bases[state.coupling].evolve(rho, ticks, dt) for rho, dt in zip(state.pair, DT, strict=True))
    return record_step(dynamics, state, pair, ticks, state.coupling, "propagate")


def apply_preparation(dynamics, seed, operations):
    state = Prepared(seed, 0, G, ())
    for action, ticks in operations:
        if action == "propagate":
            state = propagate(dynamics, state, ticks)
        elif action == "passivate_load" and ticks == 0:
            pair = tuple(extraction(rho) for rho in state.pair)
            state = record_step(dynamics, state, pair, 0, state.coupling, action)
        elif (action, state.coupling, ticks) in (("cut", G, 0), ("reconnect", 0.0, 0)):
            state = record_step(dynamics, state, state.pair, 0, 0.0 if action == "cut" else G, action)
        else:
            raise ValueError(f"Unrecognized preparation operation: {action}, {ticks}")
    if state.coupling != G:
        raise ValueError("A frozen preparation must finish connected")
    return state


def select_clocks(dynamics, state, bounds, threshold, grid):
    """Use only q in the fixed preparation interval to register each signed clock."""
    connected = dynamics.connected
    operator = np.kron(np.eye(CHAIN_DIM // 2), EXCHANGE_LOWER)
    weights = (connected.tr @ operator @ connected.vectors).T
    index = np.nonzero(weights)
    coefficients = connected.to_basis(state.pair[0])[index] * weights[index]
    advance = connected.logs[DT[0]][index]
    first, last = bounds
    phase = np.exp(advance * rk_steps(first, DT[0]))
    increment = np.exp(advance * rk_steps(grid, DT[0]))
    selected, best = {}, {}
    for count, tick in enumerate(range(first, last + 1, grid), 1):
        q = -float(np.dot(coefficients, phase).imag)
        for sign in (1, -1):
            if sign not in best or sign * q > sign * best[sign].q:
                best[sign] = SelectedClock(tick, q, count, False)
            if sign not in selected and sign * q >= threshold:
                selected[sign] = SelectedClock(tick, q, count, True)
        if len(selected) == 2:
            return selected
        phase *= increment
    return {sign: selected.get(sign, SelectedClock(best[sign].tick, best[sign].q, count, False))
            for sign in (1, -1)}


def rotate_load(dynamics, state, magnitude_floor):
    c = coherence(state.pair[0])
    factor = c.conjugate() / abs(c) if abs(c) > magnitude_floor else 1.0 + 0.0j
    phases = np.tile(factor ** LOAD_LEVELS, CHAIN_DIM)
    pair = tuple(phases[:, None] * rho * phases.conjugate()[None, :] for rho in state.pair)
    rotated = record_step(dynamics, state, pair, 0, G, "load_number_phase", factor=factor)
    if abs(coherence(pair[0]).imag) > magnitude_floor:
        raise ValueError("Frozen number-phase preparation did not make the coarse c real")
    return rotated, float(np.angle(factor))


def real_product(dynamics, settings):
    chain = np.ones((1, 1))
    populations = settings["chain_excited_probabilities"]
    if len(populations) != CHAIN_SITES or settings["load_rotated_levels"] != [0, 1]:
        raise ValueError("Invalid frozen product dimensions")
    for p in populations:
        offdiagonal = settings["chain_offdiagonal_fraction"] * math.sqrt(p * (1 - p))
        chain = np.kron(chain, [[1 - p, offdiagonal], [offdiagonal, p]])
    angle = settings["load_real_rotation_angle_rad"]
    cos, sin = math.cos(angle), math.sin(angle)
    rotation = np.array([[cos, -sin, 0], [sin, cos, 0], [0, 0, 1]])
    load = rotation @ np.diag(settings["load_eigenvalues"]) @ rotation.T
    rho = np.kron(chain, load).astype(np.complex128)
    if coherence(rho).imag != 0.0:
        raise ValueError("A real coherent product must have exactly zero q")
    energy = expectation(rho, dynamics.h[G])
    rows = tuple({"precision": label, "operation": "real_coherent_product",
                  "prep_elapsed_start": 0.0, "prep_elapsed_end": 0.0, "coupling_start": "", "coupling_end": G,
                  "energy_before": "", "energy_after": energy, "signed_external_work_on_system": "",
                  "propagation_energy_drift": "", "c_imag_before": "", "c_imag_after": 0.0,
                  "load_phase_angle": "", "input_rho_sha256": "", "output_rho_sha256": fingerprint(rho)}
                 for label in PRECISIONS)
    return Prepared((rho, rho.copy()), 0, G, rows)


def make_inputs(dynamics, recipe, source):
    seed = source_pair(M23, source)
    bases = {name: apply_preparation(dynamics, seed, plan["operations"])
             for name, plan in recipe["preparations"].items()}
    threshold = recipe["signed_q_threshold"]
    clocks = {name: select_clocks(dynamics, bases[name], plan["scan_ticks"], threshold, recipe["scan_step_ticks"])
              for name, plan in recipe["preparations"].items()}
    for origin, settings in recipe["cases"].items():
        kind = settings["type"]
        base = settings.get("preparation", "")
        meta = {"origin": origin, "preparation_type": kind, "preparation_family": base,
                "archived_source": source["origin"] if base else "",
                "target_q_sign": settings.get("q_sign", 0), "phase_rad": ""}
        if kind == "signed_reachable":
            sign = settings["q_sign"]
            chosen = clocks[base][sign]
            state = propagate(dynamics, bases[base], chosen.tick)
            q = -coherence(state.pair[0]).imag
            if abs(q - chosen.q) > FLOOR or (sign * q >= threshold) != chosen.threshold_met:
                raise ValueError(f"Selected clock differs under full-density preparation replay: {origin}")
            meta.update(prep_scan_tick=chosen.tick, prep_observations_used=chosen.count,
                        signed_threshold_met=chosen.threshold_met,
                        selection="first_signed_threshold" if chosen.threshold_met else "signed_maximum_fallback")
        elif kind == "local_load_number_phase":
            state, phase = rotate_load(dynamics, bases[base], settings["phase_magnitude_floor"])
            meta.update(selection="number_phase", phase_rad=phase)
        elif kind == "real_coherent_product":
            state = real_product(dynamics, settings)
            meta.update(selection="fixed_product_parameters")
        else:
            raise ValueError(f"Unknown frozen preparation type: {kind}")
        source_time = float((Decimal(source["source_time"]) if base else Decimal(0)) + Decimal(state.clock) / 1000)
        yield state, {**meta, "preparation_elapsed": state.clock / 1000, "source_time": source_time}


def load_density(rho):
    terminal = partial(rho)
    return terminal[:LOAD_DIM, :LOAD_DIM] + terminal[LOAD_DIM:, LOAD_DIM:]


def distance(left, right):
    return float(np.abs(spectrum(left - right)).sum() / 2)


def reference_pairs(sources):
    for source in sources:
        pair = source_pair(M23, source)
        for level, state in zip(PRECISIONS, pair, strict=True):
            yield state, {"reference_group": "M26_sources", "reference_origin": source["origin"],
                          "reference_precision": level, "reference_source_time": source["source_time"],
                          "reference_elapsed": 0.0, "reference_rho_sha256": fingerprint(state)}
    for row in read_rows(M28_ANCHORS / "m28_anchors.csv"):
        level = row["precision"]
        with np.load(M28_ANCHORS / row["anchor_file"], allow_pickle=False) as archive:
            state = archive[level]
            if fingerprint(state) != row[f"{level}_sha256"] or int(archive["tick"]) != round(float(row["fork_elapsed"]) * 1000):
                raise ValueError(f"Prior M28 anchor fails provenance: {row['anchor_file']}")
        yield state, {"reference_group": row["group"], "reference_origin": row["origin"],
                      "reference_precision": level, "reference_source_time": row["source_time"],
                      "reference_elapsed": row["fork_elapsed"], "reference_rho_sha256": fingerprint(state)}


def distance_row(origin, level, state, other, reference):
    whole = distance(state, other)
    load = distance(load_density(state), load_density(other))
    if load > whole + FLOOR:
        raise ValueError(f"Partial trace increases the state distance for {origin}/{level}")
    return {"origin": origin, "precision": level, **reference,
            "global_trace_distance": whole, "load_trace_distance": load}


def make_distances(inputs, sources):
    out = []
    for prior, reference in reference_pairs(sources):
        level = reference["reference_precision"]
        for state, meta in inputs:
            out.append(distance_row(meta["origin"], level, state.pair[PRECISIONS.index(level)], prior, reference))
    for (left, a), (right, b) in combinations(inputs, 2):
        for level, rho, other in zip(PRECISIONS, left.pair, right.pair, strict=True):
            out.append(distance_row(a["origin"], level, rho, other, {"reference_group": "unseen",
                "reference_origin": b["origin"], "reference_precision": level, "reference_source_time": b["source_time"],
                "reference_elapsed": 0.0, "reference_rho_sha256": fingerprint(other)}))
    return out


def validate_recipe(protocol):
    raw = RECIPES.read_bytes()
    registered = digest(raw)
    if registered != FROZEN_RECIPE or registered not in protocol.read_text(encoding="utf-8").lower():
        raise ValueError("The preparation recipe does not match the frozen M29 protocol digest")
    recipe = json.loads(raw)
    if (recipe["time_ticks_per_unit"], recipe["connected_coupling"], tuple(recipe["rk4_steps"]),
            recipe["scan_step_ticks"]) != (TICKS_PER_UNIT, G, DT, GRID):
        raise ValueError("The inherited physics differs from the frozen preparation settings")
    return recipe, registered


def generate(output, protocol):
    recipe, recipe_hash = validate_recipe(protocol)
    protocol_hash = digest(protocol.read_bytes())
    sources = read_rows(SOURCE_TABLE)
    source, = (row for row in sources if row["origin"] == recipe["seed_from_m26_sources"])
    dynamics = model()
    inputs = list(make_inputs(dynamics, recipe, source))
    registry, states, steps, input_records = [], [], [], []
    for state, meta in inputs:
        origin = meta["origin"]
        pair_hashes = {f"{precision}_sha256": fingerprint(rho) for precision, rho in zip(PRECISIONS, state.pair, strict=True)}
        archive = archive_bytes(state, meta["source_time"])
        raw_path = Path("densities") / f"{origin}.npz"
        write_once(output / "unseen" / raw_path, archive)
        archive_hash = digest(archive)
        input_records.append({**meta, **pair_hashes, "archive_file": raw_path.as_posix(), "archive_sha256": archive_hash,
                              "recipe_sha256": recipe_hash, "protocol_sha256": protocol_hash})
        for level, rho in zip(PRECISIONS, state.pair, strict=True):
            anchor_path = Path("unseen", origin, level, "anchor.npz")
            write_once(output / "anchors" / anchor_path, archive)
            registry.append({"group": "unseen", "origin": origin, "precision": level, "fork_elapsed": 0.0,
                             "source_time": meta["source_time"], "prefix_attempts": 0, "prefix_waits": 0,
                             **pair_hashes, "anchor_file": anchor_path.as_posix(), "archive_sha256": archive_hash,
                             "recipe_sha256": recipe_hash, "protocol_sha256": protocol_hash})
            measured = state_metrics(dynamics, rho)
            signed_work = math.fsum(row["signed_external_work_on_system"] for row in state.history
                                    if row["precision"] == level and row["signed_external_work_on_system"] != "")
            states.append({**meta, "precision": level, "coupling": G, "q": -measured["c_imag"],
                           "preparation_signed_external_work": signed_work if meta["archived_source"] else "",
                           "rho_sha256": pair_hashes[f"{level}_sha256"], **measured})
        steps.extend({"origin": origin, "operation_index": i // 2 + 1, **row} for i, row in enumerate(state.history))
    write_table(output / "unseen" / "sources.csv", input_records)
    write_table(output / "unseen" / "generation_steps.csv", steps)
    write_table(output / "unseen" / "physical_metrics.csv", states)
    write_table(output / "unseen" / "trace_distances.csv", make_distances(inputs, sources))
    write_table(output / "anchors" / "m29_unseen_anchors.csv", registry)
    manifest = {"seed_recipe": source, "recipe_sha256": recipe_hash, "protocol_sha256": protocol_hash,
                "generator_sha256": digest(Path(__file__).read_bytes()),
                "m26_source_table_sha256": digest(SOURCE_TABLE.read_bytes()),
                "m28_anchor_registry_sha256": digest((M28_ANCHORS / "m28_anchors.csv").read_bytes()),
                "input_archives": {entry["origin"]: entry["archive_sha256"] for entry in input_records}}
    write_once(output / "unseen" / "manifest.json", (json.dumps(manifest, indent=2) + "\n").encode("utf-8"))
    print(f"Prepared {len(inputs)} unseen states and {len(registry)} matched anchor entries in {output}", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT)
    parser.add_argument("--protocol", type=Path, default=ROOT / "PROTOCOL_M29.md")
    args = parser.parse_args()
    generate(args.output, args.protocol)


if __name__ == "__main__":
    main()
