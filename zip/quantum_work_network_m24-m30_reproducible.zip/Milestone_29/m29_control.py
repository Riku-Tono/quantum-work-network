"""Registered reconnection rules with explicit scalar inputs."""

EPSILON_Q = 1e-11
RELATIVE = 0.25
AMPLITUDE_FLOOR = 1e-5


def p1(amplitude, q, c0_abs):
    return amplitude >= AMPLITUDE_FLOOR and q >= RELATIVE * c0_abs


def p2(q, c0_abs):
    return q >= RELATIVE * c0_abs


def p3(q, q0):
    return q >= max(RELATIVE * abs(q0), EPSILON_Q)


def p4(q):
    return q > EPSILON_Q
