"""Validate the whole-horizon composites and perturb recorded scalar inputs."""

import argparse
from collections import defaultdict
import csv
from dataclasses import dataclass
import hashlib
import json
import math
import os
from pathlib import Path
from tempfile import TemporaryDirectory

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import numpy as np

from m29_control import EPSILON_Q, RELATIVE


ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent
M27, M28 = (WORKSPACE / f"Milestone_{number}" for number in (27, 28))
ORIGINS = ("S0", "A04", "B04", "C04")
PRECISIONS = ("coarse", "half")
STAGES = (150, 300, 540)
THOUSAND = 1000
COMPOSITES = {"M3": ("M29", "P3"), "M4": ("M29", "P4"), "M-F3": ("M28", "R3")}
Q_DELTAS = (-1e-11, -1e-12, 1e-12, 1e-11)
SENSITIVITY_FIELDS = ("group", "origin", "policy", "precision", "attempt", "elapsed_total", "observed_until",
                      "wait_elapsed", "at_limit", "q", "q0", "threshold_q", "q_minus_threshold", "perturbed_input",
                      "delta_q", "delta_q0", "revised_q", "revised_q0", "revised_threshold_q", "raw_gate",
                      "revised_gate", "changed", "raw_reconnect", "revised_reconnect", "action_changed",
                      "raw_limit_fallback", "revised_limit_fallback", "source_file")


def insist(condition, context):
    if not condition:
        raise ValueError(context)


def ticks(value):
    scaled = float(value) * THOUSAND
    clock = round(scaled)
    insist(abs(scaled - clock) < 1e-6, f"Off-grid recorded clock {value}")
    return clock


def boolean(value):
    insist(value in ("True", "False"), f"Invalid recorded Boolean: {value}")
    return value == "True"


def rows(path):
    if not path.exists():
        return []
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def relative(path):
    return Path(os.path.relpath(path.resolve(), WORKSPACE)).as_posix()


def fingerprint(array):
    return hashlib.sha256(np.asarray(array, dtype="<c16", order="C").tobytes()).hexdigest()


def same_work(left, right):
    return math.isclose(float(left), float(right), rel_tol=1e-12, abs_tol=5e-16)


def write_csv(path, values, *, fields=()):
    columns = list(dict.fromkeys([*fields, *(key for row in values for key in row)]))
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        writer.writerows(values)


def stage_folders(stages, group, origin, policy, precision):
    suffix = (origin, policy, precision) if group is None else (group, origin, policy, precision)
    return tuple(stages.joinpath(f"t{cut}", *suffix) for cut in STAGES)


def completed_folders(folders):
    for folder in folders:
        if not (folder / "checkpoint.npz").is_file():
            raise FileNotFoundError(f"Awaiting finalizable stage: {folder / 'checkpoint.npz'}")
    return folders


@dataclass(frozen=True)
class Segment:
    archive: str
    group: str
    policy: str
    origin: str
    precision: str
    events: list
    decisions: list
    checkpoint_path: Path
    checkpoint: dict


def read_segment(archive, folders, group, policy, origin, precision):
    completed_folders(folders)
    stem = archive.lower()
    events, decisions = [], []
    for folder in folders:
        history_path, decision_path = (folder / f"{stem}_{name}.csv" for name in ("history", "decisions"))
        events.extend({**row, "source_file": relative(history_path)} for row in rows(history_path))
        decisions.extend({**row, "source_file": relative(decision_path)} for row in rows(decision_path))
    checkpoint_path = folders[-1] / "checkpoint.npz"
    summary_path = folders[-1] / f"{stem}_checkpoints.csv"
    checkpoint, = rows(summary_path)
    insist(bool(events), f"No registered attempts at {archive}/{group}/{origin}/{policy}/{precision}")
    expected = origin, policy, precision
    insist(all((row["origin"], row["policy"], row["precision"]) == expected and row.get("group", group) == group
               for row in [*events, *decisions, checkpoint]),
           f"Unexpected provenance in {summary_path}")
    return Segment(archive, group, policy, origin, precision, events, decisions, checkpoint_path, checkpoint)


def event_hashes(row, stage):
    return tuple(row[f"{stage}_{level}_sha256"] for level in PRECISIONS)


def checked_events(segment, start):
    """Validate an archive's own event order and cumulative balances."""
    elapsed, count = start, 0
    realized, aligned = [], []
    previous = None
    context = f"{segment.archive}/{segment.group}/{segment.origin}/{segment.policy}/{segment.precision}"
    for attempt, row in enumerate(segment.events, 1):
        begin, end = ticks(row["elapsed_start"]), ticks(row["elapsed_total"])
        insist(int(row["attempt"]) == attempt and begin == elapsed < end <= STAGES[-1] * THOUSAND,
               f"Noncontiguous ledger {context}/{attempt}")
        if previous is not None:
            insist(event_hashes(previous, "post") == event_hashes(row, "start"),
                   f"Mismatched state handoff {context}/{attempt}")
        realized.append(float(row["net_work"]))
        aligned.append(float(row["net_work_aligned"]))
        count += int(boolean(row["accepted"]))
        insist(int(row["count"]) == count and same_work(math.fsum(realized), row["cumulative_net"])
               and same_work(math.fsum(aligned), row["cumulative_net_aligned"]),
               f"Work or accepted total disagrees with the source ledger: {context}/{attempt}")
        elapsed, previous = end, row
    checkpoint = segment.checkpoint
    insist(ticks(checkpoint["elapsed_total"]) == STAGES[-1] * THOUSAND
           and ticks(checkpoint["anchor_elapsed"]) == elapsed
           and int(checkpoint["attempts"]) == len(segment.events) and int(checkpoint["count"]) == count
           and tuple(checkpoint[f"anchor_{step}_sha256"] for step in PRECISIONS) == event_hashes(previous, "post")
           and same_work(checkpoint["cumulative_net"], math.fsum(realized))
           and same_work(checkpoint["cumulative_net_aligned"], math.fsum(aligned)),
           f"Final checkpoint differs from completed events: {context}")
    return segment.events


def original_switch(segment):
    found = [row for row in segment.decisions if boolean(row["switched"])]
    insist(len(found) == 1, f"Expected one archived mode transition: {segment.origin}/{segment.policy}/{segment.precision}")
    switch, = found
    insist(switch["mode_before"] == "forecast" and switch["mode_after"] == "wait"
           and ticks(switch["observed_until"]) <= ticks(switch["elapsed_total"]),
           f"Archived first-switch observation disagrees: {segment.origin}/{segment.policy}/{segment.precision}")
    return switch


def replay_rate_switch(segment):
    """Recompute F1's trigger before observing each ensuing attempt."""
    archived_log = {int(row["attempt"]): row for row in segment.decisions}
    accepted = []
    run_start, consecutive = None, 0
    log = []
    source = f"{segment.origin}/F1/{segment.precision}"
    for row in segment.events:
        trial = int(row["attempt"])
        now = ticks(row["elapsed_start"])
        baseline_items = [work for clock, work in accepted if 0 < clock <= 32_000]
        moving_items = [work for clock, work in accepted if now - 24_000 < clock <= now]
        baseline = math.fsum(baseline_items) / 32 if now >= 32_000 else None
        moving = math.fsum(moving_items) / 24
        low = now >= 48_000 and baseline is not None and baseline > 0 and moving <= 0.45 * baseline
        if low:
            run_start = now if run_start is None else run_start
            consecutive += 1
        else:
            run_start, consecutive = None, 0
        low_age = now - run_start if run_start is not None else 0
        switch = now >= 30_000 and consecutive >= 2 and low_age >= 4_000
        expected = archived_log[trial]
        insist(ticks(expected["elapsed_total"]) == now and ticks(expected["observed_until"]) <= now
               and boolean(expected["switched"]) == switch and int(expected["low_count"]) == consecutive
               and ((baseline is None and expected["baseline_rate"] == "") or
                    (baseline is not None and same_work(baseline, expected["baseline_rate"])))
               and same_work(moving, expected["moving_rate"])
               and ((run_start is None and expected["low_since"] == "") or
                    (run_start is not None and ticks(expected["low_since"]) == run_start)),
               f"Rate-only replay disagrees with the archived decision: {source}/{trial}")
        log.append({"group": "whole", "origin": segment.origin, "precision": segment.precision,
                    "rate_control": "F1", "attempt": trial, "elapsed_total": now / THOUSAND,
                    "latest_completed_accepted_time": accepted[-1][0] / THOUSAND if accepted else "",
                    "completed_accepted_count": len(accepted), "baseline_samples": len(baseline_items),
                    "baseline_rate": baseline, "moving_samples": len(moving_items), "moving_rate": moving,
                    "rate_trigger": low, "consecutive_low": consecutive,
                    "low_run_start": run_start / THOUSAND if run_start is not None else "",
                    "low_run_age": low_age / THOUSAND, "replayed_switch": switch, "source_file": expected["source_file"]})
        if switch:
            insist(expected["reason"] == "low_rate", f"F1 used a different switch cause: {source}")
            return expected, log
        insist(row["mode"] == "forecast" and ticks(row["tau"]) == 0,
               f"A cut wait occurred before the independent rate trigger: {source}/{trial}")
        if boolean(row["accepted"]):
            accepted.append((ticks(row["elapsed_total"]), float(row["net_work"])))
    raise ValueError(f"No rate-only switch found: {source}")


def inspect_anchor(anchor_row, prefix, prefix_segment, switch):
    anchor_file = M28 / "anchors" / anchor_row["anchor_file"]
    saved_switch = (M28 / anchor_row["source_switch"].replace("\\", "/")).resolve(strict=True)
    fork = ticks(switch["elapsed_total"])
    insist(prefix and ticks(prefix[-1]["elapsed_total"]) == fork
           and int(switch["attempt"]) == len(prefix) + 1 and ticks(anchor_row["fork_elapsed"]) == fork
           and int(anchor_row["prefix_attempts"]) == len(prefix) and int(anchor_row["prefix_waits"]) == 0,
           f"Wrong registered anchor boundary: {anchor_file}")
    digests = tuple(anchor_row[f"{step}_sha256"] for step in PRECISIONS)
    full_next = prefix_segment.events[len(prefix)]
    insist(digests == event_hashes(prefix[-1], "post") == event_hashes(full_next, "start"),
           f"Archived hash handoffs disagree at {anchor_file}")
    with np.load(anchor_file, allow_pickle=False) as archive, np.load(saved_switch, allow_pickle=False) as source:
        insist(int(archive["tick"].item()) == int(source["tick"].item()) == fork
               and float(archive["source_time"].item()) == float(anchor_row["source_time"]),
               f"Saved source clock disagrees at {anchor_file}")
        for level, witness in zip(PRECISIONS, digests, strict=True):
            insist(fingerprint(archive[level]) == fingerprint(source[level]) == witness,
                   f"Saved density hash disagrees at {anchor_file}/{level}")
        memory = json.loads(str(archive["records"].item()))
    insist(len(memory) == len(prefix), f"Prefix memory length differs at {anchor_file}")
    for recorded, row in zip(memory, prefix, strict=True):
        insist(recorded["accepted"] == boolean(row["accepted"])
               and all(float(recorded[field]) == float(row[field]) for field in
                       ("elapsed_total", "duration", "tau", "net_work", "net_work_aligned")),
               f"Prefix memory differs from realized history at {anchor_file}/{row['attempt']}")
    return {"source_anchor_file": relative(anchor_file), "source_switch_file": relative(saved_switch),
            "matched_coarse_sha256": digests[0], "matched_half_sha256": digests[1]}


def assemble_events(origin, precision, policy, fork, prefix, prefix_segment, tail, tail_segment):
    if tail:
        insist(ticks(tail[0]["elapsed_start"]) == fork and event_hashes(prefix[-1], "post") == event_hashes(tail[0], "start"),
               f"Fork density mismatch for {origin}/{policy}/{precision}")
        insist(all(ticks(row["fork_elapsed"]) == fork for row in tail),
               f"Suffix started from a different time for {origin}/{policy}/{precision}")
    realized, aligned, errors, count = [], [], [], 0
    attempt = 0
    for supplied, segment, role in ((prefix, prefix_segment, "prefix" if tail else "full"), (tail, tail_segment, "tail")):
        for row in supplied:
            attempt += 1
            value, companion = float(row["net_work"]), float(row["net_work_aligned"])
            realized.append(value)
            aligned.append(companion)
            errors.append(abs(value - companion))
            count += int(boolean(row["accepted"]))
            full, matched = math.fsum(realized), math.fsum(aligned)
            yield {**row, "group": "whole", "origin": origin, "policy": policy, "precision": precision,
                   "fork_elapsed": 0.0, "initial_switch_elapsed": fork / THOUSAND,
                   "attempt": attempt, "count": count, "cumulative_net": full, "cumulative_net_aligned": matched,
                   "cumulative_net_half_aligned": matched if precision == "coarse" else full,
                   "cumulative_step_error_bound": math.fsum(errors), "cumulative_rate": full / float(row["elapsed_total"]),
                   "segment": role, "source_archive": segment.archive, "source_group": segment.group,
                   "source_policy": segment.policy, "source_precision": segment.precision,
                   "source_attempt": row["attempt"], "source_count": row["count"],
                   "source_cumulative_net": row["cumulative_net"], "source_cumulative_net_aligned": row["cumulative_net_aligned"],
                   "segment_fork_elapsed": fork / THOUSAND if role == "tail" else 0.0}


def switch_row(origin, precision, policy, switch, anchor, prefix, prefix_segment, tail_segment):
    coherence_used = policy == "F2-R"
    return {"group": "whole", "origin": origin, "policy": policy, "precision": precision,
            "first_switch_elapsed": switch["elapsed_total"], "switch_attempt": switch["attempt"],
            "uses_phase": coherence_used, "trigger": "work_rate_and_coherence" if coherence_used else "work_rate_only",
            "source_reason": switch["reason"], "source_switch_decision_file": switch["source_file"], **anchor,
            "baseline_rate": switch["baseline_rate"], "moving_rate": switch["moving_rate"],
            "completed_prefix_attempts": len(prefix), "accepted_prefix_attempts": prefix[-1]["count"],
            "prefix_signed_work": prefix[-1]["cumulative_net"], "source_prefix_file": prefix[-1]["source_file"],
            "source_prefix_archive": prefix_segment.archive, "source_prefix_policy": prefix_segment.policy,
            "source_tail_archive": tail_segment.archive, "source_tail_group": tail_segment.group,
            "source_tail_policy": tail_segment.policy, "source_tail_checkpoint": relative(tail_segment.checkpoint_path)}


def whole(stages, output):
    registry = {(row["group"], row["origin"], row["precision"]): row for row in rows(M28 / "anchors" / "m28_anchors.csv")}
    history, switches, replay = [], [], []
    for origin in ORIGINS:
        for precision in PRECISIONS:
            f1 = read_segment("M27", stage_folders(M27 / "stages", None, origin, "F1", precision), "main", "F1", origin, precision)
            f2 = read_segment("M28", stage_folders(M28 / "stages", "main", origin, "F2-R", precision), "main", "F2-R", origin, precision)
            for baseline in (f1, f2):
                checked_events(baseline, 0)
            f1_switch, log = replay_rate_switch(f1)
            replay.extend(log)
            f2_switch = original_switch(f2)
            insist(original_switch(f1) == f1_switch and f2_switch["reason"] == "low_rate_phase_gate"
                   and boolean(f2_switch["phase_gate"]), f"Mismatched archived control switch at {origin}/{precision}")
            baseline_info = {}
            for baseline, switch in ((f1, f1_switch), (f2, f2_switch)):
                fork = ticks(switch["elapsed_total"])
                prefix = [row for row in baseline.events if ticks(row["elapsed_total"]) <= fork]
                anchor = inspect_anchor(registry[baseline.policy, origin, precision], prefix, baseline, switch)
                history.extend(assemble_events(origin, precision, baseline.policy, fork, baseline.events, baseline, (), baseline))
                switches.append(switch_row(origin, precision, baseline.policy, switch, anchor, prefix, baseline, baseline))
                baseline_info[baseline.policy] = fork, prefix, anchor
            fork, prefix, anchor = baseline_info["F1"]
            for label, (archive, continuation) in COMPOSITES.items():
                tail = read_segment(archive,
                                    stage_folders(stages if archive == "M29" else M28 / "stages", "F1", origin, continuation, precision),
                                    "F1", continuation, origin, precision)
                checked_events(tail, fork)
                history.extend(assemble_events(origin, precision, label, fork, prefix, f1, tail.events, tail))
                switches.append(switch_row(origin, precision, label, f1_switch, anchor, prefix, f1, tail))
    write_csv(output / "m29_whole_history.csv", history, fields=("group", "origin", "policy", "precision"))
    write_csv(output / "m29_whole_switches.csv", switches)
    write_csv(output / "m29_whole_rate_replay.csv", replay)
    print(f"Certified {len(switches)} whole-horizon branches and {len(history)} signed attempts", flush=True)


def predicate(policy, q, q0):
    if policy == "P3":
        threshold = max(RELATIVE * abs(q0), EPSILON_Q)
        return q >= threshold, threshold
    return q > EPSILON_Q, EPSILON_Q


def sensitivity_folders(stages):
    cohorts = {"F2-R": ORIGINS, "F1": ORIGINS, "unseen": tuple(f"U{i:02d}" for i in range(1, 7))}
    for group, origins in cohorts.items():
        for origin in origins:
            for policy in ("P3", "P4"):
                for precision in PRECISIONS:
                    yield (group, origin, policy, precision), completed_folders(stage_folders(stages, group, origin, policy, precision))


def consumed_samples(folder, key):
    """Derive the actual last clock from the fixed window, even when its gate passed."""
    selector = folder / "m29_selector.csv"
    attempts = {int(row["attempt"]): row for row in rows(folder / "m29_history.csv") if ticks(row["tau"]) > 0}
    grouped = defaultdict(list)
    for row in rows(selector):
        insist(tuple(row[field] for field in ("group", "origin", "policy", "precision")) == key,
               f"Wrong selector provenance in {selector}")
        grouped[int(row["attempt"])].append(row)
    insist(grouped.keys() == attempts.keys(), f"Missing consumed selector evidence in {folder}")
    physical = rows(folder / "m29_wait_checks.csv")
    actual = {(int(row["attempt"]), ticks(row["elapsed_total"])): row for row in physical}
    insist(len(actual) == len(physical), f"Duplicate physical wait observations in {folder}")
    for attempt, observed in grouped.items():
        trial = attempts[attempt]
        initial = ticks(trial["elapsed_start"])
        physical_last = min(6000, ticks(trial["window"]) - 20) // 200 * 200
        actual_wait = ticks(trial["tau"])
        insist([ticks(row["wait_elapsed"]) for row in observed] == list(range(1000, actual_wait + 1, 200))
               and 1000 <= actual_wait <= physical_last, f"Wrong consumed wait lattice: {selector}/{attempt}")
        for row in observed:
            delay = ticks(row["wait_elapsed"])
            limit = delay == physical_last
            insist(ticks(row["elapsed_total"]) == ticks(row["observed_until"]) == initial + delay,
                   f"Wrong acquisition clock: {selector}/{attempt}/{delay}")
            measured = actual.pop((attempt, initial + delay))
            insist(float(row["q"]) == -float(measured["c_imag"]), f"Selector q differs from its physical record: {selector}/{attempt}")
            if key[2] == "P3":
                insist(float(row["q0"]) == float(trial["current_before"]) / 0.5,
                       f"Selector q0 differs from the realized pre-cut current: {selector}/{attempt}")
            raw, reconnect = boolean(row["gate"]), boolean(row["reconnect"])
            insist(reconnect == (raw or limit) == (delay == actual_wait)
                   and boolean(row["limit"]) == (limit and not raw), f"Wrong observed gate outcome: {selector}/{attempt}/{delay}")
            yield row, limit, relative(selector)
    insist(not actual, f"Unaccounted physical wait observations in {folder}")


def perturbations(row, at_limit, path, policy):
    q = float(row["q"])
    q0 = float(row["q0"]) if policy == "P3" else None
    insist((q0 is None and row["q0"] == "") or q0 is not None, f"Prohibited q0 in {policy}")
    raw, threshold = predicate(policy, q, q0)
    insist(raw == boolean(row["gate"]) and threshold == float(row["threshold_q"]),
           f"Replayed scalar gate disagrees with its logged observation: {path}/{row['attempt']}/{row['elapsed_total']}")
    raw_reconnect = boolean(row["reconnect"])
    tags = {field: row[field] for field in ("group", "origin", "policy", "precision", "attempt", "elapsed_total", "observed_until", "wait_elapsed")}
    for input_name in (("q", "q0") if policy == "P3" else ("q",)):
        for delta in Q_DELTAS:
            delta_q = delta if input_name == "q" else 0.0
            delta_q0 = delta if input_name == "q0" else 0.0
            revised_q = q + delta_q
            revised_q0 = q0 + delta_q0 if q0 is not None else None
            revised, revised_threshold = predicate(policy, revised_q, revised_q0)
            revised_reconnect = revised or at_limit
            yield {**tags, "at_limit": at_limit, "q": q, "q0": q0, "threshold_q": threshold,
                   "q_minus_threshold": q - threshold, "perturbed_input": input_name, "delta_q": delta_q, "delta_q0": delta_q0,
                   "revised_q": revised_q, "revised_q0": revised_q0, "revised_threshold_q": revised_threshold,
                   "raw_gate": raw, "revised_gate": revised, "changed": raw != revised, "raw_reconnect": raw_reconnect,
                   "revised_reconnect": revised_reconnect, "action_changed": raw_reconnect != revised_reconnect,
                   "raw_limit_fallback": at_limit and not raw, "revised_limit_fallback": at_limit and not revised,
                   "source_file": path}


def sensitivity(stages, output):
    lanes = list(sensitivity_folders(stages))
    summary = []
    tests, samples = 0, 0
    with (output / "m29_sensitivity.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=SENSITIVITY_FIELDS)
        writer.writeheader()
        for key, folders in lanes:
            stats = defaultdict(lambda: {"evaluated_samples": 0, "predicate_changes": 0, "action_changes": 0,
                                         "threshold_changes": 0, "limit_samples": 0, "near_q_zero": 0,
                                         "near_q0_zero": 0, "near_nominal_threshold": 0,
                                         "smallest_abs_q_minus_threshold": math.inf})
            for folder in folders:
                for row, at_limit, path in consumed_samples(folder, key):
                    samples += 1
                    for trial in perturbations(row, at_limit, path, key[2]):
                        tests += 1
                        writer.writerow(trial)
                        delta = trial["delta_q"] or trial["delta_q0"]
                        metrics = stats[trial["perturbed_input"], delta]
                        metrics["evaluated_samples"] += 1
                        metrics["predicate_changes"] += int(trial["changed"])
                        metrics["action_changes"] += int(trial["action_changed"])
                        metrics["threshold_changes"] += int(trial["revised_threshold_q"] != trial["threshold_q"])
                        metrics["limit_samples"] += int(at_limit)
                        metrics["near_q_zero"] += int(abs(trial["q"]) <= max(Q_DELTAS))
                        metrics["near_q0_zero"] += int(trial["q0"] is not None and abs(trial["q0"]) <= max(Q_DELTAS))
                        margin = abs(trial["q_minus_threshold"])
                        metrics["near_nominal_threshold"] += int(margin <= max(Q_DELTAS))
                        metrics["smallest_abs_q_minus_threshold"] = min(metrics["smallest_abs_q_minus_threshold"], margin)
            for (input_name, delta), metrics in stats.items():
                summary.append({**dict(zip(("group", "origin", "policy", "precision"), key, strict=True)),
                                "perturbed_input": input_name, "delta": delta, **metrics,
                                "predicate_changes_at_limit_only": metrics["predicate_changes"] - metrics["action_changes"]})
    write_csv(output / "m29_sensitivity_summary.csv", summary)
    print(f"Checked {samples} realized scalar observations and {tests} one-input perturbations in {len(lanes)} lanes", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stages", type=Path, default=ROOT / "stages")
    parser.add_argument("--output", type=Path, default=ROOT / "results")
    parser.add_argument("--only", choices=("whole", "sensitivity"))
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha256((ROOT / "PROTOCOL_M29.md").read_bytes()).hexdigest()
    insist((ROOT / "protocol.sha256").read_text().strip() == digest == (args.stages / "protocol.sha256").read_text().strip(),
           "Formal stage protocol differs from M29 registration")
    with TemporaryDirectory(prefix=".analysis-", dir=output) as work:
        temporary = Path(work)
        if args.only in (None, "whole"):
            whole(args.stages, temporary)
        if args.only in (None, "sensitivity"):
            sensitivity(args.stages, temporary)
        for file in temporary.iterdir():
            file.replace(output / file.name)


if __name__ == "__main__":
    main()
