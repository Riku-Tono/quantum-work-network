"""Verify S0 short runs before formal calculations."""

import argparse
import json
from pathlib import Path

from run_m29 import KERNEL_CONTROLS, ROOT, physics
import numpy as np


def verify(root):
    checks = []
    for mode in KERNEL_CONTROLS:
        for step in ("coarse", "half"):
            folders = [root / "stages" / f"t{cap}" / "F2-R" / "S0" / mode / step for cap in (100, 120)]
            tables = {}
            for stem in ("history", "selector", "observations", "decisions", "waits", "wait_checks"):
                tables[stem] = [row for folder in folders for row in physics.csv_rows(folder / f"m29_{stem}.csv")]
            for item in tables["selector"]:
                if item["elapsed_total"] != item["observed_until"]:
                    raise ValueError("Noncausal selector clock")
                if (mode in ("P3", "P4") and (item["c0_abs"] or item["amplitude"])) or (mode == "P4" and item["q0"]):
                    raise ValueError("Selector logged an extra input")
            max_residual = max(abs(float(row["accepted_energy_residual"])) for row in tables["history"])
            max_pair_error = max(float(row["candidate_step_error"]) for row in tables["history"])
            if max_residual > physics.FLOOR or max_pair_error > physics.HALF_TOL:
                raise ValueError("Work accounting or precision failed")
            with np.load(folders[-1] / "checkpoint.npz", allow_pickle=False) as finished:
                report = {"policy": mode, "precision": step, "attempts": len(tables["history"]),
                          "selector_samples": len(tables["selector"]), "connected_samples": len(tables["observations"]),
                          "cumulative_net": float(finished["work"][0]), "max_accounting_residual": max_residual,
                          "max_aligned_work_difference": max_pair_error}
                checks.append(report)
                if mode != "P3":
                    continue
                for version in ("uninterrupted", "reference"):
                    other = root / version / "t120" / "F2-R" / "S0" / mode / step
                    with np.load(other / "checkpoint.npz", allow_pickle=False) as direct:
                        if any(not np.array_equal(finished[key], direct[key]) for key in finished.files):
                            raise ValueError(f"Checkpoint differs in {version}/{step}")
                    for stem, actual in tables.items():
                        candidate = list(physics.csv_rows(other / f"m29_{stem}.csv"))
                        if version == "uninterrupted" and candidate != actual:
                            raise ValueError(f"Restart row mismatch in {stem}")
                        if version == "reference" and stem == "observations":
                            attributes = ("load_current", "load_ergotropy", "load_ergotropy_rate", "c_imag", "total_work")
                            report["reference_observation_max_error"] = max(abs(float(a[key]) - float(b[key]))
                                                                             for a, b in zip(actual, candidate, strict=True)
                                                                             for key in attributes)
                            if report["reference_observation_max_error"] > physics.FLOOR or any(
                                    a["elapsed_total"] != b["elapsed_total"] or a["forecast_generated"] != b["forecast_generated"]
                                    for a, b in zip(actual, candidate, strict=True)):
                                raise ValueError("Reference observation stream differs")
                    report[f"{version}_checkpoint_exact"] = True
    return {"status": "pass", "cutoffs": [100, 120], "branches": checks}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--benchmark", type=Path, default=ROOT / "benchmark")
    args = parser.parse_args()
    result = verify(args.benchmark)
    (args.benchmark / "audit_preflight.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result), flush=True)
