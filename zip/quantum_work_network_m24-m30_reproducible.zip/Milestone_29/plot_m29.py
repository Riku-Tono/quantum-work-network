"""Draw M29's nine formal figures from the cohort-preserving CSVs."""

import argparse
from collections import defaultdict
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import PercentFormatter

from collect_m29 import (
    AVERAGE_MIN, CANDIDATES, COHORTS, GATES, INFO, LEGACY, ORIGINS, PRECISIONS, ROOT, STATE_MIN,
    UNSEEN, UNSEEN_POLICIES, csv_rows, flag, lane,
)
from plot_m28 import INK, MUTED, empty, style_axis


EPSILON_Q = 1e-11
COLORS = {
    "RP": "#535E7C", "P1": "#2676A5", "P2": "#9B5C18", "P3": "#007966", "P4": "#A44165",
    "R0": "#847749", "R1": "#77622F", "R3": "#67438C", "RH": "#3A6B6D", "E": "#282B39",
    "F2-R": "#535E7C", "F1": "#3A6B6D", "M3": "#007966", "M4": "#A44165", "M-F3": "#67438C",
}
MARKERS = {"RP": "o", "P1": "s", "P2": "^", "P3": "D", "P4": "P", "R3": "X", "RH": "v"}
LINES = {"RP": "-", "P1": ":", "P2": "--", "P3": "-.", "P4": "-"}
COHORT_NAMES = {"F2-R": "F2-R first-switch anchors", "F1": "F1 first-switch anchors",
                "unseen": "Unseen states", "main": "Full control from origin"}
COHORT_COLORS = {"F2-R": "#22679B", "F1": "#9E552D", "unseen": "#007A68"}


def read(data, name, *, optional=False):
    path = data / f"m29_{name}.csv"
    return [] if optional and not path.is_file() else csv_rows(path)


def grouping(rows, key):
    groups = defaultdict(list)
    for row in rows:
        groups[key(row)].append(row)
    return groups


def num(row, *fields):
    for field in fields:
        value = row.get(field)
        if value not in (None, ""):
            try:
                return float(value)
            except ValueError:
                continue
    return math.nan


def heading(figure, title, caption):
    figure.suptitle(title + "\n" + caption, x=0.02, ha="left", fontsize=13.25,
                    fontweight="semibold", color=INK)


def save(figure, output, name):
    figure.savefig(output / f"m29_{name}.png", dpi=180, facecolor="white")
    plt.close(figure)


def legend(figure, handles):
    if handles:
        figure.legend(handles=handles, loc="outside lower center", frameon=False, ncols=min(8, len(handles)))


def method_handles(methods):
    return [Line2D([], [], label=method, color=COLORS[method], marker=MARKERS.get(method, "o"),
                   linestyle="none", markersize=5.5) for method in methods]


def precision_handles():
    return [
        Line2D([], [], label="Coarse", color=MUTED, marker="o", linestyle="none", markersize=5.5),
        Line2D([], [], label="Half", color=MUTED, marker="o", markerfacecolor="white", linestyle="none", markersize=5.5),
    ]


def cohort_origins(group):
    return UNSEEN if group == "unseen" else ORIGINS


def method_scatter(axis, x, y, method, step, *, size=39, outline=0.95, half_face="white"):
    color = COLORS[method]
    axis.scatter(x, y, marker=MARKERS.get(method, "o"), s=size, edgecolor=color,
                 facecolor=color if step == "coarse" else half_face, linewidth=outline, zorder=4)


def plot_stages(maintenance, original, output):
    fig, axis = plt.subplots(figsize=(10.7, 5.6), layout="constrained")
    heading(fig, "Recovery across the simplification stages",
            "Each cohort is shown separately. The lower label gives the number of coherence predicates.")
    style_axis(axis, ylabel="Mean work as a fraction of RP")
    axis.yaxis.set_major_formatter(PercentFormatter(1))
    axis.axhline(AVERAGE_MIN, color=MUTED, linewidth=0.85, linestyle=":")
    axis.set(xticks=range(len(GATES)), xticklabels=[f"{method}\n{INFO[method][0]} predicates" for method in GATES])
    ratio = {(row["group"], row["policy"], row["precision"]): num(row, "ratio_of_means") for row in maintenance}
    reference = {(row["group"], row["precision"]): num(row, "mean_work") for row in original if row["policy"] == "RP"}
    for group in COHORTS:
        color = COHORT_COLORS[group]
        for step in PRECISIONS:
            have_reference = reference.get((group, step), 0) > 1e-10
            work = [1.0 if have_reference else math.nan,
                    *(ratio.get((group, method, step), math.nan) for method in CANDIDATES)]
            axis.plot(range(len(GATES)), work, color=color, marker="o", markersize=5.6,
                      markerfacecolor=color if step == "coarse" else "white",
                      linestyle="-" if step == "coarse" else "--", linewidth=1.7 if step == "coarse" else 1.15,
                      alpha=0.88 if step == "coarse" else 0.6)
    legend(fig, [*[Line2D([], [], label=COHORT_NAMES[group], color=COHORT_COLORS[group], marker="o") for group in COHORTS],
                 *precision_handles(), Line2D([], [], label="95% cohort requirement", color=MUTED, linestyle=":")])
    save(fig, output, "01_simplification_and_recovery")


def steps(rows, end):
    ordered = sorted(rows, key=lambda row: int(row["attempt"]))
    start = num(ordered[0], "fork_elapsed", "elapsed_start")
    time = [0.0, *(num(row, "elapsed_total") - start for row in ordered)]
    work = [0.0, *(num(row, "cumulative_net") for row in ordered)]
    if end - start > time[-1]:
        time.append(end - start)
        work.append(work[-1])
    return time, work


def plot_cumulative(history, endpoints, output):
    fig, axes = plt.subplots(4, 2, figsize=(11.7, 10.3), layout="constrained", sharex=True)
    heading(fig, "Cumulative work after the existing first-switch anchors",
            "Each staircase starts at zero on the fork clock. Both independently evaluated steps are shown.")
    limits = {lane(row): num(row, "elapsed_total") for row in endpoints}
    histories = grouping([row for row in history if row["group"] in LEGACY and row["policy"] in GATES], lane)
    for i, origin in enumerate(ORIGINS):
        for j, group in enumerate(LEGACY):
            axis = axes[i, j]
            axis.set_title(f"{origin} · {group}", loc="left", color=INK, fontsize=10.2)
            style_axis(axis, xlabel="Elapsed since fork" if i == 3 else "",
                       ylabel="Additional net work" if j == 0 else "", scientific=True)
            for policy in GATES:
                for step in PRECISIONS:
                    key = group, origin, policy, step
                    data = histories.get(key)
                    if data:
                        clock, work = steps(data, limits[key])
                        axis.step(clock, work, where="post", color=COLORS[policy],
                                  linestyle=LINES[policy] if step == "coarse" else (0, (3, 2)),
                                  linewidth=1.55 if step == "coarse" else 0.9, alpha=1 if step == "coarse" else 0.55)
    legend(fig, [Line2D([], [], label=method, color=COLORS[method], linestyle=LINES[method]) for method in GATES])
    save(fig, output, "02_cumulative_work_from_legacy_anchors")


def illustrative_attempt(records, group, method, preferred):
    eligible = [row for row in records if (row["group"], row["policy"], row["precision"]) == (group, method, "coarse")]
    trials = grouping(eligible, lambda row: (row["origin"], int(row["attempt"])))
    ordered = sorted(trials.items(), key=lambda item: (item[0][0] != preferred, *item[0]))
    for minimum in (3, 1):
        for key, data in ordered:
            if len(data) >= minimum:
                return key, sorted(data, key=lambda row: num(row, "elapsed_total"))
    return None, []


def plot_q_path(selector, fallback, output):
    fig, axes = plt.subplots(3, 2, figsize=(11.7, 9.4), layout="constrained", sharex=True)
    heading(fig, "Imaginary-component decisions along the executed wait",
            "For each method, show the first wait with at least three polls in S0, U05 and U06 when available.")
    source = selector if any(row.get("q") not in (None, "") for row in selector) else fallback
    for i, (group, preferred) in enumerate((("F2-R", "S0"), ("unseen", "U05"), ("unseen", "U06"))):
        for j, method in enumerate(("P3", "P4")):
            axis = axes[i, j]
            style_axis(axis, xlabel="Elapsed since cut" if i == 2 else "", ylabel="q = −Im(c)" if j == 0 else "",
                       scientific=True)
            which, path = illustrative_attempt(source, group, method, preferred)
            if not path:
                axis.set_title(f"{group} · {preferred} · {method}", loc="left", color=INK, fontsize=10.4)
                empty(axis, "No selector trace available")
                continue
            origin, attempt = which
            outcome = "timer limit" if flag(path[-1].get("limit")) else "gate" if flag(path[-1].get("gate")) else "last poll"
            axis.set_title(f"{group} · {origin} · {method} · attempt {attempt} · {outcome}",
                           loc="left", color=INK, fontsize=10.4)
            phase = [num(row, "q", "observed_q") for row in path]
            time = [num(row, "wait_elapsed", "elapsed_wait", "poll_elapsed") for row in path]
            if not all(math.isfinite(t) for t in time):
                times = [num(row, "elapsed_total") for row in path]
                cut = num(path[0], "elapsed_start", "cut_elapsed")
                if not math.isfinite(cut):
                    cut = times[0] - 1.0
                time = [t - cut for t in times]
            threshold = num(path[0], "q_threshold", "threshold_q", "threshold")
            q0 = num(path[0], "q0", "precut_q")
            if not math.isfinite(threshold):
                threshold = max(0.25 * abs(q0), EPSILON_Q) if method == "P3" and math.isfinite(q0) else EPSILON_Q
            axis.plot(time, phase, marker=".", linewidth=1.6, markersize=5, color=COLORS[method])
            axis.axhline(threshold, color=MUTED, linestyle="--", linewidth=0.9)
            if method == "P3" and math.isfinite(q0):
                axis.scatter(0, q0, marker="s", s=36, facecolor="white", edgecolor=COLORS[method], zorder=5)
            axis.scatter(time[-1], phase[-1], marker="D", s=51, facecolor="white", edgecolor=COLORS[method], zorder=5)
            axis.set_xlim(-0.18, 6.16)
    legend(fig, [Line2D([], [], label="Actual poll", color=MUTED, marker="."),
                 Line2D([], [], label="P3 pre-cut reference", color=MUTED, marker="s", markerfacecolor="white", linestyle="none"),
                 Line2D([], [], label="Reconnection threshold", color=MUTED, linestyle="--"),
                 Line2D([], [], label="Final observed poll", color=MUTED, marker="D", markerfacecolor="white", linestyle="none")])
    save(fig, output, "03_imaginary_component_wait_decisions")


def plot_retention(comparisons, output):
    fig, axes = plt.subplots(1, 3, figsize=(13.1, 5.7), layout="constrained",
                             gridspec_kw={"width_ratios": [1, 1, 1.42]})
    heading(fig, "Work retained at each starting state",
            "Work is divided by RP at the same state and step. The dotted line marks the 90% state requirement.")
    for i, (axis, group) in enumerate(zip(axes, COHORTS, strict=True)):
        origins = cohort_origins(group)
        axis.set_title(COHORT_NAMES[group], loc="left", color=INK, fontsize=10.1)
        style_axis(axis, ylabel="Net work relative to RP" if i == 0 else "")
        axis.yaxis.set_major_formatter(PercentFormatter(1))
        axis.set(xticks=range(len(origins)), xticklabels=origins)
        axis.axhline(1, color="#B3C2CF", linewidth=0.7)
        axis.axhline(STATE_MIN, color=MUTED, linestyle=":", linewidth=0.9)
        rows = [r for r in comparisons if r["group"] == group and r["policy"] in CANDIDATES]
        if not rows:
            empty(axis, "No terminal paired data")
        if any(num(row, "ratio_to_rp") < 0 for row in rows):
            axis.axhline(0, color="#B3C2CF", linewidth=0.7)
        for row in rows:
            ratio = num(row, "ratio_to_rp")
            if not math.isfinite(ratio):
                continue
            method, step = row["policy"], row["precision"]
            x = origins.index(row["origin"]) + (CANDIDATES.index(method) - 1.5) * 0.16
            method_scatter(axis, x + (-0.035 if step == "coarse" else 0.035), ratio, method, step, size=34)
    legend(fig, [*method_handles(CANDIDATES), *precision_handles()])
    save(fig, output, "04_statewise_retention")


def plot_fixed(rows, output):
    points = ("RP", "P3", "P4", "RH")
    fig, axes = plt.subplots(2, 4, figsize=(15.2, 7.25), layout="constrained",
                             gridspec_kw={"width_ratios": [1, 1, 1.25, 1]})
    heading(fig, "Comparison with fixed waiting of three time units",
            "Positive values favor the indicated method. Main trajectories use M-F3 as the fixed-wait reference.")
    for j, group in enumerate((*COHORTS, "main")):
        origins = cohort_origins(group)
        methods = points if group != "main" else ("F2-R", "F1", "M3", "M4")
        for i, name in enumerate(("net_minus_fixed", "late_rate_minus_fixed")):
            axis = axes[i, j]
            if i == 0:
                axis.set_title(COHORT_NAMES[group], loc="left", color=INK, fontsize=10.1)
            style_axis(axis, ylabel=("Net work difference" if i == 0 else "Late rate difference") if j == 0 else "",
                       scientific=True)
            axis.set(xticks=range(len(origins)), xticklabels=origins if i == 1 else ())
            axis.axhline(0, color=MUTED, linewidth=0.8)
            if not any(row["group"] == group for row in rows):
                empty(axis, "No fixed-wait comparison")
            for row in rows:
                if row["group"] != group or row["policy"] not in methods:
                    continue
                step, method = row["precision"], row["policy"]
                x = origins.index(row["origin"]) + (methods.index(method) - 1.5) * 0.14
                method_scatter(axis, x + (-0.028 if step == "coarse" else 0.028), num(row, name), method, step, size=29)
    legend(fig, [*method_handles(points), *method_handles(("F2-R", "F1", "M3", "M4")), *precision_handles()])
    save(fig, output, "05_fixed_wait_three_comparison")


def plot_unseen(endpoints, output):
    fig, axes = plt.subplots(2, 3, figsize=(12.9, 7.15), layout="constrained", sharex=True)
    heading(fig, "Recovery from six unseen preparations",
            "Each panel compares controllers on one preparation for the same local time budget.")
    selected = [row for row in endpoints if row["group"] == "unseen" and flag(row["target_covered"])]
    by_origin = grouping(selected, lambda row: row["origin"])
    for i, (axis, origin) in enumerate(zip(axes.flat, UNSEEN, strict=True)):
        axis.set_title(origin, loc="left", color=INK, fontsize=10.5)
        style_axis(axis, ylabel="Cumulative net work" if i % 3 == 0 else "", scientific=True)
        axis.set(xticks=range(len(UNSEEN_POLICIES)), xticklabels=UNSEEN_POLICIES)
        if not by_origin[origin]:
            empty(axis, "No terminal unseen data")
        if any(num(row, "cumulative_net") < 0 for row in by_origin[origin]):
            axis.axhline(0, color="#B3C2CF", linewidth=0.7)
        for row in by_origin[origin]:
            method, step = row["policy"], row["precision"]
            x = UNSEEN_POLICIES.index(method) + (-0.105 if step == "coarse" else 0.105)
            method_scatter(axis, x, num(row, "cumulative_net"), method, step, size=40)
    legend(fig, precision_handles())
    save(fig, output, "06_unseen_state_work")


def plot_observation_work(endpoints, output):
    fig, axes = plt.subplots(1, 3, figsize=(13.1, 5.5), layout="constrained")
    heading(fig, "Coherence observations and recovered work",
            "One point per state and method. Larger symbols mark more primitive coherence components per wait decision.")
    for i, (axis, group) in enumerate(zip(axes, COHORTS, strict=True)):
        axis.set_title(COHORT_NAMES[group], loc="left", color=INK, fontsize=10.1)
        style_axis(axis, xlabel="Coherence observations used", ylabel="Cumulative net work" if i == 0 else "",
                   scientific=True)
        selected = [r for r in endpoints if r["group"] == group and r["policy"] in GATES and flag(r["target_covered"])]
        if not selected:
            empty(axis, "No observation comparisons")
        for row in selected:
            method, step = row["policy"], row["precision"]
            width = INFO[method][2]
            method_scatter(axis, num(row, "coherence_observations"), num(row, "cumulative_net"), method, step,
                           size=26 + 13 * width if step == "coarse" else 45 + 13 * width, outline=0.7, half_face="none")
    legend(fig, [*method_handles(GATES), *precision_handles()])
    save(fig, output, "07_observations_and_work")


def plot_pareto(rows, output):
    fig, axes = plt.subplots(1, 3, figsize=(13.3, 5.4), layout="constrained")
    heading(fig, "Coherence burden and mean work",
            "Rings mark nondominance across component values, predicate count and work. Symbol size marks predicate count.")
    for i, (axis, group) in enumerate(zip(axes, COHORTS, strict=True)):
        axis.set_title(COHORT_NAMES[group], loc="left", color=INK, fontsize=10.1)
        style_axis(axis, xlabel="Mean primitive coherence values used", ylabel="Mean work relative to RP" if i == 0 else "")
        axis.yaxis.set_major_formatter(PercentFormatter(1))
        axis.axhline(1, color="#B2C1CD", linewidth=0.75)
        selected = [r for r in rows if r["group"] == group and r["precision"] == "coarse"]
        if not selected:
            empty(axis, "No completed cohort")
        for row in selected:
            method = row["policy"]
            x, y = num(row, "mean_primitive_coherence_component_values"), num(row, "ratio_to_rp")
            if not math.isfinite(y):
                continue
            size = 35 + 10 * num(row, "wait_controller_predicates")
            method_scatter(axis, x, y, method, "coarse", size=size)
            if flag(row["pareto_nondominated"]):
                axis.scatter(x, y, marker="o", facecolor="none", edgecolor=INK, s=size + 50, linewidth=1.05, zorder=5)
        axis.margins(x=0.11)
    legend(fig, [*method_handles(("R0", "R1", "R3", "RH", *GATES)),
                 Line2D([], [], label="Nondominated", color=INK, marker="o", markerfacecolor="white", linestyle="none")])
    save(fig, output, "08_pareto_simplicity_and_recovery")


def plot_agreement(chronology, output):
    fig, axes = plt.subplots(2, 2, figsize=(12.5, 6.8), layout="constrained")
    heading(fig, "Independent coarse and half-step decisions",
            "Cell values show differing operations and differing selector polls. A dash marks unavailable selector comparisons.")
    indexed = {(r["group"], r["origin"], r["policy"]): r for r in chronology}
    for axis, group in zip(axes.flat, (*COHORTS, "main"), strict=True):
        names = ("F2-R", "F1", "M3", "M4", "M-F3") if group == "main" else (*GATES, "R3", "RH")
        origins = cohort_origins(group)
        axis.set_title(COHORT_NAMES[group], loc="left", color=INK, fontsize=10.25)
        axis.set(xlim=(-0.5, len(names) - 0.5), ylim=(len(origins) - 0.5, -0.5),
                 xticks=range(len(names)), xticklabels=names,
                 yticks=range(len(origins)), yticklabels=origins)
        axis.tick_params(length=0, labelsize=9, colors=MUTED)
        for spine in axis.spines.values():
            spine.set_visible(False)
        for y, origin in enumerate(origins):
            for x, method in enumerate(names):
                row = indexed.get((group, origin, method))
                ops = num(row, "operation_clock_mismatches") if row else math.nan
                gate = num(row, "selector_mismatches") if row else math.nan
                bad = ops > 0 or gate > 0
                shade = "#F1D1BD" if bad else "#DEEEE9" if row else "#ECF0F3"
                axis.add_patch(plt.Rectangle((x - 0.46, y - 0.43), 0.92, 0.86, color=shade, linewidth=0))
                value = " / ".join(str(int(n)) if math.isfinite(n) else "—" for n in (ops, gate))
                axis.text(x, y, value, ha="center", va="center", fontsize=8.8, color=INK if row else MUTED)
    save(fig, output, "09_coarse_half_agreement")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=ROOT / "results")
    parser.add_argument("--output", type=Path, default=ROOT / "figures")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "text.color": INK, "legend.labelcolor": INK})
    data, output = args.data, args.output
    endpoint = read(data, "endpoints")
    pareto = read(data, "pareto")
    plot_stages(read(data, "maintenance"), pareto, output)
    plot_cumulative(read(data, "history"), endpoint, output)
    plot_q_path(read(data, "selector", optional=True), read(data, "wait_checks", optional=True), output)
    plot_retention(read(data, "condition_comparison"), output)
    plot_fixed(read(data, "fixed_comparison"), output)
    plot_unseen(endpoint, output)
    plot_observation_work(endpoint, output)
    plot_pareto(pareto, output)
    plot_agreement(read(data, "chronology"), output)


if __name__ == "__main__":
    main()
