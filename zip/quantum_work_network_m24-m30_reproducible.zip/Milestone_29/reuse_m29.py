"""Certify equal first selections on each native recorded trajectory, then rebase its logs."""

import csv
import hashlib
import json
import os
from pathlib import Path
from tempfile import TemporaryDirectory

from run_m29 import (GRID, KERNEL_CONTROLS, M28, ROOT, eligible_sample, extended_counts, get_seed,
                     physics, selector_rows, stage)
import numpy as np


MODES = {
    "P1": ("RP",),
    "P2": ("Xamp", "P1", "RP"),
    "P3": ("P2", "Xamp", "P1", "RP"),
    "P4": ("P3", "P2", "P1", "RP"),
}


def inventory(job, root, cutoffs):
    active = job.relative_path()
    if job.group == "F1":
        other = Path("F2-R", job.origin, job.policy, job.precision)
        yield [root / f"t{t // 1000}" / other for t in cutoffs], "m29"
    for policy in MODES[job.policy]:
        other = active.parent.parent / policy / job.precision
        if policy in KERNEL_CONTROLS or (job.group == "unseen" and policy == "RP"):
            yield [root / f"t{t // 1000}" / other for t in cutoffs], "m29"
        if job.group != "unseen" and policy in ("RP", "Xamp"):
            yield [M28 / "stages" / f"t{t // 1000}" / other for t in cutoffs], "m28"


def read_checks(folder, prefix):
    path = folder / f"{prefix}_wait_checks.csv"
    checks = {}
    if path.is_file():
        for row in physics.csv_rows(path):
            values = {key: float(row[key]) for key in ("elapsed_total", "observed_until", "wait_elapsed", "actual_current",
                                                       "c_real", "c_imag", "c_abs", "phase", "load_current")}
            checks.setdefault(int(row["attempt"]), []).append(values)
    return checks


def same_stage(job, cap, source, prefix, hashes, fork, records):
    """A later recorded measurement certifies only a choice at its own clock."""
    with np.load(source / "checkpoint.npz", allow_pickle=False) as checkpoint:
        if (int(checkpoint["fork_tick"]) != fork or int(checkpoint["tick"]) != cap
                or tuple(str(checkpoint[f"fork_{key}_sha256"].item()) for key in ("coarse", "half")) != hashes
                or json.loads(str(checkpoint["records"].item()))[:len(records)] != records):
            return None
    path = source / f"{prefix}_history.csv"
    result = {}
    if not path.is_file():
        return result
    physical = read_checks(source, prefix)
    for row in physics.csv_rows(path):
        index = int(row["attempt"])
        checks = physical.get(index, [])
        tau = physics.tick(row, "tau")
        maximum = min(6000, physics.tick(row, "window") - GRID) // 200 * 200
        wait_points = [physics.tick(item, "wait_elapsed") for item in checks]
        if maximum < 1000:
            if tau or checks:
                return None
        elif tau < 1000 or wait_points != list(range(1000, tau + 1, 200)):
            return None
        initial = {"c_abs": row["c_abs_before"], "c_imag": -float(row["current_before"]) / (2 * physics.G)}
        for point, check in zip(wait_points, checks, strict=True):
            hit, _ = eligible_sample(job.policy, initial, check)
            check.update(phase_gate=hit, reconnect=hit or point == maximum)
            if check["reconnect"] != (point == tau):
                return None
        if tau:
            row["wait_reason"] = "phase_gate" if checks[-1]["phase_gate"] else "phase_limit"
        for key in ("tau", "elapsed_start", "elapsed_total"):
            row[key] = float(row[key])
        extended_counts(job.policy, row, checks)
        result[index] = row, checks
    return result


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def materialize(job, target, source, prefix, choices, hashes, fork):
    target.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix=".certificate-", dir=target.parent) as temporary:
        dest = Path(temporary) / "complete"
        dest.mkdir()
        with (source / "checkpoint.npz").open("rb") as original, (dest / "checkpoint.npz").open("wb") as output:
            from shutil import copyfileobj
            copyfileobj(original, output)
        tables = physics.Tables(dest)
        try:
            for stem in ("history", "decisions", "waits", "observations", "checkpoints"):
                old = source / f"{prefix}_{stem}.csv"
                if not old.is_file():
                    continue
                for row in physics.csv_rows(old):
                    row.update(group=job.group, policy=job.policy)
                    if stem == "history":
                        revised, checks = choices[int(row["attempt"])]
                        row.update(revised, group=job.group, policy=job.policy, record_source="m29")
                        meta = {key: row[key] for key in ("group", "origin", "policy", "precision", "fork_elapsed", "attempt")}
                        for check in checks:
                            tables.add("m29_wait_checks", {**meta, **check})
                        for check in selector_rows(job.policy, row, checks):
                            tables.add("m29_selector", {**meta, **check})
                    elif stem == "waits":
                        row["wait_reason"] = choices[int(row["attempt"])][0]["wait_reason"]
                    elif stem == "decisions":
                        row["reason"] = job.policy
                    tables.add(f"m29_{stem}", row)
        finally:
            tables.close()
        proof = {"source": os.path.relpath(source, ROOT), "source_prefix": prefix, "fork_tick": fork,
                 "fork_hashes": hashes, "same_first_choice_attempts": len(choices),
                 "scalar_samples": sum(len(checked) for _, checked in choices.values()),
                 "source_checkpoint_sha256": digest(source / "checkpoint.npz"),
                 "source_history_sha256": digest(source / f"{prefix}_history.csv")}
        (dest / "equivalent_policy.json").write_text(json.dumps(proof, indent=2) + "\n", encoding="utf-8")
        stage.publish_stage(dest, target)


def reuse_or_none(job, root, cutoffs):
    _, (pair, fork, records) = get_seed(job)
    cutoffs = tuple(cap for cap in cutoffs if cap > fork)
    targets = [root / f"t{cap // 1000}" / job.relative_path() for cap in cutoffs]
    if any(path.exists() for path in targets):
        return False
    hashes = tuple(physics.fingerprint(state) for state in pair)
    for sources, prefix in inventory(job, root, cutoffs):
        if not all((path / "checkpoint.npz").is_file() for path in sources):
            continue
        selections = [same_stage(job, cap, source, prefix, hashes, fork, records)
                      for cap, source in zip(cutoffs, sources, strict=True)]
        if any(value is None for value in selections):
            continue
        for target, source, choices in zip(targets, sources, selections, strict=True):
            materialize(job, target, source, prefix, choices, hashes, fork)
        print(f"Same native trajectory {job.group}/{job.origin}/{job.policy}/{job.precision}: {sources[-1]}", flush=True)
        return True
    return False
