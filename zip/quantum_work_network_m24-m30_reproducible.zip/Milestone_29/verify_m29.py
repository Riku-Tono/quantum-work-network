"""Independently verify M29's reconnect predicates, physics and state provenance."""

import argparse
import ast
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor, as_completed
import csv
from dataclasses import dataclass
from functools import lru_cache
import importlib.util
import inspect
from itertools import product
import json
import math
from pathlib import Path
import sys
from unittest.mock import patch


ROOT = Path(__file__).resolve().parent
M28 = ROOT.parent / "Milestone_28"
M27 = ROOT.parent / "Milestone_27"
sys.path.insert(0, str(M28))

import verify_m28 as a28
from verify_m28 import audit27 as a27


READ_CSV = a27.read_rows
TICKS = a27.ticks
NUMBER = a27.number
FLAG = a27.flag
G = a27.G
RESOLUTIONS = a27.RESOLUTIONS
ORIGINS = tuple(sorted(a27.ORIGINS))
MIN_WAIT = 1_000
MAX_WAIT = 6_000
WAIT_STEP = 200
CONNECTED_STEP = a27.GRID
RP_AND_P = ("RP", "P1", "P2", "P3", "P4")
EPSILON_Q = 1e-11
Q_PERTURBATIONS = (-1e-11, -1e-12, 1e-12, 1e-11)


@dataclass(frozen=True)
class PreviousObservation:
    q: float
    magnitude: float
    real: float


@dataclass(frozen=True)
class ReconnectObservation:
    q: float
    magnitude: float
    real: float
    phase: float


def registered_predicate(rule, initial, measured, epsilon_q):
    """Reconstruct the intended rule without importing any controller code."""
    q = measured.q
    a27.insist(rule in RP_AND_P, f"Unknown reconnect rule {rule}")
    if rule == "P4":
        return q > epsilon_q
    if rule == "P3":
        return q >= max(abs(initial.q) / 4, epsilon_q)
    if q < initial.magnitude / 4:
        return False
    if rule == "P2":
        return True
    if measured.magnitude < 1e-5:
        return False
    if rule == "P1":
        return True
    return -3 * math.pi / 4 <= measured.phase <= -math.pi / 4 and measured.real <= initial.real + 1e-10


def relative_wait_clocks(window):
    """Physical monitoring can end early only to leave one connected grid sample."""
    limit = min(MAX_WAIT, window - CONNECTED_STEP) // WAIT_STEP * WAIT_STEP
    return range(MIN_WAIT, limit + 1, WAIT_STEP)


def baseline_q_resolution():
    """Derive a measured discretization bound from already audited M28 RP traces."""
    audit_path = M28 / "results" / "audit_matched.json"
    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    a27.insist(audit["protocol_sha256"] == a27.sha256(M28 / "PROTOCOL_M28.md"), "Prior audit and M28 protocol disagree")
    a27.insist(audit["boundaries"] == [150, 300, 540], "Prior audit does not cover the required clocks")
    maximum, witness, total = 0.0, None, 0
    for group in ("F2-R", "F1"):
        for origin in ORIGINS:
            for cut in audit["boundaries"]:
                observations = []
                for precision in RESOLUTIONS:
                    branch = f"{group}/{origin}/RP/{precision}"
                    a27.insist(branch in audit["matched"]["branch_results"], f"Missing prior audit evidence for {branch}")
                    path = M28 / "stages" / f"t{cut}" / group / origin / "RP" / precision / "m28_wait_checks.csv"
                    observations.append(a27.read_unique(READ_CSV(path), lambda row: (int(row["attempt"]), TICKS(row, "elapsed_total"))))
                coarse, half = observations
                a27.insist(coarse.keys() == half.keys(), f"RP audit states differ in physical clock at {group}/{origin}/{cut}")
                total += len(coarse)
                for key in coarse:
                    diff = abs(NUMBER(coarse[key], "c_imag") - NUMBER(half[key], "c_imag"))
                    if diff > maximum:
                        attempt, clock = key
                        maximum = diff
                        witness = {"group": group, "origin": origin, "boundary": cut, "attempt": attempt, "elapsed_total": clock / 1000}
    return {"matched_samples": total, "absolute_coarse_half_error": maximum, "witness": witness,
            "source_audit_sha256": a27.sha256(audit_path), "source_protocol_sha256": audit["protocol_sha256"]}


def stage_table(path):
    return READ_CSV(path) if path.is_file() else []


def audit_controller_interface(path):
    """Confirm the production pure predicates receive only the advertised scalars."""
    source = ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
    definitions = {node.name: node for node in source.body if isinstance(node, ast.FunctionDef)}
    signatures = {"p1": ("amplitude", "q", "c0_abs"), "p2": ("q", "c0_abs"), "p3": ("q", "q0"), "p4": ("q",)}
    allowed_builtins = {"abs", "max", "float", "bool"}
    module_spec = importlib.util.spec_from_file_location("audited_m29_predicates", path)
    callable_module = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(callable_module)
    report = {}
    levels = (-1e-3, -EPSILON_Q, -1e-16, 0.0, 1e-16, EPSILON_Q, math.nextafter(EPSILON_Q, math.inf), 4e-5, 1e-3)
    for name, names in signatures.items():
        fn = getattr(callable_module, name)
        signature = inspect.signature(fn)
        a27.insist(tuple(signature.parameters) == names and all(param.default is inspect.Parameter.empty and param.kind in
                   (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD) for param in signature.parameters.values()),
                   f"{name} receives additional, defaulted, or unstructured inputs")
        tree = definitions[name]
        code = [node for item in tree.body for node in ast.walk(item)]
        forbidden = (ast.Attribute, ast.Subscript, ast.Global, ast.Nonlocal, ast.Import, ast.ImportFrom, ast.Lambda)
        a27.insist(not any(isinstance(node, forbidden) for node in code), f"{name} can access a structured or hidden observation")
        env = inspect.getclosurevars(fn)
        a27.insist(not env.nonlocals and not env.unbound and set(env.builtins) <= allowed_builtins and all(
                   type(value) in (int, float) and math.isfinite(value) for value in env.globals.values()), f"{name} can refer to hidden controller state")
        a27.insist(not any(isinstance(node, ast.Call) and (not isinstance(node.func, ast.Name) or node.func.id not in allowed_builtins)
                           for node in code), f"{name} invokes a function outside its scalar predicate")
        checks = 0
        grid = [levels if arg == "q" or arg == "q0" else (0.0, 1e-6, 1e-5, 4e-5, 1e-3) for arg in names]
        for values in product(*grid):
            sample = dict(zip(names, values, strict=True))
            before = PreviousObservation(sample.get("q0", 0.0), sample.get("c0_abs", 0.0), 0.0)
            now = ReconnectObservation(sample["q"], sample.get("amplitude", 0.0), 0.0, 0.0)
            expected = registered_predicate(name.upper(), before, now, EPSILON_Q)
            a27.insist(type(fn(*values)) is bool and fn(*values) == expected, f"Scalar boundary truth table differs for {name}{values}")
            checks += 1
        report[name.upper()] = {"input_names": names, "finite_constant_dependencies": dict(env.globals), "truth_table_checks": checks}
    return report


def audit_acquisition_adapter():
    """Instrument the production data adapter with unavailable undeclared inputs."""
    import run_m29 as driver

    class Restricted(dict):
        def __getitem__(self, key):
            a27.insist(key in self, f"Attempted to acquire unregistered observable {key}")
            return super().__getitem__(key)

        def get(self, key, default=None):
            return self[key]

    input_schema = {"P1": ({"c_abs": 8e-11}, "c_abs", {"q", "c0_abs", "amplitude", "threshold_q"}),
                    "P2": ({"c_abs": 8e-11}, None, {"q", "c0_abs", "threshold_q"}),
                    "P3": ({"c_imag": 0.0}, None, {"q", "q0", "threshold_q"}),
                    "P4": ({}, None, {"q", "threshold_q"})}
    outcome = {}
    matrix = object()
    model = object()
    forbidden_history = Restricted()
    for policy, (before, amplitude, allowed) in input_schema.items():
        initial = Restricted(before)
        permitted = [Restricted({"c_imag": 0.0}), Restricted({"c_imag": -1e-10})]
        if amplitude:
            for item in permitted:
                item[amplitude] = 2e-5
        false, sample0 = driver.eligible_sample(policy, initial, permitted[0])
        true, sample1 = driver.eligible_sample(policy, initial, permitted[1])
        a27.insist(not false and true and set(sample0) == set(sample1) == allowed, f"Scalar acquisition changed {policy}")
        visits = []
        cap = 0

        def prepare_observer(actual_model, actual_matrix, _dt):
            a27.insist(actual_model is model and actual_matrix is matrix, "Wait stage altered the physical observer's identity")

            def observe(tick):
                a27.insist(tick <= cap and not (visits and visits[-1] == 1200), f"Control read a forbidden suffix at {policy}/{tick}")
                visits.append(tick)
                return permitted[(tick - 1000) // 200]

            return observe

        checks = []
        with patch.object(driver.physics, "phase_observer", prepare_observer):
            for cap in (1199, 1200):
                visits.clear()
                done, reason, detached = driver.wait_until(model, (matrix,), 0, 0, 18_000, policy, "wait", forbidden_history, cap, None, initial)
                expected = [1000, 1200] if cap == 1200 else [1000]
                a27.insist(visits == expected and len(detached) == len(expected)
                           and done == (1200 if cap == 1200 else None)
                           and reason == ("phase_gate" if cap == 1200 else "phase_limit"), f"Time-gated acquisition differs for {policy}")
                checks.append({"cutoff": cap / 1000, "physical_samples_consumed": len(visits)})
        outcome[policy] = {"initial_fields_allowed": sorted(initial), "measurement_fields_allowed": sorted(permitted[0]),
                           "exercises": checks}
    return outcome


def q_perturbations(rule, before, current, outcome, *, nominal_clocks):
    """Classify local predicate and action sensitivity without running an alternate future."""
    if rule not in ("P3", "P4"):
        return []
    result = []
    fields = ("q", "q0") if rule == "P3" else ("q",)
    for field in fields:
        for delta in Q_PERTURBATIONS:
            if field == "q":
                initial = before
                sample = ReconnectObservation(current.q + delta, current.magnitude, current.real, current.phase)
            else:
                initial = PreviousObservation(before.q + delta, before.magnitude, before.real)
                sample = current
            changed = registered_predicate(rule, initial, sample, EPSILON_Q)
            now, last = nominal_clocks
            result.append({"input": field, "delta": delta, "nominal": outcome, "perturbed": changed,
                           "predicate_changed": changed != outcome, "immediate_action_changed": now < last and changed != outcome})
    return result


def exact_preparations(model, recipes, seed):
    """Replay registered preparation operations using exact Hamiltonian evolution."""
    cache = {}
    for name, preparation in recipes["preparations"].items():
        state, coupling = seed, G
        work, clock, operations = 0.0, 0, []
        for operation, duration in preparation["operations"]:
            start_clock, start_coupling, start_state = clock, coupling, state
            before = model.energy(state, coupling)
            if operation == "propagate":
                a27.insist(duration > 0, f"Nonpositive registered propagation in {name}")
                state = model.evolve(state, coupling, duration / 1000)
                clock += duration
            elif operation in ("cut", "reconnect"):
                initial, activated = (G, 0.0) if operation == "cut" else (0.0, G)
                a27.insist(coupling == initial and duration == 0, f"Invalid coupling change in {name}")
                coupling = activated
            else:
                a27.insist(operation == "passivate_load" and coupling == G and duration == 0, f"Unregistered physical operation in {name}")
                state = a27.exact_action(model, state, 0, 0, True).after
            after = model.energy(state, coupling)
            work += before - after
            operations.append({"operation": operation, "prep_elapsed_start": start_clock / 1000, "prep_elapsed_end": clock / 1000,
                               "coupling_start": start_coupling, "coupling_end": coupling,
                               "energy_before": before, "energy_after": after, "c_imag_before": float(model.detached_c(start_state, 0).imag),
                               "c_imag_after": float(model.detached_c(state, 0).imag)})
        a27.insist(coupling == G, f"Unseen preparation {name} ends detached")
        a27.tolerance(model.energy(seed) - model.energy(state), work, f"Preparation closure of {name}")
        cache[name] = state, clock, operations
    return cache


def exact_q_path(model, state, clocks):
    """Project exact exchange coherence without copying the RK4 preparation projector."""
    terms, differences = [], []
    for basis, (energies, vectors) in zip(model.sectors, model.sector_spectra[G], strict=True):
        index = a27.np.ix_(basis, basis)
        represented = vectors.T @ state.matrix[index] @ vectors
        observable = vectors.T @ model.coherence[index] @ vectors
        terms.extend((represented * observable.T).ravel())
        differences.extend((energies[:, None] - energies[None, :]).ravel())
    frequencies = -1j * a27.np.asarray(differences)
    coefficients = a27.np.asarray(terms)
    result = []
    for offset in range(0, len(clocks), 48):
        duration = a27.np.asarray(clocks[offset:offset + 48]) / 1000
        values = a27.np.exp(duration[:, None] * frequencies[None, :]) @ coefficients
        result.extend(float(-number.imag) for number in values)
    return result


def registered_signed_tick(model, state, recipes, preparation, sign):
    start, end = preparation["scan_ticks"]
    clocks = range(start, end + 1, recipes["scan_step_ticks"])
    q_list = exact_q_path(model, state, clocks)
    index = next((i for i, q in enumerate(q_list) if sign * q >= recipes["signed_q_threshold"]), None)
    if index is None:
        index = max(range(len(q_list)), key=lambda i: sign * q_list[i])
        selection = "maximum_signed_q_with_earliest_tie"
    else:
        selection = "first_signed_threshold"
    return clocks[index], q_list[index], selection


def load_phase_rotation(matrix, angle):
    unitaries = a27.np.exp(-1j * angle * a27.LOAD_LEVELS)
    phases = a27.np.tile(unitaries, len(matrix) // len(unitaries))
    return (phases[:, None] * matrix) * phases[None, :].conj()


def construct_product(case):
    """Use positive single-site factors and the registered real load rotation."""
    density = a27.np.ones((1, 1), dtype=a27.np.complex128)
    for p in case["chain_excited_probabilities"]:
        alpha = case["chain_offdiagonal_fraction"] * math.sqrt(p * (1 - p))
        density = a27.np.kron(density, ((1 - p, alpha), (alpha, p)))
    U = a27.np.eye(len(case["load_eigenvalues"]))
    i, j = case["load_rotated_levels"]
    angle = case["load_real_rotation_angle_rad"]
    U[i, i], U[j, j] = math.cos(angle), math.cos(angle)
    U[j, i], U[i, j] = math.sin(angle), -math.sin(angle)
    load = (U * a27.np.asarray(case["load_eigenvalues"])) @ U.T
    return a27.np.kron(density, load)


def append_generation(model, steps, name, start_clock, state, stop_clock, prepared):
    before, after = model.energy(state), model.energy(prepared)
    steps.append({"operation": name, "prep_elapsed_start": start_clock / 1000, "prep_elapsed_end": stop_clock / 1000,
                  "coupling_start": G, "coupling_end": G, "energy_before": before, "energy_after": after,
                  "c_imag_before": model.detached_c(state, 0).imag, "c_imag_after": model.detached_c(prepared, 0).imag})


def generation_seed(model, recipes, base, specification, meta, coarse_phase):
    kind = specification["type"]
    if kind == "real_coherent_product":
        state = a27.State(construct_product(specification), 0.0)
        steps = [{"operation": kind, "prep_elapsed_start": 0.0, "prep_elapsed_end": 0.0, "coupling_end": G,
                  "energy_after": model.energy(state), "c_imag_after": 0.0}]
        return state, steps
    anchor, clock, initial = base[specification["preparation"]]
    steps = list(initial)
    if kind == "local_load_number_phase":
        angle = NUMBER(meta, "phase_rad")
        a27.tolerance(math.remainder(angle + coarse_phase, math.tau), 0, "Independently calculated U05 phase pulse", 1e-8)
        state = a27.State(load_phase_rotation(anchor.matrix, -angle), anchor.time)
        append_generation(model, steps, "load_number_phase", clock, anchor, clock, state)
    else:
        count = int(meta["prep_scan_tick"])
        state = model.evolve(anchor, G, count / 1000)
        append_generation(model, steps, "propagate", clock, anchor, clock + count, state)
    return state, steps


def check_preparation_ledger(archived, independent, base_hash, final_hash, context):
    a27.insist(len(archived) == len(independent), f"Preparation operation count at {context}")
    work = 0.0
    previous = base_hash
    for ordinal, (row, expected) in enumerate(zip(archived, independent, strict=True), 1):
        a27.insist(row["operation"] == expected["operation"] and int(row["operation_index"]) == ordinal
                   and row["input_rho_sha256"] == previous, f"Preparation chronology/fingerprint breaks at {context}/{ordinal}")
        for field in set(expected) - {"operation"}:
            limit = a27.HALF_TOL if field.startswith("c_imag_") else a27.EXACT_WORK_TOL
            a27.tolerance(row[field], expected[field], f"Independent preparation {field} at {context}/{ordinal}", limit)
        previous = row["output_rho_sha256"]
        if row["signed_external_work_on_system"]:
            propagated = expected["operation"] == "propagate"
            delta = NUMBER(row, "energy_after") - NUMBER(row, "energy_before")
            signed = NUMBER(row, "signed_external_work_on_system")
            drift = NUMBER(row, "propagation_energy_drift")
            a27.tolerance(signed, 0 if propagated else delta, f"Preparation work sign at {context}/{ordinal}", 1e-12)
            a27.tolerance(drift, delta if propagated else 0, f"Preparation drift at {context}/{ordinal}", 1e-12)
            work += signed
    a27.insist(previous == final_hash, f"Preparation output fingerprint at {context}")
    return work


def check_unseen_distances(unseen_dir, pairs, archived_sources):
    references = {}
    for origin, source in archived_sources.items():
        for precision in RESOLUTIONS:
            references["M26_sources", origin, precision] = a27.load_source(source, precision).matrix
    old_anchor_root = M28 / "anchors"
    for row in READ_CSV(old_anchor_root / "m28_anchors.csv"):
        precision = row["precision"]
        with a27.np.load(old_anchor_root / row["anchor_file"], allow_pickle=False) as archive:
            density = archive[precision]
            a27.insist(a27.state_sha256(density) == row[f"{precision}_sha256"], "M28 reference anchor matrix changed")
            references[row["group"], row["origin"], precision] = density
    for origin, pair in pairs.items():
        references.update({("unseen", origin, precision): rho for precision, rho in pair.items()})
    checked = {}
    for row in READ_CSV(unseen_dir / "trace_distances.csv"):
        origin, precision = row["origin"], row["precision"]
        right = references[row["reference_group"], row["reference_origin"], row["reference_precision"]]
        left = pairs[origin][precision]
        a27.insist(row["reference_rho_sha256"] == a27.state_sha256(right), "Trace distance was recorded against a changed density")
        complete = a27.trace_distance(left, right)
        load = a27.trace_distance(a27.reduced_load(a27.terminal_state(left)), a27.reduced_load(a27.terminal_state(right)))
        a27.tolerance(row["global_trace_distance"], complete, "Unseen full trace distance", 1e-12)
        a27.tolerance(row["load_trace_distance"], load, "Unseen reduced trace distance", 1e-12)
        a27.insist(load <= complete + 1e-12, "Partial trace increased the unseen state distance")
        key = origin, precision, row["reference_group"], row["reference_origin"], row["reference_precision"]
        a27.insist(key not in checked, f"Duplicate unseen distance {key}")
        checked[key] = complete
    expected = len(pairs) * sum(group != "unseen" for group, _, _ in references) + len(pairs) * (len(pairs) - 1)
    a27.insist(len(checked) == expected, f"Unseen distance coverage only {len(checked)} of {expected}")
    return {"checked_distances": len(checked), "minimum_to_existing": min(distance for key, distance in checked.items() if key[2] != "unseen")}


def audit_unseen(unseen_dir, anchor_root, protocol):
    recipes_file = ROOT / "UNSEEN_RECIPES_M29.json"
    recipes_hash, protocol_hash = a27.sha256(recipes_file), a27.sha256(protocol)
    manifest = json.loads((unseen_dir / "manifest.json").read_text(encoding="utf-8"))
    a27.insist(manifest["protocol_sha256"] == protocol_hash and manifest["recipe_sha256"] == recipes_hash
               and recipes_hash in protocol.read_text(encoding="utf-8") and manifest["generator_sha256"] == a27.sha256(ROOT / "prepare_unseen_m29.py"),
               "Unseen generation is unpinned or differs from its frozen recipe")
    archived, _ = a28.archived_origins()
    recipes = json.loads(recipes_file.read_text(encoding="utf-8"))
    seed_source = archived[recipes["seed_from_m26_sources"]]
    a27.insist(manifest["seed_recipe"] == seed_source
               and manifest["m26_source_table_sha256"] == a27.sha256(a27.M26 / "results" / "m26_sources.csv")
               and manifest["m28_anchor_registry_sha256"] == a27.sha256(M28 / "anchors" / "m28_anchors.csv"),
               "Unseen preparation source artifacts changed")
    model = a27.ReplayModel()
    seeds = {label: a27.load_source(seed_source, label) for label in RESOLUTIONS}
    preps = {label: exact_preparations(model, recipes, seed) for label, seed in seeds.items()}
    physical = a27.read_unique(READ_CSV(unseen_dir / "physical_metrics.csv"), lambda row: (row["origin"], row["precision"]))
    inputs = a27.read_unique(READ_CSV(unseen_dir / "sources.csv"), lambda row: row["origin"])
    registry = a27.read_unique(READ_CSV(anchor_root / "m29_unseen_anchors.csv"), lambda row: (row["origin"], row["precision"]))
    observed = defaultdict(list)
    for row in READ_CSV(unseen_dir / "generation_steps.csv"):
        observed[row["origin"], row["precision"]].append(row)
    a27.insist(inputs.keys() == recipes["cases"].keys(), "Unseen generation omits or invents a frozen state")
    a27.insist(physical.keys() == registry.keys() == observed.keys() == {(case, label) for case in inputs for label in RESOLUTIONS},
               "Unseen generation omits a native input or physicality witness")
    result, pairs = {}, {}
    for origin, spec in recipes["cases"].items():
        meta = inputs[origin]
        path = unseen_dir / meta["archive_file"]
        digest = a27.sha256(path)
        a27.insist(digest == meta["archive_sha256"] == manifest["input_archives"][origin]
                   and meta["protocol_sha256"] == protocol_hash and meta["recipe_sha256"] == recipes_hash,
                   f"Unseen archive provenance differs for {origin}")
        family = spec.get("preparation")
        q_selection = {}
        coarse_phase = 0.0
        if spec["type"] == "signed_reachable":
            base = preps["coarse"][family][0]
            prep = recipes["preparations"][family]
            clock, q, selection = registered_signed_tick(model, base, recipes, prep, spec["q_sign"])
            first, last = prep["scan_ticks"]
            threshold_met = selection == "first_signed_threshold"
            count = ((clock if threshold_met else last) - first) // recipes["scan_step_ticks"] + 1
            a27.insist(int(meta["prep_scan_tick"]) == clock and int(meta["prep_observations_used"]) == count
                       and FLAG(meta, "signed_threshold_met") == threshold_met and int(meta["target_q_sign"]) == spec["q_sign"],
                       f"Prep-only first signed q differs for {origin}")
            q_selection = {"selection": selection, "clock": clock / 1000, "independent_q": q, "scanned_points": count}
        elif spec["type"] == "local_load_number_phase":
            before = model.detached_c(preps["coarse"][family][0], 0)
            coarse_phase = math.atan2(before.imag, before.real) if abs(before) > spec["phase_magnitude_floor"] else 0.0
        pairs[origin], case_result = {}, {}
        with a27.np.load(path, allow_pickle=False) as saved:
            a27.insist(int(saved["tick"].item()) == 0 and json.loads(str(saved["records"].item())) == [], "Unseen controls inherited preparation work")
            expected_time = NUMBER(meta, "source_time")
            a27.insist(float(saved["source_time"].item()) == expected_time, f"Unseen state clock mismatch {origin}")
            for precision in RESOLUTIONS:
                density = saved[precision]
                data = registry[origin, precision]
                physical_row = physical[origin, precision]
                fingerprint = a27.state_sha256(density)
                a27.insist(a27.sha256(anchor_root / data["anchor_file"]) == digest == data["archive_sha256"]
                           and fingerprint == meta[f"{precision}_sha256"] == data[f"{precision}_sha256"] == physical_row["rho_sha256"],
                           f"Unseen archive and branch input differ at {origin}/{precision}")
                a27.insist(TICKS(data, "fork_elapsed") == 0 and int(data["prefix_attempts"]) == int(data["prefix_waits"]) == 0
                           and NUMBER(data, "source_time") == expected_time, f"Unseen test clock or carried work at {origin}/{precision}")
                pairs[origin][precision] = density
                state = a27.State(density, expected_time)
                a27.physical_state(state, (origin, precision))
                exact, steps = generation_seed(model, recipes, preps[precision], spec, meta, coarse_phase)
                difference = a27.maxabs(exact.matrix - density)
                a27.tolerance(exact.time, expected_time, f"Unseen generation clock at {origin}/{precision}")
                a27.tolerance(difference, 0.0, f"Independent unseen preparation at {origin}/{precision}", a27.HALF_TOL)
                q = -model.detached_c(state, 0).imag
                a27.tolerance(physical_row["q"], q, f"Unseen exact initial q at {origin}/{precision}")
                a27.tolerance(physical_row["global_energy"], model.energy(state), f"Unseen initial energy at {origin}/{precision}")
                a27.verify_logged_observation(physical_row, a27.observation(model, state), f"Unseen initial observations at {origin}/{precision}")
                base_hash = a27.state_sha256(seeds[precision].matrix) if family else ""
                work = check_preparation_ledger(observed[origin, precision], steps, base_hash, fingerprint, (origin, precision))
                if family:
                    a27.tolerance(physical_row["preparation_signed_external_work"], work, f"Unseen total preparation work at {origin}/{precision}")
                    a27.tolerance(model.energy(state) - model.energy(seeds[precision]), work,
                                  f"Unseen generation conservation at {origin}/{precision}")
                case_result[precision] = {"archive_hash": fingerprint, "q": float(q), "matrix_error": difference,
                                          "minimum_eigenvalue": float(state.eigenvalues[0]), "preparation_work_on_system": work if family else None}
        result[origin] = {"physical_source_time": expected_time, "preparation_selection": q_selection, "physical": case_result}
    return {"recipe_sha256": recipes_hash, "states": result, **check_unseen_distances(unseen_dir, pairs, archived)}


def initial_observation(ledger):
    return PreviousObservation(NUMBER(ledger, "current_before") / (2 * G),
                               NUMBER(ledger, "c_abs_before"), -NUMBER(ledger, "cut_on") / (2 * G))


def measured_observation(row):
    return ReconnectObservation(-NUMBER(row, "c_imag"), NUMBER(row, "c_abs"), NUMBER(row, "c_real"), NUMBER(row, "phase"))


def audit_detached_prefix(model, rule, ledger, table, state, context):
    """Replay the first attained gate or limit from time-stamped physical witnesses."""
    start, tau, window = (TICKS(ledger, name) for name in ("elapsed_start", "tau", "window"))
    clocks = relative_wait_clocks(window)
    if not clocks:
        a27.insist(tau == 0 and not table, f"Wait does not fit with a connected sample at {context}")
        return []
    a27.insist(tau in clocks, f"Policy missed an available or recorded off-lattice wait at {context}")
    prefix = list(range(clocks.start, tau + 1, clocks.step))
    a27.insist(len(table) == len(prefix), f"Detached prefix coverage differs at {context}")
    before = initial_observation(ledger)
    exact_start = model.detached_c(state, 0)
    for name, actual, expected in (("q0", before.q, -exact_start.imag), ("|c0|", before.magnitude, abs(exact_start)),
                                   ("Re(c0)", before.real, exact_start.real)):
        a27.tolerance(actual, expected, f"Detached physical anchor {name} at {context}", a27.HALF_TOL)
    tests = []
    for sample, delay in zip(table, prefix, strict=True):
        now = start + delay
        a27.insist(TICKS(sample, "elapsed_total") == TICKS(sample, "observed_until") == now and TICKS(sample, "wait_elapsed") == delay,
                   f"Detached control used data unavailable at decision clock {now}: {context}")
        measured = measured_observation(sample)
        exact = model.detached_c(state, delay)
        a27.tolerance(measured.q, -exact.imag, f"Detached q witness at {context}/{delay}", a27.HALF_TOL)
        a27.tolerance(measured.real, exact.real, f"Detached real part at {context}/{delay}", a27.HALF_TOL)
        a27.tolerance(measured.magnitude, math.hypot(measured.q, measured.real), f"Detached amplitude at {context}/{delay}", 1e-15)
        a27.tolerance(math.remainder(measured.phase - math.atan2(-measured.q, measured.real), math.tau),
                      0, f"Detached phase at {context}/{delay}", 1e-12)
        a27.tolerance(sample["load_current"], 2 * G * measured.q, f"Potential loaded current at {context}/{delay}", 1e-15)
        a27.tolerance(sample["actual_current"], 0.0, f"Physical current while detached at {context}/{delay}", 1e-15)
        passed = registered_predicate(rule, before, measured, EPSILON_Q)
        at_limit = delay == clocks[-1]
        a27.insist(FLAG(sample, "phase_gate") == passed and FLAG(sample, "reconnect") == (passed or at_limit)
                   and (delay == tau) == (passed or at_limit), f"Wrong first reconnect or fallback at {context}/{delay}")
        tests.extend(q_perturbations(rule, before, measured, passed, nominal_clocks=(delay, clocks[-1])))
    return tests


def replay_reuse_clock(rule, ledger, prefix):
    """Certify a target gate on a parent's actually consumed observations only."""
    before = initial_observation(ledger)
    source_tau = TICKS(ledger, "tau")
    clocks = relative_wait_clocks(TICKS(ledger, "window"))
    if not clocks:
        a27.insist(not prefix and source_tau == 0, "A no-window reuse witness contains detached samples")
        return 0
    source_prefix = [TICKS(point, "wait_elapsed") for point in prefix]
    a27.insist(source_prefix == list(range(MIN_WAIT, source_tau + 1, WAIT_STEP)), "Missing consumed prefix in a reuse source")
    for point, delay in zip(prefix, source_prefix, strict=True):
        if registered_predicate(rule, before, measured_observation(point), EPSILON_Q) or delay == clocks[-1]:
            return delay
    return None


def stage_path(path):
    return path.with_name(path.name.replace("m28_", "m29_", 1)) if path.name.startswith("m28_") else path


def read_m29(path):
    return READ_CSV(stage_path(path))


def table_m29(path):
    return stage_table(stage_path(path))


def stage_tables(folder):
    history = table_m29(folder / "m29_history.csv")
    decisions = a27.read_unique(table_m29(folder / "m29_decisions.csv"), lambda row: int(row["attempt"]))
    waits = a27.read_unique(table_m29(folder / "m29_waits.csv"), lambda row: int(row["attempt"]))
    checks = a27.group_attempt(table_m29(folder / "m29_wait_checks.csv"))
    observations = a27.group_attempt(table_m29(folder / "m29_observations.csv"))
    inputs = a27.group_attempt(table_m29(folder / "m29_selector.csv"))
    attempts = {int(row["attempt"]) for row in history}
    a27.insist(attempts == set(decisions) == set(observations) and set(checks) <= attempts and set(waits) <= attempts
               and set(inputs) <= attempts, f"Evidence does not match physical attempts in {folder}")
    diagnostics = {int(row["attempt"]): {**row, "selector": inputs[int(row["attempt"])]} for row in history}
    return history, decisions, waits, checks, observations, diagnostics


def threshold_q(rule, initial):
    if rule == "P2" or rule == "P1":
        return initial.magnitude / 4
    if rule == "P3":
        return max(abs(initial.q) / 4, EPSILON_Q)
    return EPSILON_Q


def audit_selected_inputs(diagnostic, ledger, connected, detached, phase_used, context):
    rule = ledger["policy"]
    active = rule in RP_AND_P and TICKS(ledger, "tau") > 0
    first_use = int(active and rule != "P4")
    measures = len(detached) if active else 0
    scalar_count = first_use * (1 if rule == "P3" else 2) + measures * (2 if rule in ("RP", "P1") else 1)
    fields = {"decision_observations": first_use + measures, "phase_observations": first_use + measures,
              "initial_phase_observations": first_use, "wait_phase_observations": measures, "observed_scalars": scalar_count}
    for field, expected in fields.items():
        a27.insist(int(ledger[field]) == expected, f"Observational cost differs from allowed inputs at {context}/{field}")
    a27.insist(all(FLAG(witness, "used_by_control") == active for witness in detached), f"Detached use labels at {context}")
    a27.insist(FLAG(ledger, "at_max_wait") == (TICKS(ledger, "tau") == MAX_WAIT) and
               FLAG(ledger, "fallback_limit") == (ledger["wait_reason"] == "phase_limit"), f"Incorrect forced-wait accounting at {context}")
    a27.insist(TICKS(ledger, "reconnect_elapsed") == TICKS(connected[0], "elapsed_total"), f"Reconnection clock label at {context}")
    selectors = diagnostic["selector"]
    a27.insist(len(selectors) == (len(detached) if rule in RP_AND_P[1:] else 0), f"Missing or extra selector input evidence at {context}")
    before = initial_observation(ledger)
    for row, measurement in zip(selectors, detached if selectors else [], strict=True):
        a27.insist(all(row[name] == ledger[name] for name in ("group", "origin", "policy", "precision", "attempt"))
                   and all(TICKS(row, name) == TICKS(measurement, name) for name in ("elapsed_total", "observed_until", "wait_elapsed")),
                   f"Selector input has wrong provenance or clock at {context}")
        current = measured_observation(measurement)
        expected_inputs = {"q": current.q}
        if rule in ("P1", "P2"):
            expected_inputs["c0_abs"] = before.magnitude
        if rule == "P1":
            expected_inputs["amplitude"] = current.magnitude
        if rule == "P3":
            expected_inputs["q0"] = before.q
        for field in ("q", "q0", "c0_abs", "amplitude"):
            if field in expected_inputs:
                a27.tolerance(row[field], expected_inputs[field], f"Passed permitted {field} at {context}", 1e-16)
            else:
                a27.insist(not row[field], f"Unregistered input {field} passed at {context}")
        a27.tolerance(row["threshold_q"], threshold_q(rule, before), f"Selector threshold at {context}", 1e-16)
        gate = registered_predicate(rule, before, current, EPSILON_Q)
        reconnect = FLAG(measurement, "reconnect")
        a27.insist(FLAG(row, "gate") == gate and FLAG(row, "reconnect") == reconnect and FLAG(row, "limit") == (reconnect and not gate),
                   f"Selector metadata disagrees with physical choice at {context}")


def pending_m29(row, observations, checks, boundary):
    mode = "RP" if row["policy"] in RP_AND_P else "F1"
    return a27.cross_boundary_pending({**row, "policy": mode}, observations, checks, boundary)


def verify_policy_reuse(folder, key, cap, anchor, fingerprints):
    proof_path = folder / "equivalent_policy.json"
    if not proof_path.is_file():
        return False
    proof = json.loads(proof_path.read_text(encoding="utf-8"))
    source = (ROOT / proof["source"]).resolve()
    target_group, origin, policy, precision = key
    source_group, source_origin, source_policy, source_precision = source.parts[-4:]
    a27.insist(source.parent.parent.parent.parent.name == f"t{cap // 1000}" and source_origin == origin and source_precision == precision,
               f"Reused source has a different origin, clock or precision at {key}/{cap}")
    modes = {"P1": ("RP",), "P2": ("RP", "P1", "Xamp"), "P3": ("RP", "P1", "P2", "Xamp"), "P4": ("RP", "P1", "P2", "P3")}
    a27.insist((source_group == target_group and source_policy in modes[policy]) or
               (source_group == "F2-R" and target_group == "F1" and source_policy == policy), f"Invalid or cyclic policy reuse at {key}/{cap}")
    prefix = proof["source_prefix"]
    if prefix == "m28":
        a27.insist(source.is_relative_to((M28 / "stages").resolve()), f"Source labelled M28 lies elsewhere at {key}")
        audit_name = "matched" if source_policy == "RP" else "ablations"
        source_audit = json.loads((M28 / "results" / f"audit_{audit_name}.json").read_text(encoding="utf-8"))
        a27.insist("/".join(source.parts[-4:]) in source_audit["matched"]["branch_results"] and
                   source_audit["protocol_sha256"] == a27.sha256(M28 / "PROTOCOL_M28.md"), f"No prior audit covers the reused source {source}")
    else:
        a27.insist(prefix == "m29" and source.is_relative_to(folder.resolve().parents[4]), f"M29 source outside its registered stage root at {key}")
    previous_history = source / f"{prefix}_history.csv"
    a27.insist(a27.sha256(source / "checkpoint.npz") == proof["source_checkpoint_sha256"] == a27.sha256(folder / "checkpoint.npz")
               and a27.sha256(previous_history) == proof["source_history_sha256"], f"Certified predecessor changed at {key}/{cap}")
    with a27.np.load(anchor, allow_pickle=False) as seed, a27.np.load(source / "checkpoint.npz", allow_pickle=False) as checkpoint:
        memory = json.loads(str(seed["records"].item()))
        a27.insist(int(seed["tick"].item()) == int(checkpoint["fork_tick"].item()) == proof["fork_tick"]
                   and int(checkpoint["tick"].item()) == cap
                   and json.loads(str(checkpoint["records"].item()))[:len(memory)] == memory,
                   f"Certified trajectory has another seed time, boundary or prior history at {key}/{cap}")
        a27.insist(proof["fork_hashes"] == [fingerprints[label] for label in RESOLUTIONS]
                   and all(str(checkpoint[f"fork_{label}_sha256"].item()) == a27.state_sha256(seed[label]) == fingerprints[label]
                           for label in RESOLUTIONS), f"Certified reuse has another initial density at {key}/{cap}")
    old_checks = a27.group_attempt(stage_table(source / f"{prefix}_wait_checks.csv"))
    history = READ_CSV(previous_history)
    materialized, _, _, target_checks, _, _ = stage_tables(folder)
    a27.insist(len(history) == len(materialized) == proof["same_first_choice_attempts"]
               and sum(map(len, old_checks.values())) == proof["scalar_samples"], f"Incomplete certificate at {key}/{cap}")
    fields = ("tau", "elapsed_start", "elapsed_total", "decision_elapsed_total", "accepted", "net_work", "net_work_aligned", "cut_on",
              "reconnect_on", "start_coarse_sha256", "start_half_sha256", "post_coarse_sha256", "post_half_sha256")
    witness_fields = ("elapsed_total", "observed_until", "wait_elapsed", "c_real", "c_imag", "c_abs", "phase", "load_current")
    for old, new in zip(history, materialized, strict=True):
        attempt = int(old["attempt"])
        past = old_checks[attempt]
        target = target_checks[attempt]
        choice = replay_reuse_clock(policy, old, past)
        a27.insist(choice == TICKS(old, "tau") and all(old[name] == new[name] for name in fields),
                   f"Certified law violates earliest reconnect or changes work at {key}/{cap}/{attempt}")
        a27.insist(len(past) == len(target) and all(a[name] == b[name] for a, b in zip(past, target, strict=True) for name in witness_fields),
                   f"Certificates rely on different time-local physical witnesses at {key}/{cap}/{attempt}")
    return True


PREVIOUS_WAIT_AUDIT = a28.audit_wait_choice
EXACT_ACTION = a27.exact_action


class DiscreteReplay(a27.ReplayModel):
    """Independent RK4 commutator polynomial at the registered native step."""

    def __init__(self):
        super().__init__()
        self.transforms = {}
        for coupling in (0.0, G):
            energies = a27.np.empty(a27.DIM)
            vectors = a27.np.zeros((a27.DIM, a27.DIM))
            for locations, (eigenvalues, basis) in zip(self.sectors, self.sector_spectra[coupling], strict=True):
                energies[locations] = eigenvalues
                vectors[a27.np.ix_(locations, locations)] = basis
            frequencies = energies[:, None] - energies[None, :]
            self.transforms[coupling] = vectors, frequencies

    @lru_cache(maxsize=4)
    def logarithm(self, coupling, step):
        _, frequencies = self.transforms[coupling]
        x = frequencies / step
        square = x * x
        real = 1 - square / 2 + square * square / 24
        imag = x * (square / 6 - 1)
        # |R4(−i x)|² = 1 − x⁶/72 + x⁸/576. Use log1p near unity.
        return a27.np.log1p(square ** 3 * (square / 576 - 1 / 72)) / 2 + 1j * a27.np.arctan2(imag, real)

    def evolve(self, state, coupling, elapsed):
        if elapsed == 0:
            return state
        step = {"coarse": 400, "half": 800}[state.sha256]
        count = round(elapsed * step)
        a27.insist(abs(count - elapsed * step) < 1e-7, "Independent RK4 duration is outside its step lattice")
        vectors, _ = self.transforms[coupling]
        represented = vectors.T @ state.matrix @ vectors
        represented *= a27.np.exp(count * self.logarithm(coupling, step))
        return a27.State(vectors @ represented @ vectors.T, state.time + elapsed, state.sha256)


def state_with_step(state, step):
    return a27.State(state.matrix, state.time, step)


def discrete_actions(precision):
    labels = a28.ordered_labels(precision)
    slot = 0

    def action(model, state, tau, connected, accepted):
        nonlocal slot
        label = labels[slot % 2]
        slot += 1
        result = EXACT_ACTION(model, state_with_step(state, label), tau, connected, accepted)
        return a27.ExactAction(*(state_with_step(item, label) for item in (result.waited, result.before, result.after, result.hypothetical)),
                               result.cut, result.reconnect, result.work, result.observed_work)

    return action


def exact_drift_diagnostic(key, folders, seed_file, source_time):
    """Measure continuous and checkpoint-reanchored exact discrepancies separately."""
    model = a27.ReplayModel()
    labels = a28.ordered_labels(key[-1])
    with a27.np.load(seed_file, allow_pickle=False) as source:
        clock = int(source["tick"].item())
        initial = tuple(a27.State(source[label], source_time + clock / 1000) for label in labels)
    continuous, reset = initial, initial
    reanchor_at = {}
    for boundary, folder in folders.items():
        if not (folder / "checkpoint.npz").is_file():
            continue
        with a27.np.load(folder / "checkpoint.npz", allow_pickle=False) as checkpoint:
            tick = int(checkpoint["counters"][0])
            if tick > clock:
                reanchor_at[tick] = boundary, tuple(a27.State(checkpoint[f"anchor_{label}"], source_time + tick / 1000) for label in labels)
    result = {"continuous": {"max_global_energy_error": 0.0, "max_candidate_work_error": 0.0, "attempts_above_old_energy_threshold": 0},
              "checkpoint_reanchored": {"max_global_energy_error": 0.0, "max_candidate_work_error": 0.0, "attempts_above_old_energy_threshold": 0},
              "anchor_comparisons": []}
    for folder in folders.values():
        for row in table_m29(folder / "m29_history.csv"):
            tau, connected, end = (TICKS(row, name) for name in ("tau", "elapsed_connected", "elapsed_total"))
            observed = FLAG(row, "accepted")
            calculations = {}
            for route, states in (("continuous", continuous), ("checkpoint_reanchored", reset)):
                shaped = tuple(EXACT_ACTION(model, state, tau, connected, observed) for state in states)
                primary = shaped[0]
                errors = [abs(NUMBER(row, field) - model.energy(target)) for field, target in
                          (("start_global_energy", states[0]), ("pre_global_energy", primary.before), ("post_global_energy", primary.after))]
                table = result[route]
                table["max_global_energy_error"] = max(table["max_global_energy_error"], *errors)
                table["attempts_above_old_energy_threshold"] += int(max(errors) > a27.EXACT_WORK_TOL)
                table["max_candidate_work_error"] = max(table["max_candidate_work_error"], abs(NUMBER(row, "direct_net") - primary.work))
                calculations[route] = tuple(item.after for item in shaped)
            continuous, reset = calculations["continuous"], calculations["checkpoint_reanchored"]
            if end in reanchor_at:
                boundary, states = reanchor_at[end]
                difference = max(a27.maxabs(exact.matrix - stored.matrix) for exact, stored in zip(reset, states, strict=True))
                full_difference = max(a27.maxabs(exact.matrix - stored.matrix) for exact, stored in zip(continuous, states, strict=True))
                a27.insist(math.isfinite(difference) and math.isfinite(full_difference), f"Nonfinite exact drift diagnostic at {key}/{boundary}")
                result["anchor_comparisons"].append({"saved_boundary": boundary / 1000, "actual_anchor": end / 1000,
                                                     "segment_max_density_element_error": difference,
                                                     "continuous_max_density_element_error": full_difference,
                                                     "old_exact_density_threshold_exceeded": difference > a27.HALF_TOL})
                reset = states
    return result


def audit_branch(key, folders, anchor, source_time, fingerprints):
    total_controls = {"decision_observations": 0, "observed_scalars": 0, "forced_limits": 0, "max_waits": 0}
    sensitivity = defaultdict(lambda: {"evaluations": 0, "predicate_changes": 0, "action_changes": 0})

    def wait_audit(model, row, checks, state, context):
        rule = row["policy"]
        if rule not in RP_AND_P:
            PREVIOUS_WAIT_AUDIT(model, row, checks, state, context)
            return
        for result in audit_detached_prefix(model, rule, row, checks, state, context):
            measured = sensitivity[result["input"], result["delta"]]
            measured["evaluations"] += 1
            measured["predicate_changes"] += int(result["predicate_changed"])
            measured["action_changes"] += int(result["immediate_action_changed"])

    def control_inputs(diagnostic, ledger, connected, detached, phase_used, context):
        audit_selected_inputs(diagnostic, ledger, connected, detached, phase_used, context)
        total_controls["decision_observations"] += int(ledger["decision_observations"])
        total_controls["observed_scalars"] += int(ledger["observed_scalars"])
        total_controls["forced_limits"] += int(FLAG(ledger, "fallback_limit"))
        total_controls["max_waits"] += int(FLAG(ledger, "at_max_wait"))

    with (patch.object(a28, "READ_CSV", read_m29), patch.object(a28, "table_m28", table_m29), patch.object(a28, "stage_tables", stage_tables),
          patch.object(a28, "ABLATIONS", {rule: None for rule in RP_AND_P[1:]}), patch.object(a28, "audit_wait_choice", wait_audit),
          patch.object(a28, "audit_current", control_inputs), patch.object(a28, "pending_from_action", pending_m29)):
        try:
            report = a28.audit_matched_job(key, folders, anchor, source_time, fingerprints)
            report["propagation_audit"] = "continuous_exact_unitary"
        except ValueError as error:
            reason = str(error)
            energy_contexts = ("Exact physical", "Matched cumulative conservation", "Boundary energy including pending operations")
            exact_energy_difference = reason.startswith(energy_contexts) and reason.endswith("within 2e-12")
            exact_boundary_difference = reason.startswith("Independent boundary density at") and reason.endswith("within 1e-10")
            if key[0] != "unseen" or not (exact_energy_difference or exact_boundary_difference):
                raise
            # Keep the exact-vs-discrete exceedance visible. Recheck at the same RK4 step
            # using an independent polynomial and the unchanged local numerical tolerances.
            sensitivity.clear()
            for count in total_controls:
                total_controls[count] = 0
            with patch.object(a28, "ReplayModel", DiscreteReplay), patch.object(a27, "exact_action", discrete_actions(key[-1])):
                report = a28.audit_matched_job(key, folders, anchor, source_time, fingerprints)
            report["propagation_audit"] = "independent_same_step_RK4"
            report["old_exact_witness_exceedance"] = reason
            report["exact_vs_discrete_diagnostic"] = exact_drift_diagnostic(key, folders, anchor, source_time)
    report.update(total_controls)
    report["perturbation_counts"] = [{"input": name, "delta": delta, **values} for (name, delta), values in sorted(sensitivity.items())]
    report["certified_policy_reuse_stages"] = sum(verify_policy_reuse(folder, key, cap, anchor, fingerprints)
                                                  for cap, folder in folders.items() if folder.is_dir())
    return report


def stage_folders(root, key, boundaries):
    return {clock: root.joinpath(f"t{clock // 1000}", *key) for clock in boundaries}


def independent_step_audit(key, coarse, half, coarse_report, half_report):
    histories = [[row for folder in folders.values() for row in table_m29(folder / "m29_history.csv")] for folders in (coarse, half)]
    clocks = [tuple((TICKS(row, "elapsed_start"), TICKS(row, "tau"), TICKS(row, "decision_elapsed_total"), TICKS(row, "elapsed_total"),
                     FLAG(row, "accepted")) for row in history) for history in histories]
    differing = next((i for i, (a, b) in enumerate(zip(*clocks, strict=False), 1) if a != b), None)
    if differing is None and len(clocks[0]) != len(clocks[1]):
        differing = min(map(len, clocks)) + 1
    paired = []
    selectors = []
    for folders in (coarse, half):
        paired.append({(int(row["attempt"]), TICKS(row, "elapsed_total")): NUMBER(row, "c_imag") for folder in folders.values()
                       for row in table_m29(folder / "m29_wait_checks.csv")})
        selectors.append({(int(row["attempt"]), TICKS(row, "elapsed_total")): tuple(FLAG(row, field) for field in ("gate", "reconnect", "limit"))
                          for folder in folders.values() for row in table_m29(folder / "m29_selector.csv")})
    p, q = paired
    qdiff = max((abs(p[entry] - q[entry]) for entry in p.keys() & q.keys()), default=0.0)
    coarse_choices, half_choices = selectors
    common_selector_clocks = coarse_choices.keys() & half_choices.keys()
    first_selector_difference = min((clock for clock in common_selector_clocks if coarse_choices[clock] != half_choices[clock]), default=None)
    return {"group": key[0], "origin": key[1], "policy": key[2], "matching_operation_clocks": differing is None,
            "first_different_attempt": differing, "coarse_attempts": len(clocks[0]), "half_attempts": len(clocks[1]),
            "native_net_difference_coarse_minus_half": coarse_report["cumulative_net"] - half_report["cumulative_net"],
            "matched_detached_clocks": len(p.keys() & q.keys()), "matched_detached_clock_max_q_difference": qdiff,
            "matched_selector_clocks": len(common_selector_clocks),
            "matching_selector_clocks": coarse_choices.keys() == half_choices.keys(),
            "first_different_selector_outcome": first_selector_difference,
            "boundary_trace_distances": a27.boundary_distances(coarse, half)}


def step_totals(steps):
    return {"independent_step_pairs": len(steps),
            "step_pairs_with_different_clocks": sum(not row["matching_operation_clocks"] for row in steps),
            "step_pairs_with_different_selector_clocks": sum(not row["matching_selector_clocks"] for row in steps),
            "step_pairs_with_different_selector_outcomes": sum(row["first_different_selector_outcome"] is not None for row in steps),
            "max_native_endpoint_net_difference": max((abs(row["native_net_difference_coarse_minus_half"]) for row in steps), default=0.0)}


def audit_stages(stage_root, boundaries, groups, origins, policies, precisions, unseen_anchors, workers, publish_branch=None):
    archived, _ = a28.archived_origins()
    existing_root = M28 / "anchors"
    registry = a27.read_unique(READ_CSV(existing_root / "m28_anchors.csv"), lambda row: (row["group"], row["origin"], row["precision"]))
    if "unseen" in groups:
        registry.update(a27.read_unique(READ_CSV(unseen_anchors / "m29_unseen_anchors.csv"),
                                       lambda row: (row["group"], row["origin"], row["precision"])))
    jobs = {}
    for group in groups:
        for origin in origins:
            if (origin in ORIGINS) == (group == "unseen"):
                continue
            for precision in precisions:
                row = registry[group, origin, precision]
                anchor_root = unseen_anchors if group == "unseen" else existing_root
                if group != "unseen":
                    a28.audited_anchor(M28 / "stages", existing_root, registry, archived, group, origin, precision)
                for policy in policies:
                    key = group, origin, policy, precision
                    anchor = anchor_root / row["anchor_file"]
                    fingerprints = {label: row[f"{label}_sha256"] for label in RESOLUTIONS}
                    jobs[key] = (key, stage_folders(stage_root, key, boundaries), anchor, NUMBER(row, "source_time"), fingerprints)
    a27.insist(jobs, "No M29 tracked branches match the audit options")
    def retain(key, report):
        if publish_branch is not None:
            publish_branch(key, report)
        return report

    if workers == 1:
        results = {key: retain(key, audit_branch(*args)) for key, args in jobs.items()}
    else:
        completed = {}
        failures = []
        with ProcessPoolExecutor(max_workers=workers) as pool:
            pending = {pool.submit(audit_branch, *args): key for key, args in jobs.items()}
            for future in as_completed(pending):
                key = pending[future]
                try:
                    completed[key] = retain(key, future.result())
                except Exception as error:
                    failures.append(error)
        if failures:
            raise failures[0]
        results = {key: completed[key] for key in jobs}
    totals = a28.totals_for(results.values())
    totals["certified_policy_reuse_stages"] = sum(report["certified_policy_reuse_stages"] for report in results.values())
    totals["point_perturbations"] = sum(case["evaluations"] for report in results.values() for case in report["perturbation_counts"])
    totals["perturbed_predicates_changed"] = sum(case["predicate_changes"] for report in results.values() for case in report["perturbation_counts"])
    totals["perturbed_immediate_actions_changed"] = sum(case["action_changes"] for report in results.values() for case in report["perturbation_counts"])
    totals.update(discrete_replay_totals(results.values()))
    steps = []
    for complete in results:
        if complete[-1] != "coarse":
            continue
        key = complete[:-1]
        half = *key, "half"
        if half in results:
            steps.append(independent_step_audit(key, jobs[complete][1], jobs[half][1], results[complete], results[half]))
    totals.update(step_totals(steps))
    for field in ("decision_observations", "observed_scalars", "forced_limits", "max_waits"):
        totals[field] = sum(report[field] for report in results.values())
    return {"totals": totals, "independent_step_comparison": steps, "branches": {"/".join(key): row for key, row in results.items()}}


def supplement_formal_report(stages, path, protocol):
    result = json.loads(path.read_text(encoding="utf-8"))
    return supplement_operation_checks(stages, result, protocol)


def discrete_replay_totals(results):
    selected = [row["exact_vs_discrete_diagnostic"] for row in results if "exact_vs_discrete_diagnostic" in row]
    comparisons = [checkpoint for row in selected for checkpoint in row["anchor_comparisons"]]
    return {"branches_using_same_step_rk4_comparison": len(selected),
            "max_continuous_exact_vs_rk4_absolute_energy_error": max((row["continuous"]["max_global_energy_error"] for row in selected), default=0.0),
            "max_reanchored_exact_vs_rk4_absolute_energy_error": max((row["checkpoint_reanchored"]["max_global_energy_error"] for row in selected), default=0.0),
            "max_continuous_exact_vs_rk4_anchor_element_error": max((row["continuous_max_density_element_error"] for row in comparisons), default=0.0),
            "max_reanchored_exact_vs_rk4_anchor_element_error": max((row["segment_max_density_element_error"] for row in comparisons), default=0.0),
            "reanchored_anchors_above_old_density_threshold": sum(row["old_exact_density_threshold_exceeded"] for row in comparisons)}


def supplement_operation_checks(stages, result, protocol):
    digest = a27.sha256(protocol)
    a27.insist(result["protocol_sha256"] == digest == (stages / "protocol.sha256").read_text(encoding="utf-8").strip(),
               "Independent step supplement cannot bind the saved stage audit")
    saved = result["stage_audit"]
    report = saved["branches"]
    totals = saved["totals"]
    if "step_pairs_with_different_selector_outcomes" in totals:
        return result
    boundaries = tuple(int(tick) * 1000 for tick in result["cutoffs"])
    steps, folder_inventory = [], {}
    metrics = {"decision_observations": 0, "observed_scalars": 0, "forced_limits": 0, "max_waits": 0}
    for label, branch in report.items():
        key = tuple(label.split("/"))
        folders = stage_folders(stages, key, boundaries)
        folder_inventory[label] = folders
        this = {name: 0 for name in metrics}
        histories = [event for folder in folders.values() for event in table_m29(folder / "m29_history.csv")]
        a27.insist(len(histories) == branch["attempts"] and sum(FLAG(event, "accepted") for event in histories) == branch["accepted"],
                   f"A stage no longer agrees with prior work verification at {label}")
        a27.tolerance(math.fsum(NUMBER(event, "net_work") for event in histories), branch["cumulative_net"], f"Supplement keeps audited work at {label}")
        for event in histories:
            this["decision_observations"] += int(event["decision_observations"])
            this["observed_scalars"] += int(event["observed_scalars"])
            this["forced_limits"] += int(FLAG(event, "fallback_limit"))
            this["max_waits"] += int(FLAG(event, "at_max_wait"))
        branch.update(this)
        for name, value in this.items():
            metrics[name] += value
    for label, branch in report.items():
        if not label.endswith("/coarse"):
            continue
        half = f"{label.rsplit('/', 1)[0]}/half"
        if half in report:
            steps.append(independent_step_audit(tuple(label.split("/")[:-1]), folder_inventory[label], folder_inventory[half], branch, report[half]))
    saved["independent_step_comparison"] = steps
    totals.update(metrics, **step_totals(steps))
    return result


def merge_formal_reports(stages, paths, protocol):
    combined = {}
    header = None
    for path in paths:
        result = json.loads(path.read_text(encoding="utf-8"))
        branch_audit = result.pop("stage_audit")["branches"]
        if header is None:
            header = result
        a27.insist(header == result and not set(combined) & set(branch_audit), f"Overlapping or incompatible native audits in {path}")
        combined.update(branch_audit)
    totals = a28.totals_for(combined.values())
    totals["certified_policy_reuse_stages"] = sum(report["certified_policy_reuse_stages"] for report in combined.values())
    tests = [case for branch in combined.values() for case in branch["perturbation_counts"]]
    totals["point_perturbations"] = sum(case["evaluations"] for case in tests)
    totals["perturbed_predicates_changed"] = sum(case["predicate_changes"] for case in tests)
    totals["perturbed_immediate_actions_changed"] = sum(case["action_changes"] for case in tests)
    totals.update(discrete_replay_totals(combined.values()))
    header["stage_audit"] = {"totals": totals, "branches": dict(sorted(combined.items()))}
    return supplement_operation_checks(stages, header, protocol)


def write_audit(path, result):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def check_benchmark_replay(stages, direct, reference, boundaries, precision_labels):
    summary = {}
    for precision in precision_labels:
        key = "F2-R", "S0", "P3", precision
        folders = stage_folders(stages, key, boundaries)
        final = folders[boundaries[-1]]
        if direct:
            direct_path = stage_folders(direct, key, boundaries)[boundaries[-1]]
            for report in ("history", "observations", "decisions", "selector", "wait_checks", "waits"):
                name = f"m29_{report}.csv"
                expected = [row for folder in folders.values() for row in table_m29(folder / name)]
                a27.insist(expected == table_m29(direct_path / name), f"Uninterrupted replay differs in {name}/{precision}")
            with a27.np.load(final / "checkpoint.npz", allow_pickle=False) as saved, a27.np.load(
                direct_path / "checkpoint.npz", allow_pickle=False
            ) as other:
                a27.insist(set(saved.files) == set(other.files) and all(a27.np.array_equal(saved[name], other[name]) for name in saved.files),
                           f"Uninterrupted terminal checkpoint differs for P3/{precision}")
        report = {"uninterrupted_exact": bool(direct)}
        if reference:
            alternate = stage_folders(reference, key, boundaries)[boundaries[-1]]
            expected = [row for folder in folders.values() for row in table_m29(folder / "m29_history.csv")]
            measured = table_m29(alternate / "m29_history.csv")
            a27.insist(len(expected) == len(measured), f"A projection changes P3 attempt count at {precision}")
            for before, after in zip(expected, measured, strict=True):
                for name in ("elapsed_start", "elapsed_total", "decision_elapsed_total", "tau", "accepted", "net_work"):
                    a27.insist(before[name] == after[name], f"Projection changes P3 {name} for {precision}/{before['attempt']}")
            with a27.np.load(final / "checkpoint.npz", allow_pickle=False) as saved, a27.np.load(
                alternate / "checkpoint.npz", allow_pickle=False
            ) as other:
                a27.insist(all(a27.np.array_equal(saved[name], other[name]) for name in ("coarse", "half", "work", "counters")),
                           f"Reduced projection changes P3 physical endpoint at {precision}")
            report["reference_attempts_matched"] = len(measured)
        summary[precision] = report
    return summary


def first_rate_switch(rows):
    paid, previous = [], []
    for row in rows:
        now = TICKS(row, "elapsed_start")
        a27.insist(all(clock <= now for clock, _ in paid), "Rate-only switch received unexecuted work")
        initial = math.fsum(work for clock, work in paid if 0 < clock <= a27.BASELINE_END) / 32
        moving = math.fsum(work for clock, work in paid if now - a27.RATE_SPAN < clock <= now) / 24
        low = now >= a27.FIRST_SWITCH_TEST and initial > 0 and moving <= .45 * initial
        if low:
            previous.append(now)
        else:
            previous.clear()
        if len(previous) >= 2 and now - previous[0] >= a27.PERSISTENCE:
            return now, initial, moving
        a27.insist(row["mode"] == "forecast" and TICKS(row, "tau") == 0, "Archive changes mode before the rate-only trigger")
        if FLAG(row, "accepted"):
            paid.append((TICKS(row, "elapsed_total"), NUMBER(row, "net_work")))
    raise ValueError("No actual F1 trigger encountered in the registered comparison")


def branch_history(stages, suffix, prefix):
    return [row for tick in (150, 300, 540) for row in READ_CSV(stages.joinpath(f"t{tick}", *suffix, f"{prefix}_history.csv"))]


def audit_archive_controls():
    controls, coverage = {}, []
    protocol = a27.sha256(M28 / "PROTOCOL_M28.md")
    for classified, policies in (("matched", ("RP", "R0", "R1", "R3", "RH")), ("oracle", ("E",))):
        reference = M28 / "results" / f"audit_{classified}.json"
        result = json.loads(reference.read_text(encoding="utf-8"))
        a27.insist(result["protocol_sha256"] == protocol and result["boundaries"] == [150, 300, 540], "M28 audit protocol or horizon mismatch")
        keys = [f"{group}/{origin}/{policy}/{precision}" for group in ("F2-R", "F1") for origin in ORIGINS
                for policy in policies for precision in RESOLUTIONS]
        for key in keys:
            evidence = result["matched"]["branch_results"][key]
            folder = (M28 / "stages" / "t540").joinpath(*key.split("/"))
            endpoint, = READ_CSV(folder / "m28_checkpoints.csv")
            a27.insist(TICKS(endpoint, "elapsed_total") == a27.CAP and int(endpoint["count"]) == evidence["accepted"]
                       and int(endpoint["attempts"]) == evidence["attempts"], f"Archived formal endpoint does not match audit for {key}")
            a27.tolerance(endpoint["cumulative_net"], evidence["cumulative_net"], f"Archived audited work for {key}")
        coverage.extend(keys)
        controls[classified] = a27.sha256(reference)
    return {"reused_formal_matched_branches": len(coverage), "prior_protocol_sha256": protocol, "prior_audit_sha256": controls}


def audit_whole(stages, artifacts):
    prefix_audit = json.loads((M27 / "results" / "audit.json").read_text(encoding="utf-8"))
    robust_audit = json.loads((M28 / "results" / "audit_primary.json").read_text(encoding="utf-8"))
    a27.insist(prefix_audit["protocol_sha256"] == a27.sha256(M27 / "PROTOCOL_M27.md") and
               robust_audit["protocol_sha256"] == a27.sha256(M28 / "PROTOCOL_M28.md"), "Whole controller corrupted its audited prefix source")
    controls = {"M3": (stages, "P3", "m29"), "M4": (stages, "P4", "m29"), "M-F3": (M28 / "stages", "R3", "m28")}
    published = defaultdict(list)
    for row in READ_CSV(artifacts / "m29_whole_history.csv"):
        published[row["origin"], row["policy"], row["precision"]].append(row)
    switches = a27.read_unique(READ_CSV(artifacts / "m29_whole_switches.csv"), lambda row: (row["origin"], row["policy"], row["precision"]))
    anchors = a27.read_unique(READ_CSV(M28 / "anchors" / "m28_anchors.csv"), lambda row: (row["group"], row["origin"], row["precision"]))
    a27.insist(set(published) == set(switches) == {(o, p, r) for o in ORIGINS for p in ("F1", "F2-R", *controls) for r in RESOLUTIONS},
               "Wrong whole-horizon branch coverage")
    summaries = []
    for origin in ORIGINS:
        for precision in RESOLUTIONS:
            forecast_then_rh = branch_history(M27 / "stages", (origin, "F1", precision), "m27")
            forecast_then_rp = branch_history(M28 / "stages", ("main", origin, "F2-R", precision), "m28")
            start_f1, baseline, moving = first_rate_switch(forecast_then_rh)
            parent_switches = prefix_audit["branch_results"][f"{origin}/F1/{precision}"]["switches"]
            a27.insist(start_f1 == round(parent_switches[0]["time"] * 1000), f"Independent rate-only switch differs at {origin}/{precision}")
            start_f2 = round(robust_audit["primary"]["branch_results"][f"{origin}/F2-R/{precision}"]["switches"][0]["time"] * 1000)
            prefix = [row for row in forecast_then_rh if TICKS(row, "elapsed_total") <= start_f1]
            expected_fork = anchors["F1", origin, precision]
            for policy in ("F1", "F2-R", *controls):
                key = origin, policy, precision
                switch = switches[key]
                source_f1 = policy != "F2-R"
                clock = start_f1 if source_f1 else start_f2
                a27.insist(TICKS(switch, "first_switch_elapsed") == clock and FLAG(switch, "uses_phase") == (not source_f1),
                           f"Whole branch switch or added information at {key}")
                if source_f1:
                    a27.tolerance(switch["baseline_rate"], baseline, f"Published baseline rate at {key}", 1e-17)
                    a27.tolerance(switch["moving_rate"], moving, f"Published moving rate at {key}", 1e-17)
                if policy in controls:
                    tail_dir, tail_rule, tail_prefix = controls[policy]
                    continuation = branch_history(tail_dir, ("F1", origin, tail_rule, precision), tail_prefix)
                    a27.insist(TICKS(continuation[0], "elapsed_start") == clock and all(
                               prefix[-1][f"post_{r}_sha256"] == expected_fork[f"{r}_sha256"] == continuation[0][f"start_{r}_sha256"]
                               for r in RESOLUTIONS), f"Whole branch did not inherit the exact F1 switch state at {key}")
                    history = prefix + continuation
                else:
                    history = forecast_then_rh if policy == "F1" else forecast_then_rp
                materialized = published[key]
                a27.insist(len(materialized) == len(history), f"Whole branch loses events at {key}")
                signed, companion, accepted, work50 = [], [], 0, 0.0
                for index, (old, new) in enumerate(zip(history, materialized, strict=True), 1):
                    preserved = ("elapsed_start", "elapsed_total", "tau", "decision_elapsed_total", "accepted", "net_work", "net_work_aligned",
                                 "cut_on", "reconnect_on", "start_coarse_sha256", "start_half_sha256", "post_coarse_sha256", "post_half_sha256")
                    a27.insist(int(new["attempt"]) == index and int(new["source_attempt"]) == int(old["attempt"])
                               and all(old[name] == new[name] for name in preserved), f"Composed whole event changes operation at {key}/{index}")
                    work, aligned = NUMBER(old, "net_work"), NUMBER(old, "net_work_aligned")
                    signed.append(work)
                    companion.append(aligned)
                    accepted += int(FLAG(old, "accepted"))
                    a27.insist(int(new["count"]) == accepted, f"Wrong physical accepted count at {key}/{index}")
                    a27.tolerance(new["cumulative_net"], math.fsum(signed), f"Whole energy accounting at {key}/{index}")
                    a27.tolerance(new["cumulative_net_aligned"], math.fsum(companion), f"Aligned whole energy at {key}/{index}")
                    if TICKS(old, "elapsed_total") <= 50_000:
                        work50 += work
                summaries.append({"origin": origin, "policy": policy, "precision": precision, "switch_time": clock / 1000,
                                  "attempts": len(history), "work_at_50": work50, "work_at_540": math.fsum(signed)})
    return {"branches": summaries, "checked_signed_events": sum(r["attempts"] for r in summaries), "controls": audit_archive_controls()}


def audit_sensitivity_details(summary_path, lanes):
    """Bind every published perturbation to its consumed detached sample."""
    sources = {}
    consumed = set()
    counts = defaultdict(lambda: [0, 0, 0, 0, 0, 0, 0, 0, math.inf])
    stage_root = summary_path.resolve().parent.parent / "stages"
    for lane in lanes:
        for cap in (150, 300, 540):
            folder = stage_root.joinpath(f"t{cap}", *lane)
            attempts = {row["attempt"]: row for row in table_m29(folder / "m29_history.csv")}
            source = folder / "m29_selector.csv"
            indexed = {}
            for sample in table_m29(source):
                key = sample["attempt"], TICKS(sample, "elapsed_total")
                a27.insist(key not in indexed and artifact_key(sample) == lane, f"Invalid selector sample at {source}/{key}")
                trial = attempts[key[0]]
                last = min(MAX_WAIT, TICKS(trial, "window") - CONNECTED_STEP) // WAIT_STEP * WAIT_STEP
                indexed[key] = sample, last
            sources[source] = indexed
    detail = summary_path.with_name("m29_sensitivity.csv")
    with detail.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            lane = artifact_key(row)
            policy = lane[2]
            source = ROOT.parent / row["source_file"]
            key = row["attempt"], TICKS(row, "elapsed_total")
            sample, last = sources[source][key]
            label = f"{source}/{key}"
            a27.insist(artifact_key(sample) == lane and all(TICKS(row, name) == TICKS(sample, name)
                        for name in ("observed_until", "wait_elapsed")), f"Sensitivity acquisition mismatch at {label}")
            wait = TICKS(sample, "wait_elapsed")
            at_limit = wait == last
            field = row["perturbed_input"]
            a27.insist(field == "q" or (field == "q0" and policy == "P3"), f"Unexpected sensitivity input at {label}")
            delta = NUMBER(row, f"delta_{field}")
            token = source, key, field, delta
            a27.insist(delta in Q_PERTURBATIONS and token not in consumed, f"Missing or repeated isolated perturbation at {label}")
            consumed.add(token)
            delta_q = delta if field == "q" else 0.0
            delta_q0 = delta if field == "q0" else 0.0
            q = NUMBER(sample, "q")
            q0 = NUMBER(sample, "q0") if policy == "P3" else 0.0
            revised_q, revised_q0 = q + delta_q, q0 + delta_q0
            gate = registered_predicate(policy, PreviousObservation(q0, 0, 0), ReconnectObservation(q, 0, 0, 0), EPSILON_Q)
            revised = registered_predicate(policy, PreviousObservation(revised_q0, 0, 0),
                                           ReconnectObservation(revised_q, 0, 0, 0), EPSILON_Q)
            threshold = max(EPSILON_Q, abs(q0) / 4)
            revised_threshold = max(EPSILON_Q, abs(revised_q0) / 4)
            margin = q - threshold
            numeric = {"q": q, "threshold_q": threshold, "q_minus_threshold": margin, "delta_q": delta_q, "delta_q0": delta_q0,
                       "revised_q": revised_q, "revised_threshold_q": revised_threshold}
            if policy == "P3":
                numeric.update(q0=q0, revised_q0=revised_q0)
            else:
                a27.insist(row["q0"] == row["revised_q0"] == "", f"P4 sensitivity added an absent input at {label}")
            a27.insist(all(NUMBER(row, name) == value for name, value in numeric.items()), f"Sensitivity scalar differs at {label}")
            changed, action_changed = gate != revised, gate != revised and not at_limit
            boolean = {"at_limit": at_limit, "raw_gate": gate, "revised_gate": revised, "changed": changed,
                       "raw_reconnect": gate or at_limit, "revised_reconnect": revised or at_limit,
                       "action_changed": action_changed, "raw_limit_fallback": at_limit and not gate,
                       "revised_limit_fallback": at_limit and not revised}
            a27.insist(all(FLAG(row, name) == value for name, value in boolean.items()), f"Sensitivity outcome differs at {label}")
            stats = counts[(*lane, field, delta)]
            for index, value in enumerate((True, changed, action_changed, revised_threshold != threshold, at_limit,
                                           abs(q) <= EPSILON_Q, policy == "P3" and abs(q0) <= EPSILON_Q, abs(margin) <= EPSILON_Q)):
                stats[index] += int(value)
            stats[-1] = min(stats[-1], abs(margin))
    sample_count = sum(map(len, sources.values()))
    expected_rows = sum(len(samples) * (8 if source.parts[-3] == "P3" else 4) for source, samples in sources.items())
    a27.insist(len(consumed) == expected_rows, "The detailed sensitivity table omits registered sample and perturbation combinations")
    return counts, sample_count


def audit_sensitivity_artifact(summary_path, audits):
    expected = {}
    for report in audits:
        data = json.loads(report.read_text(encoding="utf-8"))["stage_audit"]["branches"]
        for label, branch in data.items():
            for case in branch["perturbation_counts"]:
                key = (*label.split("/"), case["input"], case["delta"])
                a27.insist(key not in expected, f"Duplicate independently audited sensitivity {key}")
                expected[key] = (case["evaluations"], case["predicate_changes"], case["action_changes"])
    published = a27.read_unique(READ_CSV(summary_path), lambda row: (*[row[field] for field in
        ("group", "origin", "policy", "precision", "perturbed_input")], NUMBER(row, "delta")))
    a27.insist(expected.keys() == published.keys(), "Published and independently audited perturbation cases do not agree")
    details, sample_count = audit_sensitivity_details(summary_path, {key[:4] for key in expected})
    a27.insist(details.keys() == expected.keys(), "Detailed perturbation lanes differ from independent trajectory evidence")
    fields = ("evaluated_samples", "predicate_changes", "action_changes", "threshold_changes", "limit_samples",
              "near_q_zero", "near_q0_zero", "near_nominal_threshold", "smallest_abs_q_minus_threshold")
    for key, wanted in expected.items():
        row = published[key]
        actual = tuple(NUMBER(row, field) for field in fields)
        matches = actual == tuple(details[key]) and actual[:3] == wanted and NUMBER(row, "predicate_changes_at_limit_only") == wanted[1] - wanted[2]
        a27.insist(matches, f"Published perturbation summary does not match replay evidence at {key}")
    values = tuple(sum(row[i] for row in expected.values()) for i in range(3))
    return {"summary_records": len(expected), "consumed_samples": sample_count, "detail_rows": values[0],
            "tests": values[0], "changed_predicates": values[1], "changed_immediate_actions": values[2]}


def artifact_key(row):
    return tuple(row[name] for name in ("group", "origin", "policy", "precision"))


def audit_comparison_tables(results):
    baseline_floor = 1e-10
    endpoints = a27.read_unique(READ_CSV(results / "m29_endpoints.csv"), artifact_key)
    candidate_set = tuple(f"P{i}" for i in range(1, 5))
    expected = {(group, origin, policy, label) for group, sources, methods in (
        ("F2-R", ORIGINS, (*RP_AND_P, "R0", "R1", "R3", "RH", "E")),
        ("F1", ORIGINS, (*RP_AND_P, "R0", "R1", "R3", "RH", "E")),
        ("unseen", tuple(f"U{i:02d}" for i in range(1, 7)), (*RP_AND_P, "R3", "RH")),
        ("main", ORIGINS, ("F1", "F2-R", "M3", "M4", "M-F3", *(f"F2-R+P{i}" for i in range(1, 5)))))
        for origin in sources for policy in methods for label in RESOLUTIONS}
    a27.insist(set(endpoints) == expected, f"Published endpoints only cover {len(endpoints)} of {len(expected)} lanes")
    groups = defaultdict(list)
    history_fields = ("elapsed_start", "elapsed_total", "tau", "net_work", "accepted")
    with (results / "m29_history.csv").open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            groups[artifact_key(row)].append(tuple(row[item] for item in history_fields))
    stage_a = 0
    anchor_rows = a27.read_unique(READ_CSV(M28 / "anchors" / "m28_anchors.csv"), lambda r: (r["group"], r["origin"], r["precision"]))
    for origin in ORIGINS:
        for precision in RESOLUTIONS:
            fork = TICKS(anchor_rows["F2-R", origin, precision], "fork_elapsed")
            before = branch_history(M28 / "stages", ("main", origin, "F2-R", precision), "m28")
            prefix = [row for row in before if TICKS(row, "elapsed_total") <= fork]
            for policy in candidate_set:
                key = "main", origin, f"F2-R+{policy}", precision
                tail = groups["F2-R", origin, policy, precision]
                expected_stage_a = [tuple(row[field] for field in history_fields) for row in prefix] + tail
                a27.insist(groups[key] == expected_stage_a and TICKS(endpoints[key], "elapsed_total") == a27.CAP,
                           f"Stage A publication does not reproduce the actual split control at {key}")
                stage_a += 1
    common = READ_CSV(results / "m29_time_comparison.csv")
    late = READ_CSV(results / "m29_late_work.csv")
    for row in [*common, *late, *endpoints.values()]:
        key = artifact_key(row)
        begin, stop, fork = (TICKS(row, item) for item in ("interval_start", "elapsed_total", "fork_elapsed"))
        ledger = groups[key]
        observed = [piece for piece in ledger if round(float(piece[1]) * 1000) <= stop]
        interval = [piece for piece in observed if round(float(piece[1]) * 1000) > begin]
        total_net = math.fsum(float(piece[3]) for piece in observed)
        interval_net = math.fsum(float(piece[3]) for piece in interval)
        waiting = math.fsum(max(0.0, min(stop / 1000, float(start) + float(tau)) - float(start)) for start, _, tau, _, _ in ledger)
        accepted = [piece for piece in observed if piece[4] == "True"]
        expect = {"cumulative_net": total_net, "interval_net": interval_net, "count": len(accepted),
                  "tiny_count": sum(float(piece[3]) <= 1e-8 for piece in accepted), "cumulative_wait": waiting}
        if stop > fork:
            expect["cumulative_rate"] = 1000 * total_net / (stop - fork)
        if stop > begin:
            expect["interval_rate"] = 1000 * interval_net / (stop - begin)
        for field, value in expect.items():
            a27.tolerance(row[field], value, f"Independent published {field} for {key}/{stop}", 1e-10 if field == "cumulative_wait" else 1e-12)
    comparisons = a27.read_unique(READ_CSV(results / "m29_condition_comparison.csv"), artifact_key)
    meets = {}
    for key, row in comparisons.items():
        group, origin, policy, precision = key
        reference = NUMBER(endpoints[group, origin, "RP", precision], "cumulative_net")
        value = NUMBER(endpoints[key], "cumulative_net")
        ratio = value / reference if reference > baseline_floor else None
        a27.tolerance(row["delta_net_from_rp"], value - reference, f"Published reference difference at {key}")
        if ratio is not None:
            a27.tolerance(row["ratio_to_rp"], ratio, f"Published reference ratio for {key}")
        else:
            a27.insist(not row["ratio_to_rp"], f"Published near-zero reference ratio at {key}")
        allowed = value >= .90 * reference if ratio is not None else reference - value <= baseline_floor
        a27.insist(FLAG(row, "absolute_rule_used") == (ratio is None) and FLAG(row, "retains_state_minimum") == allowed,
                   f"Wrong individual engineering criterion at {key}")
        meets[key] = value, reference, allowed
    maintenance = a27.read_unique(READ_CSV(results / "m29_maintenance.csv"), lambda row: (row["group"], row["policy"], row["precision"]))
    a27.insist(set(maintenance) == {(group, policy, precision) for group in ("F2-R", "F1", "unseen")
               for policy in candidate_set for precision in RESOLUTIONS}, "Missing state-group engineering criteria")
    verdicts = {}
    for key, row in maintenance.items():
        group, policy, precision = key
        state = [entry for (g, _, method, step), entry in meets.items() if (g, method, step) == key]
        a27.insist(len(state) == int(row["origins"]), f"Uses incomplete origin group at {key}")
        work, ref = (math.fsum(item[i] for item in state) / len(state) for i in (0, 1))
        ratio = work / ref if ref > baseline_floor else None
        if ratio is not None:
            a27.tolerance(row["ratio_of_means"], ratio, f"Published ratio of means at {key}")
        else:
            a27.insist(not row["ratio_of_means"], f"Unstable group mean ratio at {key}")
        mean_pass = work >= .95 * ref if ratio is not None else ref - work <= baseline_floor
        all_pass = all(entry[2] for entry in state)
        verdicts[key] = mean_pass and all_pass
        a27.insist(FLAG(row, "mean_95_pass") == mean_pass and FLAG(row, "all_states_90_pass") == all_pass
                   and FLAG(row, "step_criterion_pass") == verdicts[key], f"Wrong group retention criterion at {key}")
    for key, row in maintenance.items():
        group, policy, precision = key
        other = verdicts[group, policy, "half" if precision == "coarse" else "coarse"]
        a27.insist(FLAG(row, "coarse_half_judgment_agrees") == (other == verdicts[key])
                   and FLAG(row, "simplification_accepted") == (other and verdicts[key]), f"Wrong cross-step decision at {key}")
    return {"published_endpoints": len(endpoints), "common_time_rows": len(common), "late_rows": len(late),
            "matched_reference_comparisons": len(comparisons), "engineering_judgments": len(maintenance), "stage_a_composites": stage_a}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stages", nargs="?", type=Path)
    parser.add_argument("--control", type=Path)
    parser.add_argument("--unseen", type=Path)
    parser.add_argument("--anchors", type=Path, default=ROOT / "anchors")
    parser.add_argument("--protocol", type=Path, default=ROOT / "PROTOCOL_M29.md")
    parser.add_argument("--groups", nargs="+", choices=("F2-R", "F1", "unseen"), default=("F2-R", "F1"))
    parser.add_argument("--origins", nargs="+", choices=(*ORIGINS, *(f"U{i:02d}" for i in range(1, 7))))
    parser.add_argument("--policies", nargs="+", choices=(*RP_AND_P, "R0", "R1", "R3", "RH"), default=RP_AND_P[1:])
    parser.add_argument("--precisions", nargs="+", choices=RESOLUTIONS, default=RESOLUTIONS)
    parser.add_argument("--cutoffs", nargs="+", type=int, default=(150, 300, 540))
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--uninterrupted", type=Path)
    parser.add_argument("--reference", type=Path)
    parser.add_argument("--whole", type=Path)
    parser.add_argument("--whole-stage-root", type=Path, default=ROOT / "stages")
    parser.add_argument("--sensitivity-summary", type=Path)
    parser.add_argument("--formal-audits", nargs="+", type=Path)
    parser.add_argument("--comparison-tables", type=Path)
    parser.add_argument("--branch-reports", type=Path)
    parser.add_argument("--supplement-formal-report", type=Path)
    parser.add_argument("--merge-formal-reports", nargs="+", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.supplement_formal_report:
        result = supplement_formal_report(args.stages or ROOT / "stages", args.supplement_formal_report, args.protocol)
        write_audit(args.output or args.supplement_formal_report, result)
        return
    if args.merge_formal_reports:
        a27.insist(len(args.merge_formal_reports) >= 2 and args.output, "Merging needs two native reports and an output path")
        write_audit(args.output, merge_formal_reports(args.stages or ROOT / "stages", args.merge_formal_reports, args.protocol))
        return
    result = {"baseline_q_resolution": baseline_q_resolution()}
    if args.control:
        result["scalar_controller_boundary"] = audit_controller_interface(args.control)
        result["restricted_acquisition_adapter"] = audit_acquisition_adapter()
    if args.unseen:
        result["unseen_preparations"] = audit_unseen(args.unseen, args.anchors, args.protocol)
    if args.whole:
        result["whole_horizon"] = audit_whole(args.whole_stage_root, args.whole)
    if args.sensitivity_summary:
        a27.insist(args.formal_audits, "Sensitivity summary validation requires independently audited trajectories")
        result["published_sensitivity"] = audit_sensitivity_artifact(args.sensitivity_summary, args.formal_audits)
    if args.comparison_tables:
        result["published_comparisons"] = audit_comparison_tables(args.comparison_tables)
    if args.stages:
        digest = a27.sha256(args.protocol)
        for root in (p for p in (args.stages, args.uninterrupted, args.reference) if p):
            a27.insist((root / "protocol.sha256").read_text(encoding="utf-8").strip() == digest, f"Frozen protocol differs at {root}")
        cutoffs = tuple(time * 1000 for time in args.cutoffs)
        a27.insist(tuple(sorted(set(cutoffs))) == cutoffs and 0 < cutoffs[0] <= cutoffs[-1] <= a27.CAP and args.workers > 0, "Invalid audit runtime options")
        origins = args.origins or (*ORIGINS, *(f"U{i:02d}" for i in range(1, 7)))
        result.update(protocol_sha256=digest, cutoffs=args.cutoffs)
        def publish_branch(key, branch):
            label = "/".join(key)
            write_audit(args.branch_reports / ("_".join(key) + ".json"), {**result, "stage_audit": {"branches": {label: branch}}})

        result["stage_audit"] = audit_stages(args.stages, cutoffs, args.groups, origins, args.policies, args.precisions, args.anchors, args.workers,
                                              publish_branch if args.branch_reports else None)
        if args.uninterrupted or args.reference:
            result["p3_benchmark_replay"] = check_benchmark_replay(args.stages, args.uninterrupted, args.reference, cutoffs, args.precisions)
    if args.output:
        write_audit(args.output, result)
    else:
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
