# M29 再現手順

既存4起点と未使用の6準備を用い、再接続条件を削減した制御を経過540まで比較する。 [正式報告書](MILESTONE_29_MINIMAL_INFORMATION_AND_GENERALIZATION_REPORT.md) [事前固定プロトコル](PROTOCOL_M29.md)

## 環境と実行順序

実行環境はWindows PowerShell、Python 3.14、NumPy 2.5.5、Matplotlib 3.10.9。M27・M28と、その依存マイルストーンを配布時の相対位置に置く。短縮計算でも計画上の期限は540を維持する。正式計算は150・300・540で保存し、メモリに応じてワーカー数を調整する。

```powershell
py -3.14 -m pip install 'numpy==2.5.5' 'matplotlib==3.10.9'
Set-Location Milestone_29
$env:OPENBLAS_NUM_THREADS = '1'
py -3.14 -B run_m29.py --stages redo/benchmark/stages --groups F2-R --origins S0 --cutoffs 100 120 --workers 2
py -3.14 -B run_m29.py --stages redo/benchmark/uninterrupted --groups F2-R --origins S0 --policies P3 --cutoffs 120 --workers 2
py -3.14 -B run_m29.py --stages redo/benchmark/reference --groups F2-R --origins S0 --policies P3 --cutoffs 120 --reference-projector --workers 2
py -3.14 -B benchmark_m29.py --benchmark redo/benchmark
py -3.14 -B run_m29.py --stages redo/stages --workers 8 --reuse
```

未使用の入力を再生成する場合は、既存ファイルを読み取り専用の比較対象として、再生成先を新しく指定する。方式の入力は既存のアンカーと未使用状態の登録情報から読み込む。 [未使用状態の準備手順](PREPARE_UNSEEN_M29.md)

続いて、全経過の台帳と微小摂動、共通時刻表、図を生成し、独立監査を実行する。

```powershell
py -3.14 -B analyze_m29.py --stages redo/stages --output redo/results
py -3.14 -B collect_m29.py --stages redo/stages --output redo/results
py -3.14 -B plot_m29.py --data redo/results --output redo/figures
py -3.14 -B verify_m29.py redo/benchmark/stages --origins S0 --groups F2-R --cutoffs 100 120 --uninterrupted redo/benchmark/uninterrupted --reference redo/benchmark/reference --output redo/benchmark/audit_independent.json
py -3.14 -B verify_m29.py redo/stages --groups F2-R --workers 4 --output redo/results/audit_f2r.json
py -3.14 -B verify_m29.py redo/stages --groups F1 --workers 4 --output redo/results/audit_f1.json
py -3.14 -B verify_m29.py redo/stages --groups unseen --policies RP P1 P2 P3 P4 R3 RH --workers 4 --output redo/results/audit_unseen.json
py -3.14 -B verify_m29.py --control m29_control.py --output redo/benchmark/audit_gate_inputs.json
py -3.14 -B verify_m29.py --unseen unseen --output redo/results/audit_unseen_preparations.json
py -3.14 -B verify_m29.py --whole redo/results --whole-stage-root redo/stages --output redo/results/audit_whole.json
py -3.14 -B verify_m29.py --sensitivity-summary redo/results/m29_sensitivity_summary.csv --formal-audits redo/results/audit_f2r.json redo/results/audit_f1.json redo/results/audit_unseen.json --comparison-tables redo/results --output redo/results/audit_publication.json
py -3.14 -B verify_m29.py --comparison-tables redo/results --output redo/results/audit_tables.json
```

保存点は枝ごとに確定したとき公開する。同じ出力先・計算条件で再実行すると、既に確定した枝を読み込み、続きの計算を行う。`checkpoint.npz` の `coarse`・`half` は保存境界、`anchor_coarse`・`anchor_half` は最後に完了した試行直後の密度。`pending` は境界までに観測済みの未完了操作を表す。`equivalent_policy.json` がある段階では、同じ初期状態の軌道上で各再接続時刻が同じことを再生し、源のファイルをハッシュで特定した。`--reuse` を外すと新方式を直接再計算する。

## データと単位

| 場所 | 内容 |
| --- | --- |
| `unseen/`、`anchors/unseen/` | 準備レシピ、物理性、計算台帳、トレース距離、密度とハッシュ |
| `stages/t*/.../m29_history.csv` | 分岐後の全試行と採否、切断・再接続入力、正味仕事と分岐からの累積 |
| `stages/t*/.../m29_selector.csv` | P1〜P4の許可されたスカラー、判定時計、閾値、再接続理由 |
| `stages/t*/.../m29_wait_checks.csv` | 待機中の局所観測と事後診断。条件に使った量は `m29_selector.csv` を参照 |
| `stages/t*/.../m29_observations.csv` と `m29_checkpoints.csv` | 接続中のA用観測とその時計、保存境界と再開照合 |
| `results/m29_whole_history.csv` と `m29_whole_switches.csv` | 原点からのF2-R、F1、M3、M4、M-F3の台帳と切替 |
| `results/m29_sensitivity.csv` | 状態と時計を固定した虚部判定への単点摂動 |
| `results/m29_time_comparison.csv`、`m29_endpoints.csv`、`m29_late_work.csv` | 共通時刻、終点、経過300から540の仕事と時間率 |
| `results/m29_condition_comparison.csv`、`m29_maintenance.csv`、`m29_fixed_comparison.csv` | 起点別の条件削減、性能維持の集計、固定待機・履歴適応との比較 |
| `results/m29_information.csv`、`m29_pareto.csv`、`m29_chronology.csv` | 必要情報、情報負担対回収仕事、粗半刻みの操作・判定の照合 |
| `results/audit_*.json`、`figures/` | 独立監査、成果図9枚 |

`elapsed_total` は各評価原点からの経過。既存の分岐群は `fork_elapsed` までの仕事を分岐の累積に含めない。未使用状態では評価時計を準備後にゼロから始める。`net_work` は系からの回収を正、`cut_on`・`reconnect_on` は系への入力を正とする。`decision_observations` は待機判定で使った観測点数、`observed_scalars` はその取得に必要な実成分の数。いずれも接続中のA停止に必要な観測を含めない。

共通時刻表には、完了試行を集計した `cumulative_net` と、その時点ですでに実行した未完了試行の切断・再接続を含む `cumulative_physical_net` を記載する。終点と区間率の主比較にはM28と同じ完了試行ベースの定義を使う。採択した負荷受動化と、見送った試行も含む符号付き切断・再接続入力を台帳で照合できる。

## 図

1. [条件削減の段階と回収性能](figures/m29_01_simplification_and_recovery.png)
2. [既存アンカーにおけるRP・P1〜P4の累積仕事](figures/m29_02_cumulative_work_from_legacy_anchors.png)
3. [虚部を用いた再接続判定](figures/m29_03_imaginary_component_wait_decisions.png)
4. [起点別の性能維持率](figures/m29_04_statewise_retention.png)
5. [固定待機3との比較](figures/m29_05_fixed_wait_three_comparison.png)
6. [未使用状態の回収性能](figures/m29_06_unseen_state_work.png)
7. [観測情報・観測回数と回収仕事](figures/m29_07_observations_and_work.png)
8. [簡素さと回収性能のパレート比較](figures/m29_08_pareto_simplicity_and_recovery.png)
9. [粗刻み・半刻みの判定一致](figures/m29_09_coarse_half_agreement.png)
