"""Run same-state continuations with the registered M29 information limits."""

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
M28 = ROOT.parent / "Milestone_28"
sys.path.insert(0, str(M28))
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import run_m28 as stage
from run_m28_oracle import work_projection_groups
from m29_control import EPSILON_Q, RELATIVE, p1, p2, p3, p4
import numpy as np

physics = stage.physics
Job = stage.Job
HORIZON, GRID, TOTAL_LIMIT = stage.HORIZON, stage.GRID, stage.TOTAL_LIMIT
KERNEL_CONTROLS = ("P1", "P2", "P3", "P4")
GROUPS = ("F2-R", "F1", "unseen")
UNSEEN = tuple(f"U{i:02d}" for i in range(1, 7))
UNSEEN_CONTROLS = ("RP", *KERNEL_CONTROLS, "R3", "RH")
BASE_WAIT = physics.wait_until
BASE_NEXT = stage.next_trial
BASE_COMMIT = stage.commit
ORIGINAL_LEDGER = stage.Ledger


class ReducedProjection:
    """Project the reduced load density and exchange block needed by A."""

    def __init__(self, dynamics, spectrum, dt, *, with_rate):
        if with_rate or spectrum.ndim != 2:
            raise ValueError("The alternative projection handles a single A observation stream")
        self.model, self.dt = dynamics, dt
        self.length = dynamics.horizon // GRID + 1
        self.groups = []
        for left, right, pairs, weights in work_projection_groups(dynamics):
            rows, columns = np.asarray(pairs).T
            coefficient = np.ascontiguousarray(spectrum[left, right, None] * weights)
            self.groups.append((rows, columns, coefficient))

    def prefix(self, length):
        if not 1 <= length <= self.length:
            raise ValueError("Observation prefix exceeds the available lattice")
        block = 32
        for first in range(0, length, block):
            stop = min(first + block, self.length)
            terminal = np.zeros((stop - first, 6, 6), dtype=np.complex128)
            for index, (rows, columns, weights) in enumerate(self.groups):
                observed = self.model.time_kernel(index, self.dt)[first:stop] @ weights
                terminal[:, rows, columns] = observed
                terminal[:, columns, rows] = observed.conj()
            for sample in terminal[:min(stop, length) - first]:
                yield sample, None


def eligible_sample(policy, initial, measured):
    """Acquisition adapter. Each verdict below receives only its allowed values."""
    q = -float(measured["c_imag"])
    if policy == "P1":
        amplitude, c0_abs = float(measured["c_abs"]), float(initial["c_abs"])
        return p1(amplitude, q, c0_abs), {"q": q, "amplitude": amplitude, "c0_abs": c0_abs,
                                        "threshold_q": RELATIVE * c0_abs}
    if policy == "P2":
        c0_abs = float(initial["c_abs"])
        return p2(q, c0_abs), {"q": q, "c0_abs": c0_abs, "threshold_q": RELATIVE * c0_abs}
    if policy == "P3":
        q0 = -float(initial["c_imag"])
        return p3(q, q0), {"q": q, "q0": q0, "threshold_q": max(RELATIVE * abs(q0), EPSILON_Q)}
    if policy == "P4":
        return p4(q), {"q": q, "threshold_q": EPSILON_Q}
    raise ValueError(f"No scalar selector for {policy}")


def wait_until(model, pair, primary, start, window, policy, mode, records, cap, fixed_tau, initial):
    if policy not in KERNEL_CONTROLS:
        return BASE_WAIT(model, pair, primary, start, window, policy, mode, records, cap, fixed_tau, initial)
    last = min(6000, window - GRID) // 200 * 200
    if last < 1000:
        return 0, "no_wait_fits", []
    observe = physics.phase_observer(model, pair[primary], physics.DT[primary])
    checks = []
    for delay in range(1000, last + 1, 200):
        if start + delay > cap:
            return None, "phase_limit", checks
        measured = observe(delay)
        gate, _ = eligible_sample(policy, initial, measured)
        reconnect = gate or delay == last
        checks.append({"elapsed_total": (start + delay) / 1000, "observed_until": (start + delay) / 1000,
                       "wait_elapsed": delay / 1000, "phase_gate": gate, "reconnect": reconnect,
                       "actual_current": 0.0, **measured})
        if reconnect:
            return delay, "phase_gate" if gate else "phase_limit", checks
    raise ValueError("The registered wait lattice was exhausted without a decision")


def next_trial(job, model, pair, elapsed, control, records, cap, ending, oracle, rate_floor):
    if job.policy not in KERNEL_CONTROLS or ending != "active" or TOTAL_LIMIT - elapsed < GRID:
        return BASE_NEXT(job, model, pair, elapsed, control, records, cap, ending, oracle, rate_floor)
    window = min(HORIZON, TOTAL_LIMIT - elapsed)
    decision = {"elapsed_total": elapsed / 1000, "observed_until": elapsed / 1000, "reason": job.policy,
                "mode_before": "wait", "mode_after": "wait", "switched": False}
    trial = physics.attempt(model, pair, job.primary, elapsed, window, job.policy, "wait", records, cap)
    return decision, trial, trial.boundary, trial.pending


class Ledger(ORIGINAL_LEDGER):
    def add(self, name, row):
        name = name.replace("m27_", "m28_")
        if name == "m28_history":
            row["cumulative_rate"] = row["cumulative_net"] / (row["elapsed_total"] - row["fork_elapsed"])
            row["record_source"] = "m29"
        physics.Tables.add(self, name.replace("m28_", "m29_"), row)


def selector_rows(policy, row, checks):
    first = {"c_abs": row["c_abs_before"], "c_imag": -float(row["current_before"]) / (2 * physics.G)}
    for check in checks:
        changed, inputs = eligible_sample(policy, first, check)
        if changed != check["phase_gate"]:
            raise ValueError("The recorded permitted inputs do not reproduce the gate")
        yield {**{key: check[key] for key in ("elapsed_total", "observed_until", "wait_elapsed")},
               **{key: inputs.get(key) for key in ("q", "q0", "c0_abs", "amplitude", "threshold_q")},
               "gate": changed, "reconnect": check["reconnect"], "limit": check["reconnect"] and not changed}


def extended_counts(policy, row, checks):
    active = row["tau"] > 0 and policy in ("RP", *KERNEL_CONTROLS)
    reference_count = int(active and policy != "P4")
    measures = len(checks) if active else 0
    now_width = 2 if policy in ("P1", "RP") else 1
    reference_width = 1 if policy == "P3" else 2
    row.update(decision_observations=reference_count + measures,
               observed_scalars=reference_count * reference_width + measures * now_width,
               phase_observations=reference_count + measures, initial_phase_observations=reference_count,
               wait_phase_observations=measures, reconnect_elapsed=row["elapsed_start"] + row["tau"],
               fallback_limit=row["wait_reason"] == "phase_limit", at_max_wait=row["tau"] == 6.0)
    for check in checks:
        check["used_by_control"] = active


def commit(tables, job, meta, decision, trial, work, companion, bound, count, source_time):
    row = trial.row
    extended_counts(job.policy, row, trial.wait_checks)
    if job.policy in KERNEL_CONTROLS:
        for check in selector_rows(job.policy, row, trial.wait_checks):
            tables.add("m29_selector", {**meta, **check})
    return physics.add_attempt(tables, meta, decision, trial, work, companion, bound, count, source_time)


def register(destination):
    digest = hashlib.sha256((ROOT / "PROTOCOL_M29.md").read_bytes()).hexdigest()
    if digest != (ROOT / "protocol.sha256").read_text().strip():
        raise ValueError("M29 protocol changed after registration")
    destination.mkdir(parents=True, exist_ok=True)
    filename = destination / "protocol.sha256"
    if filename.exists() and filename.read_text().strip() != digest:
        raise ValueError("Another protocol is registered here")
    if not filename.exists():
        filename.write_text(digest + "\n", encoding="ascii")


def get_seed(job):
    if job.group == "unseen":
        source, = (row for row in physics.csv_rows(ROOT / "unseen" / "sources.csv") if row["origin"] == job.origin)
    else:
        source = stage.source_for(job.origin)
    return source, stage.branch_seed(job, source)


@contextmanager
def adapters(reduced):
    """Scope the inherited stage runner's extension points to this worker."""
    hooks = ((stage, "Ledger", Ledger), (stage, "next_trial", next_trial), (stage, "commit", commit),
             (physics, "ConnectedObservations", ReducedProjection if reduced else stage.REFERENCE_PROJECTOR),
             (physics, "wait_until", wait_until))
    originals = [(scope, name, getattr(scope, name)) for scope, name, _ in hooks]
    for scope, name, value in hooks:
        setattr(scope, name, value)
    try:
        yield
    finally:
        for scope, name, value in originals:
            setattr(scope, name, value)


def run_job(job, root, cutoffs, *, reduced=True):
    source, seed = get_seed(job)
    model = physics.model_instance()
    if getattr(model, "m29_kernel_precision", None) != job.precision:
        model.time_kernel.cache_clear()
        model.m29_kernel_precision = job.precision
    previous = None
    with adapters(reduced):
        for cap in cutoffs:
            if cap <= seed[1]:
                continue
            destination = root / f"t{cap // 1000}" / job.relative_path()
            if not destination.is_dir():
                summary = stage.run_stage(job, model, source, seed, destination, cap, previous, None, stage.RATE_FLOOR)
                fields = ("group", "origin", "policy", "precision", "elapsed_total", "count", "cumulative_net", "seconds")
                print(json.dumps({field: summary[field] for field in fields}), flush=True)
            elif not (destination / "checkpoint.npz").is_file():
                raise ValueError(f"Incomplete output {destination}")
            previous = destination


def run_cohort(group, origin, step_name, modes, root, cutoffs, reduced, reuse):
    anchors = (ROOT if group == "unseen" else M28) / "anchors"
    for mode in modes:
        job = Job(group, origin, mode, step_name, anchors)
        if reuse and mode in KERNEL_CONTROLS:
            from reuse_m29 import reuse_or_none
            if reuse_or_none(job, root, cutoffs):
                continue
        run_job(job, root, cutoffs, reduced=reduced)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stages", type=Path, default=ROOT / "stages")
    parser.add_argument("--groups", nargs="+", choices=GROUPS, default=GROUPS)
    parser.add_argument("--origins", nargs="+", choices=(*stage.ORIGINS, *UNSEEN))
    parser.add_argument("--policies", nargs="+", choices=UNSEEN_CONTROLS)
    parser.add_argument("--precisions", nargs="+", choices=stage.PRECISIONS, default=stage.PRECISIONS)
    parser.add_argument("--cutoffs", nargs="+", type=int, default=[150, 300, 540])
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--reference-projector", action="store_true")
    parser.add_argument("--reuse", action="store_true")
    args = parser.parse_args()
    if args.cutoffs != sorted(set(args.cutoffs)) or not 1 <= args.cutoffs[0] <= args.cutoffs[-1] <= 540:
        parser.error("Cutoffs must be unique, increasing and in [1, 540]")
    if args.workers < 1:
        parser.error("Workers must be positive")
    register(args.stages)
    cuts = tuple(value * 1000 for value in args.cutoffs)
    jobs = []
    for group in args.groups:
        origins = UNSEEN if group == "unseen" else stage.ORIGINS
        modes = UNSEEN_CONTROLS if group == "unseen" else KERNEL_CONTROLS
        if args.policies:
            modes = tuple(name for name in modes if name in args.policies)
        for step_name in args.precisions:
            for origin in origins:
                if modes and (not args.origins or origin in args.origins):
                    jobs.append((group, origin, step_name, modes, args.stages, cuts, not args.reference_projector, args.reuse))
    if args.workers == 1:
        for arguments in jobs:
            run_cohort(*arguments)
    else:
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            tasks = {pool.submit(run_cohort, *arguments): arguments[:3] for arguments in jobs}
            failures = []
            for future in as_completed(tasks):
                try:
                    future.result()
                except Exception as exc:
                    failures.append(tasks[future])
                    print(f"Stage failed {tasks[future]}: {exc}", file=sys.stderr, flush=True)
            if failures:
                raise RuntimeError(f"Failed cohort jobs {failures}")


if __name__ == "__main__":
    main()
