# M27 再現手順

予報型停止Aと、採択履歴または交換コヒーレンスの位相で待機を決めるF1〜F3を、4起点で経過540まで比較する。方式A・B・C25・Eの正式台帳はM26から読み込む。F1〜F3は粗刻みと半刻みで制御を独立に実行する。条件は [事前固定プロトコル](PROTOCOL_M27.md)、結果は [正式報告書](MILESTONE_27_ADAPTIVE_WORK_EXTRACTION_REPORT.md) にある。

## 環境と入力

Windows PowerShell、Python 3.14、NumPy 2.5.5、Matplotlib 3.10.9を使用した。`Milestone_21`、`Milestone_23`〜`Milestone_26`を配布時と同じ相対位置に置く。初期密度とそのSHA256は `../Milestone_26/results/m26_sources.csv` に登録している。基準入力と物理条件は [M26の再現手順](../Milestone_26/README_M26.md) にも記載されている。

```powershell
py -3.14 -m pip install 'numpy==2.5.5' 'matplotlib==3.10.9'
Set-Location Milestone_27
$env:OPENBLAS_NUM_THREADS = '1'
```

## 実行順序

短縮計算は実験全体の期限を540に保ち、保存上限だけを120にする。正式計算も150・300で同じ窓を維持する。出力先には新しいディレクトリ名を指定する。

```powershell
py -3.14 -B ../Milestone_26/verify_m26.py
py -3.14 -B run_m27.py redo/benchmark --cutoffs 60 120 --origins S0 --workers 4
py -3.14 -B run_m27.py redo/benchmark_uninterrupted --cutoffs 120 --origins S0 --workers 4
py -3.14 -B verify_m27.py redo/benchmark --cutoffs 60 120 --origins S0 --oneshot redo/benchmark_uninterrupted --workers 2 --output redo/benchmark_audit.json
py -3.14 -B run_m27.py redo/stages --cutoffs 150 300 540 --workers 6
py -3.14 -B verify_m27.py redo/stages --workers 4 --output redo/results/audit.json
py -3.14 -B collect_m27.py --runs redo/stages --output redo/results
py -3.14 -B compare_m27_checkpoints.py --stages redo/stages --output redo/results/m27_step_states.csv
py -3.14 -B diagnose_m27.py --stages redo/stages --output redo/results --workers 2
py -3.14 -B verify_m27_diagnostics.py --stages redo/stages --data redo/results
py -3.14 -B plot_m27.py --data redo/results --output redo/figures
```

途中で停止したときは、同じ出力先・保存点・条件で再実行できる。各段階は枝ごとに完了時に保存し、次段階が前段階の `checkpoint.npz` を読み込む。`anchor_coarse`・`anchor_half` は最後の確定試行の直後、`coarse`・`half` は保存境界そのものの密度を表す。`controller`・`records` は確定した制御情報、`pending` は保存時点までに確定した再接続と抽出予定を含む。進行中の試行はアンカーから保存境界までの観測を再生して照合する。`switch_*.npz` は対応時刻での切断直前の密度を保存する。

正式計算のS0/F2を経過540まで連続実行した結果も照合できる。正式計算を終えた後、切替に使う増加率へ正の下限を入れたC04/F2の探索的半刻みを別の出力先へ保存できる。

```powershell
py -3.14 -B run_m27.py redo/uninterrupted --cutoffs 540 --origins S0 --policies F2 --workers 2
py -3.14 -B verify_m27.py redo/stages --workers 4 --oneshot redo/uninterrupted --oneshot-origins S0 --oneshot-policies F2 --output redo/results/audit_oneshot.json
py -3.14 -B explore_m27_rate_floor.py --formal redo/stages --output redo/exploration/rate_floor
```

## 結果ファイル

| 場所 | 内容 |
| --- | --- |
| `results/m27_history.csv` | 全方式の試行、採否、時間、切替入力、仕事と状態量。M26の対照はM26主軌道と同時刻評価の半刻みを含む |
| `results/m27_time_comparison.csv` | 8共通時刻の累積・区間・回数・仕事率・待機時間。時間は起点からのモデル経過 |
| `results/m27_decisions.csv` | 各試行開始時点での率、持続判定、位相、切替の理由と観測済み時刻 |
| `results/m27_waits.csv` と `results/m27_wait_checks.csv` | 実行した待機、位相・コヒーレンスの時系列、再接続時の電流、符号反転と回収仕事 |
| `results/m27_observations.csv` | 接続の0.02格子で抽出までに観測した局所量と予報発行時刻 |
| `results/m27_action_summary.csv` と `results/m27_skip_followups.csv` | 区間別採択、極小仕事、抽出間隔、待機と見送り後の回収 |
| `results/m27_endpoints.csv`、`results/m27_independent_steps.csv`、`results/m27_chronology.csv` | 枝の終端と粗半差、時刻や待機の差 |
| `results/m27_step_states.csv` | 独立制御の粗半間と、同じ操作時刻で揃えた粗半間の全状態トレース距離 |
| `results/m27_gap.csv` と `results/m27_crossovers.csv` | 仕事差の推移と、分解能を超えたリード交代 |
| `results/m27_switch_summary.csv` | 切替時刻とM26でのA/Eの最後のリード交代 |
| `results/m27_checkpoints.csv` と `stages/` | 保存点一覧、状態、確定済み台帳、試行途中の既知予定、切替状態、独立半刻みの枝 |
| `results/m27_states.csv`、`results/m27_state_distances.csv`、`results/m27_branches.csv`、`results/m27_branch_history.csv`、`results/m27_wait_contrasts.csv` | A・E・Fの状態比較、18窓能力、トレース距離、分岐台帳、同一起点での待機比較 |
| `experiment_manifest.json` | 物理・数値条件、起点の出典、登録プロトコルと計算コードのハッシュ |
| `audit_m26_controls.txt`、`verify_m27.py`、`verify_m27_diagnostics.py` | M26対照監査の実行記録、M27の独立監査コード |
| `exploration/rate_floor/` | 増加率下限を加えたC04/F2の探索的計算、条件、正式結果との比較 |
| `figures/` | 主実験と切替診断の10図 |

`net_work` の正は系からの回収、`cut_on` と `reconnect_on` の正は系への入力。`cumulative_net` は互換性のため試行を完了した時点で台帳へ記帳する。試行途中に切断・再接続が生じたときは、`pending_switch_net` が既に物理系と授受した未記帳分を表す。`cumulative_physical_net` は両者の和。`precision=half` のFは自分の観測で選択した軌道で、`*_half_aligned` は粗刻みで選んだ操作を半刻みで同時刻評価した値を表す。
