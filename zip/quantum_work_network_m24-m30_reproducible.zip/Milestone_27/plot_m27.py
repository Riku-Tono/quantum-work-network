"""Render the ten M27 figures from the comparison and diagnostic CSVs."""

import argparse
from bisect import bisect_right
from collections import defaultdict
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator, PercentFormatter

from collect_m27 import ADAPTIVE, ORIGINS, ROOT, csv_rows, ticks


INK = "#19324A"
MUTED = "#546C80"
GRID = "#E4ECF1"
STYLES = {
    "A": ("#275A9C", "o", "-"),
    "B": ("#626B75", "s", ":"),
    "C25": ("#82711C", "v", "--"),
    "E": ("#714692", "D", "-"),
    "F1": ("#B45219", "^", "--"),
    "F2": ("#007A69", "P", "-"),
    "F3": ("#AB3758", "X", "-."),
}
BRANCH_STYLES = {
    "A": STYLES["A"],
    "online_wait": STYLES["F2"],
    "E_retrospective": STYLES["E"],
}
BRANCH_LABELS = {
    "A": "A continued",
    "online_wait": "Online wait",
    "E_retrospective": "E-type retrospective",
}


def load(data, name, *, optional=False):
    path = data / f"m27_{name}.csv"
    return [] if optional and not path.exists() else csv_rows(path)


def group(rows, *fields):
    groups = defaultdict(list)
    for row in rows:
        groups[tuple(row[field] for field in fields)].append(row)
    return groups


def coarse(rows):
    return [row for row in rows if row.get("precision", "coarse") == "coarse"]


def num(row, field):
    value = row.get(field)
    return float(value) if value not in ("", None) else math.nan


def is_true(value):
    return str(value).casefold() in ("true", "1")


def style_axis(axis, *, xlabel="", ylabel="", scientific=False):
    axis.set(xlabel=xlabel, ylabel=ylabel)
    axis.grid(color=GRID, linewidth=0.8, zorder=0)
    axis.spines[["top", "right"]].set_visible(False)
    axis.spines[["left", "bottom"]].set_color("#B2C1CD")
    axis.tick_params(colors=MUTED, labelsize=9)
    axis.xaxis.label.set_color(MUTED)
    axis.yaxis.label.set_color(MUTED)
    if scientific:
        axis.ticklabel_format(axis="y", style="sci", scilimits=(-3, 3), useMathText=True)


def grid(title, caption, *, scientific=False, xlabel="Elapsed model time", ylabel="", sharex=False):
    figure, axes = plt.subplots(2, 2, figsize=(11.7, 7.8), layout="constrained", sharex=sharex)
    figure.suptitle(title + "\n" + caption, x=0.02, ha="left", fontsize=14, color=INK, fontweight="semibold")
    for i, (origin, axis) in enumerate(zip(ORIGINS, axes.flat, strict=True)):
        axis.set_title(origin, loc="left", fontweight="semibold", color=INK, fontsize=11)
        style_axis(axis, xlabel=xlabel if i >= 2 or not sharex else "", ylabel=ylabel if i % 2 == 0 else "",
                   scientific=scientific)
    return figure, dict(zip(ORIGINS, axes.flat, strict=True))


def line(axis, x, y, policy, *, markers=False, style=None, **kwargs):
    color, marker, pattern = style or STYLES[policy]
    axis.plot(x, y, color=color, linestyle=pattern, marker=marker if markers else None,
              linewidth=1.55, markersize=4.2, **kwargs)


def legend(figure, names, *, styles=STYLES, labels=None, extra=()):
    handles = []
    for name in names:
        color, marker, pattern = styles[name]
        handles.append(Line2D([], [], label=(labels or {}).get(name, name), color=color, marker=marker,
                              linestyle=pattern, linewidth=1.55, markersize=4.5))
    handles.extend(extra)
    if handles:
        figure.legend(handles=handles, loc="outside lower center", frameon=False, ncols=min(7, len(handles)))


def empty(axis, message="No records available"):
    axis.text(0.5, 0.5, message, ha="center", va="center", transform=axis.transAxes, color=MUTED, fontsize=10)


def save(figure, output, name):
    figure.savefig(output / f"m27_{name}.png", dpi=180, facecolor="white")
    plt.close(figure)


def event_profiles(ledger, horizon):
    events = {0: (0.0, 0), ticks(horizon): (0.0, 0)}
    paid, count = 0.0, 0
    for row in sorted(ledger, key=lambda r: int(r["attempt"])):
        clock = ticks(row["elapsed_total"])
        if clock > ticks(horizon):
            break
        paid = num(row, "cumulative_net")
        count = int(row["count"])
        events[clock] = paid, count
    events[ticks(horizon)] = paid, count
    elapsed = [tick / 1000 for tick in sorted(events)]
    work, counts = zip(*(events[tick] for tick in sorted(events)), strict=True)
    return elapsed, list(work), list(counts)


def plot_time_profiles(histories, horizon, output):
    series = {name: event_profiles(rows, horizon) for name, rows in histories.items()}
    policies = [policy for policy in STYLES if any((origin, policy) in series for origin in ORIGINS)]
    for kind, title, caption, ylabel in (
        ("01_cumulative_work", "Cumulative net work", "Work credited through each event time", "Net work"),
        ("02_cumulative_rate", "Cumulative work per elapsed time", "Credited work divided by the elapsed time at each point", "Net work / time"),
    ):
        figure, axes = grid(title, caption, scientific=True, ylabel=ylabel, sharex=True)
        for origin, axis in axes.items():
            axis.set_xlim(0, horizon)
            plotted = False
            for policy in policies:
                if (origin, policy) not in series:
                    continue
                plotted = True
                elapsed, work, _ = series[origin, policy]
                if kind.startswith("01"):
                    line(axis, elapsed, work, policy, drawstyle="steps-post")
                else:
                    x, rate = [], []
                    for before, after, earned, next_earned in zip(elapsed, elapsed[1:], work, work[1:]):
                        points = [before + fraction * (after - before) / 6 for fraction in range(7)]
                        x.extend([*points, after])
                        rate.extend([*(earned / t if t else 0.0 for t in points), next_earned / after])
                    line(axis, x, rate, policy)
            if not plotted:
                empty(axis)
        legend(figure, policies)
        save(figure, output, kind)
    return series


def plot_interval_rates(comparisons, output):
    groups = group(comparisons, "origin", "policy")
    figure, axes = grid("Work per unit time within each common interval",
                        "Each point is centered in its interval and uses the full interval width.",
                        scientific=True, ylabel="Interval net work / time", sharex=True)
    for (origin, policy), rows in groups.items():
        ordered = sorted(rows, key=lambda row: num(row, "elapsed_total"))
        for row in ordered:
            start, end = num(row, "interval_start"), num(row, "elapsed_total")
            rate = num(row, "interval_rate")
            axis = axes[origin]
            line(axis, [start, end], [rate, rate], policy)
            color, marker, _ = STYLES[policy]
            axis.scatter((start + end) / 2, rate, s=23, color=color, marker=marker, zorder=3)
    legend(figure, [policy for policy in STYLES if any((origin, policy) in groups for origin in ORIGINS)])
    save(figure, output, "03_interval_rate")


def plot_extractions(profiles, summaries, output):
    figure, axes = plt.subplots(4, 2, figsize=(11.7, 9), layout="constrained", sharex="col")
    figure.suptitle("Extraction count and tiny-work fraction\nTiny work is accepted net work at or below $10^{-8}$.",
                    x=0.02, ha="left", color=INK, fontsize=14, fontweight="semibold")
    groups = group([row for row in summaries if row["range"] == "common_interval"], "origin", "policy")
    policies = [policy for policy in STYLES if any((origin, policy) in profiles for origin in ORIGINS)]
    for i, origin in enumerate(ORIGINS):
        left, right = axes[i]
        left.set_title(f"{origin} · cumulative extraction count", loc="left", color=INK, fontsize=10)
        right.set_title(f"{origin} · tiny-work share in each interval", loc="left", color=INK, fontsize=10)
        style_axis(left, xlabel="Elapsed model time" if i == 3 else "")
        style_axis(right, xlabel="Interval end time" if i == 3 else "")
        left.yaxis.set_major_locator(MaxNLocator(integer=True, nbins=4))
        right.yaxis.set_major_formatter(PercentFormatter(1))
        right.set_ylim(-0.04, 1.04)
        for policy in policies:
            profile = profiles.get((origin, policy))
            if profile:
                elapsed, _, count = profile
                line(left, elapsed, count, policy, drawstyle="steps-post")
            rows = groups.get((origin, policy), [])
            if rows:
                line(right, [num(row, "elapsed_total") for row in rows],
                     [num(row, "tiny_work_fraction") for row in rows], policy, markers=True)
    legend(figure, policies)
    save(figure, output, "04_extractions_and_tiny_work")


def plot_switches(rows, summary, output):
    figure, axes = grid("Adaptive switching and the moving work rate",
                        "Filled markers show coarse mode changes. The vertical line marks the last M26 A/E lead change.",
                        scientific=True, ylabel="Moving net work / time", sharex=True)
    main = coarse(rows)
    groups = group(main, "origin", "policy")
    coarse_switches = {(r["origin"], r["policy"], ticks(r["elapsed_total"]), r["mode_after"])
                       for r in main if is_true(r["switched"])}
    half_only = [r for r in rows if r["precision"] == "half" and is_true(r["switched"])
                 and (r["origin"], r["policy"], ticks(r["elapsed_total"]), r["mode_after"]) not in coarse_switches]
    archived = {row["origin"]: num(row, "m26_last_ae_crossover_elapsed") for row in summary}
    known = []
    for origin, axis in axes.items():
        present = False
        for policy in ADAPTIVE:
            history = sorted(groups.get((origin, policy), ()), key=lambda row: num(row, "elapsed_total"))
            if history:
                present = True
                known.append(policy)
                times = [num(row, "elapsed_total") for row in history]
                rate = [num(row, "moving_rate") for row in history]
                baseline = [num(row, "baseline_rate") for row in history]
                line(axis, times, rate, policy)
                color, _, _ = STYLES[policy]
                if any(math.isfinite(value) and value > 0 for value in baseline):
                    axis.plot(times, baseline, color=color, linewidth=0.7, alpha=0.32, linestyle=":")
                for when, value, row in zip(times, rate, history, strict=True):
                    if is_true(row.get("switched", "")):
                        color, marker, _ = STYLES[policy]
                        axis.scatter(when, value, color=color, marker=marker, s=52, edgecolor="white", linewidth=0.65,
                                     zorder=5)
        if not present:
            empty(axis, "No adaptive decision records")
        elif origin in archived and math.isfinite(archived[origin]) and archived[origin] <= axis.get_xlim()[1]:
            axis.axvline(archived[origin], color=MUTED, linestyle="--", linewidth=1, zorder=1)
    for row in half_only:
        axis = axes[row["origin"]]
        color, marker, _ = STYLES[row["policy"]]
        axis.scatter(num(row, "elapsed_total"), num(row, "moving_rate"), facecolor="white", edgecolor=color,
                     marker=marker, s=61, linewidth=1.1, zorder=6)
    auxiliary = [
        Line2D([], [], color=MUTED, linestyle=":", label="Initial rate"),
        Line2D([], [], color=MUTED, linestyle="--", label="Last M26 A/E lead change"),
    ]
    if half_only:
        auxiliary.append(Line2D([], [], color=MUTED, marker="o", markerfacecolor="white", linestyle="none",
                                label="Half-step mode change"))
    legend(figure, list(dict.fromkeys(known)), extra=auxiliary if known else ())
    save(figure, output, "05_switches_and_moving_rate")


def plot_waits(rows, output):
    figure, axes = plt.subplots(2, 2, figsize=(11.7, 7.8), layout="constrained")
    figure.suptitle("Cut waits, exchange phase, and exchange current\nOne point per positive cut wait across the four origins.",
                    x=0.02, ha="left", color=INK, fontsize=14, fontweight="semibold")
    panels = (
        ("tau", "phase_change", "Cut wait duration", "Circular phase change (rad)", False),
        ("phase_after", "current_after", "Phase at reconnection (rad)", "Current after reconnection", True),
        ("tau", "current_after", "Cut wait duration", "Current after reconnection", True),
        ("tau", "net_work", "Cut wait duration", "Subsequent net work", True),
    )
    groups = group(rows, "policy")
    policies = [policy for policy in ADAPTIVE if (policy,) in groups]
    for axis, (xf, yf, xlabel, ylabel, scientific) in zip(axes.flat, panels, strict=True):
        style_axis(axis, xlabel=xlabel, ylabel=ylabel, scientific=scientific)
        present = False
        for policy in policies:
            finite = [(num(row, xf), num(row, yf)) for row in groups[policy,]]
            finite = [(x, y) for x, y in finite if math.isfinite(x) and math.isfinite(y)]
            if finite:
                color, marker, _ = STYLES[policy]
                axis.scatter(*zip(*finite, strict=True), color=color, marker=marker, s=22, alpha=0.68)
                present = True
        if not present:
            empty(axis, "No cut waits recorded")
    legend(figure, policies)
    save(figure, output, "06_wait_phase_and_current")


def plot_capacity(rows, output):
    groups = group(rows, "origin", "source_policy")
    figure, axes = grid("Recoverable work in a common 18-unit diagnostic window",
                        "States are matched at each adaptive first switch. Points show retrospective single-extraction work.",
                        scientific=True, ylabel="Maximum single-extraction net work", sharex=True)
    policies = [policy for policy in STYLES if any((origin, policy) in groups for origin in ORIGINS)]
    for origin, axis in axes.items():
        present = False
        for policy in policies:
            history = groups.get((origin, policy), [])
            if history:
                present = True
                color, marker, _ = STYLES[policy]
                marker_style = {"facecolor": "white", "edgecolor": color, "s": 77} if policy == "A" else {
                    "color": color, "s": 28 if policy in ADAPTIVE else 59,
                }
                axis.scatter([num(row, "elapsed_total") for row in history],
                             [num(row, "diagnostic_work") for row in history], marker=marker, alpha=0.8, **marker_style)
        if not present:
            empty(axis, "No first-switch snapshots")
    legend(figure, policies)
    save(figure, output, "07_diagnostic_capacity")


def plot_gaps(gaps, crossovers, output):
    groups = group(gaps, "origin", "left", "right")
    marks = group(crossovers, "origin", "left", "right")
    columns = [reference for reference in ("A", "E") if any(reference in (left, right) for _, left, right in groups)]
    figure, axes = plt.subplots(4, max(1, len(columns)), figsize=(11.7, 10.0), layout="constrained",
                                sharex=True, squeeze=False)
    figure.suptitle("Cumulative work differences and lead changes\nOpen circles mark a change in the resolved leader.",
                    x=0.02, ha="left", color=INK, fontsize=14, fontweight="semibold")
    plotted = set()
    for i, origin in enumerate(ORIGINS):
        for j, reference in enumerate(columns):
            axis = axes[i, j]
            axis.set_title(f"{origin} · difference from {reference}", loc="left", color=INK, fontsize=10)
            style_axis(axis, xlabel="Elapsed model time" if i == 3 else "", ylabel="Net work difference" if j == 0 else "",
                       scientific=True)
            axis.axhline(0, color=MUTED, linewidth=0.75)
            for policy in ("E", *ADAPTIVE):
                if policy == reference:
                    continue
                key = (origin, policy, reference)
                sign = 1
                if key not in groups:
                    key = (origin, reference, policy)
                    sign = -1
                if key not in groups:
                    continue
                plotted.add(policy)
                data = groups[key]
                line(axis, [num(row, "elapsed_total") for row in data], [sign * num(row, "gap") for row in data],
                     policy, drawstyle="steps-post")
                events = marks.get(key, [])
                if events:
                    axis.scatter([num(row, "elapsed_total") for row in events], [sign * num(row, "gap") for row in events],
                                 s=17, edgecolor=STYLES[policy][0], facecolor="white", linewidth=0.85, zorder=4)
    legend(figure, [policy for policy in STYLES if policy in plotted])
    save(figure, output, "08_work_gaps_and_crossovers")


def plot_branches(rows, output):
    groups = group(rows, "origin", "switch_policy", "branch")
    figure, axes = grid("Work recovered after branching at the first switch",
                        "Colors show continuation rules. Each curve uses the same starting state as its siblings.",
                        scientific=True, xlabel="Elapsed time since switch", ylabel="Additional net work", sharex=True)
    for origin, axis in axes.items():
        present = False
        for policy in ADAPTIVE:
            for branch, style in BRANCH_STYLES.items():
                data = sorted(groups.get((origin, policy, branch), []), key=lambda row: num(row, "elapsed_since_switch"))
                if data:
                    present = True
                    line(axis, [num(row, "elapsed_since_switch") for row in data],
                         [num(row, "cumulative_net") for row in data], branch, markers=True,
                         style=(style[0], STYLES[policy][1], style[2]))
        if not present:
            empty(axis, "No branch diagnostics")
    marker_handles = [Line2D([], [], color=INK, marker=STYLES[policy][1], linestyle="none", markersize=5, label=policy)
                      for policy in ADAPTIVE if any(key[1] == policy for key in groups)]
    if groups:
        legend(figure, BRANCH_STYLES, styles=BRANCH_STYLES, labels=BRANCH_LABELS, extra=marker_handles)
    save(figure, output, "09_switch_branches")


def plot_ergotropy(rows, output):
    groups = group(rows, "origin", "source_policy")
    figure, axes = grid("Remaining global ergotropy and recoverable work",
                        "Global ergotropy uses the connected Hamiltonian for all matched states.",
                        scientific=True, xlabel="Full-system ergotropy (connected)", ylabel="Maximum single-extraction net work")
    policies = [policy for policy in STYLES if any((origin, policy) in groups for origin in ORIGINS)]
    for origin, axis in axes.items():
        present = False
        for policy in policies:
            data = groups.get((origin, policy), [])
            if data:
                present = True
                color, marker, _ = STYLES[policy]
                marker_style = {"facecolor": "white", "edgecolor": color, "s": 77} if policy == "A" else {
                    "color": color, "s": 28 if policy in ADAPTIVE else 59,
                }
                axis.scatter([num(row, "connected_global_ergotropy") for row in data],
                             [num(row, "diagnostic_work") for row in data], marker=marker, alpha=0.8, **marker_style)
        if not present:
            empty(axis, "No first-switch snapshots")
    legend(figure, policies)
    save(figure, output, "10_global_ergotropy_and_capacity")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=ROOT / "results")
    parser.add_argument("--diagnostics", type=Path, help="Read state and branch tables from a separate directory")
    parser.add_argument("--output", type=Path, default=ROOT / "figures")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "text.color": INK, "legend.labelcolor": INK})

    history = group(coarse(load(args.data, "history")), "origin", "policy")
    common = coarse(load(args.data, "time_comparison"))
    horizon = max(num(row, "elapsed_total") for row in common)
    diagnostics = args.diagnostics or args.data
    profiles = plot_time_profiles(history, horizon, args.output)
    plot_interval_rates(common, args.output)
    plot_extractions(profiles, coarse(load(args.data, "action_summary")), args.output)
    plot_switches(load(args.data, "decisions", optional=True),
                  coarse(load(args.data, "switch_summary", optional=True)), args.output)
    plot_waits(coarse(load(args.data, "waits", optional=True)), args.output)
    states = coarse(load(diagnostics, "states", optional=True))
    plot_capacity(states, args.output)
    plot_gaps(load(args.data, "gap"), load(args.data, "crossovers"), args.output)
    plot_branches(coarse(load(diagnostics, "branches", optional=True)), args.output)
    plot_ergotropy(states, args.output)


if __name__ == "__main__":
    main()
