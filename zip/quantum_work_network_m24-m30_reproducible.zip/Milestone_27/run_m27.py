"""Run causal adaptive extraction and restart on physical checkpoint boundaries."""

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict, dataclass
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parent
M26 = ROOT.parent / "Milestone_26"
sys.path.insert(0, str(M26))
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

from run_m26 import M23, ORIGINS, TOTAL_LIMIT
from run_m25 import fingerprint, half_physicality, source_pair
from m25_diagnostics import state_metrics
from m23_spectral import DT, EXCHANGE_LOWER, FLOOR, G, GRID, HALF_TOL, HORIZON, Dynamics, local_diagnostics, maxabs, partial, rk_steps
from m24_physics import ConnectedObservations, observe_local
from m24_rules import FORECAST, targets
from m26_snapshots import Snapshot, continue_passively
from run_m23 import Tables, account, csv_rows

import numpy as np

from m27_control import POLICIES, Controller, angle_delta, empirical_wait, phase_reconnect, tick

PRECISIONS = ("coarse", "half")
SOURCE_TABLE = M26 / "results" / "m26_sources.csv"
OBSERVED = ("load_ergotropy", "load_ergotropy_rate", "load_current", "c_abs", "c_real", "c_imag", "total_work")
MODEL = None


def model_instance():
    global MODEL
    if MODEL is None:
        MODEL = Dynamics(HORIZON)
    return MODEL


def observation(values):
    measured = {key: float(values[key]) for key in OBSERVED}
    measured["phase"] = math.atan2(measured["c_imag"], measured["c_real"])
    return measured


def phase_observer(model, rho, dt):
    basis = model.bases[0]
    if not hasattr(model, "m27_cut_exchange"):
        operator = np.kron(np.eye(len(rho) // len(EXCHANGE_LOWER)), EXCHANGE_LOWER)
        weights = (basis.tr @ operator @ basis.vectors).T
        index = np.nonzero(weights)
        model.m27_cut_exchange = (index, weights[index])
    index, weights = model.m27_cut_exchange
    coefficient = basis.to_basis(rho)[index] * weights
    advance = basis.logs[dt][index]

    def measure(delay):
        value = complex(np.dot(coefficient, np.exp(advance * rk_steps(delay, dt))))
        return {"c_real": value.real, "c_imag": value.imag, "c_abs": abs(value),
                "phase": math.atan2(value.imag, value.real), "load_current": -2 * G * value.imag}

    return measure


def wait_until(model, pair, primary, start, window, policy, mode, records, cap, fixed_tau, initial):
    if mode == "forecast":
        return 0, "no_wait", []
    if fixed_tau is not None:
        target, reason = min(fixed_tau, window - GRID), "diagnostic_fixed"
    elif policy == "F1":
        target, reason = empirical_wait(records, window - GRID)
    else:
        target = min(6000, window - GRID) // 200 * 200
        reason = "phase_limit"
        if target < 1000:
            return 0, "no_wait_fits", []
    if not target:
        return 0, reason, []
    physical_phase_gate = policy != "F1" and fixed_tau is None
    measure = phase_observer(model, pair[primary], DT[primary])
    checks = []
    times = range(1000 if physical_phase_gate else 200, target + 1, 200)
    for delay in times:
        if start + delay > cap:
            break
        current = measure(delay)
        gate = physical_phase_gate and phase_reconnect(current, initial, G)
        reconnect = gate or delay == target
        checks.append({"elapsed_total": (start + delay) / 1000, "observed_until": (start + delay) / 1000,
                       "wait_elapsed": delay / 1000, "phase_gate": gate, "reconnect": reconnect,
                       "actual_current": 0.0, **current})
        if gate:
            return delay, "phase_gate", checks
    return (None if physical_phase_gate and start + target > cap else target), reason, checks


@dataclass
class Attempt:
    after: tuple
    row: dict | None
    wait_checks: list
    observations: list
    boundary: Snapshot
    pending: dict


def attempt(model, pair, primary, start, window, policy, mode, records, cap=None, fixed_tau=None):
    """Execute one attempt through its stop or a checkpoint, whichever comes first."""
    cap = start + window if cap is None else min(cap, start + window)
    initial = observation(observe_local(partial(pair[primary])))
    tau, wait_reason, checks = wait_until(model, pair, primary, start, window, policy, mode, records,
                                         cap, fixed_tau, initial)
    after_cut = tau != 0
    cut = tuple(-2 * G * float(local_diagnostics(partial(rho))["c_real"]) if after_cut else 0.0 for rho in pair)
    pending = {"tau": tau, "forecast_tick": None, "execute_tick": None,
               "cut_applied": after_cut, "reconnect_applied": False, "switch_net": -cut[primary],
               "last_observation_tick": start}
    if tau is None or start + tau > cap:
        boundary_pair = tuple(model.bases[0].evolve(rho, cap - start, dt) for rho, dt in zip(pair, DT, strict=True))
        pending["last_observation_tick"] = tick(checks[-1]) if checks else start
        boundary = Snapshot(boundary_pair, 0.0, cap, "wait")
        return Attempt(boundary_pair, None, checks, [], boundary, pending)

    waiting = tuple(model.bases[0].evolve(rho, tau, dt) if tau else rho for rho, dt in zip(pair, DT, strict=True))
    reconnect = tuple(2 * G * float(local_diagnostics(partial(rho))["c_real"]) if tau else 0.0 for rho in waiting)
    pending.update(reconnect_applied=bool(tau), switch_net=-cut[primary] - reconnect[primary])
    connect = start + tau
    last = (window - tau) // GRID
    observed_last = min(last, (cap - connect) // GRID)
    projection = ConnectedObservations(model, model.connected.to_basis(waiting[primary]), DT[primary], with_rate=False)
    samples = []
    planned = decided = None
    previous = None
    stop_reason = "forecast"
    for index, (terminal, _) in enumerate(projection.prefix(observed_last + 1)):
        present = observation(observe_local(terminal))
        now = connect + index * GRID
        pending["last_observation_tick"] = now
        if planned is None:
            proposed = targets(index, previous, present, last).get(FORECAST)
            if proposed is not None:
                planned, decided = proposed, index
            elif index == last:
                planned = decided = last
                stop_reason = "horizon"
            if planned is not None:
                pending.update(forecast_tick=now, execute_tick=connect + planned * GRID)
        samples.append({"index": index, "elapsed_total": now / 1000, "observed_until": now / 1000,
                        "forecast_generated": decided == index, "execute": planned == index, **present})
        if planned == index:
            break
        previous = present

    if planned is None or planned > observed_last:
        boundary_pair = tuple(model.connected.evolve(rho, cap - connect, dt)
                              for rho, dt in zip(waiting, DT, strict=True))
        boundary = Snapshot(boundary_pair, G, cap, "connected")
        return Attempt(boundary_pair, None, checks, samples, boundary, pending)

    duration = tau + planned * GRID
    end = start + duration
    if duration <= 0:
        raise ValueError("Extraction must follow a positive elapsed interval")
    before = tuple(model.connected.evolve(rho, planned * GRID, dt) for rho, dt in zip(waiting, DT, strict=True))
    local_work = [float(local_diagnostics(partial(rho))["total_work"]) for rho in before]
    local_work[primary] = samples[-1]["total_work"]
    candidates = tuple(work - w_cut - w_reconnect for work, w_cut, w_reconnect in zip(local_work, cut, reconnect, strict=True))
    error = abs(candidates[0] - candidates[1])
    if error > HALF_TOL:
        raise ValueError(f"Unresolved step convergence at {end}: {error:g}")
    accounts = [account(model, start_rho, waited, pre, net, tau, w_cut, w_reconnect)
                for start_rho, waited, pre, net, w_cut, w_reconnect in
                zip(pair, waiting, before, candidates, cut, reconnect, strict=True)]
    primary_account = accounts[primary][0]
    margin = candidates[primary] - error
    accepted = margin > FLOOR and primary_account["direct_net"] > FLOOR and candidates[primary] >= FLOOR
    after = tuple(virtual if accepted else rho for (_, virtual), rho in zip(accounts, before, strict=True))
    net_pair = tuple(entry[0]["direct_net"] if accepted else -w_cut - w_reconnect
                     for entry, w_cut, w_reconnect in zip(accounts, cut, reconnect, strict=True))
    pre = state_metrics(model, before[primary])
    post = state_metrics(model, after[primary]) if accepted else pre
    other = 1 - primary
    paired_physicality = max(half_physicality(before[other]), half_physicality(after[other]))
    if paired_physicality > FLOOR:
        raise ValueError(f"Aligned companion physicality failed at {end}: {paired_physicality:g}")
    residual = post["global_energy"] - (primary_account["start_global_energy"] - net_pair[primary])
    passive_drift = post["global_passive_energy"] - pre["global_passive_energy"]
    chain_drift = post["bare_chain_energy"] - pre["bare_chain_energy"]
    if max(abs(residual), abs(passive_drift), abs(chain_drift), abs(post["load_ergotropy"]) if accepted else 0) > FLOOR:
        raise ValueError(f"Physical-accounting invariant failed at {end}: {residual, passive_drift, chain_drift}")
    reconnected = samples[0]
    wait_fields = {"phase_before": initial["phase"], "phase_after": reconnected["phase"],
                   "phase_change": angle_delta(reconnected["phase"], initial["phase"]),
                   "current_before": initial["load_current"], "current_after": reconnected["load_current"],
                   "sign_reversal": initial["load_current"] * reconnected["load_current"] < 0,
                   "c_abs_before": initial["c_abs"], "c_abs_after": reconnected["c_abs"], "wait_reason": wait_reason}
    row = {
        "mode": mode, "accepted": accepted, "outcome": "extracted" if accepted else "unresolved_candidate",
        "stop_reason": stop_reason, "window": window / 1000, "tau": tau / 1000, "elapsed_start": start / 1000,
        "elapsed_connected": planned * GRID / 1000, "duration": duration / 1000, "elapsed_total": end / 1000,
        "decision_elapsed_total": (connect + decided * GRID) / 1000, "observed_until": end / 1000,
        "threshold": FLOOR, "skipped_peaks": 0, "candidate_net": candidates[primary],
        "candidate_net_half": candidates[1], "candidate_net_aligned": candidates[other],
        "candidate_step_error": error, "resolution_margin": margin, "net_work": net_pair[primary],
        "net_work_aligned": net_pair[other], "cut_on": cut[primary], "reconnect_on": reconnect[primary],
        "cut_on_half": cut[1], "reconnect_on_half": reconnect[1], "cut_on_aligned": cut[other],
        "reconnect_on_aligned": reconnect[other], "accepted_energy_residual": residual,
        "global_passive_unitary_drift": passive_drift, "bare_chain_unitary_drift": chain_drift,
        "direct_net_half": accounts[1][0]["direct_net"], "direct_net_aligned": accounts[other][0]["direct_net"],
        "half_state_max_error": maxabs(after[0] - after[1]), "max_half_physicality_error": paired_physicality,
        **primary_account, "post_global_energy": post["global_energy"], **wait_fields,
        **{f"pre_{name}": value for name, value in pre.items()},
        **{f"post_{name}": value for name, value in post.items()},
        **{f"{stage}_{label}_sha256": fingerprint(rho) for stage, states in (("start", pair), ("pre", before), ("post", after))
           for label, rho in zip(PRECISIONS, states, strict=True)},
    }
    return Attempt(after, row, checks, samples, Snapshot(after, G, end, "operation_end"), pending)


def compact_record(row):
    return {key: row[key] for key in ("elapsed_total", "duration", "tau", "accepted", "net_work", "net_work_aligned")}


def resolve(model, pair, primary, elapsed, policy, control, records, cap):
    decision = control.update(policy, elapsed, observation(observe_local(partial(pair[primary]))), records)
    trial = attempt(model, pair, primary, elapsed, min(HORIZON, TOTAL_LIMIT - elapsed),
                    policy, control.mode, records, cap)
    return decision, trial


def next_boundary(model, pair, primary, elapsed, policy, control, records, ending, cap):
    if ending != "active" or TOTAL_LIMIT - elapsed < GRID:
        snapshot = continue_passively(model, Snapshot(pair, G, elapsed, "operation_end"), cap)
        return snapshot, {}, None, None
    decision, trial = resolve(model, pair, primary, elapsed, policy, control, records, cap)
    return trial.boundary, trial.pending, decision, trial


def add_attempt(tables, meta, decision, trial, work, aligned_work, error_bound, count, absolute_origin):
    row = trial.row
    revised_work = work + row["net_work"]
    revised_aligned = aligned_work + row["net_work_aligned"]
    error_bound += abs(row["net_work"] - row["net_work_aligned"])
    count += int(row["accepted"])
    entry = {**meta, "count": count, **row, "cumulative_net": revised_work,
             "cumulative_net_aligned": revised_aligned,
             "cumulative_net_half_aligned": revised_aligned if meta["precision"] == "coarse" else revised_work,
             "cumulative_step_error_bound": error_bound, "cumulative_rate": revised_work / row["elapsed_total"],
             "absolute_time": absolute_origin + row["elapsed_total"], "record_source": "m27"}
    tables.add("m27_history", entry)
    tables.add("m27_decisions", {**meta, **decision})
    for sample in trial.observations:
        tables.add("m27_observations", {**meta, **sample})
    for check in trial.wait_checks:
        tables.add("m27_wait_checks", {**meta, **check})
    if row["tau"]:
        names = ("tau", "elapsed_start", "phase_before", "phase_after", "phase_change", "current_before", "current_after",
                 "sign_reversal", "c_abs_before", "c_abs_after", "wait_reason", "net_work", "accepted", "cut_on", "reconnect_on")
        tables.add("m27_waits", {**meta, **{name: row[name] for name in names},
                                 "elapsed_total": row["elapsed_start"] + row["tau"],
                                 "extraction_elapsed": row["elapsed_total"],
                                 "wait_start_observed_until": row["elapsed_start"],
                                 "observed_until": row["elapsed_start"] + row["tau"]})
    return revised_work, revised_aligned, error_bound, count


def run_stage(model, source, policy, primary, destination, cap, previous):
    started = time.perf_counter()
    precision = PRECISIONS[primary]
    records = []
    control = Controller()
    elapsed = completed = count = 0
    work = aligned_work = error_bound = 0.0
    ending = "active"
    origin_pair = source_pair(M23, source)
    energy_origin = tuple(float(np.einsum("ij,ji->", rho, model.h[G]).real) for rho in origin_pair)
    pair = origin_pair
    resume_error = None
    if previous is not None:
        with np.load(previous / "checkpoint.npz", allow_pickle=False) as saved:
            pair = saved["anchor_coarse"], saved["anchor_half"]
            elapsed, completed, count = map(int, saved["counters"])
            work, aligned_work, error_bound = map(float, saved["work"])
            ending = str(saved["ending"].item())
            control = Controller(**json.loads(str(saved["controller"].item())))
            records = json.loads(str(saved["records"].item()))
            prior = int(saved["tick"].item())
            replay, known, _, _ = next_boundary(model, pair, primary, elapsed, policy, Controller(**asdict(control)),
                                                 records, ending, prior)
            resume_error = max(maxabs(rho - saved[label]) for rho, label in zip(replay.pair, PRECISIONS, strict=True))
            if (resume_error > FLOOR or replay.coupling != float(saved["coupling"].item())
                    or known != json.loads(str(saved["pending"].item()))):
                raise ValueError(f"Saved boundary replay failed: {previous}: {resume_error:g}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix=".pending-", dir=destination.parent, ignore_cleanup_errors=True) as temporary:
        folder = Path(temporary) / "complete"
        folder.mkdir()
        tables = Tables(folder)
        base = {"origin": source["origin"], "policy": policy, "precision": precision}
        initial_attempt = completed
        try:
            while True:
                controller_candidate = Controller(**asdict(control))
                boundary, pending, decision, trial = next_boundary(model, pair, primary, elapsed, policy, controller_candidate,
                                                                   records, ending, cap)
                if trial is None or trial.row is None:
                    break
                if decision["switched"]:
                    np.savez_compressed(folder / f"switch_{elapsed}.npz", coarse=pair[0], half=pair[1], tick=elapsed)
                completed += 1
                meta = {**base, "attempt": completed}
                work, aligned_work, error_bound, count = add_attempt(tables, meta, decision, trial, work, aligned_work,
                                                                     error_bound, count, float(source["source_time"]))
                elapsed = boundary.tick
                pair = trial.after
                control = controller_candidate
                records.append(compact_record(trial.row))
                expected = (work, aligned_work) if primary == 0 else (aligned_work, work)
                closure = max(abs(float(np.einsum("ij,ji->", rho, model.h[G]).real) + recovered - initial)
                              for rho, recovered, initial in zip(pair, expected, energy_origin, strict=True))
                if closure > FLOOR:
                    raise ValueError(f"Cumulative energy closure failed: {meta}: {closure:g}")
                if not trial.row["accepted"] and control.mode == "forecast":
                    ending = "numeric_floor"
                elif TOTAL_LIMIT - elapsed < GRID:
                    ending = "time_cap" if elapsed == TOTAL_LIMIT else "time_cap_no_grid"
            physicality = max(half_physicality(rho) for rho in boundary.pair)
            if physicality > FLOOR:
                raise ValueError(f"Boundary physicality failed at {cap}: {physicality:g}")
            np.savez_compressed(folder / "checkpoint.npz", coarse=boundary.pair[0], half=boundary.pair[1],
                                anchor_coarse=pair[0], anchor_half=pair[1], counters=(elapsed, completed, count),
                                tick=cap, coupling=boundary.coupling, phase=boundary.phase,
                                controller=json.dumps(asdict(control), sort_keys=True),
                                records=json.dumps(records, sort_keys=True), pending=json.dumps(pending, sort_keys=True),
                                work=(work, aligned_work, error_bound), ending=ending)
            summary = {**base, "elapsed_total": cap / 1000, "anchor_elapsed": elapsed / 1000,
                       "attempts": completed, "attempts_in_stage": completed - initial_attempt, "count": count,
                       "ending": ending, "coupling": boundary.coupling, "phase": boundary.phase,
                       "mode": control.mode, "cumulative_net": work, "cumulative_net_aligned": aligned_work,
                       "cumulative_step_error_bound": error_bound, "boundary_physicality_error": physicality,
                       "resumed_state_error": resume_error,
                       "cut_applied": pending.get("cut_applied", False), "reconnect_applied": pending.get("reconnect_applied", False),
                       "pending_switch_net": pending.get("switch_net", 0.0),
                       "pending_tau_tick": pending.get("tau"), "forecast_tick": pending.get("forecast_tick"),
                       "execute_tick": pending.get("execute_tick"), "last_observation_tick": pending.get("last_observation_tick"),
                       **{f"{stage}_{label}_sha256": fingerprint(rho)
                          for stage, states in (("boundary", boundary.pair), ("anchor", pair))
                          for label, rho in zip(PRECISIONS, states, strict=True)}}
            tables.add("m27_checkpoints", summary)
        finally:
            tables.close()
        folder.rename(destination)
    return {**summary, "seconds": time.perf_counter() - started}


def run_chain(source, policy, precision, root, cutoffs):
    model = model_instance()
    primary = PRECISIONS.index(precision)
    previous = None
    for cap in cutoffs:
        destination = root / f"t{cap // 1000}" / source["origin"] / policy / precision
        if destination.exists():
            if not (destination / "checkpoint.npz").is_file():
                raise ValueError(f"Incomplete stage: {destination}")
            print(f"Verified checkpoint presence {destination}", flush=True)
        else:
            summary = run_stage(model, source, policy, primary, destination, cap, previous)
            print(json.dumps({key: summary[key] for key in ("origin", "policy", "precision", "elapsed_total",
                                                            "count", "ending", "cumulative_net", "seconds")}), flush=True)
        previous = destination


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage_root", type=Path)
    parser.add_argument("--cutoffs", type=int, nargs="+", default=(150, 300, 540))
    parser.add_argument("--origins", nargs="+", choices=ORIGINS, default=ORIGINS)
    parser.add_argument("--policies", nargs="+", choices=POLICIES, default=POLICIES)
    parser.add_argument("--precisions", nargs="+", choices=PRECISIONS, default=PRECISIONS)
    parser.add_argument("--workers", type=int, default=4)
    args = parser.parse_args()
    if sorted(set(args.cutoffs)) != args.cutoffs and tuple(sorted(set(args.cutoffs))) != args.cutoffs:
        parser.error("Cutoffs must be unique and increase")
    if min(args.cutoffs) < 1 or max(args.cutoffs) * 1000 > TOTAL_LIMIT or args.workers < 1:
        parser.error("Cutoffs must be in 1..540, and workers must be positive")
    protocol = hashlib.sha256((ROOT / "PROTOCOL_M27.md").read_bytes()).hexdigest()
    args.stage_root.mkdir(parents=True, exist_ok=True)
    registration = args.stage_root / "protocol.sha256"
    if registration.exists() and registration.read_text().strip() != protocol:
        parser.error("Stage root was created with another experimental protocol")
    registration.write_text(protocol + "\n")
    sources = {row["origin"]: row for row in csv_rows(SOURCE_TABLE)}
    cutoffs = tuple(cap * 1000 for cap in args.cutoffs)
    jobs = [(sources[origin], policy, precision, args.stage_root, cutoffs)
            for precision in args.precisions for policy in args.policies for origin in args.origins]
    if args.workers == 1:
        for job in jobs:
            run_chain(*job)
    else:
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            for task in as_completed([pool.submit(run_chain, *job) for job in jobs]):
                task.result()


if __name__ == "__main__":
    main()
