"""Measure physical state divergence caused by separate coarse and half controls."""

import argparse
import csv
from pathlib import Path

from run_m27 import ORIGINS, POLICIES, ROOT, partial
import numpy as np


def load_state(archive):
    terminal = partial(archive)
    return terminal[:3, :3] + terminal[3:, 3:]


def trace_distance(a, b):
    difference = a - b
    spectrum = np.linalg.eigvalsh((difference + difference.conj().T) / 2)
    return np.abs(spectrum).sum() / 2


def compare(stages):
    for time in (150, 300, 540):
        for origin in ORIGINS:
            for policy in POLICIES:
                folder = stages / f"t{time}" / origin / policy
                with (np.load(folder / "coarse" / "checkpoint.npz", allow_pickle=False) as coarse,
                      np.load(folder / "half" / "checkpoint.npz", allow_pickle=False) as half):
                    coarse_state, half_state = coarse["coarse"], half["half"]
                    same_history = (trace_distance(coarse_state, coarse["half"]),
                                    trace_distance(half["coarse"], half_state))
                    yield {
                        "origin": origin, "policy": policy, "elapsed_total": time,
                        "independent_global_trace_distance": trace_distance(coarse_state, half_state),
                        "independent_load_trace_distance": trace_distance(load_state(coarse_state), load_state(half_state)),
                        "coarse_control_aligned_global_trace_distance": same_history[0],
                        "half_control_aligned_global_trace_distance": same_history[1],
                        "coarse_coupling": float(coarse["coupling"]), "half_coupling": float(half["coupling"]),
                        "coarse_count": int(coarse["counters"][2]), "half_count": int(half["counters"][2]),
                        "coarse_cumulative_net": float(coarse["work"][0]),
                        "half_cumulative_net": float(half["work"][0]),
                        "half_minus_coarse_net": float(half["work"][0] - coarse["work"][0]),
                    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stages", type=Path, default=ROOT / "stages")
    parser.add_argument("--output", type=Path, default=ROOT / "results" / "m27_step_states.csv")
    args = parser.parse_args()
    rows = list(compare(args.stages))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    main()
