"""Join the audited M26 controls with the M27 adaptive ledgers."""

import argparse
from bisect import bisect_right
from collections import defaultdict
import csv
from itertools import combinations
from pathlib import Path
from statistics import median


ROOT = Path(__file__).resolve().parent
M26_RESULTS = ROOT.parent / "Milestone_26" / "results"
ORIGINS = ("S0", "A04", "B04", "C04")
CONTROLS = ("A", "B", "C25", "E")
ADAPTIVE = ("F1", "F2", "F3")
COMMON = (50, 100, 150, 200, 300, 360, 450, 540)
TINY_WORK = 1e-8
FLOOR = 1e-12


def csv_rows(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def write_csv(path, records, *, fields=()):
    columns = list(dict.fromkeys([*fields, *(key for row in records for key in row)]))
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        writer.writerows(records)


def ticks(value):
    return round(float(value) * 1000)


def accepted(row):
    return str(row["accepted"]).casefold() in ("true", "1")


def key(row):
    return row["origin"], row["policy"], row["precision"]


def skipped(row):
    return int(row.get("skipped_peaks") or 0)


def skip_followups(attempts):
    """Group bypassed candidates by the next actual extraction."""
    records = []
    next_extraction = None
    for row in reversed(attempts):
        is_accepted = accepted(row)
        if is_accepted:
            next_extraction = row
        peak_skips = skipped(row)
        if not peak_skips and is_accepted:
            continue
        outcome = row.get("outcome", "")
        is_rejected = not is_accepted and outcome != "time_cap"
        if peak_skips or is_rejected:
            records.append({
                **dict(zip(("origin", "policy", "precision"), key(row), strict=True)),
                "attempt": row["attempt"],
                "attempt_end": float(row["elapsed_total"]),
                "outcome": outcome,
                "skipped_peaks": peak_skips,
                "rejected_attempts": int(is_rejected),
                "next_extraction_elapsed": float(next_extraction["elapsed_total"]) if next_extraction else "",
                "next_extraction_net": float(next_extraction["net_work"]) if next_extraction else "",
            })
    return list(reversed(records))


class Ledger:
    def __init__(self, attempts, cutoff, checkpoints=()):
        self.attempts = sorted(attempts, key=lambda row: int(row["attempt"]))
        self.starts = [ticks(row["elapsed_start"]) for row in self.attempts]
        self.checkpoints = {ticks(row["elapsed_total"]): row for row in checkpoints}
        self.events = [row for row in self.attempts if ticks(row["elapsed_total"]) <= cutoff]
        self.event_times = [ticks(row["elapsed_total"]) for row in self.events]
        self.actions = [row for row in self.events if accepted(row)]
        self.times = [ticks(row["elapsed_total"]) for row in self.actions]
        self.intervals = [right - left for left, right in zip([0, *self.times], self.times)]
        if self.event_times != sorted(self.event_times) or any(value <= 0 for value in self.intervals):
            raise ValueError(f"Unexpected event or extraction clock order for {key(self.attempts[0])}")
        self.paid = [0.0]
        self.accepted_work = [0.0]
        self.aligned_error = [0.0]
        for number, row in enumerate(self.events, 1):
            net = float(row["net_work"])
            paid = float(row["cumulative_net"])
            count = len(self.accepted_work) - 1 + int(accepted(row))
            if int(row["attempt"]) != number or int(row["count"]) != count or abs(paid - self.paid[-1] - net) > FLOOR:
                raise ValueError(f"Discontinuous work or count for {key(row)} attempt {row['attempt']}")
            if accepted(row):
                if net <= 0:
                    raise ValueError(f"Nonpositive accepted net for {key(row)} attempt {row['attempt']}")
                self.accepted_work.append(self.accepted_work[-1] + net)
            self.paid.append(paid)
            if row.get("net_work_aligned"):
                delta = abs(net - float(row["net_work_aligned"]))
            else:
                coarse, half = row.get("candidate_net"), row.get("candidate_net_half")
                delta = abs(float(coarse) - float(half)) if coarse and half else 0.0
            if not accepted(row):
                delta = 0.0
            self.aligned_error.append(self.aligned_error[-1] + delta)
        self.waits = []
        for row in self.attempts:
            start = ticks(row["elapsed_start"])
            stop = min(start + ticks(row.get("tau") or 0), ticks(row["elapsed_total"]), cutoff)
            if stop > start:
                if self.waits and start < self.waits[-1][1]:
                    raise ValueError(f"Overlapping cut waits for {key(row)}")
                self.waits.append((start, stop))
        terminal = self.checkpoints.get(cutoff)
        if terminal and str(terminal.get("cut_applied", "")).casefold() == "true" and (
            not self.attempts or ticks(self.attempts[-1]["elapsed_total"]) <= cutoff
        ):
            start = ticks(terminal["anchor_elapsed"])
            tau = terminal.get("pending_tau_tick")
            stop = min(cutoff, start + int(tau)) if tau else cutoff
            if stop > start:
                self.waits.append((start, stop))
        self.followups = skip_followups(self.events)

    def at(self, tick):
        return bisect_right(self.times, tick)

    def net_at(self, tick):
        return self.paid[bisect_right(self.event_times, tick)]

    def resolution_at(self, tick):
        return self.aligned_error[bisect_right(self.event_times, tick)]

    def pending_switch_net(self, tick):
        index = bisect_right(self.starts, tick) - 1
        checkpoint = self.checkpoints.get(tick, {})
        saved_value = float(checkpoint.get("pending_switch_net") or 0)
        if index < 0 or tick >= ticks(self.attempts[index]["elapsed_total"]):
            return saved_value
        row = self.attempts[index]
        reconnect_tick = self.starts[index] + ticks(row.get("tau") or 0)
        inferred = -float(row.get("cut_on") or 0)
        if tick >= reconnect_tick:
            inferred -= float(row.get("reconnect_on") or 0)
        if checkpoint and abs(saved_value - inferred) > FLOOR:
            raise ValueError(f"Checkpoint switch input disagrees with ledger for {key(row)} at {tick / 1000}")
        return inferred

    def waiting(self, tick):
        return sum(max(0, min(tick, end) - start) for start, end in self.waits) / 1000

    def compare(self, tag, start, stop):
        before, after = self.at(start), self.at(stop)
        count = after - before
        total_work = self.net_at(stop)
        interval_work = total_work - self.net_at(start)
        interval_accepted = self.accepted_work[after] - self.accepted_work[before]
        interval_span = (stop - start) / 1000
        elapsed = stop / 1000
        cumulative_wait = self.waiting(stop)
        interval_wait = cumulative_wait - self.waiting(start)
        pending = self.pending_switch_net(stop)
        return {
            **tag,
            "elapsed_total": elapsed,
            "interval_start": start / 1000,
            "count": after,
            "cumulative_net": total_work,
            "cumulative_rate": total_work / elapsed,
            "pending_switch_net": pending,
            "cumulative_physical_net": total_work + pending,
            "cumulative_accepted_net": self.accepted_work[after],
            "mean_work": self.accepted_work[after] / after if after else "",
            "cumulative_wait": cumulative_wait,
            "interval_count": count,
            "interval_net": interval_work,
            "interval_rate": interval_work / interval_span,
            "interval_mean_work": interval_accepted / count if count else "",
            "interval_wait": interval_wait,
        }

    def summarize(self, comparison, label):
        start = ticks(comparison["interval_start"])
        stop = ticks(comparison["elapsed_total"])
        before, after = self.at(start), self.at(stop)
        values = [float(row["net_work"]) for row in self.actions[before:after]]
        followups = [row for row in self.followups if start < ticks(row["attempt_end"]) <= stop]
        recovered = {row["next_extraction_elapsed"]: row["next_extraction_net"]
                     for row in followups if row["next_extraction_net"] != ""}
        tiny = sum(value <= TINY_WORK for value in values)
        return {
            **comparison,
            "range": label,
            "tiny_work_count": tiny,
            "tiny_work_fraction": tiny / len(values) if values else "",
            "median_interval": median(self.intervals[before:after]) / 1000 if values else "",
            "median_work": median(values) if values else "",
            "skipped_peaks": sum(row["skipped_peaks"] for row in followups),
            "rejected_attempts": sum(row["rejected_attempts"] for row in followups),
            "post_skip_extractions": len(recovered),
            "post_skip_total_work": sum(recovered.values()),
            "post_skip_median_work": median(recovered.values()) if recovered else "",
        }


def normalize(rows, *, provenance, precision="coarse"):
    return [{"precision": precision, "ledger_source": provenance, **row} for row in rows]


def artifact_paths(runs, filename):
    return sorted(path for path in runs.rglob(filename)
                  if not any(part.startswith(".pending-") for part in path.relative_to(runs).parts))


def merge_run_artifact(runs, filename):
    return [row for path in artifact_paths(runs, filename) for row in csv_rows(path)]


def stream_run_artifact(runs, filename, output):
    paths = artifact_paths(runs, filename)
    fields = ["origin", "policy", "precision"]
    for path in paths:
        with path.open(encoding="utf-8-sig", newline="") as stream:
            fields.extend(field for field in (csv.DictReader(stream).fieldnames or ()) if field not in fields)
    with (output / filename).open("w", encoding="utf-8", newline="") as target:
        writer = csv.DictWriter(target, fieldnames=fields)
        writer.writeheader()
        for path in paths:
            with path.open(encoding="utf-8-sig", newline="") as stream:
                writer.writerows(csv.DictReader(stream))


def switch_summary(ledgers, decisions, archived_crossovers):
    last_ea = {}
    for row in archived_crossovers:
        if {row["left"], row["right"]} == {"A", "E"}:
            origin = row["origin"]
            when = float(row["elapsed_total"])
            last_ea[origin] = max(when, last_ea.get(origin, 0))
    switched = defaultdict(list)
    for row in decisions:
        if str(row["switched"]).casefold() in ("true", "1"):
            switched[key(row)].append(row)
    summary = []
    for origin, policy, step in ledgers:
        if policy not in ADAPTIVE:
            continue
        changes = sorted(switched[origin, policy, step], key=lambda row: ticks(row["elapsed_total"]))
        first = changes[0] if changes else {}
        m26_last = last_ea.get(origin, "")
        summary.append({
            "origin": origin, "policy": policy, "precision": step,
            "switch_count": len(changes),
            "returned_to_forecast": sum(row["mode_after"] == "forecast" for row in changes),
            "first_switch_elapsed": first.get("elapsed_total", ""),
            "first_switch_reason": first.get("reason", ""),
            "first_switch_observed_until": first.get("observed_until", ""),
            "first_switch_moving_rate": first.get("moving_rate", ""),
            "first_switch_baseline_rate": first.get("baseline_rate", ""),
            "m26_last_ae_crossover_elapsed": m26_last,
            "first_switch_minus_m26_last_ae_crossover": float(first["elapsed_total"]) - m26_last
            if first and m26_last != "" else "",
        })
    return summary


def independent_steps(times):
    pairs = defaultdict(dict)
    for row in times:
        if row["policy"] in ADAPTIVE:
            pairs[row["origin"], row["policy"], row["elapsed_total"]][row["precision"]] = row
    comparisons = []
    for (origin, policy, elapsed), pair in pairs.items():
        if "coarse" not in pair or "half" not in pair:
            continue
        coarse, half = pair["coarse"], pair["half"]
        comparisons.append({"origin": origin, "policy": policy, "elapsed_total": elapsed, **{
            f"{field}_half_minus_coarse": half[field] - coarse[field]
            for field in ("cumulative_net", "interval_net", "count", "cumulative_wait")
        }})
    return comparisons


def chronology(ledgers, decisions):
    switch_clocks = defaultdict(list)
    for row in sorted(decisions, key=lambda item: ticks(item["elapsed_total"])):
        if str(row["switched"]).casefold() in ("true", "1"):
            switch_clocks[key(row)].append((ticks(row["elapsed_total"]), row["mode_after"]))
    comparisons = []
    for origin in ORIGINS:
        for policy in ADAPTIVE:
            ck, hk = (origin, policy, "coarse"), (origin, policy, "half")
            if ck not in ledgers or hk not in ledgers:
                continue
            coarse, half = ledgers[ck], ledgers[hk]
            paired_actions = list(zip(coarse.times, half.times))
            paired_modes = list(zip(switch_clocks[ck], switch_clocks[hk]))
            paired_attempts = list(zip(coarse.events, half.events))
            action_diff = next((i for i, pair in enumerate(paired_actions) if pair[0] != pair[1]), None)
            wait_diffs = [(r, s) for r, s in paired_attempts if ticks(r["tau"]) != ticks(s["tau"])]
            start_diff = next(((r, s) for r, s in paired_attempts
                               if (ticks(r["elapsed_total"]), r["accepted"], r.get("mode")) !=
                               (ticks(s["elapsed_total"]), s["accepted"], s.get("mode"))), None)
            action_c, action_h = paired_actions[action_diff] if action_diff is not None else (None, None)
            if action_diff is None and len(coarse.times) != len(half.times):
                action_diff = len(paired_actions)
                action_c = coarse.times[action_diff] if action_diff < len(coarse.times) else None
                action_h = half.times[action_diff] if action_diff < len(half.times) else None
            comparisons.append({
                "origin": origin, "policy": policy,
                "coarse_attempts": len(coarse.events), "half_attempts": len(half.events),
                "matching_attempt_clocks": sum(ticks(r["elapsed_total"]) == ticks(s["elapsed_total"])
                                               for r, s in paired_attempts),
                "first_different_attempt": start_diff[0]["attempt"] if start_diff else "",
                "coarse_extractions": len(coarse.times), "half_extractions": len(half.times),
                "matching_extraction_clocks": sum(left == right for left, right in paired_actions),
                "max_extraction_clock_delta": max((abs(left - right) for left, right in paired_actions), default=0) / 1000,
                "first_different_extraction_ordinal": action_diff + 1 if action_diff is not None else "",
                "first_different_extraction_coarse": action_c / 1000 if action_c is not None else "",
                "first_different_extraction_half": action_h / 1000 if action_h is not None else "",
                "coarse_switches": len(switch_clocks[ck]), "half_switches": len(switch_clocks[hk]),
                "matching_switch_clocks_and_modes": sum(left == right for left, right in paired_modes),
                "coarse_switch_sequence": " ".join(f"{when / 1000:g}/{mode}" for when, mode in switch_clocks[ck]),
                "half_switch_sequence": " ".join(f"{when / 1000:g}/{mode}" for when, mode in switch_clocks[hk]),
                "wait_choice_mismatches": len(wait_diffs),
                "first_wait_choice_mismatch_attempt": wait_diffs[0][0]["attempt"] if wait_diffs else "",
                "first_different_wait_coarse": wait_diffs[0][0]["tau"] if wait_diffs else "",
                "first_different_wait_half": wait_diffs[0][1]["tau"] if wait_diffs else "",
            })
    return comparisons


def work_gaps(ledgers, cutoff):
    gaps, crossovers = [], []
    for origin in ORIGINS:
        systems = {policy: ledger for (source, policy, step), ledger in ledgers.items()
                   if source == origin and step == "coarse" and policy in ("A", "E", *ADAPTIVE)}
        for (left, first), (right, second) in combinations(systems.items(), 2):
            grid = sorted({0, cutoff, *first.event_times, *second.event_times})
            previous = ""
            for tick in grid:
                gap = first.net_at(tick) - second.net_at(tick)
                resolution = FLOOR + first.resolution_at(tick) + second.resolution_at(tick)
                leader = left if gap > resolution else right if gap < -resolution else ""
                row = {"origin": origin, "left": left, "right": right, "elapsed_total": tick / 1000,
                       "gap": gap, "resolution_bound": resolution, "leader": leader}
                gaps.append(row)
                if leader:
                    if previous and leader != previous:
                        crossovers.append({**row, "leading_before": previous, "leading_after": leader})
                    previous = leader
    return gaps, crossovers


def collect(runs, output, controls, horizon, *, controls_only=False):
    cutoff = ticks(horizon)
    history = normalize(csv_rows(controls / "m26_history.csv"), provenance="M26")
    selected = normalize(merge_run_artifact(runs, "m27_history.csv"), provenance="M27")
    checkpoints = normalize(merge_run_artifact(runs, "m27_checkpoints.csv"), provenance="M27")
    if not selected and not checkpoints and not controls_only:
        raise FileNotFoundError(f"No M27 adaptive ledgers or checkpoints found under {runs}")
    control_endpoints = csv_rows(controls / "m26_endpoints.csv")
    if horizon == COMMON[-1]:
        if len(control_endpoints) != len(ORIGINS) * len(CONTROLS) or any(
            ticks(row["common_limit"]) != cutoff for row in control_endpoints
        ):
            raise ValueError("M26 control endpoints do not cover the M27 formal horizon")
    final = {key(row): row for row in checkpoints if ticks(row["elapsed_total"]) == cutoff}
    final.update({key(row): row for row in normalize(control_endpoints, provenance="M26")
                  if ticks(row["common_limit"]) == cutoff})
    groups = defaultdict(list)
    for row in [*history, *selected]:
        groups[key(row)].append(row)
    for row in checkpoints:
        groups.setdefault(key(row), [])
    run_checkpoints = defaultdict(list)
    for row in checkpoints:
        run_checkpoints[key(row)].append(row)
    ledgers = {group: Ledger(attempts, cutoff, run_checkpoints[group]) for group, attempts in groups.items()}
    output.mkdir(parents=True, exist_ok=True)
    write_csv(output / "m27_history.csv", [row for rows in groups.values() for row in rows
                                          if ticks(row["elapsed_total"]) <= cutoff])
    decisions = merge_run_artifact(runs, "m27_decisions.csv")
    write_csv(output / "m27_decisions.csv", decisions, fields=("origin", "policy", "precision"))
    for filename in ("m27_waits.csv", "m27_wait_checks.csv", "m27_observations.csv"):
        stream_run_artifact(runs, filename, output)
    write_csv(output / "m27_checkpoints.csv", checkpoints, fields=("origin", "policy", "precision"))
    times, summaries, endpoints = [], [], []
    stops = sorted({cutoff, *(time * 1000 for time in COMMON if time * 1000 <= cutoff)})
    for (origin, policy, step), ledger in ledgers.items():
        tag = {"origin": origin, "policy": policy, "precision": step}
        for start, stop in zip([0, *stops], stops):
            comparison = ledger.compare(tag, start, stop)
            times.append(comparison)
            summaries.append(ledger.summarize(comparison, "common_interval"))
        if cutoff > 300_000:
            summaries.append(ledger.summarize(ledger.compare(tag, 300_000, cutoff), "late"))
        terminal = ledger.compare(tag, 0, cutoff)
        checkpoint = final.get((origin, policy, step), {})
        if checkpoint and (int(checkpoint["count"]) != terminal["count"]
                           or abs(float(checkpoint["cumulative_net"]) - terminal["cumulative_net"]) > FLOOR):
            raise ValueError(f"Checkpoint disagrees with ledger for {origin}/{policy}/{step}")
        ending = checkpoint.get("ending", "")
        observed = checkpoint.get("elapsed_observed", checkpoint.get(
            "elapsed_total" if ending == "active" else "anchor_elapsed", ""
        ))
        endpoints.append({**terminal,
                          "attempts": len(ledger.events),
                          "completed_checkpoint": bool(checkpoint),
                          "ending": ending,
                          "elapsed_observed": observed,
                          "last_extraction_elapsed": ledger.times[-1] / 1000 if ledger.times else "",
                          "aligned_candidate_delta_sum": ledger.aligned_error[-1]})
    write_csv(output / "m27_time_comparison.csv", times)
    write_csv(output / "m27_action_summary.csv", summaries)
    write_csv(output / "m27_endpoints.csv", endpoints)
    write_csv(output / "m27_switch_summary.csv",
              switch_summary(ledgers, decisions, csv_rows(controls / "m26_crossovers.csv")),
              fields=("origin", "policy", "precision", "switch_count"))
    write_csv(output / "m27_independent_steps.csv", independent_steps(times),
              fields=("origin", "policy", "elapsed_total", "cumulative_net_half_minus_coarse"))
    write_csv(output / "m27_chronology.csv", chronology(ledgers, decisions),
              fields=("origin", "policy", "coarse_attempts", "half_attempts"))
    write_csv(output / "m27_skip_followups.csv", [row for ledger in ledgers.values() for row in ledger.followups],
              fields=("origin", "policy", "precision", "attempt"))
    gaps, crossovers = work_gaps(ledgers, cutoff)
    write_csv(output / "m27_gap.csv", gaps)
    write_csv(output / "m27_crossovers.csv", crossovers,
              fields=("origin", "left", "right", "elapsed_total", "leading_before", "leading_after"))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, default=ROOT / "stages")
    parser.add_argument("--output", type=Path, default=ROOT / "results")
    parser.add_argument("--m26", type=Path, default=M26_RESULTS)
    parser.add_argument("--horizon", type=float, default=COMMON[-1])
    parser.add_argument("--controls-only", action="store_true", help="Allow a dry run with only the M26 controls")
    args = parser.parse_args()
    collect(args.runs, args.output, args.m26, args.horizon, controls_only=args.controls_only)
