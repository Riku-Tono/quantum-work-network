"""Audit M27 ledgers with independent unitary propagation and causal replay."""

import argparse
from bisect import bisect_right
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass
from functools import lru_cache
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
M26 = ROOT.parent / "Milestone_26"
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
sys.path.insert(0, str(M26))

from verify_m26 import ExactContinuation, dynamics_step
from verify_m25 import (
    CAP, DIM, G, GRID, HALF_TOL, HORIZON, LOAD_LEVELS, M23, OCCUPATION, ORIGINS, TOL, State,
    close, file_hash, flag, insist, maxabs, np, number, physical_state, read_rows,
    read_unique, reduced_load, state_file, terminal_state, ticks,
)


ADAPTIVE = ("F1", "F2", "F3")
CONTROLS = ("A", "B", "C25", "E")
RESOLUTIONS = ("coarse", "half")
BOUNDARIES = (150_000, 300_000, CAP)
BOUNDARY_STATE_TOL = HALF_TOL
EXACT_WORK_TOL = 2 * TOL
BASELINE_END = 32_000
RATE_SPAN = 24_000
FIRST_SWITCH_TEST = 48_000
DWELL = 30_000
PERSISTENCE = 4_000
PHASE_AMPLITUDE = 1e-5
PHASE_WINDOWS = (-3 * math.pi / 4, -math.pi / 4)
COMMON = (50, 100, 150, 200, 300, 360, 450, 540)


def sha256(path):
    """Use the existing read-only file-hash helper with normalized case."""
    return file_hash(path).lower()


def state_sha256(matrix):
    return hashlib.sha256(np.asarray(matrix, dtype="<c16", order="C").tobytes()).hexdigest()


def tolerance(value, expected, context, limit=EXACT_WORK_TOL):
    close(float(value), float(expected), context, limit)


def signed_phase_delta(a, b):
    return math.remainder(b - a, math.tau)


def observation(model, state, coupling=G):
    """Derive local measurements and use the partial trace of the commutator."""
    terminal = terminal_state(state.matrix)
    load = reduced_load(terminal)
    values, vectors = np.linalg.eigh(load)
    product = np.diag(LOAD_LEVELS) @ load + coupling * reduced_load(model.exchange @ terminal)
    load_derivative = -1j * (product - product.conj().T)
    passive_derivative = np.diag(vectors.conj().T @ load_derivative @ vectors)[::-1].real
    c = terminal[1, 3] + math.sqrt(2) * terminal[2, 4]
    return {
        "load_ergotropy": float(LOAD_LEVELS @ (np.diag(load).real - values[::-1])),
        "load_ergotropy_rate": float(LOAD_LEVELS @ (np.diag(load_derivative).real - passive_derivative)),
        "c_real": float(c.real),
        "c_imag": float(c.imag),
        "c_abs": float(abs(c)),
        "c_phase": math.atan2(c.imag, c.real) if abs(c) > TOL else None,
        "load_current": float(-2 * G * c.imag),
    }


@dataclass(frozen=True)
class ExactAction:
    waited: State
    before: State
    after: State
    hypothetical: State
    cut: float
    reconnect: float
    work: float
    observed_work: float


def exact_action(model, anchor, wait, connected, accepted):
    waited, before, imaginary, cut, reconnect = dynamics_step(model, anchor, wait, connected)
    after = imaginary if accepted else before
    work = model.energy(anchor) - model.energy(imaginary)
    observed = model.energy(anchor) - model.energy(after)
    return ExactAction(waited, before, after, imaginary, cut, reconnect, work, observed)


def action_snapshot(model, anchor, start, wait, connected, action, tick):
    """Right-continuous state with completed extraction applied at its clock."""
    elapsed = tick - start
    insist(0 <= elapsed <= wait + connected, f"Snapshot lies outside attempt: {tick}")
    if elapsed == wait + connected:
        return action.after, G
    if elapsed < wait:
        return model.evolve(anchor, 0, elapsed / 1000), 0.0
    return model.evolve(action.waited, G, (elapsed - wait) / 1000), G


def verify_logged_observation(row, exact, context, prefix=""):
    for name, expected in exact.items():
        column = f"{prefix}{name}"
        if name == "c_phase" and column not in row and prefix + "phase" in row:
            column = prefix + "phase"
        if column not in row or row[column] == "":
            continue
        actual = number(row, column)
        if name == "c_phase":
            # Compare in the complex plane at the native measurement scale.
            if expected is not None:
                weighted_error = exact["c_abs"] * abs(signed_phase_delta(expected, actual))
                tolerance(weighted_error, 0, f"Independent {column} for {context}", HALF_TOL)
        else:
            tolerance(actual, expected, f"Independent {column} for {context}", HALF_TOL)


def first_a_forecast(samples, max_index, load_floor=TOL):
    """Replay the first irrevocable M26 A forecast from sampled history."""
    past_rate = None
    for index, (ergotropy, rate) in enumerate(samples):
        if past_rate is not None and ergotropy > load_floor and 0 < rate < past_rate:
            delay = rate / (past_rate - rate)
            target = index + max(1, math.floor(delay + 0.5))
            if delay <= 5 and target <= max_index:
                return index, target, "forecast"
        if index == max_index:
            return index, index, "horizon"
        past_rate = rate
    raise ValueError("A forecast absent from recorded observation prefix")


def load_source(source, resolution):
    name = source[f"{resolution}_path"]
    expected = source[f"{resolution}_sha256"]
    return state_file(M23, name, expected, ticks(source, "source_time"))


def audit_controls(run_official):
    """Identify the exact control inputs and optionally rerun M26's full audit."""
    data = M26 / "results"
    sources = read_unique(read_rows(data / "m26_sources.csv"), lambda row: row["origin"])
    insist(set(sources) == ORIGINS, "M26 sources have wrong origin coverage")
    endpoints = read_unique(read_rows(data / "m26_endpoints.csv"), lambda row: (row["origin"], row["policy"]))
    insist(set(endpoints) == {(o, p) for o in ORIGINS for p in CONTROLS}, "M26 endpoint coverage differs")
    common = read_unique(read_rows(data / "m26_time_comparison.csv"),
                         lambda row: (row["origin"], row["policy"], ticks(row, "elapsed_total")))
    insist(sum(key[2] == CAP for key in common) == len(endpoints), "M26 lacks shared 540 endpoint rows")
    files = ("m26_sources.csv", "m26_endpoints.csv", "m26_time_comparison.csv", "m26_history.csv",
             "m26_checkpoints.csv", "m26_crossovers.csv")
    hashes = {name: sha256(data / name) for name in files}
    stored = ROOT / "audit_m26_controls.txt"
    output = stored.read_text(encoding="utf-8").splitlines() if stored.exists() else None
    if run_official:
        command = [sys.executable, "-B", str(M26 / "verify_m26.py")]
        result = subprocess.run(command, capture_output=True, check=True, text=True, encoding="utf-8")
        output = result.stdout.strip().splitlines()
        insist({name: sha256(data / name) for name in files} == hashes, "M26 inputs changed during verification")
    return {"source_sha256": hashes, "official_audit": output, "rerun": run_official}, sources


def table(path):
    return read_rows(path) if path.is_file() else []


def group_attempt(rows):
    grouped = defaultdict(list)
    for row in rows:
        grouped[int(row["attempt"])].append(row)
    return grouped


def optional_ticks(row, field):
    return ticks(row, field) if row.get(field, "") != "" else None


def phase_value(row):
    phase = row["phase"]
    return None if not phase else float(phase)


def phase_band(phase):
    return phase is not None and PHASE_WINDOWS[0] <= phase <= PHASE_WINDOWS[1]


def gate_at(decision, previous, accepted):
    magnitude, work = number(decision, "c_abs"), number(decision, "load_ergotropy")
    phase = phase_value(decision)
    inbound = phase_band(phase) and number(decision, "load_current") > 0 and number(decision, "load_ergotropy_rate") > 0
    previous_phase = phase_value(previous) if previous is not None else None
    turning = (phase is not None and previous_phase is not None and number(previous, "c_abs") >= PHASE_AMPLITUDE
               and abs(signed_phase_delta(previous_phase, phase)) >= math.pi / 3)
    short = bool(accepted and accepted[-1][1] <= 1e-8 and accepted[-1][0] - (accepted[-2][0] if len(accepted) >= 2 else 0) <= 100)
    return magnitude >= PHASE_AMPLITUDE and work <= 1e-8 and (inbound or turning or short), inbound, turning, short


class DecisionReplay:
    """Reconstruct the switching inputs from previously committed work only."""

    def __init__(self, policy):
        self.policy = policy
        self.mode = "forecast"
        self.last_switch = 0
        self.switches = []
        self.accepted = []
        self.previous = None
        self.low = ()
        self.high = ()
        self.baseline = None
        self.wait_history = defaultdict(list)
        self.wait_number = 0

    def audit(self, decision, start, context):
        insist(ticks(decision, "observed_until") == start, f"Future or stale mode observation at {context}")
        prior = self.accepted[-1] if self.accepted else None
        expected_interval = prior[0] - (self.accepted[-2][0] if len(self.accepted) >= 2 else 0) if prior else None
        if prior:
            insist(optional_ticks(decision, "latest_accepted_time") == prior[0], f"Wrong work witness clock for {context}")
            tolerance(number(decision, "latest_accepted_work"), prior[1], f"Last accepted work for {context}", TOL)
        else:
            insist(optional_ticks(decision, "latest_accepted_time") is None and decision["latest_accepted_work"] == "",
                   f"Work witness exists before first acceptance at {context}")
        if expected_interval is not None:
            insist(optional_ticks(decision, "latest_interval") == expected_interval, f"Wrong extraction interval for {context}")

        if start >= BASELINE_END and self.baseline is None:
            self.baseline = math.fsum(w for t, w in self.accepted if t <= BASELINE_END) / (BASELINE_END / 1000)
        if self.baseline is not None:
            tolerance(number(decision, "baseline_rate"), self.baseline, f"Baseline rate for {context}", 1e-17)
        else:
            insist(not decision["baseline_rate"], f"Baseline recorded before initial period at {context}")
        moving = math.fsum(w for t, w in self.accepted if start - RATE_SPAN < t <= start) / (RATE_SPAN / 1000)
        tolerance(number(decision, "moving_rate"), moving, f"Moving rate for {context}", 1e-17)

        mode_before = decision["mode_before"]
        insist(mode_before == self.mode, f"Wrong prior mode at {context}")
        eligible = start >= FIRST_SWITCH_TEST and self.baseline is not None and self.baseline > 0
        self.low = (*self.low, start) if self.mode == "forecast" and eligible and moving <= .45 * self.baseline else ()
        self.high = (*self.high, start) if self.mode == "wait" and eligible and moving >= .8 * self.baseline else ()
        for name, records in (("low", self.low), ("high", self.high)):
            insist(int(decision[f"{name}_count"]) == len(records), f"Wrong {name} persistence count at {context}")
            insist(optional_ticks(decision, f"{name}_since") == (records[0] if records else None),
                   f"Wrong {name} persistence start at {context}")
        low_persistent = len(self.low) >= 2 and start - self.low[0] >= PERSISTENCE
        high_persistent = len(self.high) >= 2 and start - self.high[0] >= PERSISTENCE
        gate, inbound, turning, short = gate_at(decision, self.previous, self.accepted)
        for field, expected in (("phase_gate", gate), ("supplying", inbound), ("rotated", turning), ("repeatedly_micro", short)):
            insist(flag(decision, field) == expected, f"Incorrect {field} at {context}")
        insist(ticks(decision, "last_mode_change") == self.last_switch, f"Wrong last transition time at {context}")

        next_mode = self.mode
        reason = "hold"
        if self.mode == "forecast" and low_persistent and (self.policy == "F1" or gate):
            if start - self.last_switch >= DWELL:
                next_mode = "wait"
                reason = "low_rate" if self.policy == "F1" else "low_rate_phase_gate"
        if self.mode == "wait" and self.policy == "F3" and high_persistent and not gate and start - self.last_switch >= DWELL:
            next_mode = "forecast"
            reason = "high_rate_phase_gate_clear"
        insist(decision["mode_after"] == next_mode, f"Incorrect mode transition at {context}: expected {next_mode}")
        insist(flag(decision, "switched") == (next_mode != self.mode) and decision["reason"] == reason,
               f"Incorrect mode transition classification at {context}")

        if next_mode != self.mode:
            self.last_switch = start
            self.switches.append((start, self.mode, next_mode))
            self.low = ()
            self.high = ()
        self.mode = next_mode
        self.previous = decision

    def expected_learning_wait(self, window):
        choices = [t for t in range(1000, 6001, 1000) if t + GRID <= window]
        if not choices:
            return 0, "no_wait_fits"
        self.wait_number += 1
        if self.wait_number <= 6:
            requested = self.wait_number * 1000
        elif self.wait_number % 7 == 0:
            requested = (1 + (self.wait_number // 7 - 1) % 6) * 1000
        else:
            scored = []
            for wait in choices:
                recent = self.wait_history[wait][-3:]
                if recent:
                    rate = math.fsum(w for w, _ in recent) / math.fsum(t / 1000 for _, t in recent)
                    scored.append((rate, -wait))
            return (-max(scored)[1], "empirical_exploit") if scored else (min(choices), "empirical_unseen")
        return (requested if requested in choices else min(choices)), "empirical_explore"

    def commit(self, end, tau, duration, work, accepted):
        if accepted:
            self.accepted.append((end, work))
        if self.mode == "wait" and self.policy == "F1" and tau:
            self.wait_history[tau].append((work, duration))

    def checkpoint(self):
        return {
            "mode": self.mode, "last_change": self.last_switch,
            "low_since": self.low[0] if self.low else None, "low_count": len(self.low),
            "high_since": self.high[0] if self.high else None, "high_count": len(self.high),
            "last_phase": phase_value(self.previous) if self.previous else 0.0,
            "last_amplitude": number(self.previous, "c_abs") if self.previous else 0.0,
        }


class ReplayModel(ExactContinuation):
    def __init__(self):
        super().__init__()
        self.sectors = tuple(np.flatnonzero(OCCUPATION == charge) for charge in np.unique(OCCUPATION))
        mixing = OCCUPATION[:, None] != OCCUPATION[None, :]
        insist(all(not np.any(hamiltonian[mixing]) for hamiltonian in self.h.values()), "Audit Hamiltonian mixes excitation sectors")
        self.sector_spectra = {g: tuple(np.linalg.eigh(hamiltonian[np.ix_(sector, sector)]) for sector in self.sectors)
                               for g, hamiltonian in self.h.items()}
        operator = np.zeros((6, 6), dtype=np.complex128)
        operator[3, 1], operator[4, 2] = 1, math.sqrt(2)
        self.coherence = np.kron(np.eye(DIM // 6), operator)

    @lru_cache(maxsize=128)
    def exact_blocks(self, coupling, elapsed):
        return tuple((vectors * np.exp(-1j * values * elapsed)) @ vectors.T
                     for values, vectors in self.sector_spectra[coupling])

    def evolve(self, state, g, elapsed):
        if elapsed == 0:
            return state
        operators = self.exact_blocks(g, elapsed)
        left = np.empty_like(state.matrix)
        result = np.empty_like(state.matrix)
        for sector, unitary in zip(self.sectors, operators, strict=True):
            left[sector, :] = unitary @ state.matrix[sector, :]
        for sector, unitary in zip(self.sectors, operators, strict=True):
            result[:, sector] = left[:, sector] @ unitary.conj().T
        return State(result, state.time + elapsed)

    @lru_cache(maxsize=32)
    def detached_coherence(self, tick):
        unitary = self.propagator(0, tick / 1000)
        return unitary.conj().T @ self.coherence @ unitary

    def detached_c(self, state, tick):
        return np.einsum("ij,ji->", self.detached_coherence(tick), state.matrix)


def audit_wait(model, checks, anchor, decision, row, context):
    start, window, tau = (ticks(row, key) for key in ("elapsed_start", "window", "tau"))
    if tau == 0:
        insist(not checks, f"No-wait attempt has detached observations at {context}")
        insist(row["wait_reason"] in {"no_wait", "no_wait_fits"}, f"Incorrect no-wait reason at {context}")
        return
    phase_policy = row["policy"] != "F1"
    last = min(6000, window - GRID) // 200 * 200 if phase_policy else tau
    first = 1000 if phase_policy else 200
    insist(first <= tau <= last and tau % 200 == 0, f"Off-grid wait at {context}")
    expected_ticks = list(range(first, tau + 1, 200))
    clocks = [ticks(witness, "elapsed_total") - start for witness in checks]
    insist(clocks == expected_ticks, f"Missing or future detached observations at {context}")
    c0 = complex(number(decision, "c_real"), number(decision, "c_imag"))
    for witness, dt in zip(checks, clocks, strict=True):
        insist(ticks(witness, "observed_until") == start + dt and ticks(witness, "wait_elapsed") == dt,
               f"Detached observation read ahead at {context}/{dt}")
        expected = model.detached_c(anchor, dt)
        real, imag = number(witness, "c_real"), number(witness, "c_imag")
        tolerance(real, expected.real, f"Detached coherence real part at {context}/{dt}", HALF_TOL)
        tolerance(imag, expected.imag, f"Detached coherence imaginary part at {context}/{dt}", HALF_TOL)
        magnitude = math.hypot(real, imag)
        tolerance(number(witness, "c_abs"), magnitude, f"Detached coherence amplitude at {context}/{dt}", TOL)
        phase = phase_value(witness)
        if phase is not None and magnitude > TOL:
            tolerance(signed_phase_delta(math.atan2(imag, real), phase), 0, f"Detached phase at {context}/{dt}", 1e-8)
        gate = (phase_policy and phase_band(phase) and magnitude >= PHASE_AMPLITUDE and -imag >= .25 * number(decision, "c_abs")
                and real <= c0.real + 1e-10)
        insist(flag(witness, "phase_gate") == gate, f"Wrong detached coherence gate at {context}/{dt}")
        for field, value in (("load_current", -2 * G * imag), ("actual_current", 0.0)):
            tolerance(number(witness, field), value, f"Wrong detached {field} at {context}/{dt}", TOL)
        insist(flag(witness, "reconnect") == (gate or dt == last), f"Bad reconnect witness at {context}/{dt}")
        if gate or dt == last:
            insist(dt == tau, f"Reconnect delayed past first valid phase at {context}")
    insist(gate or tau == last, f"Reconnect occurred before first valid phase at {context}")
    if phase_policy:
        insist(row["wait_reason"] == ("phase_gate" if gate else "phase_limit"), f"Wrong phase reconnect reason at {context}")


def audit_connected(model, observations, action, row, context):
    start, window, tau, connected, end = (ticks(row, key) for key in
                                           ("elapsed_start", "window", "tau", "elapsed_connected", "elapsed_total"))
    maximum = (window - tau) // GRID
    connect = start + tau
    insist(len(observations) == connected // GRID + 1, f"Missing or surplus connected observations at {context}")
    samples = []
    for i, witness in enumerate(observations):
        clock = connect + i * GRID
        insist(int(witness["index"]) == i and ticks(witness, "elapsed_total") == clock
               and ticks(witness, "observed_until") == clock, f"Future or off-grid connected observation at {context}/{i}")
        samples.append((number(witness, "load_ergotropy"), number(witness, "load_ergotropy_rate")))
    decided, execute, reason = first_a_forecast(samples, maximum)
    insist(ticks(row, "decision_elapsed_total") == connect + decided * GRID and row["stop_reason"] == reason,
           f"Ledger does not record first A forecast at {context}")
    insist(execute == connected // GRID and ticks(row, "observed_until") == end, f"Execution differs from first A forecast at {context}")
    for index, witness in enumerate(observations):
        insist(flag(witness, "forecast_generated") == (index == decided) and flag(witness, "execute") == (index == execute),
               f"Forecast or execution witness contradicts prefix replay at {context}/{index}")
    for index in {0, max(decided - 1, 0), decided, execute}:
        state = action.before if index == execute else model.evolve(action.waited, G, index * GRID / 1000)
        verify_logged_observation(observations[index], observation(model, state), f"{context}/sample {index}")
    tolerance(number(row, "candidate_net"), number(observations[-1], "total_work") - number(row, "cut_on") - number(row, "reconnect_on"),
              f"Accepted-candidate accounting from observation at {context}", TOL)


def audit_energy(model, row, action, companion, anchor, context, summary):
    half = companion if row["precision"] == "coarse" else action
    expected = {"cut_on": action.cut, "reconnect_on": action.reconnect,
                "cut_on_aligned": companion.cut, "reconnect_on_aligned": companion.reconnect,
                "cut_on_half": half.cut, "reconnect_on_half": half.reconnect,
                "net_work": action.observed_work, "direct_net": action.work,
                "net_work_aligned": companion.observed_work, "direct_net_aligned": companion.work,
                "direct_net_half": half.work,
                "candidate_net": action.work, "candidate_net_aligned": companion.work, "candidate_net_half": half.work,
                "direct_total_work": model.energy(action.before) - model.energy(action.hypothetical),
                "start_global_energy": model.energy(anchor), "pre_global_energy": model.energy(action.before),
                "post_global_energy": model.energy(action.after)}
    for field, value in expected.items():
        actual = number(row, field)
        tolerance(actual, value, f"Exact physical {field} at {context}")
        if field in {"net_work", "direct_net", "cut_on", "reconnect_on"}:
            summary["max_independent_work_error"] = max(summary["max_independent_work_error"], abs(actual - value))
    for field in ("accepted_energy_residual", "balance_residual", "waiting_energy_drift", "connected_energy_drift",
                  "cut_linear_residual", "reconnect_linear_residual", "global_passive_unitary_drift", "bare_chain_unitary_drift"):
        measured = abs(number(row, field))
        tolerance(measured, 0.0, f"Energy and invariant residual {field} at {context}", TOL)
        summary["max_energy_residual"] = max(measured, summary["max_energy_residual"])
    for prefix in ("pre", "post"):
        trace = abs(number(row, prefix + "_trace_error"))
        herm = abs(number(row, prefix + "_hermiticity_error"))
        minimum = number(row, prefix + "_minimum_eigenvalue")
        insist(max(trace, herm, -minimum) <= TOL, f"Unphysical recorded state {prefix} at {context}")
        summary["max_trace_error"] = max(trace, summary["max_trace_error"])
        summary["max_hermiticity_error"] = max(herm, summary["max_hermiticity_error"])
        summary["min_eigenvalue"] = min(minimum, summary["min_eigenvalue"])
    tolerance(number(row, "max_half_physicality_error"), 0.0, f"Unphysical aligned state at {context}", TOL)
    if flag(row, "accepted"):
        residual = number(row, "post_load_ergotropy")
        tolerance(residual, 0.0, f"Post-passivation load work remains at {context}", TOL)
        summary["max_post_ergotropy"] = max(abs(residual), summary["max_post_ergotropy"])
    if not flag(row, "accepted"):
        tolerance(number(row, "net_work"), -number(row, "cut_on") - number(row, "reconnect_on"),
                  f"Omitted switch work on rejected extraction at {context}", TOL)
    candidate, aligned = (number(row, field) for field in ("candidate_net", "candidate_net_aligned"))
    step = abs(candidate - aligned)
    summary["max_candidate_step_error"] = max(step, summary["max_candidate_step_error"])
    insist(step <= HALF_TOL, f"Unresolved aligned step convergence at {context}")
    tolerance(number(row, "candidate_step_error"), step, f"Incorrect candidate step difference at {context}", 1e-18)
    tolerance(number(row, "resolution_margin"), candidate - step, f"Incorrect resolution margin at {context}", 1e-18)
    expected_acceptance = candidate - step > TOL and number(row, "direct_net") > TOL and candidate >= TOL
    insist(flag(row, "accepted") == expected_acceptance, f"Invalid numerical acceptance at {context}")


def pair_key(row):
    return row["origin"], row["policy"], row["precision"]


def check_wait_summary(wait_row, history, decision, observations, context):
    opening, closing = phase_value(decision), phase_value(observations[0])
    initial_current, final_current = (number(sample, "load_current") for sample in (decision, observations[0]))
    expected = {"phase_before": opening, "phase_after": closing, "phase_change": signed_phase_delta(opening, closing),
                "current_before": initial_current, "current_after": final_current,
                "c_abs_before": number(decision, "c_abs"), "c_abs_after": number(observations[0], "c_abs")}
    for field, value in expected.items():
        tolerance(number(history, field), value, f"Inconsistent wait {field} at {context}", 1e-8 if "phase" in field else TOL)
    insist(flag(history, "sign_reversal") == (initial_current * final_current < 0), f"Wrong current sign reversal at {context}")
    if wait_row is not None:
        for field in (*expected, "sign_reversal", "tau", "net_work", "wait_reason"):
            if field in wait_row:
                insist(wait_row[field] == history[field], f"Wait and physical ledgers differ for {field} at {context}")
        start, tau, end = (ticks(history, key) for key in ("elapsed_start", "tau", "elapsed_total"))
        insist(ticks(wait_row, "wait_start_observed_until") == start
               and ticks(wait_row, "observed_until") == ticks(wait_row, "elapsed_total") == start + tau
               and ticks(wait_row, "extraction_elapsed") == end, f"Future data in wait summary at {context}")


def verify_boundary(model, folder, key, boundary, snapshot, anchors, counters, work, pending_from_rows, controller, ledger):
    context = f"{key} boundary {boundary}"
    row, = read_rows(folder / "m27_checkpoints.csv")
    insist(pair_key(row) == key and ticks(row, "elapsed_total") == boundary, f"Checkpoint identity differs at {context}")
    clock, attempts, accepted = counters
    insist((ticks(row, "anchor_elapsed"), int(row["attempts"]), int(row["count"])) == counters, f"Wrong counters at {context}")
    for field, value in zip(("cumulative_net", "cumulative_net_aligned", "cumulative_step_error_bound"), work, strict=True):
        tolerance(number(row, field), value, f"Checkpoint {field} at {context}", TOL)
    tolerance(number(row, "boundary_physicality_error"), 0, f"Checkpoint physicality at {context}", TOL)
    if row["resumed_state_error"]:
        tolerance(number(row, "resumed_state_error"), 0, f"Restart mismatch at {context}", TOL)
    with np.load(folder / "checkpoint.npz", allow_pickle=False) as saved:
        insist(int(saved["tick"].item()) == boundary and tuple(saved["counters"]) == counters, f"NPZ clocks differ at {context}")
        insist(str(saved["ending"].item()) == row["ending"] and str(saved["phase"].item()) == row["phase"], f"NPZ phase differs at {context}")
        tolerance(float(saved["coupling"].item()), number(row, "coupling"), f"NPZ coupling at {context}", TOL)
        for actual, expected in zip(saved["work"], work, strict=True):
            tolerance(float(actual), expected, f"NPZ work at {context}", TOL)
        records = json.loads(str(saved["records"].item()))
        insist(len(records) == attempts and sum(record["accepted"] for record in records) == accepted, f"NPZ accepted ledger differs at {context}")
        insist(records == ledger, f"Checkpoint stored different history from committed events at {context}")
        insist(json.loads(str(saved["controller"].item())) == controller and row["mode"] == controller["mode"],
               f"Controller state failed independent boundary replay at {context}")
        expected_ending = "active"
        if ledger and not ledger[-1]["accepted"] and controller["mode"] == "forecast":
            expected_ending = "numeric_floor"
        elif CAP - clock < GRID:
            expected_ending = "time_cap" if clock == CAP else "time_cap_no_grid"
        insist(row["ending"] == expected_ending, f"Independently determined ending differs at {context}")
        if records:
            insist(round(records[-1]["elapsed_total"] * 1000) == clock, f"NPZ ledger extends beyond anchor at {context}")
        for field, value in zip(("net_work", "net_work_aligned"), work[:2], strict=True):
            tolerance(math.fsum(record[field] for record in records), value, f"NPZ cumulative {field} at {context}", TOL)
        pending = json.loads(str(saved["pending"].item()))
        if expected_ending != "active":
            insist(not pending and number(row, "coupling") == G, f"Terminated branch has a pending action at {context}")
        observed = pending.get("last_observation_tick")
        forecast = pending.get("forecast_tick")
        execute = pending.get("execute_tick")
        insist(observed is None or clock <= observed <= boundary, f"Checkpoint read beyond boundary at {context}")
        insist(forecast is None or clock <= forecast <= observed <= boundary < execute,
               f"Checkpoint records a future or completed forecast at {context}")
        for csv_field, name in (("pending_tau_tick", "tau"), ("forecast_tick", "forecast_tick"),
                                ("execute_tick", "execute_tick"), ("last_observation_tick", "last_observation_tick")):
            insist((int(row[csv_field]) if row[csv_field] else None) == pending.get(name), f"Inconsistent pending schedule at {context}")
        for field in ("cut_applied", "reconnect_applied"):
            insist(flag(row, field) == pending.get(field, False), f"Inconsistent {field} at {context}")
        tolerance(number(row, "pending_switch_net"), pending.get("switch_net", 0), f"Pending switch accounting at {context}", TOL)
        if pending_from_rows is not None:
            for field, value in pending_from_rows.items():
                if field == "switch_net":
                    tolerance(pending[field], value, f"Independent switch accounting at {context}")
                else:
                    insist(pending[field] == value, f"Independent pending {field} differs at {context}: {pending[field]} != {value}")
            detached = pending_from_rows["cut_applied"] and not pending_from_rows["reconnect_applied"]
            insist(number(row, "coupling") == (0 if detached else G) and row["phase"] == ("wait" if detached else "connected"),
                   f"Wrong independently reconstructed physical boundary phase at {context}")
        if snapshot is None:
            # The short benchmark may end inside an uncommitted final attempt.
            coupling = float(saved["coupling"].item())
            tau = pending.get("tau") or 0
            if coupling == 0:
                snapshot = tuple(model.evolve(state, 0, (boundary - clock) / 1000) for state in anchors)
            else:
                snapshot = tuple(model.evolve(model.evolve(state, 0, tau / 1000), G, (boundary - clock - tau) / 1000)
                                 for state in anchors)
        current_energy = model.energy(snapshot[0], number(row, "coupling"))
        tolerance(current_energy + number(row, "pending_switch_net"), model.energy(anchors[0]),
                  f"Energy closure with pending switch inputs at {context}")
        maximum_error = 0.0
        labels = RESOLUTIONS if key[2] == "coarse" else tuple(reversed(RESOLUTIONS))
        for label, anchor, target in zip(labels, anchors, snapshot, strict=True):
            for prefix, entry, state in (("anchor", "anchor_" + label, anchor), ("boundary", label, target)):
                matrix = saved[entry]
                insist(matrix.shape == (DIM, DIM) and np.isfinite(matrix).all(), f"Invalid NPZ {entry} at {context}")
                insist(state_sha256(matrix) == row[f"{prefix}_{label}_sha256"], f"NPZ hash mismatch {entry} at {context}")
                physical_state(State(matrix, state.time), (context, entry))
                error = maxabs(matrix - state.matrix)
                tolerance(error, 0, f"Exact density difference {entry} at {context}", BOUNDARY_STATE_TOL)
                maximum_error = max(error, maximum_error)
    return maximum_error


def cross_boundary_pending(row, observations, checks, boundary):
    start, tau = (ticks(row, field) for field in ("elapsed_start", "tau"))
    in_wait = boundary < start + tau
    observation = max(ticks(record, "elapsed_total") for record in [*observations, *checks, {"elapsed_total": row["elapsed_start"]}]
                      if ticks(record, "elapsed_total") <= boundary)
    forecast = ticks(row, "decision_elapsed_total")
    return {"tau": None if in_wait and row["policy"] != "F1" else tau,
            "forecast_tick": forecast if forecast <= boundary else None,
            "execute_tick": ticks(row, "elapsed_total") if forecast <= boundary else None,
            "cut_applied": bool(tau), "reconnect_applied": bool(tau) and not in_wait,
            "switch_net": -number(row, "cut_on") - (0 if in_wait else number(row, "reconnect_on")),
            "last_observation_tick": observation}


def verify_switch_state(folder, trial, states, context):
    clock = ticks(trial, "elapsed_start")
    path = folder / f"switch_{clock}.npz"
    labels = RESOLUTIONS if trial["precision"] == "coarse" else tuple(reversed(RESOLUTIONS))
    with np.load(path, allow_pickle=False) as saved:
        insist(int(saved["tick"].item()) == clock, f"Invalid switch state clock at {context}")
        for label, state in zip(labels, states, strict=True):
            matrix = saved[label]
            insist(state_sha256(matrix) == trial[f"start_{label}_sha256"], f"Switch state hash differs at {context}/{label}")
            tolerance(maxabs(matrix - state.matrix), 0, f"Independent switch matrix at {context}/{label}", BOUNDARY_STATE_TOL)


def audit_branch(model, source, key, folders, control_history):
    origin, policy, precision = key
    other = "half" if precision == "coarse" else "coarse"
    states = load_source(source, precision), load_source(source, other)
    for state, label in zip(states, (precision, other), strict=True):
        physical_state(state, (origin, "source", label))
    initial_energy = tuple(model.energy(state) for state in states)
    previous_hashes = {label: state_sha256(load_source(source, label).matrix) for label in RESOLUTIONS}
    control = DecisionReplay(policy)
    summary = dict(attempts=0, accepted=0, rejected=0, observations=0, wait_checks=0, waiting_attempts=0, switches=[],
                   max_independent_work_error=0.0, max_energy_residual=0.0, max_trace_error=0.0,
                   max_hermiticity_error=0.0, min_eigenvalue=0.0, max_post_ergotropy=0.0,
                   max_candidate_step_error=0.0, max_boundary_state_error=0.0, max_aligned_state_error=0.0,
                   max_resume_error=0.0, m26_a_prefix_attempts=0, max_forecast_lead=0.0)
    history, extraction_times, ledger, net_path = [], [], [], [0.0]
    clock, completed, accepted_count = 0, 0, 0
    work = (0.0, 0.0, 0.0)
    endings = False
    boundaries = {tick: read_rows(folder / "m27_checkpoints.csv")[0] for tick, folder in folders.items()}
    boundary_inputs = {}
    for boundary, folder in folders.items():
        stage_history = table(folder / "m27_history.csv")
        decisions = read_unique(table(folder / "m27_decisions.csv"), lambda row: int(row["attempt"]))
        waits = read_unique(table(folder / "m27_waits.csv"), lambda row: int(row["attempt"]))
        checks = group_attempt(table(folder / "m27_wait_checks.csv"))
        observed = group_attempt(table(folder / "m27_observations.csv"))
        attempts = {int(row["attempt"]) for row in stage_history}
        insist(set(decisions) == attempts == set(observed) and set(waits) <= attempts and set(checks) <= attempts,
               f"Inconsistent stage evidence coverage for {folder}")
        insist(int(boundaries[boundary]["attempts_in_stage"]) == len(stage_history), f"Stage counters do not match committed evidence for {folder}")
        stage_switch_paths = set()
        for row in stage_history:
            number_in_branch = int(row["attempt"])
            decision = decisions[number_in_branch]
            observations = observed[number_in_branch]
            wait_checks = checks[number_in_branch]
            context = (origin, policy, precision, number_in_branch)
            insist(number_in_branch == completed + 1 and pair_key(row) == key and not endings, f"Noncontiguous ledger at {context}")
            for item in [decision, *observations, *wait_checks, *([waits[number_in_branch]] if number_in_branch in waits else [])]:
                insist(pair_key(item) == key, f"Unexpected observation provenance at {context}")
            start, window, tau, connected, duration, end = (ticks(row, field) for field in
                ("elapsed_start", "window", "tau", "elapsed_connected", "duration", "elapsed_total"))
            insist(clock == start and window == min(HORIZON, CAP - start)
                   and 0 <= tau and GRID <= connected and connected % GRID == 0
                   and duration == tau + connected == end - start <= window and end <= boundary,
                   f"Off-lattice, unexecuted or overlapping ledger interval at {context}")
            tolerance(number(row, "absolute_time"), number(source, "source_time") + end / 1000, f"Physical clock at {context}", TOL)
            insist(all(row[f"start_{label}_sha256"] == digest for label, digest in previous_hashes.items()),
                   f"State hash chain disconnected at {context}")
            for label in RESOLUTIONS:
                previous_hashes[label] = row[f"post_{label}_sha256"]

            verify_logged_observation(decision, observation(model, states[0]), f"{context}/mode decision")
            insist(ticks(decision, "elapsed_total") == start, f"Decision clock differs at {context}")
            prior_controller = control.checkpoint()
            control.audit(decision, start, context)
            insist(control.mode == row["mode"], f"Execution mode differs from decision at {context}")
            if flag(decision, "switched"):
                verify_switch_state(folder, row, states, context)
                stage_switch_paths.add(f"switch_{start}.npz")
            if control.mode == "forecast":
                insist(tau == 0 and row["wait_reason"] == "no_wait", f"Forecast mode detached at {context}")
                if precision == "coarse" and not control.switches:
                    control_row = control_history[number_in_branch - 1]
                    for field in ("elapsed_start", "elapsed_total", "decision_elapsed_total"):
                        insist(ticks(row, field) == ticks(control_row, field), f"Initial forecast disagrees with M26 A at {context}/{field}")
                    tolerance(number(row, "net_work"), number(control_row, "net_work"), f"Initial forecast work disagrees with M26 A at {context}", TOL)
                    insist(flag(row, "accepted") == flag(control_row, "accepted"), f"Initial forecast acceptance disagrees with M26 A at {context}")
                    summary["m26_a_prefix_attempts"] += 1
            elif policy == "F1":
                insist((tau, row["wait_reason"]) == control.expected_learning_wait(window), f"F1 did not use prior reward rule at {context}")
            elif min(6000, window - GRID) >= 1000:
                insist(tau >= 1000, f"Phase wait skipped available observations at {context}")
            insist((number_in_branch in waits) == bool(tau), f"Missing time and phase wait record at {context}")
            audit_wait(model, wait_checks, states[0], decision, row, context)

            approved = flag(row, "accepted")
            actions = tuple(exact_action(model, state, tau, connected, approved) for state in states)
            audit_connected(model, observations, actions[0], row, context)
            audit_energy(model, row, *actions, states[0], context, summary)
            check_wait_summary(waits.get(number_in_branch), row, decision, observations, context)
            n_work, aligned_work = (number(row, field) for field in ("net_work", "net_work_aligned"))
            work_after = work[0] + n_work, work[1] + aligned_work, work[2] + abs(n_work - aligned_work)
            for field, value in zip(("cumulative_net", "cumulative_net_aligned", "cumulative_step_error_bound"), work_after, strict=True):
                tolerance(number(row, field), value, f"Independent {field} at {context}", TOL)
            for action, recovered, budget in zip(actions, work_after[:2], initial_energy, strict=True):
                tolerance(model.energy(action.after) + recovered, budget, f"Independent cumulative energy budget at {context}")

            for time, checkpoint in boundaries.items():
                if start <= time < end and (time not in boundary_inputs or boundary_inputs[time][0] is None):
                    clocks = [action_snapshot(model, state, start, tau, connected, action, time)[0]
                              for state, action in zip(states, actions, strict=True)]
                    insist(ticks(checkpoint, "anchor_elapsed") == start, f"Boundary omitted previous operation at {context}/{time}")
                    boundary_inputs[time] = (tuple(clocks), states, (start, completed, accepted_count), work,
                                             cross_boundary_pending(row, observations, wait_checks, time), prior_controller, list(ledger))
            if approved:
                extraction_times.append(end)
            accepted_count += int(approved)
            insist(int(row["count"]) == accepted_count, f"Committed extraction count differs at {context}")
            control.commit(end, tau, duration, n_work, approved)
            states = tuple(action.after for action in actions)
            clock, completed, work = end, number_in_branch, work_after
            endings = control.mode == "forecast" and not approved
            summary["attempts"] += 1
            summary["accepted"] += int(approved)
            summary["rejected"] += int(not approved)
            summary["observations"] += len(observations)
            summary["wait_checks"] += len(wait_checks)
            summary["waiting_attempts"] += int(bool(tau))
            summary["max_aligned_state_error"] = max(summary["max_aligned_state_error"], number(row, "half_state_max_error"))
            decision_tick = ticks(row, "decision_elapsed_total")
            summary["max_forecast_lead"] = max(summary["max_forecast_lead"], (end - decision_tick) / 1000)
            mode_evidence = {field: number(decision, field) if decision[field] else None for field in
                             ("moving_rate", "baseline_rate", "load_ergotropy", "load_ergotropy_rate", "load_current", "c_abs", "phase")}
            mode_evidence.update({field: flag(decision, field) for field in ("phase_gate", "supplying", "rotated", "repeatedly_micro")})
            mode_evidence.update(mode=control.mode, switch_reason=decision["reason"], wait_reason=row["wait_reason"])
            history.append((start, tau, decision_tick, end, mode_evidence))
            net_path.append(work[0])
            ledger.append({"elapsed_total": end / 1000, "duration": duration / 1000, "tau": tau / 1000,
                           "accepted": approved, "net_work": n_work, "net_work_aligned": aligned_work})
        insist({path.name for path in folder.glob("switch_*.npz")} == stage_switch_paths, f"Unexpected switch checkpoints for {folder}")
        if boundary not in boundary_inputs:
            snapshot = tuple(model.evolve(state, G, (boundary - clock) / 1000) for state in states) if endings or CAP - clock < GRID else None
            boundary_inputs[boundary] = (snapshot, states, (clock, completed, accepted_count), work, None,
                                         control.checkpoint(), list(ledger))
    # Crossing checkpoints can be interpreted using the next stage's committed attempt.
    for boundary, folder in folders.items():
        maximum = verify_boundary(model, folder, key, boundary, *boundary_inputs[boundary])
        summary["max_boundary_state_error"] = max(maximum, summary["max_boundary_state_error"])
        resumed_error = boundaries[boundary]["resumed_state_error"]
        if resumed_error:
            summary["max_resume_error"] = max(summary["max_resume_error"], float(resumed_error))
    summary["switches"] = [{"time": tick / 1000, "before": before, "after": after} for tick, before, after in control.switches]
    summary["cumulative_net"] = work[0]
    summary["cumulative_net_aligned"] = work[1]
    end_ticks = [row[3] for row in history]
    last_boundary = next(reversed(folders))
    summary["cumulative_net_at_common_times"] = {str(time): net_path[bisect_right(end_ticks, time * 1000)]
                                                 for time in COMMON if time * 1000 <= last_boundary}
    return history, extraction_times, summary


def branch_folders(root, key, boundaries):
    return {tick: root.joinpath(f"t{tick // 1000}", *key) for tick in boundaries}


def compare_oneshot(root, folders, key):
    """Require identical event evidence and independent final checkpoint payloads."""
    boundary, staged = next(reversed(folders.items()))
    direct = root.joinpath(f"t{boundary // 1000}", *key)
    names = ("m27_history.csv", "m27_decisions.csv", "m27_observations.csv", "m27_wait_checks.csv", "m27_waits.csv")
    for filename in names:
        from_stages = [row for folder in folders.values() for row in table(folder / filename)]
        insist(from_stages == table(direct / filename), f"One-shot and restarted {filename} differ for {key}")
    with np.load(staged / "checkpoint.npz", allow_pickle=False) as resumed, np.load(direct / "checkpoint.npz", allow_pickle=False) as one:
        insist(resumed.files == one.files, f"One-shot and restarted checkpoint inventories differ for {key}")
        for field in resumed.files:
            insist(np.array_equal(resumed[field], one[field]), f"One-shot and restarted checkpoint {field} differ for {key}")


def trace_distance(left, right):
    difference = left - right
    density = (difference + difference.conj().T) / 2
    return float(np.abs(np.linalg.eigvalsh(density)).sum() / 2)


def boundary_distances(coarse_folders, half_folders):
    comparisons = []
    for tick, coarse_path in coarse_folders.items():
        half_path = half_folders[tick]
        with np.load(coarse_path / "checkpoint.npz", allow_pickle=False) as coarse, np.load(half_path / "checkpoint.npz", allow_pickle=False) as half:
            native_coarse, native_half = coarse["coarse"], half["half"]
            comparisons.append({
                "elapsed_total": tick / 1000,
                "native_state_trace_distance": trace_distance(native_coarse, native_half),
                "coarse_clock_aligned_trace_distance": trace_distance(native_coarse, coarse["half"]),
                "half_clock_aligned_trace_distance": trace_distance(native_half, half["coarse"]),
            })
    return comparisons


def convergence(origin, policy, coarse, half, coarse_folders, half_folders):
    coarse_history, coarse_extracts, c = coarse
    half_history, half_extracts, h = half
    coarse_ticks = [row[:4] for row in coarse_history]
    half_ticks = [row[:4] for row in half_history]
    coarse_switches, half_switches = c["switches"], h["switches"]
    first_change = next((i for i, (x, y) in enumerate(zip(coarse_ticks, half_ticks, strict=False), 1) if x != y), None)
    if first_change is None and len(coarse_ticks) != len(half_ticks):
        first_change = min(len(coarse_ticks), len(half_ticks)) + 1
    first_coarse = coarse_history[first_change - 1] if first_change is not None and first_change <= len(coarse_history) else None
    first_half = half_history[first_change - 1] if first_change is not None and first_change <= len(half_history) else None
    coarse_extractions, half_extractions = set(coarse_extracts), set(half_extracts)
    return {
        "origin": origin, "policy": policy,
        "coarse_switch_times": [row["time"] for row in coarse_switches],
        "half_switch_times": [row["time"] for row in half_switches],
        "identical_switches": coarse_switches == half_switches,
        "identical_attempt_clocks": coarse_ticks == half_ticks,
        "identical_extraction_clocks": coarse_extracts == half_extracts,
        "nonmatching_coarse_extraction_times": len(coarse_extractions - half_extractions),
        "nonmatching_half_extraction_times": len(half_extractions - coarse_extractions),
        "first_attempt_clock_change": first_change,
        "first_change_clock_order": ["anchor", "wait_duration", "forecast_issue", "operation_end"],
        "coarse_attempt_at_first_change_ticks": first_coarse[:4] if first_coarse is not None else None,
        "half_attempt_at_first_change_ticks": first_half[:4] if first_half is not None else None,
        "first_change_coarse_evidence": first_coarse[4] if first_coarse is not None else None,
        "first_change_half_evidence": first_half[4] if first_half is not None else None,
        "latest_coarse_extraction_time": coarse_extracts[-1] / 1000 if coarse_extracts else None,
        "latest_half_extraction_time": half_extracts[-1] / 1000 if half_extracts else None,
        "aligned_cumulative_delta": c["cumulative_net"] - c["cumulative_net_aligned"],
        "independent_cumulative_delta": c["cumulative_net"] - h["cumulative_net"],
        "max_common_cumulative_delta": max((abs(net - h["cumulative_net_at_common_times"][time])
                                            for time, net in c["cumulative_net_at_common_times"].items()), default=0.0),
        "boundary_distances": boundary_distances(coarse_folders, half_folders),
    }


AUDIT_MODEL = None


def audit_job(key, source, folders, control_history, oneshot):
    global AUDIT_MODEL
    if AUDIT_MODEL is None:
        AUDIT_MODEL = ReplayModel()
    for index, (tick, folder) in enumerate(folders.items()):
        row, = read_rows(folder / "m27_checkpoints.csv")
        insist(bool(row["resumed_state_error"]) == bool(index), f"Missing actual boundary resume result at {key}/{tick}")
    result = audit_branch(AUDIT_MODEL, source, key, folders, control_history)
    if oneshot:
        compare_oneshot(oneshot, folders, key)
    summary = result[2]
    print(f"PASS {'/'.join(key)}: {summary['attempts']} attempts, {summary['switches']} switches, "
          f"exact state error {summary['max_boundary_state_error']:.6g}", flush=True)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stages", nargs="?", type=Path, default=ROOT / "stages")
    parser.add_argument("--cutoffs", nargs="+", type=int, default=(150, 300, 540))
    parser.add_argument("--origins", nargs="+", choices=sorted(ORIGINS), default=sorted(ORIGINS))
    parser.add_argument("--policies", nargs="+", choices=ADAPTIVE, default=ADAPTIVE)
    parser.add_argument("--precisions", nargs="+", choices=RESOLUTIONS, default=RESOLUTIONS)
    parser.add_argument("--oneshot", type=Path)
    parser.add_argument("--oneshot-origins", nargs="+", choices=sorted(ORIGINS), default=sorted(ORIGINS))
    parser.add_argument("--oneshot-policies", nargs="+", choices=ADAPTIVE, default=ADAPTIVE)
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--run-controls", action="store_true")
    args = parser.parse_args()
    insist(args.workers >= 1, "Worker count must be positive")
    boundaries = tuple(cutoff * 1000 for cutoff in args.cutoffs)
    insist(0 < boundaries[0] and boundaries[-1] <= CAP and list(boundaries) == sorted(set(boundaries)), "Invalid increasing stage times")
    protocol = sha256(ROOT / "PROTOCOL_M27.md")
    insist((args.stages / "protocol.sha256").read_text(encoding="utf-8").strip() == protocol, "Saved stages use a different protocol")
    if args.oneshot:
        insist((args.oneshot / "protocol.sha256").read_text(encoding="utf-8").strip() == protocol, "One-shot reference uses a different protocol")
    controls, sources = audit_controls(args.run_controls)
    control_histories = defaultdict(list)
    for row in read_rows(M26 / "results" / "m26_history.csv"):
        if row["policy"] == "A":
            control_histories[row["origin"]].append(row)
    keys = [(origin, policy, precision) for origin in args.origins for policy in args.policies for precision in args.precisions]
    oneshot_keys = [key for key in keys if args.oneshot and key[0] in args.oneshot_origins and key[1] in args.oneshot_policies]
    jobs = {key: (key, sources[key[0]], branch_folders(args.stages, key, boundaries), control_histories[key[0]],
                  args.oneshot if key in oneshot_keys else None) for key in keys}
    if args.workers == 1:
        results = {key: audit_job(*job) for key, job in jobs.items()}
    else:
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            pending = {key: pool.submit(audit_job, *job) for key, job in jobs.items()}
            results = {key: job.result() for key, job in pending.items()}
    branches = {"/".join(key): value[2] for key, value in results.items()}
    pairs = [(origin, policy) for origin in args.origins for policy in args.policies]
    comparisons = [convergence(*key, results[*key, "coarse"], results[*key, "half"],
                               jobs[*key, "coarse"][2], jobs[*key, "half"][2]) for key in pairs
                   if all((*key, precision) in results for precision in RESOLUTIONS)]
    totals = {field: sum(item[field] for item in branches.values()) for field in
              ("attempts", "accepted", "rejected", "observations", "wait_checks", "waiting_attempts", "m26_a_prefix_attempts")}
    for field in ("max_independent_work_error", "max_energy_residual", "max_trace_error", "max_hermiticity_error",
                  "max_post_ergotropy", "max_candidate_step_error", "max_boundary_state_error",
                  "max_aligned_state_error", "max_resume_error", "max_forecast_lead"):
        totals[field] = max(item[field] for item in branches.values())
    totals["min_eigenvalue"] = min(item["min_eigenvalue"] for item in branches.values())
    totals["max_future_observation_lead"] = 0.0
    for key in ("switches", "attempt_clocks", "extraction_clocks"):
        totals[f"branch_pairs_with_different_{key}"] = sum(not row[f"identical_{key}"] for row in comparisons)
    totals["max_independent_cumulative_delta"] = max((abs(row["independent_cumulative_delta"]) for row in comparisons), default=0.0)
    totals["max_common_cumulative_delta"] = max((row["max_common_cumulative_delta"] for row in comparisons), default=0.0)
    report = {"protocol_sha256": protocol, "boundaries": args.cutoffs, "controls": controls,
              "one_shot_comparison": bool(oneshot_keys), "one_shot_branches": ["/".join(key) for key in oneshot_keys],
              "totals": totals, "branch_results": branches, "convergence": comparisons}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(f"PASS: {len(branches)} adaptive branches and {len(branches) * len(boundaries)} checkpoints; "
          f"{sum(item['observations'] for item in branches.values())} connected observations, "
          f"{sum(item['wait_checks'] for item in branches.values())} wait observations", flush=True)


if __name__ == "__main__":
    main()
