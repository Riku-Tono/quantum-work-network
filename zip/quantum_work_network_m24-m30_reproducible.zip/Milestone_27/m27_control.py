"""Frozen M27 decisions applied to time-stamped observations and completed work."""

from dataclasses import dataclass
import math

POLICIES = ("F1", "F2", "F3")
BASE_END = 32_000
ROLLING = 24_000
EARLIEST = 48_000
PERSIST = 4_000
DWELL = 30_000
WAIT_ARMS = tuple(range(1000, 6001, 1000))
PHASE_MIN = 1e-5
MICRO = 1e-8


def angle_delta(after, before):
    return math.remainder(after - before, 2 * math.pi)


def supply_phase(phase):
    return -3 * math.pi / 4 <= phase <= -math.pi / 4


def tick(row, field="elapsed_total"):
    return round(float(row[field]) * 1000)


@dataclass
class Controller:
    mode: str = "forecast"
    last_change: int = 0
    low_since: int | None = None
    low_count: int = 0
    high_since: int | None = None
    high_count: int = 0
    last_phase: float = 0.0
    last_amplitude: float = 0.0

    def update(self, policy, now, observation, records):
        accepted = [row for row in records if row["accepted"]]
        base = (math.fsum(row["net_work"] for row in accepted if 0 < tick(row) <= BASE_END) / 32
                if now >= BASE_END else None)
        moving = math.fsum(row["net_work"] for row in accepted if now - ROLLING < tick(row) <= now) / 24
        last = accepted[-1] if accepted else None
        interval = tick(last) - (tick(accepted[-2]) if len(accepted) > 1 else 0) if last else None
        latest_work = last["net_work"] if last else None
        phase = observation["phase"]
        phase_difference = angle_delta(phase, self.last_phase)
        supplying = supply_phase(phase) and observation["load_current"] > 0 and observation["load_ergotropy_rate"] > 0
        rotated = self.last_amplitude >= PHASE_MIN and abs(phase_difference) >= math.pi / 3
        micro = latest_work is not None and latest_work <= MICRO and interval <= 100
        phase_gate = (observation["load_ergotropy"] <= MICRO and observation["c_abs"] >= PHASE_MIN
                      and (supplying or rotated or micro))
        eligible = now >= EARLIEST and base is not None and base > 0
        if self.mode == "forecast" and eligible and moving <= 0.45 * base:
            if self.low_since is None:
                self.low_since = now
            self.low_count += 1
        else:
            self.low_since, self.low_count = None, 0
        if self.mode == "wait" and eligible and moving >= 0.8 * base:
            if self.high_since is None:
                self.high_since = now
            self.high_count += 1
        else:
            self.high_since, self.high_count = None, 0
        low = self.low_count >= 2 and now - self.low_since >= PERSIST
        high = self.high_count >= 2 and now - self.high_since >= PERSIST
        previous_mode = self.mode
        changed_at = self.last_change
        reason = "hold"
        if self.mode == "forecast" and low and (policy == "F1" or phase_gate):
            if now - self.last_change >= DWELL:
                self.mode = "wait"
                reason = "low_rate" if policy == "F1" else "low_rate_phase_gate"
        elif self.mode == "wait" and policy == "F3" and high and not phase_gate:
            if now - self.last_change >= DWELL:
                self.mode = "forecast"
                reason = "high_rate_phase_gate_clear"
        self.last_phase = phase
        self.last_amplitude = observation["c_abs"]
        switched = self.mode != previous_mode
        row = {
            "elapsed_total": now / 1000, "observed_until": now / 1000,
            "mode_before": previous_mode, "mode_after": self.mode, "switched": switched, "reason": reason,
            "baseline_rate": base, "moving_rate": moving,
            "low_count": self.low_count, "low_since": self.low_since / 1000 if self.low_since is not None else None,
            "high_count": self.high_count, "high_since": self.high_since / 1000 if self.high_since is not None else None,
            "last_mode_change": changed_at / 1000, "phase_gate": phase_gate, "supplying": supplying,
            "rotated": rotated, "repeatedly_micro": micro, "phase_difference": phase_difference,
            "latest_accepted_time": tick(last) / 1000 if last else None,
            "latest_accepted_work": latest_work, "latest_interval": interval / 1000 if last else None,
            **observation,
        }
        if switched:
            self.last_change = now
            self.low_since, self.low_count = None, 0
            self.high_since, self.high_count = None, 0
        return row


def empirical_wait(records, maximum):
    arms = [value for value in WAIT_ARMS if value <= maximum]
    if not arms:
        return 0, "no_wait_fits"
    previous = [row for row in records if float(row["tau"]) > 0]
    number = len(previous) + 1
    if number <= len(WAIT_ARMS) or number % 7 == 0:
        index = number - 1 if number <= len(WAIT_ARMS) else (number // 7 - 1) % len(WAIT_ARMS)
        planned = WAIT_ARMS[index]
        return (planned if planned in arms else arms[0]), "empirical_explore"
    rates = {}
    for arm in arms:
        samples = [row for row in previous if tick(row, "tau") == arm][-3:]
        if samples:
            rates[arm] = math.fsum(row["net_work"] for row in samples) / math.fsum(row["duration"] for row in samples)
    if not rates:
        return arms[0], "empirical_unseen"
    return max(rates, key=lambda arm: (rates[arm], -arm)), "empirical_exploit"


def phase_reconnect(observation, before, g):
    return (supply_phase(observation["phase"]) and observation["c_abs"] >= PHASE_MIN
            and observation["load_current"] >= 0.25 * 2 * g * before["c_abs"]
            and observation["c_real"] <= before["c_real"] + 1e-10)
