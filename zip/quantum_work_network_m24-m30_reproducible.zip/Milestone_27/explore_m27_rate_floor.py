"""Retest C04/F2 half-step with a positive-rate floor in the phase gate."""

import argparse
import csv
import json
from pathlib import Path

import run_m27 as run

RATE_FLOOR = 1e-12


class ControllerWithRateFloor(run.Controller):
    def update(self, policy, now, observed, records):
        actual = observed["load_ergotropy_rate"]
        gated = 0.0 if 0.0 < actual <= RATE_FLOOR else actual
        result = super().update(policy, now, {**observed, "load_ergotropy_rate": gated}, records)
        result["load_ergotropy_rate"] = actual
        result["load_ergotropy_rate_for_phase_gate"] = gated
        return result


def trajectory(stages, variant, precision, times):
    switch = None
    for elapsed in times:
        folder = stages / f"t{elapsed}" / "C04" / "F2" / precision
        if switch is None:
            switch = min((int(path.stem.removeprefix("switch_")) / 1000
                          for path in folder.glob("switch_*.npz")), default=None)
        checkpoint, = run.csv_rows(folder / "m27_checkpoints.csv")
        yield {"variant": variant, "precision": precision, "elapsed_total": elapsed,
               "first_switch": switch, "count": checkpoint["count"], "cumulative_net": checkpoint["cumulative_net"],
               "primary_boundary_sha256": checkpoint[f"boundary_{precision}_sha256"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--formal", type=Path, default=run.ROOT / "stages")
    parser.add_argument("--output", type=Path, default=run.ROOT / "exploration" / "rate_floor")
    args = parser.parse_args()
    if args.output.resolve() == args.formal.resolve() or args.formal.resolve() in args.output.resolve().parents:
        parser.error("Exploration must have its own output directory")
    times = (150, 300, 540)
    if sum(1 for _ in args.formal.glob("t540/*/*/*/checkpoint.npz")) != 24:
        parser.error("All formal branches must finish before the exploratory run")
    source, = (row for row in run.csv_rows(run.SOURCE_TABLE) if row["origin"] == "C04")
    settings = {"analysis": "exploratory", "origin": "C04", "policy": "F2", "precision": "half",
                "phase_gate_positive_rate_floor": RATE_FLOOR,
                "formal_protocol_sha256": (args.formal / "protocol.sha256").read_text().strip()}
    args.output.mkdir(parents=True, exist_ok=True)
    config = args.output / "conditions.json"
    if config.exists() and json.loads(config.read_text()) != settings:
        parser.error("Exploration output already has different conditions")
    config.write_text(json.dumps(settings, indent=2) + "\n")
    run.Controller = ControllerWithRateFloor
    exploratory = args.output / "stages"
    run.run_chain(source, "F2", "half", exploratory, tuple(time * 1000 for time in times))
    rows = [*trajectory(args.formal, "formal", "coarse", times),
            *trajectory(args.formal, "formal", "half", times),
            *trajectory(exploratory, "positive_rate_floor", "half", times)]
    with (args.output / "comparison.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    main()
