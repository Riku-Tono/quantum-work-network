"""Independently check M27 matched state, branch and single-wait diagnostics."""

import argparse
from collections import defaultdict
from itertools import combinations
import math
from pathlib import Path

from verify_m27 import (
    G, GRID, HALF_TOL, HORIZON, LOAD_LEVELS, M26, ROOT, TOL, ReplayModel, State, exact_action, flag, insist,
    load_source, maxabs, np, number, observation, physical_state, read_rows, read_unique, reduced_load,
    state_sha256, terminal_state, ticks, tolerance,
)
from verify_m26 import terminal_prefix


CONTINUATIONS = ("A", "online_wait", "E_retrospective")
OFFSETS = (0, 18_000, 36_000, 54_000)
RESOLUTIONS = ("coarse", "half")


def read_group(path, *keys):
    groups = defaultdict(list)
    for row in read_rows(path):
        groups[tuple(row[key] for key in keys)].append(row)
    return groups


def archived_states(model, source, history, times):
    state, clock = load_source(source, "coarse"), 0
    pending = set(times)
    result = {}
    count, work = 0, 0.0
    for row in history:
        if clock in pending:
            result[clock] = state, G, count, work
            pending.remove(clock)
        if not pending:
            break
        start, end, tau, connected = (ticks(row, key) for key in ("elapsed_start", "elapsed_total", "tau", "elapsed_connected"))
        insist(start == clock and end == start + tau + connected, f"Archived chronology breaks at {row['origin']}/{row['policy']}/{start}")
        accepted = flag(row, "accepted")
        action = exact_action(model, state, tau, connected, accepted)
        for tick in sorted(t for t in pending if start < t < end):
            coupling = 0.0 if tick < start + tau else G
            base = state if coupling == 0.0 else action.waited
            elapsed = tick - (start if coupling == 0.0 else start + tau)
            result[tick] = model.evolve(base, coupling, elapsed / 1000), coupling, count, work
            pending.remove(tick)
        state = action.after
        if accepted:
            count += 1
            work += number(row, "net_work")
        clock = end
    for tick in pending:
        insist(tick >= clock, "An archived state lies before the end of its replay")
        result[tick] = model.evolve(state, G, (tick-clock)/1000), G, count, work
    return result


def trace_norm(matrix):
    return float(np.linalg.svd(matrix, compute_uv=False).sum() / 2)


def connected_current(state):
    terminal = terminal_state(state.matrix)
    return -2 * G * float((terminal[1, 3] + math.sqrt(2) * terminal[2, 4]).imag)


def work_from_terminal(model, terminal):
    load = reduced_load(terminal)
    values, vectors = np.linalg.eigh(load)
    pivots = np.argmax(np.abs(vectors[::-1]), axis=0)
    phases = vectors[len(load) - 1 - pivots, np.arange(len(load))]
    passive = (vectors * (phases.conj()/np.abs(phases))).conj().T[::-1]
    unitary = np.kron(np.eye(2), passive)
    freed = LOAD_LEVELS @ (np.diag(load).real - values[::-1])
    interaction_change = unitary @ terminal @ unitary.conj().T - terminal
    return float(freed - G * np.einsum("ij,ji->", model.exchange, interaction_change).real)


def audit_state(model, row, raw, *, witness_cache):
    total = ticks(row, "physical_time") / 1000
    coupling = number(row, "coupling")
    chosen = ticks(row, "elapsed_connected")
    insist(0 <= chosen <= HORIZON and not chosen % GRID and int(row["candidate_count"]) == HORIZON//GRID + 1,
           "Common window state used a different diagnostic grid")
    for i, resolution in enumerate(RESOLUTIONS):
        suffix = "_half" if i else ""
        matrix = raw[i]
        sha = state_sha256(matrix)
        insist(row[f"{resolution}_sha256"] == sha, "Matched-state fingerprint mismatch")
        state = State(matrix, total)
        physical_state(state, "cloned diagnostic state")
        measured = observation(model, state, coupling)
        for field in ("c_real", "c_imag", "c_abs", "load_ergotropy"):
            tolerance(row[field + suffix], measured[field], f"Cloned state {field}/{resolution}")
        tolerance(row["load_current" + suffix], measured["load_current"] if coupling else 0.0,
                  f"Actual load current/{resolution}")
        if row["c_phase" + suffix]:
            error = math.remainder(number(row, "c_phase" + suffix) - measured["c_phase"], 2 * math.pi)
            tolerance(error * measured["c_abs"], 0.0, f"Coherence phase/{resolution}")
        energy = model.energy(state, coupling)
        ergotropy = energy - model.eigensystems[coupling][0] @ state.eigenvalues[::-1]
        tolerance(row["global_ergotropy" + suffix], ergotropy, f"Full Hamiltonian ergotropy/{resolution}")
        same_h = model.energy(state, G) - model.eigensystems[G][0] @ state.eigenvalues[::-1]
        tolerance(row["connected_global_ergotropy" + suffix], same_h, f"Common connected Hamiltonian ergotropy/{resolution}")
        after = exact_action(model, state, 0, chosen, True).after
        work = energy - model.energy(after)
        reconnect = model.energy(state) - energy
        tolerance(row["reconnect_on" + suffix], reconnect, f"Cloned state reconnect debit/{resolution}")
        tolerance(row["direct_max_net" + suffix], work, f"Selected full Hamiltonian work/{resolution}")
        if not i:
            cache_key = (sha, coupling, chosen)
            if cache_key not in witness_cache:
                witness_times = sorted(set(range(0, HORIZON + 1, 500)) |
                                       {chosen + step * GRID for step in range(-2, 3) if 0 <= chosen + step * GRID <= HORIZON})
                witness_cache[cache_key] = max(work_from_terminal(model, terminal) - reconnect
                                               for _, terminal in terminal_prefix(model, state, witness_times))
            insist(work + 2 * TOL >= witness_cache[cache_key], "An independent in-window witness beats selected diagnostic work")
    usable = number(row, "max_net") - abs(number(row, "max_net") - number(row, "max_net_half")) > TOL
    usable &= number(row, "direct_max_net") > TOL
    insist(flag(row, "accepted") == usable, "Matched-state common-window acceptance differs")
    tolerance(row["diagnostic_work"], number(row, "direct_max_net") if usable else 0.0, "Credited common-window diagnostic")


def audit_choice(model, state, row, context):
    start, end, tau, connected, window = (ticks(row, key) for key in (
        "elapsed_start", "elapsed_total", "tau", "elapsed_connected", "window"))
    insist(0 < end-start == tau+connected <= window and connected % GRID == 0, f"Counterfactual chronology {context}")
    if row["stop_reason"] == "retrospective":
        insist(not row["decision_elapsed_total"] and int(row["oracle_candidates"]) > 0,
               f"Retrospective branch appears online {context}")
    else:
        decision = ticks(row, "decision_elapsed_total")
        insist(start+tau <= decision <= end and (decision-start-tau) % GRID == 0 and int(row["oracle_candidates"]) == 0,
               f"Online branch forecast used an unavailable observation {context}")
    accepted = flag(row, "accepted")
    action = exact_action(model, state, tau, connected, accepted)
    tolerance(row["cut_on"], action.cut, f"Counterfactual cut accounting {context}")
    tolerance(row["reconnect_on"], action.reconnect, f"Counterfactual reconnect accounting {context}")
    tolerance(row["candidate_net"], action.work, f"Counterfactual candidate work {context}")
    tolerance(row["net_work"], action.observed_work, f"Counterfactual committed work {context}")
    margin = number(row, "candidate_net") - abs(number(row, "candidate_net") - number(row, "candidate_net_half"))
    insist(accepted == (margin > TOL and number(row, "direct_net") > TOL), f"Counterfactual work floor {context}")
    current_before = connected_current(state)
    current_after = connected_current(action.waited)
    tolerance(row["current_before_cut"], current_before, f"Counterfactual start current {context}", HALF_TOL)
    tolerance(row["current_after_reconnect"], current_after, f"Counterfactual reconnect current {context}", HALF_TOL)
    if min(abs(current_before), abs(current_after)) > HALF_TOL:
        insist(flag(row, "current_reversed") == (current_before * current_after < 0.0), f"Counterfactual sign change {context}")
    return action.after


def audit_wait_contrasts(model, state, rows, key):
    choices = read_unique(rows, lambda row: row["contrast"])
    insist(choices.keys() == {"no_wait", "fixed_wait", "phase_wait"}, f"Missing matched wait comparisons for {key}")
    baseline = number(choices["no_wait"], "net_work")
    initial = observation(model, state)
    actual = None
    for delay in range(1000, 6001, 200):
        c = model.detached_c(state, delay)
        phase = math.atan2(c.imag, c.real)
        if (-3*math.pi/4 <= phase <= -math.pi/4 and abs(c) >= 1e-5 and -c.imag >= .25*initial["c_abs"]
                and c.real <= initial["c_real"] + 1e-10) or delay == 6000:
            actual = delay
            break
    for mode, tau in (("no_wait", 0), ("fixed_wait", 3000), ("phase_wait", actual)):
        row = choices[mode]
        insist(ticks(row, "tau") == tau and ticks(row, "window") == HORIZON and row["stop_reason"] != "retrospective",
               f"Wrong single-attempt matched wait choice {key}/{mode}")
        insist(row["initial_coarse_sha256"] == state_sha256(state.matrix), f"Wrong single-attempt start state {key}/{mode}")
        audit_choice(model, state, row, (key, mode))
        tolerance(row["net_gain_over_no_wait"], number(row, "net_work") - baseline, f"Wait contrast difference {key}/{mode}")
    return len(choices)


def audit_branches(model, state, summaries, ledgers, key, start):
    for branch in CONTINUATIONS:
        rows = sorted(ledgers[(*key, branch)], key=lambda row: int(row["branch_attempt"]))
        summary = read_unique(summaries[(*key, branch)], lambda row: ticks(row, "elapsed_since_switch"))
        insist(summary.keys() == set(OFFSETS), f"Branch misses common offsets {key}/{branch}")
        anchor, clock = state, start
        for index, row in enumerate(rows, 1):
            insist(int(row["branch_attempt"]) == index and ticks(row, "elapsed_start") == clock,
                   f"Broken branch handoff {key}/{branch}/{index}")
            insist((row["stop_reason"] == "retrospective") == (branch == "E_retrospective") and
                   (branch != "A" or ticks(row, "tau") == 0), f"Branch used another continuation {key}/{branch}/{index}")
            insist(ticks(row, "window") == min(HORIZON, start + OFFSETS[-1] - clock),
                   f"Branch used an incorrect final window {key}/{branch}/{index}")
            anchor = audit_choice(model, anchor, row, (key, branch, index))
            clock = ticks(row, "elapsed_total")
        old_work, old_count, old_offset = 0.0, 0, 0
        for offset in OFFSETS:
            row = summary[offset]
            insist(ticks(row, "elapsed_total") == start + offset, f"Wrong branch comparison time {key}/{branch}/{offset}")
            seen = [x for x in rows if ticks(x, "elapsed_total") <= start + offset]
            work, count = math.fsum(number(x, "net_work") for x in seen), sum(flag(x, "accepted") for x in seen)
            wait = sum(max(0, min(ticks(x, "tau"), start + offset - ticks(x, "elapsed_start"))) for x in rows)
            insist(int(row["count"]) == count and int(row["interval_count"]) == count - old_count
                   and ticks(row, "wait_time") == wait, f"Wrong branch count, waits or interval {key}/{branch}/{offset}")
            tolerance(row["cumulative_net"], work, f"Common branch work {key}/{branch}/{offset}")
            tolerance(row["interval_rate"], (work - old_work) * 1000/(offset - old_offset) if offset else 0.0,
                      f"Common branch work rate {key}/{branch}/{offset}")
            old_work, old_count, old_offset = work, count, offset
    return sum(len(ledgers[(*key, branch)]) for branch in CONTINUATIONS)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=ROOT / "results")
    parser.add_argument("--stages", type=Path, default=ROOT / "stages")
    args = parser.parse_args()
    data = args.data
    states = read_group(data / "m27_states.csv", "origin", "switch_policy")
    distances = read_group(data / "m27_state_distances.csv", "origin", "switch_policy")
    summaries = read_group(data / "m27_branches.csv", "origin", "switch_policy", "branch")
    ledgers = read_group(data / "m27_branch_history.csv", "origin", "switch_policy", "branch")
    contrasts = read_group(data / "m27_wait_contrasts.csv", "origin", "switch_policy")
    statuses = read_group(data / "m27_switch_status.csv", "origin", "switch_policy")
    switched = {key for key, (row,) in statuses.items() if flag(row, "switched")}
    insist(states.keys() == distances.keys() == contrasts.keys() == switched, "Inconsistent first-switch diagnostic coverage")
    insist(summaries.keys() == ledgers.keys() == {(*key, mode) for key in switched for mode in CONTINUATIONS},
           "Inconsistent counterfactual branch coverage")
    archive = read_group(M26 / "results" / "m26_history.csv", "origin", "policy")
    sources = read_unique(read_rows(M26 / "results" / "m26_sources.csv"), lambda row: row["origin"])
    model = ReplayModel()
    witnesses = {}
    branch_count, contrast_count = 0, 0
    clock_by_origin = defaultdict(set)
    for key, rows in states.items():
        clock_by_origin[key[0]].add(ticks(rows[0], "elapsed_total"))
    reference = {(origin, mode): archived_states(model, sources[origin], archive[origin, mode], times)
                 for origin, times in clock_by_origin.items() for mode in ("A", "E")}
    for key, rows in states.items():
        origin, mode = key
        by_mode = read_unique(rows, lambda row: row["source_policy"])
        insist(by_mode.keys() == {"A", "E", mode}, f"Matched state processes differ for {key}")
        start = ticks(by_mode[mode], "elapsed_total")
        exact_time = ticks(sources[origin], "source_time") + start
        path = data / "diagnostic_checkpoints" / f"switch_{origin}_{mode}.npz"
        with np.load(path, allow_pickle=False) as z:
            insist(int(z["tick"]) == start, f"Matched clock differs from archived state file for {key}")
            raw = {branch: tuple(z[f"{branch}_{step}"] for step in RESOLUTIONS) for branch in by_mode}
        first = min((int(file.stem.removeprefix("switch_")), file) for file in args.stages.glob(
            f"t*/{origin}/{mode}/coarse/switch_*.npz"))
        insist(first[0] == start, f"Diagnosis does not use the first switch for {key}")
        with np.load(first[1], allow_pickle=False) as registered:
            for i, resolution in enumerate(RESOLUTIONS):
                insist(np.array_equal(registered[resolution], raw[mode][i]),
                       f"Initial branch state differs from formal pre-cut snapshot for {key}/{resolution}")
        for branch, row in by_mode.items():
            insist(ticks(row, "elapsed_total") == start and ticks(row, "physical_time") == exact_time,
                   f"Unmatched physical clock for {key}/{branch}")
            if branch in ("A", "E"):
                exact, coupling, count, work = reference[origin, branch][start]
                insist(number(row, "coupling") == coupling and int(row["count"]) == count,
                       f"Wrong archived control coupling or count for {key}/{branch}")
                tolerance(row["cumulative_net"], work, f"Archived control cumulative work for {key}/{branch}")
                insist(maxabs(exact.matrix - raw[branch][0]) <= HALF_TOL, f"Independent full-H control state mismatch {key}/{branch}")
            audit_state(model, row, raw[branch], witness_cache=witnesses)
        pairs = read_unique(distances[key], lambda row: (row["policy_a"], row["policy_b"]))
        insist({frozenset(pair) for pair in pairs} == {frozenset(pair) for pair in combinations(by_mode, 2)},
               f"Matched state pairwise coverage {key}")
        for (left, right), row in pairs.items():
            errors = [raw[branch][0] - raw[branch][1] for branch in (left, right)]
            tolerance(row["global_step_distance_bound"], sum(trace_norm(error) for error in errors),
                      f"Global coarse/half distance bound {key}/{left}/{right}")
            tolerance(row["load_step_distance_bound"], sum(trace_norm(reduced_load(terminal_state(error))) for error in errors),
                      f"Load coarse/half distance bound {key}/{left}/{right}")
            for i, suffix in enumerate(("", "_half")):
                delta = raw[left][i] - raw[right][i]
                tolerance(row["global_trace_distance" + suffix], trace_norm(delta), f"Global trace distance {key}/{left}/{right}")
                reduced = reduced_load(terminal_state(delta))
                tolerance(row["load_trace_distance" + suffix], trace_norm(reduced), f"Load trace distance {key}/{left}/{right}")
        state = State(raw[mode][0], exact_time/1000)
        branch_count += audit_branches(model, state, summaries, ledgers, key, start)
        contrast_count += audit_wait_contrasts(model, state, contrasts[key], key)
        print(f"{origin}/{mode}: matched states, trace distances, branch evolution and wait contrasts verified", flush=True)
    print(f"{len(switched)} switch points, {sum(map(len, states.values()))} states, {branch_count} branch operations, "
          f"{contrast_count} wait contrasts, {len(witnesses)} independent common-window witness searches passed.")


if __name__ == "__main__":
    main()
