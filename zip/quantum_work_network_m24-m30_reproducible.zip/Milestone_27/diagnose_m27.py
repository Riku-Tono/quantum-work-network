"""Compare frozen M27 switch states and run independent counterfactual branches."""

import argparse
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass
from itertools import combinations
import math
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
M26 = ROOT.parent / "Milestone_26"
sys.path.insert(0, str(M26))
os.environ.setdefault("OPENBLAS_NUM_THREADS", "2")

import numpy as np

from run_m26 import Anchor, M23, M25, archived_anchor, fingerprint, from_m25, model, source_pair
from m26_snapshots import Snapshot, continue_passively, snapshot_at, snapshot_future_work_many, snapshot_metrics
from m25_control import retrospective, switch_input, waiting_state
from m25_diagnostics import state_metrics
from m23_spectral import DT, FLOOR, G, GRID, HALF_TOL, HORIZON, LOAD_DIM, extraction, partial
from m24_physics import observe_local
from m21_observables import expectation, spectrum
from run_m23 import account, csv_rows, ms

from collect_m27 import ADAPTIVE, ORIGINS, write_csv


BRANCH_TIMES = (0, 18_000, 36_000, 54_000)
METHODS = ("A", "online_wait", "E_retrospective")


@dataclass(frozen=True)
class StateAt:
    snapshot: Snapshot
    count: int
    cumulative_net: float


@dataclass(frozen=True)
class BranchAttempt:
    pair: tuple
    row: dict


def official_replay(dynamics, source, history, ticks):
    """Use actual archived operations and the certified M25 handoff."""
    pending = set(ticks)
    result = {}
    policy = history[0]["policy"]
    certified = archived_anchor(M25, (source["origin"], policy), history[29])
    current = Anchor(source_pair(M23, source), 0, 0, 0, 0.0, 0.0)
    for row in history:
        if not pending:
            break
        if current.tick in pending:
            result[current.tick] = StateAt(Snapshot(current.pair, G, current.tick, "operation_end"),
                                           current.count, current.cumulative)
            pending.remove(current.tick)
        start, end, tau, duration, connected = (ms(row[field]) for field in (
            "elapsed_start", "elapsed_total", "tau", "duration", "elapsed_connected"))
        if (start, end, duration) != (current.tick, current.tick + tau + connected, tau + connected):
            raise ValueError(f"Discontinuous M26 archive at {source['origin']}/{policy}/{start}")
        if int(row["count"]) <= 30 and row["record_source"] == "m25_archive":
            next_state = from_m25(dynamics, current, row, certified)
        else:
            before = tuple(dynamics.connected.evolve(waiting_state(dynamics, rho, tau, dt), connected, dt)
                           for rho, dt in zip(current.pair, DT, strict=True))
            after = tuple(extraction(rho) for rho in before) if row["accepted"] == "True" else before
            next_state = Anchor(after, end, int(row["count"]), int(row["attempt"]),
                                float(row["cumulative_net"]), float(row["net_work"]))
        for tick in sorted(t for t in pending if start < t <= end):
            snap = snapshot_at(dynamics, current.pair, next_state.pair, start, tau, duration, tick)
            accepted = next_state if tick == end else current
            result[tick] = StateAt(snap, accepted.count, accepted.cumulative)
            pending.remove(tick)
        current = next_state
    for tick in sorted(pending):
        if tick < current.tick:
            raise ValueError(f"Missing archived snapshot at {tick}")
        terminal = Snapshot(current.pair, G, current.tick, "operation_end")
        result[tick] = StateAt(continue_passively(dynamics, terminal, tick), current.count, current.cumulative)
    return result


def trace_distance(left, right):
    return float(np.abs(spectrum(left - right)).sum() / 2)


def load_reduction(rho):
    terminal = partial(rho)
    return terminal[:LOAD_DIM, :LOAD_DIM] + terminal[LOAD_DIM:, LOAD_DIM:]


def trace_distances(left, right):
    result = {}
    for label, transform in (("global", lambda rho: rho), ("load", load_reduction)):
        a, b = tuple(transform(rho) for rho in left), tuple(transform(rho) for rho in right)
        coarse, half = tuple(trace_distance(x, y) for x, y in zip(a, b, strict=True))
        bound = trace_distance(*a) + trace_distance(*b)
        if abs(coarse - half) > bound + FLOOR:
            raise ValueError("Trace-distance coarse/half difference exceeds its triangle bound")
        result.update({f"{label}_trace_distance": coarse, f"{label}_trace_distance_half": half,
                       f"{label}_step_distance_bound": bound})
    if result["load_trace_distance"] > result["global_trace_distance"] + FLOOR:
        raise ValueError("Trace distance increased under partial trace")
    return result


def state_comparison(dynamics, meta, states):
    rows, distances = [], []
    for (policy, state), diagnostic in zip(states.items(), snapshot_future_work_many(
            dynamics, (state.snapshot for state in states.values())), strict=True):
        snapshot = state.snapshot
        coarse = snapshot_metrics(dynamics, snapshot)
        half = snapshot_metrics(dynamics, snapshot, half=True)
        connected_ergotropy = (tuple(state_metrics(dynamics, rho)["global_ergotropy"] for rho in snapshot.pair)
                               if snapshot.coupling == 0.0 else (coarse["global_ergotropy"], half["global_ergotropy"]))
        rows.append({
            **meta, "source_policy": policy, "elapsed_total": snapshot.tick / 1000,
            "physical_time": meta["origin_time"] + snapshot.tick / 1000,
            "count": state.count, "cumulative_net": state.cumulative_net,
            "phase": snapshot.phase, "continuation": snapshot.continuation,
            "coarse_sha256": fingerprint(snapshot.pair[0]), "half_sha256": fingerprint(snapshot.pair[1]),
            **coarse, **{f"{key}_half": value for key, value in half.items()}, **diagnostic,
            "connected_global_ergotropy": connected_ergotropy[0],
            "connected_global_ergotropy_half": connected_ergotropy[1],
            "diagnostic_work_half": diagnostic["direct_max_net_half"] if diagnostic["accepted"] else 0.0,
        })
    for (policy_a, a), (policy_b, b) in combinations(states.items(), 2):
        distances.append({**meta, "elapsed_total": a.snapshot.tick / 1000, "policy_a": policy_a,
                          "policy_b": policy_b, **trace_distances(a.snapshot.pair, b.snapshot.pair)})
    return rows, distances


def phase(before, after):
    c0 = complex(before["c_real"], before["c_imag"])
    c1 = complex(after["c_real"], after["c_imag"])
    return {"c_abs_before_cut": abs(c0), "c_abs_after_reconnect": abs(c1),
            "phase_before_cut": float(np.angle(c0)) if abs(c0) > FLOOR else None,
            "phase_after_reconnect": float(np.angle(c1)) if abs(c1) > FLOOR else None,
            "phase_change_wrapped": float(np.angle(c1 * c0.conjugate())) if min(abs(c0), abs(c1)) > FLOOR else None,
            "current_before_cut": float(before["load_current"]),
            "current_after_reconnect": float(after["load_current"]),
            "current_reversed": float(before["load_current"]) * float(after["load_current"]) < 0.0}


def retrospective_attempt(dynamics, pair, start, window):
    selected, trials, _ = retrospective(dynamics, pair, window, "E")
    tau, index = selected.tau, selected.index
    waiting = tuple(waiting_state(dynamics, rho, tau, dt) for rho, dt in zip(pair, DT, strict=True))
    connected = index * GRID
    if not 0 < tau + connected <= window:
        raise ValueError("Counterfactual attempt did not advance the experiment clock")
    before = tuple(dynamics.connected.evolve(rho, connected, dt) for rho, dt in zip(waiting, DT, strict=True))
    cuts = tuple(switch_input(rho, wait, tau) for rho, wait in zip(pair, waiting, strict=True))
    pre = tuple(observe_local(partial(rho)) for rho in before)
    work, half = tuple(float(obs["total_work"]) - sum(switches)
                       for obs, switches in zip(pre, cuts, strict=True))
    if abs(work - half) > HALF_TOL or abs(work - selected.work) > FLOOR:
        raise ValueError("Counterfactual candidate work failed convergence or search parity")
    checks, virtual = zip(*(account(dynamics, initial, waited, at_stop, candidate, tau, *switches)
                            for initial, waited, at_stop, candidate, switches in zip(
                                pair, waiting, before, (work, half), cuts, strict=True)), strict=True)
    margin = work - abs(work - half)
    accepted = margin > FLOOR and checks[0]["direct_net"] > FLOOR
    clock = start + tau + connected
    row = {
        "elapsed_start": start / 1000, "elapsed_total": clock / 1000, "duration": (tau + connected) / 1000,
        "window": window / 1000, "tau": tau / 1000, "elapsed_connected": connected / 1000,
        "decision_elapsed_total": "", "stop_reason": "retrospective",
        "oracle_candidates": sum(trial.count for trial in trials), "accepted": accepted,
        "net_work": checks[0]["direct_net"] if accepted else -sum(cuts[0]),
        "net_work_half_aligned": checks[1]["direct_net"] if accepted else -sum(cuts[1]),
        "candidate_net": work, "candidate_net_half": half, "resolution_margin": margin,
        "cut_on": cuts[0][0], "reconnect_on": cuts[0][1], "direct_net_half": checks[1]["direct_net"],
        "cut_on_half": cuts[1][0], "reconnect_on_half": cuts[1][1],
        **checks[0], "post_global_energy": expectation((virtual if accepted else before)[0], dynamics.h[G]),
        **phase(observe_local(partial(pair[0])), observe_local(partial(waiting[0]))),
    }
    return BranchAttempt(virtual if accepted else before, row)


def causal_attempt(dynamics, pair, start, window, policy, mode, records, *, cap=None, fixed_tau=None):
    from run_m27 import attempt

    trial = attempt(dynamics, pair, 0, start, window, policy, mode, records, cap=cap, fixed_tau=fixed_tau)
    row = trial.row
    if row is None:
        raise ValueError("Diagnostic replay interrupted a candidate before its terminal trial clock")
    row = {**row, "oracle_candidates": 0, "net_work_half_aligned": row["net_work_aligned"],
           "c_abs_before_cut": row["c_abs_before"], "c_abs_after_reconnect": row["c_abs_after"],
           "phase_before_cut": row["phase_before"], "phase_after_reconnect": row["phase_after"],
           "phase_change_wrapped": row["phase_change"], "current_before_cut": row["current_before"],
           "current_after_reconnect": row["current_after"], "current_reversed": row["sign_reversal"]}
    return BranchAttempt(trial.after, row)


def branch_summary(meta, branch, start, records, final_tick, *, offsets=BRANCH_TIMES):
    rows = []
    prior_tick, prior_work, prior_count = start, 0.0, 0
    for offset in offsets:
        tick = start + offset
        completed = [row for row in records if ms(row["elapsed_total"]) <= tick]
        count = sum(row["accepted"] for row in completed)
        work = math.fsum(row["net_work"] for row in completed)
        work_half = math.fsum(row["net_work_half_aligned"] for row in completed)
        elapsed = (tick-prior_tick)/1000
        wait = sum(max(0, min(ms(row["tau"]), tick - ms(row["elapsed_start"]))) for row in records)
        rows.append({
            **meta, "branch": branch, "elapsed_since_switch": offset / 1000, "elapsed_total": tick / 1000,
            "count": count, "cumulative_net": work, "cumulative_net_half_aligned": work_half,
            "cumulative_rate": work / (offset / 1000) if offset else 0.0,
            "interval_net": work - prior_work, "interval_count": count-prior_count,
            "interval_rate": (work-prior_work)/elapsed if elapsed else 0.0,
            "wait_time": wait / 1000, "status": "passive" if final_tick < tick else "executed",
        })
        prior_tick, prior_work, prior_count = tick, work, count
    return rows


def run_counterfactual(dynamics, start_state, meta, prior, branch, *, offsets=BRANCH_TIMES):
    start = start_state.snapshot.tick
    stop = start + offsets[-1]
    pair, tick = start_state.snapshot.pair, start
    records = []
    while stop - tick >= GRID:
        window = min(HORIZON, stop-tick)
        if branch == "E_retrospective":
            trial = retrospective_attempt(dynamics, pair, tick, window)
        else:
            mode = "wait" if branch == "online_wait" else "forecast"
            trial = causal_attempt(dynamics, pair, tick, window, meta["switch_policy"], mode, prior + records, cap=stop)
        pair = trial.pair
        row = trial.row
        tick = ms(row["elapsed_total"])
        if tick <= ms(row["elapsed_start"]) or tick > stop:
            raise ValueError(f"Invalid counterfactual operation at {meta}/{branch}/{tick}")
        records.append(row)
        if not row["accepted"] and branch != "online_wait":
            break
    summary = branch_summary(meta, branch, start, records, tick, offsets=offsets)
    rows = [{**meta, "branch": branch, "branch_attempt": index, **row}
            for index, row in enumerate(records, 1)]
    return summary, rows


def same_state_wait(dynamics, state, meta):
    rows = []
    start = state.snapshot.tick
    for contrast, mode, fixed_tau in (("no_wait", "forecast", 0), ("fixed_wait", "wait", 3000),
                                      ("phase_wait", "wait", None)):
        trial = causal_attempt(dynamics, state.snapshot.pair, start, HORIZON, "F2", mode, [], fixed_tau=fixed_tau)
        rows.append({**meta, "contrast": contrast, **trial.row,
                     "elapsed_since_switch": trial.row["elapsed_total"]-start/1000,
                     "initial_coarse_sha256": fingerprint(state.snapshot.pair[0]),
                     "initial_half_sha256": fingerprint(state.snapshot.pair[1])})
    baseline = rows[0]["net_work"]
    for row in rows:
        row["net_gain_over_no_wait"] = row["net_work"] - baseline
    return rows


def stage_dirs(stages, origin, policy):
    relative = Path(origin) / policy / "coarse"
    candidates = [stages / relative, *stages.glob(f"*/{relative.as_posix()}")]
    return [path for path in candidates if path.is_dir()]


def history_before(folders, tick):
    history = {}
    for folder in folders:
        path = folder / "m27_history.csv"
        if not path.exists():
            continue
        for row in csv_rows(path):
            if ms(row["elapsed_total"]) > tick:
                continue
            row = {**row, "accepted": row["accepted"] == "True",
                   **{key: float(row[key]) for key in ("tau", "duration", "net_work", "elapsed_start", "elapsed_total")}}
            index = int(row["attempt"])
            if index in history and row != history[index]:
                raise ValueError(f"Conflicting M27 archived branch row for attempt {index}")
            history[index] = row
    return [history[i] for i in sorted(history)]


def get_switch(folders):
    matches = sorted((int(path.stem.removeprefix("switch_")), path) for folder in folders
                     for path in folder.glob("switch_*.npz"))
    if not matches:
        return None
    tick, path = matches[0]
    with np.load(path, allow_pickle=False) as switch:
        pair = (switch["coarse"], switch["half"])
        if int(switch["tick"]) != tick:
            raise ValueError(f"Switch state timestamp disagrees with {path}")
    history = history_before(folders, tick)
    if history:
        latest = history[-1]
        if ms(latest["elapsed_total"]) != tick:
            raise ValueError(f"Switch state lacks its preceding ledger row: {path}")
        for rho, label in zip(pair, ("coarse", "half"), strict=True):
            if fingerprint(rho) != latest[f"post_{label}_sha256"]:
                raise ValueError(f"Switch state is not the committed ledger state: {path}/{label}")
        count, work = int(latest["count"]), float(latest["cumulative_net"])
    elif tick == 0:
        count, work = 0, 0.0
    else:
        raise ValueError(f"Switch state has no prior executed history: {path}")
    return StateAt(Snapshot(pair, G, tick, "pre_cut"), count, work), history


def diagnose_origin(origin, stages, checkpoints, *, switches_only=False):
    dynamics = model()
    source, = [r for r in csv_rows(M26 / "results" / "m26_sources.csv") if r["origin"] == origin]
    origin_time = float(source["source_time"])
    statuses, branches, attempts, contrasts, states, distances = [], [], [], [], [], []
    switches = {}
    for policy in ADAPTIVE:
        folders = stage_dirs(stages, origin, policy)
        saved = get_switch(folders)
        statuses.append({"origin": origin, "switch_policy": policy, "has_run": bool(folders),
                         "switched": saved is not None,
                         "elapsed_total": saved[0].snapshot.tick / 1000 if saved is not None else ""})
        if saved is not None:
            switches[policy] = saved
    if not switches:
        return statuses, states, distances, branches, attempts, contrasts
    ticks = {state.snapshot.tick for state, _ in switches.values()}
    official = {policy: [] for policy in ("A", "E")}
    for row in csv_rows(M26 / "results" / "m26_history.csv"):
        if row["origin"] == origin and row["policy"] in official:
            official[row["policy"]].append(row)
    replay = {policy: official_replay(dynamics, source, rows, ticks) for policy, rows in official.items()}
    comparisons, branch_cache, wait_cache = {}, {}, {}
    for policy, (state, prior) in switches.items():
        tick = state.snapshot.tick
        meta = {"origin": origin, "switch_policy": policy, "origin_time": origin_time,
                "switch_elapsed": tick / 1000}
        copies = {"A": replay["A"][tick], "E": replay["E"][tick], policy: state}
        hashes = tuple(fingerprint(rho) for rho in state.snapshot.pair)
        key = (tick, hashes)
        if key in comparisons:
            previous, rows, metrics = comparisons[key]
            rows = [{**row, **meta, "source_policy": policy if row["source_policy"] == previous else row["source_policy"]}
                    for row in rows]
            metrics = [{**row, **meta, "policy_b": policy if row["policy_b"] == previous else row["policy_b"]}
                       for row in metrics]
        else:
            rows, metrics = state_comparison(dynamics, meta, copies)
            comparisons[key] = (policy, rows, metrics)
        states.extend(rows)
        distances.extend(metrics)
        if checkpoints is not None:
            storage = {f"{name}_{size}": rho for name, copy in copies.items()
                       for size, rho in zip(("coarse", "half"), copy.snapshot.pair, strict=True)}
            path = checkpoints / f"switch_{origin}_{policy}.npz"
            if path.exists():
                with np.load(path, allow_pickle=False) as saved:
                    if int(saved["tick"]) != tick or any(not np.array_equal(saved[name], matrix) for name, matrix in storage.items()):
                        raise ValueError(f"Saved diagnostic checkpoint differs from input states: {path}")
            else:
                with path.open("xb") as stream:
                    np.savez_compressed(stream, tick=tick, **storage)
        if switches_only:
            continue
        for branch in METHODS:
            branch_key = (key, branch, branch == "online_wait" and policy == "F1")
            if branch_key in branch_cache:
                summary, ledger = ([{**row, **meta} for row in table] for table in branch_cache[branch_key])
            else:
                summary, ledger = run_counterfactual(dynamics, state, meta, prior, branch)
                branch_cache[branch_key] = (summary, ledger)
            branches.extend(summary)
            attempts.extend(ledger)
        if key in wait_cache:
            contrast_rows = [{**row, **meta} for row in wait_cache[key]]
        else:
            contrast_rows = same_state_wait(dynamics, state, meta)
            wait_cache[key] = contrast_rows
        contrasts.extend(contrast_rows)
    return statuses, states, distances, branches, attempts, contrasts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stages", type=Path, default=ROOT / "stages")
    parser.add_argument("--output", type=Path, default=ROOT / "results")
    parser.add_argument("--origins", nargs="+", choices=ORIGINS, default=ORIGINS)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--switches-only", action="store_true", help="Save common-window comparisons without branching.")
    args = parser.parse_args()
    if not args.stages.is_dir():
        parser.error(f"M27 stages not found: {args.stages}")
    args.output.mkdir(parents=True, exist_ok=True)
    checkpoints = args.output / "diagnostic_checkpoints"
    checkpoints.mkdir(exist_ok=True)
    with ProcessPoolExecutor(max_workers=args.workers) as executor:
        futures = {origin: executor.submit(diagnose_origin, origin, args.stages, checkpoints,
                                           switches_only=args.switches_only) for origin in args.origins}
        results = []
        for origin, task in futures.items():
            result = task.result()
            results.append(result)
            print(f"{origin}: compared {sum(row['switched'] for row in result[0])} first switches", flush=True)
    filenames = ("m27_switch_status", "m27_states", "m27_state_distances", "m27_branches",
                 "m27_branch_history", "m27_wait_contrasts")
    for name, tables in zip(filenames, zip(*results, strict=True), strict=True):
        write_csv(args.output / (name + ".csv"), [row for table in tables for row in table],
                  fields=("origin", "switch_policy"))


if __name__ == "__main__":
    main()
