"""Plot M28's convergence, matched branches, phase gain, and current diagnostics."""

import argparse
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import PercentFormatter

from collect_m28 import ANCHORS, BRANCHES, MAIN, ORIGINS, PRECISIONS, ROOT, accepted, flag, lane, read_optional
from plot_m27 import INK, MUTED, empty, grid, style_axis


COLORS = {
    "F2": "#555C78", "F2-R": "#007868",
    "R0": "#295B9E", "R1": "#9A5C17", "R3": "#65731C", "R6": "#647580",
    "RH": "#A33F67", "RP": "#007868", "E": "#734392",
}
CURRENT_COLORS = {**COLORS, "Xamp": "#C56B30", "Xcurrent": "#4C55A2"}
PATTERNS = {"R0": ":", "R1": "--", "R3": "-.", "R6": ":", "RH": "--", "RP": "-", "E": "-"}
ORIGIN_COLORS = dict(zip(ORIGINS, ("#2863A3", "#B15424", "#00836C", "#8B4D90"), strict=True))
ORIGIN_MARKERS = dict(zip(ORIGINS, ("o", "^", "D", "s"), strict=True))
BASELINE_STYLE = {"R1": ("#9A5C17", "o"), "RH": ("#A33F67", "D")}


def read(data, name):
    return read_optional(data / f"m28_{name}.csv")


def num(row, field):
    value = row.get(field)
    return float(value) if value not in (None, "") else math.nan


def groups(rows, key):
    grouped = {}
    for row in rows:
        grouped.setdefault(key(row), []).append(row)
    return grouped


def heading(figure, title, caption):
    figure.suptitle(title + "\n" + caption, x=0.02, ha="left", fontsize=13.5,
                    fontweight="semibold", color=INK)


def save(figure, output, name):
    figure.savefig(output / f"m28_{name}.png", dpi=180, facecolor="white")
    plt.close(figure)


def legend(figure, handles):
    if handles:
        figure.legend(handles=handles, loc="outside lower center", frameon=False, ncols=min(7, len(handles)))


def policy_handles(names, *, markers=None):
    return [Line2D([], [], color=COLORS[name], linestyle=PATTERNS.get(name, "-"),
                   marker=markers, label=name, linewidth=1.5) for name in names]


def steps(rows, horizon, *, fork_axis=False):
    first = rows[0]
    fork = num(first, "fork_elapsed")
    if not math.isfinite(fork):
        fork = num(first, "elapsed_start")
    origin = fork if fork_axis else 0.0
    ordered = sorted(rows, key=lambda row: int(row["attempt"]))
    clocks = [fork - origin, *(num(row, "elapsed_total") - origin for row in ordered)]
    work = [0.0, *(num(row, "cumulative_net") for row in ordered)]
    if horizon - origin > clocks[-1]:
        clocks.append(horizon - origin)
        work.append(work[-1])
    return clocks, work


def plot_main(histories, limits, horizon, output):
    figure, axes = grid("Original F2 and robust F2-R",
                        "Cumulative signed work at each trial closure. Dashes denote independently controlled half steps.",
                        scientific=True, ylabel="Cumulative net work", sharex=True)
    for origin, axis in axes.items():
        shown = False
        for policy in MAIN:
            for step in PRECISIONS:
                key = ("main", origin, policy, step)
                rows = histories.get(key, [])
                if rows:
                    shown = True
                    axis.step(*steps(rows, limits[key]), color=COLORS[policy], where="post",
                              linestyle="-" if step == "coarse" else "--", linewidth=1.6)
        if not shown:
            empty(axis)
        axis.set_xlim(0, horizon)
    legend(figure, [*policy_handles(MAIN),
                    Line2D([], [], color=MUTED, linestyle="-", label="Coarse"),
                    Line2D([], [], color=MUTED, linestyle="--", label="Half")])
    save(figure, output, "01_original_and_robust_work")


def plot_control(histories, decisions, chronology, limits, horizon, output):
    change_rows = groups([row for row in decisions if row["group"] == "main" and flag(row.get("switched"))], lane)
    checks = {(row["origin"], row["policy"]): int(row["different_attempts_by_ordinal"])
              for row in chronology}
    figure, axes = grid("Independent coarse and half-step control histories",
                        "Ticks show accepted extractions. Diamonds show switch times. Thick bands indicate waiting mode.",
                        sharex=True)
    specifications = [(policy, step) for policy in MAIN for step in PRECISIONS]
    for origin, axis in axes.items():
        for index, (policy, step) in enumerate(specifications):
            key = ("main", origin, policy, step)
            rows = histories.get(key, [])
            if not rows:
                continue
            color = COLORS[policy]
            stop = limits[key]
            axis.hlines(index, 0, stop, color="#DDE4EA", linewidth=1)
            changes = sorted(change_rows.get(key, []), key=lambda row: num(row, "elapsed_total"))
            for i, row in enumerate(changes):
                when = num(row, "elapsed_total")
                following = num(changes[i + 1], "elapsed_total") if i + 1 < len(changes) else stop
                if when > stop:
                    break
                following = min(following, stop)
                if row.get("mode_after") == "wait":
                    axis.hlines(index, when, following, color=color, alpha=0.35, linewidth=6)
                axis.scatter(when, index, color=color, marker="D", facecolor="white", s=31, zorder=5)
            clocks = [num(row, "elapsed_total") for row in rows if accepted(row)]
            axis.vlines(clocks, index - 0.14, index + 0.14, color=color, linewidth=0.65)
        axis.set(yticks=range(len(specifications)), yticklabels=[f"{p} · {s}" for p, s in specifications],
                 xlim=(0, horizon), ylim=(-0.53, 3.53))
        axis.invert_yaxis()
        if all((origin, policy) in checks for policy in MAIN):
            counts = " / ".join(str(checks[origin, policy]) for policy in MAIN)
            axis.set_title(f"Different attempts · F2 / F2-R  {counts}", loc="right", fontsize=8, color=MUTED)
    save(figure, output, "02_independent_control_histories")


def plot_sensitivity(sensitivity, perturbations, output):
    figure, axes = plt.subplots(1, 2, figsize=(11.7, 5.1), layout="constrained")
    heading(figure, "Rate-floor and observation-perturbation sensitivity",
            "The replay compares first-switch clocks and counts decision flips after one rate value is perturbed.")
    left, right = axes
    style_axis(left, xlabel="Positive rate floor", ylabel="First switch elapsed time")
    style_axis(right, xlabel="Added rate at a single decision", ylabel="Share of replayed decisions flipped")
    floors = (0, 1e-14, 1e-12, 1e-10)
    shifts = (-1e-12, -1e-14, 1e-14, 1e-12)
    floor_labels = ("0", "$10^{-14}$", "$10^{-12}$", "$10^{-10}$")
    left.set(xticks=range(len(floors)), xticklabels=floor_labels)
    right.set(xticks=range(len(shifts)), xticklabels=("$-10^{-12}$", "$-10^{-14}$", "$+10^{-14}$", "$+10^{-12}$"))
    right.yaxis.set_major_formatter(PercentFormatter(1))
    shown = False
    for origin, rows in groups(sensitivity, lambda row: row.get("origin", "C04")).items():
        for row in rows:
            floor, clock = num(row, "rate_floor"), num(row, "first_switch")
            if floor not in floors or not math.isfinite(clock):
                continue
            shown = True
            color = ORIGIN_COLORS[origin]
            coarse = row["precision"] == "coarse"
            x = floors.index(floor) + (-0.045 if coarse else 0.045)
            left.scatter(x, clock, s=37, facecolor=color if coarse else "white", edgecolor=color,
                         marker=ORIGIN_MARKERS[origin], linewidth=0.9)
    if not shown:
        empty(left, "No rate-floor sensitivity rows")
    tested = groups(perturbations, lambda row: (num(row, "rate_floor"), num(row, "rate_perturbation")))
    floor_marks = ("o", "D", "^", "s")
    for threshold, label, color, marker in zip(floors, floor_labels, ORIGIN_COLORS.values(), floor_marks, strict=True):
        points = []
        for x, shift in enumerate(shifts):
            rows = tested.get((threshold, shift), [])
            if rows:
                changes = sum(flag(row["decision_changed"]) for row in rows)
                points.append((x, changes / len(rows)))
        if points:
            right.plot(*zip(*points, strict=True), marker=marker, linewidth=1.15, markersize=4, color=color, label=label)
    if tested:
        right.set_ylim(bottom=0)
        right.legend(frameon=False, title="Rate floor", ncols=2)
    else:
        empty(right, "No observation-perturbation rows")
    if shown:
        legend(figure, [*[Line2D([], [], color=ORIGIN_COLORS[o], marker=ORIGIN_MARKERS[o], linestyle="none", label=o)
                          for o in ORIGINS],
                        Line2D([], [], color=MUTED, marker="o", linestyle="none", label="Coarse"),
                        Line2D([], [], color=MUTED, marker="o", markerfacecolor="white", linestyle="none", label="Half")])
    save(figure, output, "03_rate_floor_sensitivity")


def plot_forks(histories, limits, output):
    figure, axes = plt.subplots(4, 2, figsize=(11.7, 10), layout="constrained", sharex=True)
    heading(figure, "Work recovered from matched starting states",
            "Work resets at each fork. Thin dashed traces show the independent half-step branches.")
    included = set()
    for i, origin in enumerate(ORIGINS):
        for j, anchor in enumerate(ANCHORS):
            axis = axes[i, j]
            axis.set_title(f"{origin} · {anchor} anchor", loc="left", color=INK, fontsize=10)
            style_axis(axis, xlabel="Elapsed time since fork" if i == 3 else "",
                       ylabel="Additional net work" if j == 0 else "", scientific=True)
            present = False
            for policy in BRANCHES:
                for step in PRECISIONS:
                    key = (anchor, origin, policy, step)
                    rows = histories.get(key, [])
                    if rows:
                        present = True
                        included.add(policy)
                        axis.step(*steps(rows, limits[key], fork_axis=True), where="post", color=COLORS[policy],
                                  linestyle=PATTERNS[policy] if step == "coarse" else (0, (3, 2)),
                                  linewidth=1.48 if step == "coarse" else 0.86,
                                  alpha=1 if step == "coarse" else 0.6)
            if not present:
                empty(axis, "No matched branches")
    legend(figure, policy_handles([policy for policy in BRANCHES if policy in included]))
    save(figure, output, "04_same_state_branch_work")


def plot_gain(gains, output):
    figure, axes = plt.subplots(1, 2, figsize=(11.7, 5.4), layout="constrained", sharey=True)
    heading(figure, "Additional work attributed to phase-guided waits",
            "For each matched state, RP is compared with fixed wait R1 and historical wait RH.")
    for i, (axis, anchor) in enumerate(zip(axes, ANCHORS, strict=True)):
        style_axis(axis, ylabel="RP minus baseline net work" if i == 0 else "", scientific=True)
        axis.set_title(f"{anchor} anchor", loc="left", color=INK, fontsize=11)
        axis.axhline(0, color=MUTED, linewidth=0.75)
        axis.set(xticks=range(len(ORIGINS)), xticklabels=ORIGINS)
        rows = [row for row in gains if row["group"] == anchor and row["baseline"] in BASELINE_STYLE]
        if not rows:
            empty(axis, "No phase comparisons")
        for row in rows:
            x = ORIGINS.index(row["origin"])
            baseline = row["baseline"]
            color, marker = BASELINE_STYLE[baseline]
            step = row["precision"]
            offset = (-0.18 if baseline == "R1" else 0.18) + (-0.055 if step == "coarse" else 0.055)
            axis.scatter(x + offset, num(row, "additional_net"), marker=marker, s=49,
                         facecolor=color if step == "coarse" else "white", edgecolor=color, linewidth=1.1, zorder=4)
    legend(figure, [*[Line2D([], [], color=color, marker=marker, linestyle="none", label=f"RP − {name}")
                      for name, (color, marker) in BASELINE_STYLE.items()],
                    Line2D([], [], color=MUTED, marker="o", linestyle="none", label="Coarse"),
                    Line2D([], [], color=MUTED, marker="o", markerfacecolor="white", linestyle="none", label="Half")])
    save(figure, output, "05_added_phase_gain_by_origin")


def plot_late(late, output):
    figure, axes = plt.subplots(1, 3, figsize=(13.1, 5.3), layout="constrained", sharey=True,
                                gridspec_kw={"width_ratios": [1, 2.25, 2.25]})
    heading(figure, "Late work rate after elapsed 300",
            "Each point uses work credited in (300, 540] divided by the common duration 240.")
    for i, (axis, group) in enumerate(zip(axes, ("main", *ANCHORS), strict=True)):
        policy_names = MAIN if group == "main" else BRANCHES
        axis.set_title("Main from origin" if group == "main" else f"{group} anchor",
                       loc="left", color=INK, fontsize=10)
        style_axis(axis, ylabel="Late net work / time" if i == 0 else "", scientific=True)
        axis.set(xticks=range(len(policy_names)), xticklabels=policy_names)
        rows = [row for row in late if row["group"] == group and row["policy"] in policy_names]
        if not rows:
            empty(axis, "No late-time rows")
        for row in rows:
            origin, step = row["origin"], row["precision"]
            x = policy_names.index(row["policy"]) + (ORIGINS.index(origin) - 1.5) * 0.095
            x += -0.02 if step == "coarse" else 0.02
            color = ORIGIN_COLORS[origin]
            axis.scatter(x, num(row, "interval_rate"), marker=ORIGIN_MARKERS[origin],
                         facecolor=color if step == "coarse" else "white", edgecolor=color, s=26, linewidth=0.85)
    legend(figure, [*[Line2D([], [], color=ORIGIN_COLORS[o], marker=ORIGIN_MARKERS[o], linestyle="none", label=o)
                      for o in ORIGINS],
                    Line2D([], [], color=MUTED, marker="o", linestyle="none", label="Coarse"),
                    Line2D([], [], color=MUTED, marker="o", markerfacecolor="white", linestyle="none", label="Half")])
    save(figure, output, "06_late_interval_work_rate")


def plot_observation_value(gains, output):
    figure, axes = plt.subplots(1, 2, figsize=(11.7, 5.5), layout="constrained", sharey=True)
    heading(figure, "Extra coherence observations and net phase gain",
            "Slope from the origin is the break-even cost per additional observation.")
    for i, (axis, anchor) in enumerate(zip(axes, ANCHORS, strict=True)):
        axis.set_title(f"{anchor} anchor", loc="left", color=INK, fontsize=11)
        style_axis(axis, xlabel="Additional coherence observations by RP", ylabel="Additional net work" if i == 0 else "",
                   scientific=True)
        axis.axhline(0, color=MUTED, linewidth=0.72)
        rows = [row for row in gains if row["group"] == anchor and row["baseline"] in BASELINE_STYLE]
        if not rows:
            empty(axis, "No observation-cost comparisons")
        for row in rows:
            color, marker = BASELINE_STYLE[row["baseline"]]
            x, y = num(row, "additional_phase_observations"), num(row, "additional_net")
            coarse = row["precision"] == "coarse"
            axis.scatter(x, y, marker=marker, s=33 if coarse else 66, facecolor=color if coarse else "none",
                         edgecolor=color, zorder=4)
            if coarse:
                axis.annotate(row["origin"], (x, y), xytext=(5, 4), textcoords="offset points", fontsize=8, color=MUTED)
        axis.margins(x=0.16)
    legend(figure, [*[Line2D([], [], color=color, marker=marker, linestyle="none", label=f"RP − {name}")
                      for name, (color, marker) in BASELINE_STYLE.items()],
                    Line2D([], [], color=MUTED, marker="o", linestyle="none", label="Coarse"),
                    Line2D([], [], color=MUTED, marker="o", markerfacecolor="white", linestyle="none", label="Half")])
    save(figure, output, "07_phase_observations_and_gain")


def plot_current(rows, output):
    figure, axes = plt.subplots(2, 2, figsize=(11.7, 8.0), layout="constrained")
    heading(figure, "Integrated connected exchange current and recovered work",
            "Each point is one coarse-step attempt from a completed path. Current is integrated through the stop.")
    shown = set()
    panels = (
        ("Main from origin", "main", MAIN),
        ("F2-R anchor", "F2-R", BRANCHES),
        ("F1 anchor", "F1", BRANCHES),
        ("Amplitude and current conditions removed individually", "F2-R", ("RP", "Xamp", "Xcurrent")),
    )
    for i, (axis, (title, group, policies)) in enumerate(zip(axes.flat, panels, strict=True)):
        axis.set_title(title, loc="left", color=INK, fontsize=10)
        style_axis(axis, xlabel="Signed current integral", ylabel="Attempt net work" if i % 2 == 0 else "", scientific=True)
        axis.ticklabel_format(axis="x", style="sci", scilimits=(-3, 3), useMathText=True)
        axis.axvline(0, color=MUTED, linewidth=0.65, zorder=0)
        axis.axhline(0, color=MUTED, linewidth=0.65, zorder=0)
        selected = [r for r in rows if r["group"] == group and r["precision"] == "coarse" and r["policy"] in policies]
        present = False
        for policy, records in groups(selected, lambda row: row["policy"]).items():
            xy = [(num(r, "integrated_current"), num(r, "net_work")) for r in records]
            xy = [(x, y) for x, y in xy if math.isfinite(x) and math.isfinite(y)]
            if xy:
                present = True
                shown.add(policy)
                axis.scatter(*zip(*xy, strict=True), s=14, alpha=0.34, color=CURRENT_COLORS[policy], edgecolor="none")
        if not present:
            empty(axis, "No integrated current logged")
    legend(figure, [Line2D([], [], color=CURRENT_COLORS[policy], marker="o", linestyle="none", label=policy)
                    for policy in (*MAIN, *BRANCHES, "Xamp", "Xcurrent") if policy in shown])
    save(figure, output, "08_integrated_current_and_work")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=ROOT / "results")
    parser.add_argument("--output", type=Path, default=ROOT / "figures")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "text.color": INK, "legend.labelcolor": INK})
    history = groups(read(args.data, "history"), lane)
    endpoints = read(args.data, "endpoints")
    limits = {lane(row): num(row, "elapsed_total") for row in endpoints}
    horizon = max(num(row, "target_elapsed") for row in endpoints)
    phase_gain = read(args.data, "phase_gain")
    plot_main(history, limits, horizon, args.output)
    plot_control(history, read(args.data, "decisions"), read(args.data, "step_chronology"), limits, horizon, args.output)
    plot_sensitivity(read(args.data, "sensitivity"), read(args.data, "perturbations"), args.output)
    plot_forks(history, limits, args.output)
    plot_gain(phase_gain, args.output)
    plot_late(read(args.data, "late_work"), args.output)
    plot_observation_value(phase_gain, args.output)
    plot_current(read(args.data, "current"), args.output)


if __name__ == "__main__":
    main()
