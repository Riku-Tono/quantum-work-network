"""Run the M28 adaptive controls and matched, restartable work-extraction branches."""

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import csv
from dataclasses import asdict, dataclass
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import sys
from tempfile import TemporaryDirectory
import time

ROOT = Path(__file__).resolve().parent
M27 = ROOT.parent / "Milestone_27"
sys.path.insert(0, str(M27))
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import run_m27 as physics
from m26_snapshots import snapshot_at
import numpy as np

ORIGINS = physics.ORIGINS
PRECISIONS = physics.PRECISIONS
GRID, HORIZON, TOTAL_LIMIT = physics.GRID, physics.HORIZON, physics.TOTAL_LIMIT
FLOOR, G = physics.FLOOR, physics.G
RATE_FLOOR = 1e-12
COMMON = (50_000, 100_000, 150_000, 200_000, 300_000, 360_000, 450_000, 540_000)
FIXED = {"R1": 1000, "R3": 3000, "R6": 6000}
MATCHED = ("R0", "R1", "R3", "R6", "RH", "RP")
GROUPS = ("F2-R", "F1")
ABLATIONS = {"Xphase": "phase", "Xamp": "amplitude", "Xcurrent": "current", "Xinput": "input"}
SCALAR_RECORD_KEYS = ("elapsed_total", "duration", "tau", "accepted", "net_work", "net_work_aligned")
REFERENCE_PROJECTOR = physics.ConnectedObservations


class ClockOrderedProjection(REFERENCE_PROJECTOR):
    """Batch projection kernels while delivering one current-clock sample at a time."""

    def prefix(self, length, stride=1):
        length = self._check_length(length)
        if stride <= 0:
            raise ValueError("Observation stride must be positive")
        # Only the experiment projection sees this buffer. The inherited controller
        # receives one observation at a time and stops the iterator at execution.
        batch = 16 * stride
        for first in range(0, length, batch):
            stop = min(first + batch, self.length)
            count = len(range(first, stop, stride))
            matrices = []
            for group, projection in enumerate(self.projections):
                kernel = self.dynamics.time_kernel(group, self.dt)[first:stop:stride]
                value = kernel @ projection.coefficients
                matrices.append(value.reshape(count, self.batch_size, self.channels, -1).swapaxes(0, 1))
            terminals, rates = self._assemble(matrices)
            valid = len(range(first, min(stop, length), stride))
            for index, terminal in enumerate(terminals[:valid]):
                yield terminal, None if rates is None else rates[index]


@dataclass(frozen=True)
class Job:
    group: str
    origin: str
    policy: str
    precision: str
    anchor_root: Path | None = None

    @property
    def primary(self):
        return PRECISIONS.index(self.precision)

    def relative_path(self):
        return Path(self.group, self.origin, self.policy, self.precision)


def register(root):
    digest = hashlib.sha256((ROOT / "PROTOCOL_M28.md").read_bytes()).hexdigest()
    root.mkdir(parents=True, exist_ok=True)
    target = root / "protocol.sha256"
    if target.exists() and target.read_text().strip() != digest:
        raise ValueError(f"Protocol differs from the one registered in {root}")
    if not target.exists():
        try:
            with target.open("x", encoding="ascii") as stream:
                stream.write(digest + "\n")
        except FileExistsError:
            if target.read_text().strip() != digest:
                raise
    return digest


def source_for(origin):
    source, = (row for row in physics.csv_rows(physics.SOURCE_TABLE) if row["origin"] == origin)
    return source


def records_before(rows, clock):
    return [{key: (row[key] == "True" if key == "accepted" else float(row[key]))
             for key in SCALAR_RECORD_KEYS if key in row} for row in rows if physics.tick(row) <= clock]


def branch_seed(job, source):
    if job.group == "main":
        return physics.source_pair(physics.M23, source), 0, []
    if job.anchor_root is None:
        raise ValueError("Matched branches need a registered anchor")
    path = job.anchor_root / job.group / job.origin / job.precision / "anchor.npz"
    with np.load(path, allow_pickle=False) as archive:
        pair = tuple(archive[name] for name in PRECISIONS)
        tick = int(archive["tick"].item())
        records = json.loads(str(archive["records"].item()))
        if float(archive["source_time"].item()) != float(source["source_time"]):
            raise ValueError(f"Fork source time differs: {path}")
        if any(physics.tick(row) > tick for row in records):
            raise ValueError(f"Unexecuted record in fork: {path}")
    return pair, tick, records


def control_update(control, elapsed, actual, records, rate_floor):
    raw = actual["load_ergotropy_rate"]
    gated = 0.0 if 0.0 < raw <= rate_floor else raw
    rule = control.update("F2", elapsed, {**actual, "load_ergotropy_rate": gated}, records)
    return {**rule, "load_ergotropy_rate": raw, "load_ergotropy_rate_for_gate": gated, "rate_floor": rate_floor}


def ablated_gate(removed):
    def gate(measured, before, coupling):
        conditions = {
            "phase": -3 * math.pi / 4 <= measured["phase"] <= -math.pi / 4,
            "amplitude": measured["c_abs"] >= 1e-5,
            "current": measured["load_current"] >= 0.25 * 2 * coupling * before["c_abs"],
            "input": measured["c_real"] <= before["c_real"] + 1e-10,
        }
        return all(passed for name, passed in conditions.items() if name != removed)
    return gate


def next_trial(job, model, pair, elapsed, control, records, cap, ending, oracle, rate_floor):
    if ending != "active" or TOTAL_LIMIT - elapsed < GRID:
        point = physics.Snapshot(pair, G, elapsed, "operation_end")
        return None, None, physics.continue_passively(model, point, cap), {}
    window = min(HORIZON, TOTAL_LIMIT - elapsed)
    if job.group == "main":
        actual = physics.observation(physics.observe_local(physics.partial(pair[job.primary])))
        decision = control_update(control, elapsed, actual, records, rate_floor)
        trial = physics.attempt(model, pair, job.primary, elapsed, window, "F2", control.mode, records, cap)
    elif job.policy == "E":
        if oracle is None:
            raise ValueError("Retrospective branches need an oracle")
        decision = {"elapsed_total": elapsed / 1000, "observed_until": None, "reason": "retrospective",
                    "mode_before": "retrospective", "mode_after": "retrospective", "switched": False}
        trial = oracle(model, pair, job.primary, elapsed, window, cap)
    else:
        selector = "F1" if job.policy == "RH" else "F2"
        mode = "forecast" if job.policy == "R0" else "wait"
        fixed = FIXED.get(job.policy)
        if fixed is not None and fixed > window - GRID:
            fixed = 0
        decision = {"elapsed_total": elapsed / 1000, "observed_until": elapsed / 1000, "reason": job.policy,
                    "mode_before": mode, "mode_after": mode, "switched": False}
        trial = physics.attempt(model, pair, job.primary, elapsed, window, selector, mode, records, cap, fixed_tau=fixed)
    return decision, trial, trial.boundary, trial.pending


def connected_current(samples):
    values = [row["load_current"] for row in samples]
    ergotropy = [row["load_ergotropy"] for row in samples]
    span = GRID / 1000
    positive, integral = [], []
    prior_nonzero = None
    sign_times = []
    for left, right in zip(values, values[1:]):
        integral.append(span * (left + right) / 2)
        if left >= 0 and right >= 0 and (left or right):
            positive.append(span)
        elif left * right < 0:
            positive.append(span * max(left, right) / (abs(left) + abs(right)))
    for row in samples:
        value = row["load_current"]
        if not value:
            continue
        if prior_nonzero is not None and prior_nonzero[1] * value < 0:
            clock, old = prior_nonzero
            sign_times.append(clock + (row["elapsed_total"] - clock) * abs(old) / (abs(old) + abs(value)))
        prior_nonzero = row["elapsed_total"], value
    return {"integrated_current": math.fsum(integral), "positive_current_duration": math.fsum(positive),
            "first_current_sign_change": sign_times[0] if sign_times else None, "current_sign_changes": len(sign_times),
            "current_sign_change_times": "|".join(f"{clock:.12g}" for clock in sign_times),
            "load_ergotropy_start": ergotropy[0], "load_ergotropy_max": max(ergotropy), "load_ergotropy_end": ergotropy[-1],
            "connected_sample_count": len(samples)}


class Ledger(physics.Tables):
    def add(self, name, row):
        if name == "m27_history":
            row["cumulative_rate"] = row["cumulative_net"] / (row["elapsed_total"] - row["fork_elapsed"])
            row["record_source"] = "m28"
        super().add(name.replace("m27_", "m28_"), row)


def commit(tables, job, meta, decision, trial, work, companion, bound, count, source_time):
    row = trial.row
    uses_phase = job.policy in ("RP", *ABLATIONS) or (job.group == "main" and row["mode"] == "wait")
    phase_count = 1 + len(trial.wait_checks) if uses_phase and row["tau"] > 0 else 0
    row.update(phase_observations=phase_count, reconnect_elapsed=row["elapsed_start"] + row["tau"],
               initial_phase_observations=int(phase_count > 0), wait_phase_observations=(phase_count - 1 if phase_count else 0))
    tables.add("m28_current", {**meta, **{name: row[name] for name in ("elapsed_start", "elapsed_total", "tau", "accepted",
                "current_after", "cut_on", "reconnect_on", "net_work", "phase_observations")},
                **connected_current(trial.observations)})
    for sample in trial.wait_checks:
        sample["used_by_control"] = bool(phase_count)
    return physics.add_attempt(tables, meta, decision, trial, work, companion, bound, count, source_time)


def save_snapshot(folder, snapshot):
    np.savez_compressed(folder / f"state_t{snapshot.tick // 1000:03d}.npz", coarse=snapshot.pair[0], half=snapshot.pair[1],
                        tick=snapshot.tick, coupling=snapshot.coupling)


def publish_stage(folder, destination):
    for delay in (0.1, 0.25, 0.5, 1.0, 2.0, None):
        try:
            folder.rename(destination)
            return
        except PermissionError as error:
            if delay is None or getattr(error, "winerror", None) not in (5, 32) or destination.exists():
                raise
            time.sleep(delay)


def run_stage(job, model, source, seed, destination, cap, previous, oracle, rate_floor):
    started = time.perf_counter()
    initial, fork, records = seed
    records = list(records)
    pair = initial
    clock, completed, count = fork, 0, 0
    work = companion = bound = 0.0
    control, ending = physics.Controller(), "active"
    prior = fork - 1
    resume_error = None
    if previous is not None:
        with np.load(previous / "checkpoint.npz", allow_pickle=False) as old:
            pair = tuple(old[f"anchor_{label}"] for label in PRECISIONS)
            clock, completed, count = map(int, old["counters"])
            work, companion, bound = map(float, old["work"])
            ending, prior = str(old["ending"].item()), int(old["tick"].item())
            control = physics.Controller(**json.loads(str(old["controller"].item())))
            records = json.loads(str(old["records"].item()))
            _, _, boundary, pending = next_trial(job, model, pair, clock, physics.Controller(**asdict(control)), records,
                                                  prior, ending, oracle, rate_floor)
            resume_error = max(physics.maxabs(state - old[label]) for state, label in zip(boundary.pair, PRECISIONS, strict=True))
            if (resume_error > FLOOR or boundary.coupling != float(old["coupling"].item())
                    or pending != json.loads(str(old["pending"].item()))):
                raise ValueError(f"Restart did not reproduce the saved state or control plan: {previous}")

    origin_energy = tuple(float(np.einsum("ij,ji->", rho, model.h[G]).real) for rho in initial)
    probes = [point for point in COMMON if prior < point < cap] if job.group == "main" else []
    destination.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix=".pending-", dir=destination.parent) as temporary:
        folder = Path(temporary) / "complete"
        folder.mkdir()
        tables = Ledger(folder)
        base = {"group": job.group, "origin": job.origin, "policy": job.policy, "precision": job.precision,
                "fork_elapsed": fork / 1000}
        prior_attempt = completed
        try:
            while True:
                candidate_control = physics.Controller(**asdict(control))
                decision, trial, boundary, pending = next_trial(job, model, pair, clock, candidate_control, records, cap,
                                                                 ending, oracle, rate_floor)
                if trial is None or trial.row is None:
                    for point in probes:
                        # The unfinished interval has already been consumed through cap.
                        _, _, state, _ = next_trial(job, model, pair, clock, physics.Controller(**asdict(control)), records,
                                                      point, ending, oracle, rate_floor)
                        save_snapshot(folder, state)
                    break
                tau = physics.tick(trial.row, "tau")
                reached = [point for point in probes if clock <= point < boundary.tick]
                for point in reached:
                    save_snapshot(folder, snapshot_at(model, pair, trial.after, clock, tau, boundary.tick - clock, point))
                probes = [point for point in probes if point not in reached]
                if decision["switched"]:
                    np.savez_compressed(folder / f"switch_{clock}.npz", coarse=pair[0], half=pair[1], tick=clock)
                completed += 1
                work, companion, bound, count = commit(tables, job, {**base, "attempt": completed}, decision, trial,
                                                        work, companion, bound, count, float(source["source_time"]))
                clock, pair, control = boundary.tick, trial.after, candidate_control
                records.append(physics.compact_record(trial.row))
                recovered = (work, companion) if job.primary == 0 else (companion, work)
                residual = max(abs(float(np.einsum("ij,ji->", rho, model.h[G]).real) + signed - energy)
                               for rho, signed, energy in zip(pair, recovered, origin_energy, strict=True))
                if residual > FLOOR:
                    raise ValueError(f"Branch energy account does not close for {job} at {clock}: {residual:g}")
                if job.group == "main" and not trial.row["accepted"] and control.mode == "forecast":
                    ending = "numeric_floor"
                elif TOTAL_LIMIT - clock < GRID:
                    ending = "time_cap" if clock == TOTAL_LIMIT else "time_cap_no_grid"
            if job.group == "main" and cap in COMMON:
                save_snapshot(folder, boundary)
            physicality = max(physics.half_physicality(rho) for rho in boundary.pair)
            if physicality > FLOOR:
                raise ValueError(f"Nonphysical boundary {cap} for {job}: {physicality:g}")
            np.savez_compressed(folder / "checkpoint.npz", coarse=boundary.pair[0], half=boundary.pair[1],
                                anchor_coarse=pair[0], anchor_half=pair[1], counters=(clock, completed, count),
                                tick=cap, coupling=boundary.coupling, phase=boundary.phase,
                                controller=json.dumps(asdict(control), sort_keys=True), records=json.dumps(records, sort_keys=True),
                                pending=json.dumps(pending, sort_keys=True), work=(work, companion, bound), ending=ending,
                                fork_tick=fork, fork_coarse_sha256=physics.fingerprint(initial[0]),
                                fork_half_sha256=physics.fingerprint(initial[1]))
            summary = {**base, "elapsed_total": cap / 1000, "anchor_elapsed": clock / 1000, "attempts": completed,
                       "attempts_in_stage": completed - prior_attempt, "count": count, "ending": ending,
                       "coupling": boundary.coupling, "phase": boundary.phase, "mode": control.mode,
                       "cumulative_net": work, "cumulative_net_aligned": companion, "cumulative_step_error_bound": bound,
                       "boundary_physicality_error": physicality, "resumed_state_error": resume_error,
                       "cut_applied": pending.get("cut_applied", False), "reconnect_applied": pending.get("reconnect_applied", False),
                       "pending_switch_net": pending.get("switch_net", 0.0), "pending_tau_tick": pending.get("tau"),
                       "forecast_tick": pending.get("forecast_tick"), "execute_tick": pending.get("execute_tick"),
                       "last_observation_tick": pending.get("last_observation_tick"),
                       **{f"{which}_{label}_sha256": physics.fingerprint(rho)
                          for which, states in (("boundary", boundary.pair), ("anchor", pair), ("fork", initial))
                          for label, rho in zip(PRECISIONS, states, strict=True)}}
            tables.add("m28_checkpoints", summary)
        finally:
            tables.close()
        publish_stage(folder, destination)
    return {**summary, "seconds": time.perf_counter() - started}


def run_job(job, root, cutoffs, oracle=None, rate_floor=RATE_FLOOR, phase_ablation=None, *, buffered=True):
    register(root)
    source = source_for(job.origin)
    seed = branch_seed(job, source)
    model = physics.model_instance()
    if getattr(model, "m28_kernel_precision", None) != job.precision:
        model.time_kernel.cache_clear()
        model.m28_kernel_precision = job.precision
    previous = None
    original_projector = physics.ConnectedObservations
    original_gate = physics.phase_reconnect
    physics.ConnectedObservations = ClockOrderedProjection if buffered else REFERENCE_PROJECTOR
    if phase_ablation is not None:
        physics.phase_reconnect = ablated_gate(phase_ablation)
    summaries = []
    try:
        for cap in cutoffs:
            if cap <= seed[1]:
                continue
            destination = root / f"t{cap // 1000}" / job.relative_path()
            if destination.is_dir():
                if not (destination / "checkpoint.npz").is_file():
                    raise ValueError(f"Incomplete stage: {destination}")
            else:
                data = run_stage(job, model, source, seed, destination, cap, previous, oracle, rate_floor)
                summaries.append(data)
                print(json.dumps({key: data[key] for key in ("group", "origin", "policy", "precision", "elapsed_total",
                                                            "count", "cumulative_net", "seconds")}), flush=True)
            previous = destination
    finally:
        physics.ConnectedObservations = original_projector
        physics.phase_reconnect = original_gate
    return summaries


def prepare_anchors(stages, destination, origins, precisions):
    registry = []
    for group in GROUPS:
        for origin in origins:
            for precision in precisions:
                base = stages if group == "F2-R" else M27 / "stages"
                suffix = Path("main", origin, group, precision) if group == "F2-R" else Path(origin, group, precision)
                folders = [path / suffix for path in sorted(base.glob("t*"), key=lambda name: int(name.name[1:]))]
                switches = [path for folder in folders for path in folder.glob("switch_*.npz")]
                if not switches:
                    raise ValueError(f"No first switch for {group}/{origin}/{precision}")
                chosen = min(switches, key=lambda path: int(path.stem.split("_")[1]))
                with np.load(chosen, allow_pickle=False) as archive:
                    pair = tuple(archive[label] for label in PRECISIONS)
                    tick = int(archive["tick"].item())
                filename = "m28_history.csv" if group == "F2-R" else "m27_history.csv"
                rows = [row for folder in folders if (folder / filename).is_file() for row in physics.csv_rows(folder / filename)
                        if physics.tick(row) <= tick]
                if not rows or physics.tick(rows[-1]) != tick:
                    raise ValueError(f"First switch lacks a matching committed anchor: {chosen}")
                hashes = tuple(physics.fingerprint(state) for state in pair)
                if tuple(rows[-1][f"post_{label}_sha256"] for label in PRECISIONS) != hashes:
                    raise ValueError(f"Fork density does not match its history: {chosen}")
                memory = records_before(rows, tick)
                output = destination / group / origin / precision / "anchor.npz"
                output.parent.mkdir(parents=True, exist_ok=True)
                source_time = float(source_for(origin)["source_time"])
                np.savez_compressed(output, coarse=pair[0], half=pair[1], tick=tick, records=json.dumps(memory, sort_keys=True),
                                    source_time=source_time)
                registry.append({"group": group, "origin": origin, "precision": precision, "fork_elapsed": tick / 1000,
                                 "source_time": source_time, "prefix_attempts": len(memory),
                                 "prefix_waits": sum(row["tau"] > 0 for row in memory),
                                 "coarse_sha256": hashes[0], "half_sha256": hashes[1],
                                 "source_switch": os.path.relpath(chosen, ROOT), "anchor_file": output.relative_to(destination).as_posix()})
    with (destination / "m28_anchors.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(registry[0]))
        writer.writeheader()
        writer.writerows(registry)


def reuse_identical_anchor(job, root, cutoffs):
    """Materialize the same deterministic continuation for identical registered inputs."""
    if job.group != "F1":
        return
    peer = Job("F2-R", job.origin, job.policy, job.precision, job.anchor_root)
    source = source_for(job.origin)
    original, fork, memory = branch_seed(job, source)
    equivalent, peer_fork, peer_memory = branch_seed(peer, source)
    if fork != peer_fork or memory != peer_memory or not all(np.array_equal(a, b) for a, b in zip(original, equivalent, strict=True)):
        return
    previous_count = 0
    for cap in cutoffs:
        if cap <= fork:
            continue
        stage = root / f"t{cap // 1000}"
        reference, destination = stage / peer.relative_path(), stage / job.relative_path()
        if not (reference / "checkpoint.npz").is_file():
            return
        summary, = physics.csv_rows(reference / "m28_checkpoints.csv")
        completed = int(summary["attempts"])
        if completed - int(summary["attempts_in_stage"]) != previous_count:
            return
        previous_count = completed
        if destination.is_dir():
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        with TemporaryDirectory(prefix=".equivalent-", dir=destination.parent) as temporary:
            folder = Path(temporary) / "complete"
            folder.mkdir()
            for entry in reference.iterdir():
                if entry.suffix != ".csv":
                    shutil.copyfile(entry, folder / entry.name)
                    continue
                with (folder / entry.name).open("w", encoding="utf-8", newline="") as stream:
                    writer = None
                    for row in physics.csv_rows(entry):
                        row["group"] = job.group
                        if writer is None:
                            writer = csv.DictWriter(stream, fieldnames=list(row))
                            writer.writeheader()
                        writer.writerow(row)
            relation = {"same_pair_and_completed_history": True, "reference": peer.relative_path().as_posix()}
            (folder / "equivalent_anchor.json").write_text(json.dumps(relation, indent=2) + "\n", encoding="utf-8")
            publish_stage(folder, destination)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("main", "anchors", "matched"))
    parser.add_argument("--stages", type=Path, default=ROOT / "stages")
    parser.add_argument("--anchors", type=Path, default=ROOT / "anchors")
    parser.add_argument("--cutoffs", nargs="+", type=int, default=[150, 300, 540])
    parser.add_argument("--origins", nargs="+", choices=ORIGINS, default=ORIGINS)
    parser.add_argument("--precisions", nargs="+", choices=PRECISIONS, default=PRECISIONS)
    parser.add_argument("--groups", nargs="+", choices=GROUPS, default=GROUPS)
    parser.add_argument("--policies", nargs="+", choices=MATCHED, default=MATCHED)
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--reference-projector", action="store_true")
    parser.add_argument("--rate-floor", type=float, default=RATE_FLOOR)
    args = parser.parse_args()
    if args.cutoffs != sorted(set(args.cutoffs)) or not 1 <= args.cutoffs[0] <= args.cutoffs[-1] <= 540:
        parser.error("Cutoffs must be unique, increasing and in [1, 540]")
    if args.workers < 1 or not math.isfinite(args.rate_floor) or args.rate_floor < 0:
        parser.error("Invalid worker count or rate floor")
    if args.action == "anchors":
        prepare_anchors(args.stages, args.anchors, args.origins, args.precisions)
        return
    cuts = tuple(value * 1000 for value in args.cutoffs)
    groups = ("main",) if args.action == "main" else tuple(args.groups)
    policies = ("F2-R",) if args.action == "main" else tuple(args.policies)
    jobs = [Job(group, origin, policy, step, args.anchors) for step in args.precisions for group in groups
            for policy in policies for origin in args.origins]
    register(args.stages)
    if args.action == "matched":
        for job in jobs:
            reuse_identical_anchor(job, args.stages, cuts)
    options = {"rate_floor": args.rate_floor, "buffered": not args.reference_projector}
    if args.workers == 1:
        for job in jobs:
            run_job(job, args.stages, cuts, **options)
    else:
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            for task in as_completed([pool.submit(run_job, job, args.stages, cuts, **options) for job in jobs]):
                task.result()


if __name__ == "__main__":
    main()
