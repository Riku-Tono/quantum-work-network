"""Run M28's separately labelled retrospective E continuation."""

import argparse
from collections import OrderedDict
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass
from functools import lru_cache
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent
M27 = ROOT.parent / "Milestone_27"
sys.path.insert(0, str(M27))
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import numpy as np

from run_m27 import Attempt, OBSERVED, PRECISIONS, half_physicality
from m25_control import ORIGINS, Trial, retrospective, switch_input, waiting_state
from m25_diagnostics import state_metrics
from m23_spectral import DT, FLOOR, G, GRID, HALF_TOL, LOAD_DIM, OCCUPATION, local_diagnostics, maxabs, partial
from m24_physics import observe_local
from m26_snapshots import Snapshot, snapshot_at
from run_m23 import COARSE_TAUS, account
from run_m25 import fingerprint


BATCH_SIZE = 30
ORDER_GUARD = 1e-14
SELECTION_CACHE_SIZE = 128


@lru_cache(maxsize=2)
def sector_bridges(model):
    overlap = model.bases[0].tr @ model.connected.vectors
    sectors = (np.flatnonzero(OCCUPATION == value) for value in np.unique(OCCUPATION))
    return tuple((sector, np.ascontiguousarray(overlap[np.ix_(sector, sector)])) for sector in sectors)


@lru_cache(maxsize=2)
def work_projection_groups(model):
    """Keep the exchange block and merge equal contributions to the reduced load."""
    result = []
    for left, right, pairs, weights in model.groups:
        columns = {}
        for i, (a, b) in enumerate(pairs):
            key = (a % LOAD_DIM, b % LOAD_DIM) if a // LOAD_DIM == b // LOAD_DIM else (a, b)
            if key in columns:
                columns[key] += weights[:, i]
            else:
                columns[key] = weights[:, i].copy()
        result.append((left, right, tuple(columns), np.ascontiguousarray(np.column_stack(tuple(columns.values())))))
    return tuple(result)


def work_projector(model, spectra, dt, count):
    # Candidate work depends on the reduced load (sum of both diagonal
    # blocks) and the exchange block. Put that sum in the first block, leaving
    # the second zero. Diagnostics that use terminal populations use the full
    # projection at the chosen execution instead.
    size = 2 * LOAD_DIM
    terminal = np.zeros((len(spectra), count, size, size), dtype=np.complex128)
    for group, (left, right, pairs, weights) in enumerate(work_projection_groups(model)):
        multiplier = spectra[:, left, right].T
        coefficient = np.ascontiguousarray((multiplier[:, :, None] * weights[:, None, :]).reshape(len(left), -1))
        values = (model.time_kernel(group, dt)[:count] @ coefficient).reshape(count, len(spectra), len(pairs))
        for j, (a, b) in enumerate(pairs):
            terminal[..., a, b] = values[..., j].T
            terminal[..., b, a] = values[..., j].conjugate().T
    return terminal


@dataclass(frozen=True)
class SearchResult:
    selected: Trial
    trials: list[Trial]
    centers: tuple[int, ...]
    used_reference: bool


class Candidates:
    """Project wait candidates onto the connected basis in excitation blocks."""

    def __init__(self, model, state, dt, *, reference=False):
        self.model = model
        self.state = state
        self.dt = dt
        self.reference = reference
        self.wait_basis = model.bases[0]
        self.cut_basis = self.wait_basis.to_basis(state)
        self.c0 = float(local_diagnostics(partial(state))["c_real"])
        self.evaluated = {}

    def connected_spectra(self, taus):
        cut = self.wait_basis
        model = self.model
        waiting = [cut.step_spectral(self.cut_basis, tau, self.dt) for tau in taus]
        if self.reference:
            return np.stack([model.connected.to_basis(cut.from_basis(rho) if tau else self.state)
                             for tau, rho in zip(taus, waiting, strict=True)])
        waiting = np.stack(waiting)
        left = np.empty_like(waiting)
        connected = np.empty_like(waiting)
        bridges = sector_bridges(model)
        for sector, block in bridges:
            left[:, sector, :] = block.T @ waiting[:, sector, :]
        for sector, block in bridges:
            connected[:, :, sector] = left[:, :, sector] @ block
        if taus[0] == 0:
            connected[0] = model.connected.to_basis(self.state)
        return connected

    def scan(self, taus, window, stage):
        if self.reference:
            self.evaluated.clear()
        unseen = [tau for tau in taus if tau not in self.evaluated]
        batch_size = 10 if self.reference else BATCH_SIZE
        projector = self.model.terminal_grid if self.reference else lambda *args: work_projector(self.model, *args)
        for start in range(0, len(unseen), batch_size):
            batch = unseen[start:start + batch_size]
            counts = [(window - tau) // GRID + 1 for tau in batch]
            spectra = self.connected_spectra(batch)
            projected = local_diagnostics(projector(spectra, self.dt, max(counts)))
            for i, (tau, count) in enumerate(zip(batch, counts, strict=True)):
                switches = 2 * G * (projected["c_real"][i, 0] - self.c0) if tau else 0.0
                first = int(tau == 0)
                works = projected["total_work"][i, first:count] - switches
                selected = int(np.argmax(works))
                work = float(works[selected])
                tied = not self.reference and int(np.count_nonzero(works >= work - ORDER_GUARD)) > 1
                self.evaluated[tau] = first + selected, count - first, work, tied
        trials = [Trial(stage, tau, *self.evaluated[tau][:3]) for tau in taus]
        return trials, any(self.evaluated[tau][3] for tau in taus)


def at_candidate(model, rho, dt, trial):
    waited = waiting_state(model, rho, trial.tau, dt)
    before = model.connected.evolve(waited, trial.index * GRID, dt)
    cut, reconnect = switch_input(rho, waited, trial.tau)
    return float(local_diagnostics(partial(before))["total_work"]) - cut - reconnect


def select(model, pair, primary, window, *, reference=False):
    """Use the M25 E coarse/fine search and time tie-break at either step size."""
    if reference and primary == 0:
        winner, trials, centers = retrospective(model, pair, window, "E")
        return SearchResult(winner, trials, centers, True)
    scans = Candidates(model, pair[primary], DT[primary], reference=reference)
    coarse, ambiguous = scans.scan(tuple(tau for tau in COARSE_TAUS if tau <= window), window, "A")
    maxima = [trial for i, trial in enumerate(coarse)
              if (i == 0 or trial.work > coarse[i - 1].work)
              and (i == len(coarse) - 1 or trial.work >= coarse[i + 1].work)]
    ranked = sorted(maxima, key=lambda trial: (-trial.work, trial.tau))
    centers = ranked[:3]
    ambiguous |= any(abs(a.work - b.work) <= ORDER_GUARD for a, b in zip(coarse, coarse[1:]))
    ambiguous |= len(ranked) > 3 and abs(ranked[2].work - ranked[3].work) <= ORDER_GUARD
    lattice = set()
    for trial in centers:
        bound = min(6000, window)
        if trial.tau == 6000:
            neighbor = coarse[-2]
            other = 1 - primary
            margin = sum(abs(t.work - at_candidate(model, pair[other], DT[other], t)) for t in (trial, neighbor))
            resolved_gain = trial.work - neighbor.work - FLOOR - margin
            if resolved_gain > 0.0:
                bound = min(6250, window)
            ambiguous |= abs(resolved_gain) <= ORDER_GUARD
        lattice.update(range(max(0, trial.tau - 250), min(bound, trial.tau + 250) + 1, 25))
    refined, refined_ambiguous = scans.scan(sorted(lattice), window, "C")
    trials = coarse + refined
    winner = min(trials, key=lambda trial: (-trial.work, trial.elapsed, trial.tau))
    similar = any((trial.tau, trial.index) != (winner.tau, winner.index) and winner.work - trial.work <= ORDER_GUARD
                  for trial in trials)
    if not reference and (ambiguous or refined_ambiguous or similar):
        return select(model, pair, primary, window, reference=True)
    return SearchResult(winner, trials, tuple(trial.tau for trial in centers), reference)


def assert_search_parity(fast, reference):
    def times(result):
        return [(trial.stage, trial.tau, trial.index, trial.count) for trial in result.trials]

    if (fast.selected.tau, fast.selected.index) != (reference.selected.tau, reference.selected.index):
        raise ValueError("E candidate winner differs from the reference projection")
    if fast.centers != reference.centers or times(fast) != times(reference):
        raise ValueError("E candidate grid or per-wait maximum differs from the reference projection")
    error = max(abs(a.work - b.work) for a, b in zip(fast.trials, reference.trials, strict=True))
    if error > ORDER_GUARD:
        raise ValueError(f"E candidate work differs from reference by {error:g}")
    return error


@dataclass(frozen=True)
class CachedSearch:
    result: SearchResult
    seconds: float
    reference_seconds: float | None
    reference_error: float | None


class Oracle:
    """Checkpointable E attempt with all retrospective evidence confined to E."""

    def __init__(self, *, check_reference=False):
        self.check_reference = check_reference
        self.cache = OrderedDict()

    def search(self, model, pair, primary, window):
        key = primary, window, *(fingerprint(rho) for rho in pair)
        if key not in self.cache:
            start = time.perf_counter()
            result = select(model, pair, primary, window)
            seconds = time.perf_counter() - start
            reference_seconds = reference_error = None
            if self.check_reference:
                started = time.perf_counter()
                reference = select(model, pair, primary, window, reference=True)
                reference_seconds = time.perf_counter() - started
                reference_error = assert_search_parity(result, reference)
            self.cache[key] = CachedSearch(result, seconds, reference_seconds, reference_error)
            if len(self.cache) > SELECTION_CACHE_SIZE:
                self.cache.popitem(last=False)
        else:
            self.cache.move_to_end(key)
        return self.cache[key]

    def __call__(self, model, pair, primary, start, window, cap):
        saved = self.search(model, pair, primary, window)
        result = saved.result
        selected = result.selected
        tau, duration = selected.tau, selected.elapsed
        connected = selected.index * GRID
        end = start + duration
        other = 1 - primary
        waited = tuple(waiting_state(model, rho, tau, dt) for rho, dt in zip(pair, DT, strict=True))
        cuts = tuple(switch_input(rho, wait, tau) for rho, wait in zip(pair, waited, strict=True))
        covered = min(cap, end)
        cut_applied = bool(tau)
        reconnect_applied = cut_applied and covered >= start + tau
        last_observed = (start + tau + (covered - start - tau) // GRID * GRID
                         if covered >= start + tau else start)
        switch_net = -cuts[primary][0] - (cuts[primary][1] if reconnect_applied else 0.0)
        pending = {"tau": tau, "forecast_tick": start, "execute_tick": end, "cut_applied": cut_applied,
                   "reconnect_applied": reconnect_applied, "switch_net": switch_net,
                   "last_observation_tick": last_observed}
        if end > cap:
            boundary = snapshot_at(model, pair, None, start, tau, duration, cap)
            return Attempt(boundary.pair, None, [], [], boundary, pending)
        before = tuple(model.connected.evolve(rho, connected, dt) for rho, dt in zip(waited, DT, strict=True))
        candidates = tuple(float(local_diagnostics(partial(rho))["total_work"]) - cut - reconnect
                           for rho, (cut, reconnect) in zip(before, cuts, strict=True))
        error = abs(candidates[0] - candidates[1])
        if abs(candidates[primary] - selected.work) > FLOOR or error > HALF_TOL:
            raise ValueError(f"E selected candidate movement or aligned error at {start}: {error:g}")
        accounts, virtual = zip(*(account(model, seed, wait, pre, work, tau, *switches)
                                  for seed, wait, pre, work, switches in zip(pair, waited, before, candidates, cuts, strict=True)),
                                strict=True)
        margin = candidates[primary] - error
        accepted = margin > FLOOR and accounts[primary]["direct_net"] > FLOOR
        after = virtual if accepted else before
        net = tuple(check["direct_net"] if accepted else -sum(switches)
                    for check, switches in zip(accounts, cuts, strict=True))
        pre = state_metrics(model, before[primary])
        post = state_metrics(model, after[primary]) if accepted else pre
        other_physicality = max(half_physicality(before[other]), half_physicality(after[other]))
        closure = post["global_energy"] - accounts[primary]["start_global_energy"] + net[primary]
        passive_drift = post["global_passive_energy"] - pre["global_passive_energy"]
        chain_drift = post["bare_chain_energy"] - pre["bare_chain_energy"]
        if max(abs(closure), abs(passive_drift), abs(chain_drift), other_physicality,
               abs(post["load_ergotropy"]) if accepted else 0.0) > FLOOR:
            raise ValueError(f"E physicality or accounting failed at {end}")
        initial = observe_local(partial(pair[primary]))
        reconnected = observe_local(partial(waited[primary]))
        before_phase, after_phase = (float(np.angle(complex(rho["c_real"], rho["c_imag"]))) for rho in (initial, reconnected))
        phase_change = float(np.angle(np.exp(1j * (after_phase - before_phase))))
        search_log = [{"stage": trial.stage, "tau_tick": trial.tau, "connected_index": trial.index,
                       "candidate_count": trial.count, "max_net": trial.work, "selected": trial is selected}
                      for trial in result.trials]
        row = {
            "mode": "retrospective", "accepted": accepted, "outcome": "extracted" if accepted else "unresolved_candidate",
            "stop_reason": "retrospective", "window": window / 1000, "tau": tau / 1000, "elapsed_start": start / 1000,
            "elapsed_connected": connected / 1000, "duration": duration / 1000, "elapsed_total": end / 1000,
            "decision_elapsed_total": "", "observed_until": end / 1000,
            "threshold": FLOOR, "skipped_peaks": 0, "candidate_net": candidates[primary], "candidate_net_half": candidates[1],
            "candidate_net_aligned": candidates[other], "candidate_step_error": error, "resolution_margin": margin,
            "net_work": net[primary], "net_work_aligned": net[other],
            "cut_on": cuts[primary][0], "reconnect_on": cuts[primary][1], "cut_on_half": cuts[1][0],
            "reconnect_on_half": cuts[1][1], "cut_on_aligned": cuts[other][0], "reconnect_on_aligned": cuts[other][1],
            "accepted_energy_residual": closure, "global_passive_unitary_drift": passive_drift, "bare_chain_unitary_drift": chain_drift,
            "direct_net_half": accounts[1]["direct_net"], "direct_net_aligned": accounts[other]["direct_net"],
            "half_state_max_error": maxabs(after[0] - after[1]), "max_half_physicality_error": other_physicality,
            **accounts[primary], "post_global_energy": post["global_energy"],
            "phase_before": before_phase, "phase_after": after_phase, "phase_change": phase_change,
            "current_before": float(initial["load_current"]), "current_after": float(reconnected["load_current"]),
            "sign_reversal": initial["load_current"] * reconnected["load_current"] < 0.0,
            "c_abs_before": float(initial["c_abs"]), "c_abs_after": float(reconnected["c_abs"]), "wait_reason": "retrospective",
            "oracle_candidates": sum(trial.count for trial in result.trials), "oracle_wait_candidates": len(result.trials),
            "oracle_reference_fallback": result.used_reference, "oracle_search_seconds": saved.seconds,
            "oracle_reference_seconds": saved.reference_seconds, "oracle_reference_max_error": saved.reference_error,
            "oracle_centers_json": json.dumps(result.centers), "oracle_search_json": json.dumps(search_log, separators=(",", ":")),
            **{f"pre_{name}": value for name, value in pre.items()}, **{f"post_{name}": value for name, value in post.items()},
            **{f"{stage}_{label}_sha256": fingerprint(rho) for stage, states in (("start", pair), ("pre", before), ("post", after))
               for label, rho in zip(PRECISIONS, states, strict=True)},
        }
        observations = oracle_observations(model, waited[primary], DT[primary], start + tau, selected.index)
        return Attempt(after, row, [], observations, Snapshot(after, G, end, "operation_end"), pending)


def oracle_observations(model, waited, dt, reconnect, last):
    spectrum = model.connected.to_basis(waited)[None]
    terminals = model.terminal_grid(spectrum, dt, last + 1)[0]
    measured = observe_local(terminals)
    indices = np.arange(last + 1)
    phases = np.arctan2(measured["c_imag"], measured["c_real"])
    return [{"index": int(i), "elapsed_total": (reconnect + i * GRID) / 1000,
             "observed_until": (reconnect + i * GRID) / 1000, "forecast_generated": False, "execute": i == last,
             **{name: float(measured[name][i]) for name in OBSERVED}, "phase": float(phases[i])} for i in indices]


def run_origin(origin, precision, groups, stages, anchors, cutoffs, benchmark):
    from run_m28 import Job, run_job

    oracle = Oracle(check_reference=benchmark)
    for group in groups:
        run_job(Job(group, origin, "E", precision, anchors), stages, cutoffs, oracle=oracle)
    return origin, precision


def main():
    from run_m28 import GROUPS, register

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stages", type=Path)
    parser.add_argument("--anchors", type=Path)
    parser.add_argument("--groups", nargs="+", choices=GROUPS)
    parser.add_argument("--origins", nargs="+", choices=ORIGINS)
    parser.add_argument("--precisions", nargs="+", choices=PRECISIONS, default=PRECISIONS)
    parser.add_argument("--cutoffs", nargs="+", type=int)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--benchmark", action="store_true", help="Compare every S0 search with the reference projection.")
    args = parser.parse_args()
    root = ROOT / "benchmark" if args.benchmark else ROOT
    stages = args.stages or root / "stages"
    anchors = args.anchors or root / "anchors"
    groups = args.groups or (("F2-R",) if args.benchmark else GROUPS)
    origins = args.origins or (("S0",) if args.benchmark else ORIGINS)
    cutoffs = tuple(value * 1000 for value in (args.cutoffs or ((120,) if args.benchmark else (150, 300, 540))))
    if tuple(sorted(set(cutoffs))) != cutoffs or not 0 < cutoffs[0] <= cutoffs[-1] <= 540_000:
        parser.error("Cutoffs must be increasing and inside (0, 540]")
    paths = [anchors / group / origin / precision / "anchor.npz"
             for group in groups for origin in origins for precision in args.precisions]
    missing = [path for path in paths if not path.is_file()]
    if missing:
        parser.error(f"Matched anchor is missing: {missing[0]}")
    register(stages)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(run_origin, origin, precision, groups, stages, anchors, cutoffs, args.benchmark)
                   for origin in origins for precision in args.precisions]
        for job in as_completed(futures):
            origin, precision = job.result()
            print(f"Completed E continuation for {origin}/{precision}", flush=True)


if __name__ == "__main__":
    main()
