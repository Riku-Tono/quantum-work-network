"""Rebase audited M27 F1 waiting tails to the exact matched RH fork."""

import argparse
from collections import defaultdict
import json
from pathlib import Path
from tempfile import TemporaryDirectory

from run_m28 import Job, Ledger, M27, ORIGINS, PRECISIONS, ROOT, branch_seed, commit, physics, publish_stage, register, source_for
import numpy as np


EVENT_KEYS = ("origin", "policy", "precision", "attempt")
HISTORY_KEYS = {*EVENT_KEYS, "count", "cumulative_net", "cumulative_net_aligned", "cumulative_net_half_aligned",
                "cumulative_step_error_bound", "cumulative_rate", "absolute_time", "record_source"}


def by_event(directory, name, prefix):
    path = directory / f"m27_{name}.csv"
    data = defaultdict(list)
    if path.is_file():
        for row in physics.csv_rows(path):
            number = int(row["attempt"])
            if number > prefix:
                data[number].append({key: value for key, value in row.items() if key not in EVENT_KEYS})
    return data


def run(stages, anchors):
    audit = json.loads((M27 / "results/audit.json").read_text(encoding="utf-8"))
    archived = M27 / "stages"
    if audit["boundaries"] != [150, 300, 540]:
        raise ValueError("Archived M27 audit does not cover the registered boundaries")
    register(stages)
    for origin in ORIGINS:
        source = source_for(origin)
        for precision in PRECISIONS:
            job = Job("F1", origin, "RH", precision, anchors)
            pair, tick, memory = branch_seed(job, source)
            expected = tuple(physics.fingerprint(state) for state in pair)
            prefix = len(memory)
            prefix_accepted = sum(row["accepted"] for row in memory)
            work = companion = bound = 0.0
            count = replays = 0
            clock = tick
            for cap in (150, 300, 540):
                folder = archived / f"t{cap}" / origin / "F1" / precision
                destination = stages / f"t{cap}" / job.relative_path()
                origin_label = {"group": "F1", "origin": origin, "policy": "RH", "precision": precision,
                                "fork_elapsed": tick / 1000}
                if destination.is_dir():
                    checkpoint, = physics.csv_rows(destination / "m28_checkpoints.csv")
                    work, companion, bound = (float(checkpoint[k]) for k in ("cumulative_net", "cumulative_net_aligned",
                                                                             "cumulative_step_error_bound"))
                    count, replays = (int(checkpoint[k]) for k in ("count", "attempts"))
                    clock = physics.tick(checkpoint, "anchor_elapsed")
                    continue
                destination.parent.mkdir(parents=True, exist_ok=True)
                with TemporaryDirectory(prefix=".archive-replay-", dir=destination.parent) as temporary:
                    output = Path(temporary) / "complete"
                    output.mkdir()
                    tables = Ledger(output)
                    observed = by_event(folder, "observations", prefix)
                    wait = by_event(folder, "wait_checks", prefix)
                    before = replays
                    try:
                        for record in physics.csv_rows(folder / "m27_history.csv"):
                            number = int(record["attempt"])
                            if number <= prefix:
                                continue
                            if ((number, physics.tick(record, "elapsed_start"), record["mode"]) != (prefix + replays + 1, clock, "wait")
                                    or (replays == 0 and tuple(record[f"start_{label}_sha256"] for label in PRECISIONS) != expected)):
                                raise ValueError(f"Archived branch has different fork or policy: {origin}/{precision}/{number}")
                            row = {key: value for key, value in record.items() if key not in HISTORY_KEYS}
                            for key in ("net_work", "net_work_aligned", "tau", "elapsed_start", "elapsed_total"):
                                row[key] = float(row[key])
                            row["accepted"] = row["accepted"] == "True"
                            for sample in observed[number]:
                                for key in ("elapsed_total", "load_ergotropy", "load_current"):
                                    sample[key] = float(sample[key])
                            record_clock = clock / 1000
                            decision = {"elapsed_total": record_clock, "observed_until": record_clock, "reason": "RH",
                                        "mode_before": "wait", "mode_after": "wait", "switched": False}
                            trial = physics.Attempt((), row, wait[number], observed[number], None, {})
                            replays += 1
                            work, companion, bound, count = commit(tables, job, {**origin_label, "attempt": replays}, decision,
                                                                    trial, work, companion, bound, count, float(source["source_time"]))
                            clock = physics.tick(record)
                        summary, = physics.csv_rows(folder / "m27_checkpoints.csv")
                        if (int(summary["attempts"]), int(summary["count"]), physics.tick(summary, "anchor_elapsed")) != (
                                replays + prefix, count + prefix_accepted, clock):
                            raise ValueError(f"Boundary accounting differs from checked archive: {folder}")
                        summary.update(origin_label, attempts=replays, count=count, attempts_in_stage=replays-before,
                                       cumulative_net=work, cumulative_net_aligned=companion, cumulative_step_error_bound=bound,
                                       mode="forecast", fork_coarse_sha256=expected[0], fork_half_sha256=expected[1])
                        tables.add("m28_checkpoints", summary)
                    finally:
                        tables.close()
                    with np.load(folder / "checkpoint.npz", allow_pickle=False) as archive:
                        entries = dict(archive)
                    entries.update(work=(work, companion, bound), counters=(clock, replays, count),
                                   controller=json.dumps(vars(physics.Controller()), sort_keys=True), fork_tick=tick,
                                   fork_coarse_sha256=expected[0], fork_half_sha256=expected[1])
                    np.savez_compressed(output / "checkpoint.npz", **entries)
                    provenance = {"archive": f"../Milestone_27/stages/t{cap}/{origin}/F1/{precision}",
                                  "source_audit": "../Milestone_27/results/audit.json",
                                  "input_hashes": expected, "fork_elapsed": tick / 1000, "source_prefix_trials": prefix}
                    (output / "archived_wait_tail.json").write_text(json.dumps(provenance, indent=2) + "\n", encoding="utf-8")
                    publish_stage(output, destination)
                print(f"Rebased audited RH {origin}/{precision} through {cap}: {replays} trials", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stages", type=Path, default=ROOT / "stages")
    parser.add_argument("--anchors", type=Path, default=ROOT / "anchors")
    args = parser.parse_args()
    run(args.stages, args.anchors)
