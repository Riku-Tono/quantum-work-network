"""Compare independent clocks, state propagation, and registered rate-floor sensitivity."""

import argparse
import csv
import math
from pathlib import Path

from run_m28 import COMMON, M27, ORIGINS, PRECISIONS, RATE_FLOOR, ROOT, Job, physics, run_job
import numpy as np

FLOORS = (0.0, 1e-14, RATE_FLOOR, 1e-10)
PERTURBATIONS = (-1e-12, -1e-14, 1e-14, 1e-12)
CONTROL_FIELDS = ("mode_after", "switched", "accepted", "outcome", "tau", "reconnect_elapsed", "elapsed_total")
PREDICATES = ("phase_gate", "supplying", "rotated", "repeatedly_micro")


def stages_for(root, group, origin, policy, step):
    key = Path(origin, policy, step) if group is None else Path(group, origin, policy, step)
    return [root / f"t{time}" / key for time in (150, 300, 540)]


def stack(folders, filename):
    return [row for folder in folders for row in physics.csv_rows(folder / filename)]


def switched(decisions):
    return next((float(row["elapsed_total"]) for row in decisions if row["switched"] == "True"), None)


def enough_rate_evidence(row):
    elapsed = float(row["elapsed_total"])
    return bool(row["low_since"] and int(row["low_count"]) >= 2 and elapsed - float(row["low_since"]) >= 4 - 1e-10
                and elapsed - float(row["last_mode_change"]) >= 30 - 1e-10)


def would_switch(row, threshold, delta=0.0):
    if not enough_rate_evidence(row):
        return False
    phase = float(row["phase"])
    supplying = (-3 * math.pi / 4 <= phase <= -math.pi / 4 and float(row["load_current"]) > 0
                 and float(row["load_ergotropy_rate"]) + delta > threshold)
    return (float(row["load_ergotropy"]) <= 1e-8 and float(row["c_abs"]) >= 1e-5
            and (supplying or row["rotated"] == "True" or row["repeatedly_micro"] == "True"))


def rates(history):
    return {"cumulative_net": math.fsum(float(row["net_work"]) for row in history),
            "count": sum(row["accepted"] == "True" for row in history),
            "late_rate": math.fsum(float(row["net_work"]) for row in history if float(row["elapsed_total"]) > 300) / 240}


def trace_distance(a, b):
    difference = a - b
    return float(np.abs(np.linalg.eigvalsh((difference + difference.conj().T) / 2)).sum() / 2)


def state_distances(stages):
    for origin in ORIGINS:
        native = [stages_for(stages, "main", origin, "F2-R", step) for step in PRECISIONS]
        for tick in COMMON:
            name = f"state_t{tick // 1000:03d}.npz"
            left, right = [next(folder / name for folder in folders if (folder / name).is_file()) for folders in native]
            with np.load(left, allow_pickle=False) as coarse, np.load(right, allow_pickle=False) as half:
                yield {"origin": origin, "policy": "F2-R", "elapsed_total": tick / 1000,
                       "independent_global_trace_distance": trace_distance(coarse["coarse"], half["half"]),
                       "coarse_control_aligned_global_trace_distance": trace_distance(coarse["coarse"], coarse["half"]),
                       "half_control_aligned_global_trace_distance": trace_distance(half["coarse"], half["half"]),
                       "coarse_coupling": float(coarse["coupling"]), "half_coupling": float(half["coupling"])}


def compare_sequences(origin, policy, coarse, half, coarse_decisions, half_decisions):
    def observed(row):
        return tuple(row.get(field) or (str(round(float(row["elapsed_start"]) + float(row["tau"]), 6))
                                        if field == "reconnect_elapsed" else "") for field in CONTROL_FIELDS[2:])
    paired = list(zip(coarse, half))
    changed = [i for i, (a, b) in enumerate(paired, 1) if observed(a) != observed(b)]
    at_coarse = {row["elapsed_total"]: row for row in coarse_decisions}
    at_half = {row["elapsed_total"]: row for row in half_decisions}
    matched = at_coarse.keys() & at_half.keys()
    different = sum(any(at_coarse[t][field] != at_half[t][field] for field in PREDICATES) for t in matched)
    accepted_coarse = [row for row in coarse if row["accepted"] == "True"]
    accepted_half = [row for row in half if row["accepted"] == "True"]
    return {"origin": origin, "policy": policy, "switch_coarse": switched(coarse_decisions),
            "switch_half": switched(half_decisions), "coarse_attempts": len(coarse), "half_attempts": len(half),
            "different_attempts_by_ordinal": len(changed) + abs(len(coarse) - len(half)),
            "first_different_attempt": (changed[0] if changed else len(paired) + 1 if len(coarse) != len(half) else ""),
            "shared_decision_clocks": len(matched), "different_diagnostic_predicates_at_shared_clocks": different,
            "different_mode_decisions_at_shared_clocks": sum(at_coarse[t]["mode_after"] != at_half[t]["mode_after"]
                                                              or at_coarse[t]["switched"] != at_half[t]["switched"] for t in matched),
            "unmatched_decision_clocks": len(at_coarse.keys() ^ at_half.keys()),
            "coarse_extractions": len(accepted_coarse), "half_extractions": len(accepted_half),
            "max_paired_extraction_clock_delta": max((abs(physics.tick(a) - physics.tick(b)) / 1000
                                                       for a, b in zip(accepted_coarse, accepted_half)), default=0.0),
            "max_paired_reconnect_clock_delta": max((abs(physics.tick(a, "elapsed_start") + physics.tick(a, "tau")
                                                         - physics.tick(b, "elapsed_start") - physics.tick(b, "tau")) / 1000
                                                       for a, b in paired), default=0.0),
            "coarse_cumulative_net": rates(coarse)["cumulative_net"], "half_cumulative_net": rates(half)["cumulative_net"],
            "coarse_late_rate": rates(coarse)["late_rate"], "half_late_rate": rates(half)["late_rate"]}


def analyze(stages, exploration):
    sensitivity, perturbations, chronology = [], [], []
    for origin in ORIGINS:
        groups = {"F2": [], "F2-R": []}
        for step in PRECISIONS:
            main = stages_for(stages, "main", origin, "F2-R", step)
            archived = stages_for(M27 / "stages", None, origin, "F2", step)
            h_main, d_main = (stack(main, f"m28_{key}.csv") for key in ("history", "decisions"))
            h_old, d_old = (stack(archived, f"m27_{key}.csv") for key in ("history", "decisions"))
            groups["F2"].append((h_old, d_old))
            groups["F2-R"].append((h_main, d_main))
            first_main = switched(d_main)
            prefix = [row for row in d_main if row["mode_before"] == "forecast"]
            for floor in FLOORS:
                replay = next((float(row["elapsed_total"]) for row in prefix if would_switch(row, floor)), None)
                if floor == 0:
                    history, first, source = h_old, switched(d_old), "M27 verified archive"
                    if replay is not None and replay != first:
                        raise ValueError(f"Old-rule prefix disagrees with M27 archive: {origin}/{step}")
                elif replay == first_main:
                    history, first = h_main, first_main
                    source = "registered execution" if floor == RATE_FLOOR else "identical causal switch replay"
                else:
                    path = exploration / f"rate_{floor:.0e}"
                    run_job(Job("main", origin, "F2-R", step), path, (150_000, 300_000, 540_000), rate_floor=floor)
                    folders = stages_for(path, "main", origin, "F2-R", step)
                    history, first = stack(folders, "m28_history.csv"), switched(stack(folders, "m28_decisions.csv"))
                    source = "independent exploratory execution"
                sensitivity.append({"origin": origin, "precision": step, "rate_floor": floor, "first_switch": first,
                                    "same_switch_as_formal": first == first_main, "source": source,
                                    **rates(history)})
                if source == "independent exploratory execution":
                    evaluated = [row for row in stack(folders, "m28_decisions.csv") if row["mode_before"] == "forecast"]
                else:
                    evaluated = [row for row in prefix if first is None or float(row["elapsed_total"]) <= first]
                for row in evaluated:
                    status = would_switch(row, floor)
                    for delta in PERTURBATIONS:
                        revised = would_switch(row, floor, delta)
                        perturbations.append({"origin": origin, "precision": step, "rate_floor": floor,
                                              "elapsed_total": row["elapsed_total"], "load_ergotropy_rate": row["load_ergotropy_rate"],
                                              "rate_perturbation": delta, "unperturbed_switch": status,
                                              "perturbed_switch": revised, "decision_changed": status != revised})
        for policy, ((hc, dc), (hh, dh)) in groups.items():
            chronology.append(compare_sequences(origin, policy, hc, hh, dc, dh))
    return sensitivity, perturbations, chronology


def write_table(path, rows):
    rows = list(rows)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stages", type=Path, default=ROOT / "stages")
    parser.add_argument("--output", type=Path, default=ROOT / "results")
    parser.add_argument("--exploration", type=Path, default=ROOT / "exploration")
    args = parser.parse_args()
    args.output.mkdir(exist_ok=True, parents=True)
    results = analyze(args.stages, args.exploration)
    for dataset, name in zip((*results, state_distances(args.stages)), ("sensitivity", "perturbations", "step_chronology", "step_states"), strict=True):
        write_table(args.output / f"m28_{name}.csv", dataset)


if __name__ == "__main__":
    main()
