"""Assemble the formal M28 histories and matched-state work comparisons."""

import argparse
from bisect import bisect_right
from collections import defaultdict
import csv
from math import fsum
from pathlib import Path
from statistics import correlation, median
import sys


ROOT = Path(__file__).resolve().parent
M27 = ROOT.parent / "Milestone_27"
sys.path.insert(0, str(M27))
from collect_m27 import (COMMON, FLOOR, ORIGINS, TINY_WORK, accepted, artifact_paths, csv_rows, ticks, write_csv)


MAIN = ("F2", "F2-R")
ANCHORS = ("F2-R", "F1")
BRANCHES = ("R0", "R1", "R3", "R6", "RH", "RP", "E")
ABLATIONS = ("Xphase", "Xamp", "Xcurrent", "Xinput")
PRECISIONS = ("coarse", "half")
CLOCK = 1000
LATE_START = 300 * CLOCK


def lane(row):
    return row["group"], row["origin"], row["policy"], row["precision"]


def flag(value):
    return str(value).casefold() in ("true", "1")


def read_optional(path):
    return csv_rows(path) if path.is_file() else []


def merge(stages, filename):
    return [row for path in artifact_paths(stages, filename) for row in csv_rows(path)]


def stream_artifact(stages, filename, target):
    paths = artifact_paths(stages, filename)
    fields = ["group", "origin", "policy", "precision"]
    for path in paths:
        with path.open(encoding="utf-8-sig", newline="") as stream:
            fields.extend(field for field in (csv.DictReader(stream).fieldnames or ()) if field not in fields)
    with target.open("w", encoding="utf-8", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=fields)
        writer.writeheader()
        for path in paths:
            with path.open(encoding="utf-8-sig", newline="") as stream:
                writer.writerows(csv.DictReader(stream))


class Timeline:
    """Signed work posted on closed attempts, with elapsed time measured from the fork."""

    def __init__(self, rows, checkpoint, cutoff, certified_through):
        self.rows = tuple(sorted(rows, key=lambda row: int(row["attempt"])))
        self.starts = [ticks(row["elapsed_start"]) for row in self.rows]
        initial = self.rows[0] if self.rows else checkpoint
        fork = initial.get("fork_elapsed")
        self.fork = ticks(fork) if fork not in ("", None) else ticks(initial.get("elapsed_start") or 0)
        self.events = [row for row in self.rows if ticks(row["elapsed_total"]) <= cutoff]
        self.times = [ticks(row["elapsed_total"]) for row in self.events]
        self.actions = [row for row in self.events if accepted(row)]
        self.action_times = [ticks(row["elapsed_total"]) for row in self.actions]
        self.checkpoint = checkpoint
        self.covered_through = min(cutoff, max(certified_through, self.times[-1] if self.times else self.fork))
        self.work, self.count, self.tiny, self.phase = [0.0], [0], [0], [0]
        self.positive = [0]
        self.reconnection_times, self.waits = [], []
        previous = self.fork
        for row in self.rows:
            start = ticks(row["elapsed_start"])
            stop = ticks(row["elapsed_total"])
            if start != previous or stop <= start:
                raise ValueError(f"Discontinuous attempt clock in {lane(row)} at {row['attempt']}")
            previous = stop
            tau = ticks(row.get("tau") or 0)
            if not 0 <= tau <= stop - start:
                raise ValueError(f"Invalid cut wait in {lane(row)} at {row['attempt']}")
            if tau:
                self.waits.append((start, min(start + tau, cutoff)))
                if start + tau <= cutoff:
                    self.reconnection_times.append(start + tau)
                    self.positive.append(self.positive[-1] + int(float(row.get("current_after") or 0) > 0))
            if stop > cutoff:
                continue
            credit = float(row["net_work"])
            recorded = float(row["cumulative_net"])
            if abs(recorded - self.work[-1] - credit) > FLOOR:
                raise ValueError(f"Discontinuous signed work in {lane(row)} at {row['attempt']}")
            if accepted(row) and credit <= 0:
                raise ValueError(f"Nonpositive accepted work in {lane(row)} at {row['attempt']}")
            self.work.append(recorded)
            self.count.append(self.count[-1] + int(accepted(row)))
            self.tiny.append(self.tiny[-1] + int(accepted(row) and credit <= TINY_WORK))
            self.phase.append(self.phase[-1] + int(row.get("phase_observations") or 0))
        if checkpoint:
            checkpoint_time = ticks(checkpoint["elapsed_total"])
            if checkpoint_time == cutoff:
                if (abs(float(checkpoint["cumulative_net"]) - self.work[-1]) > FLOOR
                        or int(checkpoint["count"]) != self.count[-1]
                        or int(checkpoint["attempts"]) != len(self.events)):
                    raise ValueError(f"Checkpoint disagrees with completed attempts for {lane(checkpoint)}")
                if flag(checkpoint.get("cut_applied")) and previous <= cutoff:
                    start = ticks(checkpoint["anchor_elapsed"])
                    tau = checkpoint.get("pending_tau_tick")
                    end = min(cutoff, start + int(tau)) if tau else cutoff
                    if end > start:
                        self.waits.append((start, end))

    def waiting(self, elapsed):
        return sum(max(0, min(elapsed, stop) - start) for start, stop in self.waits) / CLOCK

    def pending_work(self, tick):
        index = bisect_right(self.starts, tick) - 1
        if index < 0 or tick >= ticks(self.rows[index]["elapsed_total"]):
            if self.checkpoint and tick == ticks(self.checkpoint["elapsed_total"]):
                return float(self.checkpoint.get("pending_switch_net") or 0)
            return 0.0
        row = self.rows[index]
        value = -float(row.get("cut_on") or 0)
        if tick >= self.starts[index] + ticks(row.get("tau") or 0):
            value -= float(row.get("reconnect_on") or 0)
        return value

    def at(self, tick, start):
        if tick < self.fork or start > tick:
            raise ValueError("Comparison is outside the post-fork trajectory")
        start = max(start, self.fork)
        before, now = bisect_right(self.times, start), bisect_right(self.times, tick)
        count, tiny = self.count[now], self.tiny[now]
        elapsed = (tick - self.fork) / CLOCK
        interval = (tick - start) / CLOCK
        interval_work = self.work[now] - self.work[before]
        pending = self.pending_work(tick)
        interval_count = count - self.count[before]
        interval_tiny = tiny - self.tiny[before]
        recounted = bisect_right(self.reconnection_times, tick)
        return {
            "fork_elapsed": self.fork / CLOCK,
            "elapsed_total": tick / CLOCK,
            "elapsed_since_fork": elapsed,
            "cumulative_net": self.work[now],
            "pending_switch_net": pending,
            "cumulative_physical_net": self.work[now] + pending,
            "cumulative_rate": self.work[now] / elapsed if elapsed else "",
            "count": count,
            "tiny_count": tiny,
            "tiny_fraction": tiny / count if count else "",
            "cumulative_wait": self.waiting(tick),
            "phase_observations": self.phase[now],
            "reconnections": recounted,
            "positive_current_reconnections": self.positive[recounted],
            "positive_current_reconnection_fraction": self.positive[recounted] / recounted if recounted else "",
            "interval_start": start / CLOCK,
            "interval_net": interval_work,
            "interval_rate": interval_work / interval if interval else "",
            "interval_count": interval_count,
            "interval_tiny_count": interval_tiny,
            "interval_tiny_fraction": interval_tiny / interval_count if interval_count else "",
            "interval_wait": self.waiting(tick) - self.waiting(start),
            "interval_phase_observations": self.phase[now] - self.phase[before],
        }


def tags(key):
    return dict(zip(("group", "origin", "policy", "precision"), key, strict=True))


def archive_old_f2(m27):
    checks = defaultdict(int)
    for row in csv_rows(m27 / "m27_wait_checks.csv"):
        if row["policy"] == "F2":
            checks[row["origin"], row["precision"], row["attempt"]] += 1
    history = [
        {**row, "group": "main", "fork_elapsed": 0, "ledger_source": "M27 formal",
         "phase_observations": checks[row["origin"], row["precision"], row["attempt"]]
         + int(float(row["tau"]) > 0)}
        for row in csv_rows(m27 / "m27_history.csv") if row["policy"] == "F2"
    ]
    decisions, checkpoints = (
        [{**row, "group": "main", "fork_elapsed": 0, "ledger_source": "M27 formal"}
         for row in csv_rows(m27 / f"m27_{name}.csv") if row["policy"] == "F2"]
        for name in ("decisions", "checkpoints")
    )
    return history, decisions, checkpoints


def comparison(timelines, cutoff):
    comparisons, endpoints, late = [], [], []
    common = sorted({cutoff, *(time * CLOCK for time in COMMON if time * CLOCK <= cutoff)})
    for key, timeline in timelines.items():
        if timeline.fork >= timeline.covered_through:
            continue
        last = timeline.covered_through
        label = tags(key)
        before = timeline.fork
        for time in common:
            if time <= timeline.fork:
                continue
            if time > last:
                break
            comparisons.append({**label, **timeline.at(time, before)})
            before = time
        end = {**label, **timeline.at(last, timeline.fork),
               "target_elapsed": cutoff / CLOCK,
               "terminal_checkpoint": bool(timeline.checkpoint),
               "ending": timeline.checkpoint.get("ending", ""),
               "attempts": len(timeline.events),
               "last_extraction": timeline.action_times[-1] / CLOCK if timeline.actions else ""}
        endpoints.append(end)
        if last == cutoff and cutoff > max(timeline.fork, LATE_START):
            late.append({**label, **timeline.at(cutoff, LATE_START)})
    indexed = {(lane(row), row["elapsed_total"]): row for row in comparisons}
    full = {lane(row): row for row in endpoints}
    for row in comparisons:
        other = indexed.get(((row["group"], row["origin"], "E", row["precision"]), row["elapsed_total"]))
        value = other["cumulative_net"] if other else 0
        row["e_oracle_fraction"] = row["cumulative_net"] / value if value > 0 else ""
    for row in endpoints:
        other = full.get((row["group"], row["origin"], "E", row["precision"]))
        value = other["cumulative_net"] if other and other["elapsed_total"] == row["elapsed_total"] else 0
        row["e_oracle_fraction"] = row["cumulative_net"] / value if value > 0 else ""
    return comparisons, endpoints, late


def phase_gains(endpoints):
    summary = {lane(row): row for row in endpoints if row["terminal_checkpoint"]}
    gains = []
    for (group, origin, policy, precision), phase in summary.items():
        if policy != "RP":
            continue
        fixed = [summary[group, origin, baseline, precision] for baseline in ("R0", "R1", "R3", "R6")
                 if (group, origin, baseline, precision) in summary]
        best = max(fixed, key=lambda row: row["cumulative_net"]) if len(fixed) == 4 else None
        for name in ("R1", "RH", "best_fixed"):
            baseline = best if name == "best_fixed" else summary.get((group, origin, name, precision))
            if not baseline:
                continue
            if baseline["fork_elapsed"] != phase["fork_elapsed"]:
                raise ValueError(f"Mismatched physical fork clocks for {group}/{origin}/{precision}")
            benefit = phase["cumulative_net"] - baseline["cumulative_net"]
            extra = phase["phase_observations"] - baseline["phase_observations"]
            allowed = benefit / extra if extra > 0 else ""
            gains.append({
                "group": group, "origin": origin, "precision": precision, "fork_elapsed": phase["fork_elapsed"],
                "elapsed_total": phase["elapsed_total"], "baseline": name, "baseline_policy": baseline["policy"],
                "phase_net": phase["cumulative_net"], "baseline_net": baseline["cumulative_net"],
                "additional_net": benefit, "additional_work_rate": phase["cumulative_rate"] - baseline["cumulative_rate"],
                "phase_observations": phase["phase_observations"], "baseline_phase_observations": baseline["phase_observations"],
                "additional_phase_observations": extra, "break_even_cost_per_observation": allowed,
                "positive_cost_affordable": bool(extra > 0 and benefit > 0),
                "phase_e_oracle_fraction": phase["e_oracle_fraction"], "baseline_e_oracle_fraction": baseline["e_oracle_fraction"],
            })
    return gains


def main_differences(comparisons):
    indexed = {(row["origin"], row["policy"], row["precision"], row["elapsed_total"]): row
               for row in comparisons if row["group"] == "main"}
    differences = []
    for (origin, policy, precision, elapsed), robust in indexed.items():
        if policy != "F2-R":
            continue
        old = indexed.get((origin, "F2", precision, elapsed))
        if old:
            differences.append({
                "origin": origin, "precision": precision, "elapsed_total": elapsed,
                "old_cumulative_net": old["cumulative_net"], "robust_cumulative_net": robust["cumulative_net"],
                "delta_net": robust["cumulative_net"] - old["cumulative_net"],
                "delta_rate": robust["cumulative_rate"] - old["cumulative_rate"],
                "delta_interval_rate": robust["interval_rate"] - old["interval_rate"],
                "delta_count": robust["count"] - old["count"],
                "delta_wait": robust["cumulative_wait"] - old["cumulative_wait"],
            })
    return differences


def chronology(timelines, decision_rows):
    changes, flags = defaultdict(list), defaultdict(list)
    names = ("mode_before", "mode_after", "switched", "phase_gate", "supplying", "rotated", "repeatedly_micro")
    for row in sorted(decision_rows, key=lambda row: ticks(row["elapsed_total"])):
        flags[lane(row)].append((ticks(row["elapsed_total"]), *(row.get(name) for name in names)))
        if flag(row.get("switched")):
            changes[lane(row)].append((ticks(row["elapsed_total"]), row["mode_after"]))
    result = []
    for group, origin, policy, step in timelines:
        if step != "coarse" or (group, origin, policy, "half") not in timelines:
            continue
        coarse_key, half_key = (group, origin, policy, "coarse"), (group, origin, policy, "half")
        coarse, half = timelines[coarse_key], timelines[half_key]
        common_end = min(coarse.covered_through, half.covered_through)
        if common_end <= max(coarse.fork, half.fork):
            continue
        coarse_actions = [time for time in coarse.action_times if time <= common_end]
        half_actions = [time for time in half.action_times if time <= common_end]
        coarse_events = [row for row in coarse.events if ticks(row["elapsed_total"]) <= common_end]
        half_events = [row for row in half.events if ticks(row["elapsed_total"]) <= common_end]
        coarse_times = [ticks(row["elapsed_total"]) for row in coarse_events]
        half_times = [ticks(row["elapsed_total"]) for row in half_events]
        paired = list(zip(coarse_actions, half_actions))
        first = next((i for i, (left, right) in enumerate(paired) if left != right), None)
        if first is None and len(coarse_actions) != len(half_actions):
            first = len(paired)
        c_first = coarse_actions[first] / CLOCK if first is not None and first < len(coarse_actions) else ""
        h_first = half_actions[first] / CLOCK if first is not None and first < len(half_actions) else ""
        c_changes, h_changes = ([entry for entry in changes[key] if entry[0] <= common_end] for key in (coarse_key, half_key))
        flag_pairs = [(left, right) for left, right in zip(flags[coarse_key], flags[half_key])
                      if max(left[0], right[0]) <= common_end]
        first_flag = next(((left, right) for left, right in flag_pairs if left != right), None)
        reconnect = [
            [when for when in source.reconnection_times if when <= common_end] for source in (coarse, half)
        ]
        c_work, h_work = coarse.work[len(coarse_times)], half.work[len(half_times)]
        result.append({
            "group": group, "origin": origin, "policy": policy,
            "compared_through": common_end / CLOCK,
            "coarse_fork_elapsed": coarse.fork / CLOCK, "half_fork_elapsed": half.fork / CLOCK,
            "coarse_switches": " ".join(f"{when / CLOCK:g}/{mode}" for when, mode in c_changes),
            "half_switches": " ".join(f"{when / CLOCK:g}/{mode}" for when, mode in h_changes),
            "same_switch_history": c_changes == h_changes,
            "coarse_attempts": len(coarse_events), "half_attempts": len(half_events),
            "matching_attempt_clocks": sum(left == right for left, right in zip(coarse_times, half_times)),
            "accepted_flag_mismatches": sum(accepted(left) != accepted(right) for left, right in zip(coarse_events, half_events)),
            "first_different_control_flag_coarse": first_flag[0][0] / CLOCK if first_flag else "",
            "first_different_control_flag_half": first_flag[1][0] / CLOCK if first_flag else "",
            "coarse_reconnection_count": len(reconnect[0]), "half_reconnection_count": len(reconnect[1]),
            "matching_reconnection_clocks": sum(left == right for left, right in zip(*reconnect)),
            "coarse_count": len(coarse_actions), "half_count": len(half_actions),
            "matching_extraction_clocks": sum(left == right for left, right in paired),
            "max_extraction_clock_difference": max((abs(left - right) for left, right in paired), default=0) / CLOCK,
            "first_extraction_clock_mismatch": first + 1 if first is not None else "",
            "first_different_coarse_elapsed": c_first, "first_different_half_elapsed": h_first,
            "wait_length_mismatches": sum(ticks(left["tau"]) != ticks(right["tau"]) for left, right in zip(coarse_events, half_events)),
            "coarse_final_work": c_work, "half_final_work": h_work,
            "half_minus_coarse_net": h_work - c_work,
        })
    return result


def ablation_summary(endpoints, timelines):
    lookup = {lane(row): row for row in endpoints if row["terminal_checkpoint"]}
    summary = []
    for key, row in lookup.items():
        if row["policy"] not in ABLATIONS:
            continue
        group, origin, _, precision = key
        baseline_key = group, origin, "RP", precision
        base = lookup.get(baseline_key)
        if base:
            fields = ("elapsed_start", "elapsed_total", "tau")
            schedules = [
                [(*(ticks(event[field]) for field in fields), accepted(event)) for event in timelines[label].events]
                for label in (baseline_key, key)
            ]
            common = list(zip(*schedules))
            mismatches = [i for i, (left, right) in enumerate(common, 1) if left != right]
            unpaired = abs(len(schedules[0]) - len(schedules[1]))
            first = mismatches[0] if mismatches else len(common) + 1 if unpaired else ""
            summary.append({
                **tags(key), "fork_elapsed": row["fork_elapsed"], "elapsed_total": row["elapsed_total"],
                "different_attempts_by_ordinal": len(mismatches) + unpaired,
                "first_different_attempt": first,
                "rp_cumulative_net": base["cumulative_net"], "cumulative_net": row["cumulative_net"],
                "delta_net_from_rp": row["cumulative_net"] - base["cumulative_net"],
                "delta_work_rate_from_rp": row["cumulative_rate"] - base["cumulative_rate"],
                "delta_wait_from_rp": row["cumulative_wait"] - base["cumulative_wait"],
                "delta_phase_observations_from_rp": row["phase_observations"] - base["phase_observations"],
                "e_oracle_fraction": row["e_oracle_fraction"],
            })
    return summary


def current_correlations(rows):
    grouped = defaultdict(list)
    for row in rows:
        if row.get("integrated_current") not in (None, "") and row.get("net_work") not in (None, ""):
            grouped[lane(row)].append(row)
    summaries = []
    for key, group in grouped.items():
        work = [float(row["net_work"]) for row in group]
        current = [float(row["integrated_current"]) for row in group]
        coefficient = correlation(current, work) if len(set(current)) > 1 and len(set(work)) > 1 else ""
        instantaneous = [float(row["current_after"]) for row in group]
        instantaneous_corr = correlation(instantaneous, work) if len(set(instantaneous)) > 1 and len(set(work)) > 1 else ""
        reconnect_inputs = [float(row["reconnect_on"]) for row in group]
        reconnect_corr = correlation(reconnect_inputs, work) if len(set(reconnect_inputs)) > 1 and len(set(work)) > 1 else ""
        positive_span = [float(row["positive_current_duration"]) for row in group]
        signs = [int(row["current_sign_changes"]) for row in group]
        summaries.append({**tags(key), "attempts": len(group), "integrated_current": fsum(current),
                          "net_work": fsum(work), "pearson_current_net": coefficient,
                          "pearson_initial_current_net": instantaneous_corr,
                          "pearson_reconnect_input_net": reconnect_corr,
                          "median_positive_current_duration": median(positive_span),
                          "sign_change_attempts": sum(bool(count) for count in signs)})
    return summaries


def expected_lanes():
    return [(group, origin, policy, step)
            for group, policies in (("main", MAIN), *((group, BRANCHES) for group in ANCHORS))
            for origin in ORIGINS for policy in policies for step in PRECISIONS]


def collect(stages, output, m27, cutoff):
    old_history, old_decisions, old_checkpoints = archive_old_f2(m27)
    history = [{**row, "ledger_source": "M28 formal"} for row in merge(stages, "m28_history.csv")]
    decisions = [row for row in [*old_decisions, *merge(stages, "m28_decisions.csv")]
                 if ticks(row["elapsed_total"]) <= cutoff]
    checkpoints = [*old_checkpoints, *merge(stages, "m28_checkpoints.csv")]
    groups = defaultdict(list)
    for row in [*old_history, *history]:
        groups[lane(row)].append(row)
    final = {lane(row): row for row in checkpoints if ticks(row["elapsed_total"]) == cutoff}
    certified = defaultdict(int)
    for row in checkpoints:
        key = lane(row)
        certified[key] = max(certified[key], ticks(row["elapsed_total"]))
    for key in final:
        groups.setdefault(key, [])
    timelines = {key: Timeline(rows, final.get(key, {}), cutoff, certified[key]) for key, rows in groups.items()}
    fork_times = defaultdict(set)
    for (group, origin, _, precision), timeline in timelines.items():
        fork_times[group, origin, precision].add(timeline.fork)
    if any(len(choices) > 1 for choices in fork_times.values()):
        raise ValueError("Branches in a matched group have different fork clocks")
    comparison_rows, endpoints, late = comparison(timelines, cutoff)
    output.mkdir(parents=True, exist_ok=True)
    core = ("group", "origin", "policy", "precision")
    current_rows = [row for row in merge(stages, "m28_current.csv") if ticks(row["elapsed_total"]) <= cutoff]
    for name, rows in (
        ("history", [row for timeline in timelines.values() for row in timeline.events]),
        ("decisions", decisions), ("checkpoints", checkpoints), ("time_comparison", comparison_rows),
        ("main_differences", main_differences(comparison_rows)),
        ("endpoints", endpoints), ("late_work", late), ("phase_gain", phase_gains(endpoints)),
        ("ablation_summary", ablation_summary(endpoints, timelines)),
        ("chronology", chronology(timelines, decisions)), ("current", current_rows),
        ("current_summary", current_correlations(current_rows)),
        ("coverage", [{**tags(key), "recorded": key in groups, "terminal_checkpoint": key in final,
                       "target_elapsed": cutoff / CLOCK} for key in expected_lanes()]),
    ):
        fields = {
            "phase_gain": ("group", "origin", "precision"),
            "chronology": ("group", "origin", "policy"),
            "main_differences": ("origin", "precision", "elapsed_total"),
        }.get(name, core)
        write_csv(output / f"m28_{name}.csv", rows, fields=fields)
    for name in ("waits", "wait_checks", "observations"):
        filename = f"m28_{name}.csv"
        stream_artifact(stages, filename, output / filename)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stages", type=Path, default=ROOT / "stages")
    parser.add_argument("--output", type=Path, default=ROOT / "results")
    parser.add_argument("--m27", type=Path, default=M27 / "results")
    parser.add_argument("--horizon", type=int, default=COMMON[-1])
    args = parser.parse_args()
    if not 0 < args.horizon <= COMMON[-1]:
        parser.error("Horizon must be between 1 and 540.")
    collect(args.stages, args.output, args.m27, args.horizon * CLOCK)


if __name__ == "__main__":
    main()
