# M28 再現手順

M28は、M27を引き継ぐ適応F2-Rの数値頑健性と、同じ分岐状態からの待機規則の違いを検証する。評価と登録条件は [正式報告書](MILESTONE_28_NUMERICAL_ROBUSTNESS_AND_PHASE_REPORT.md) と [事前固定プロトコル](PROTOCOL_M28.md) に記載した。

## 環境と入力

Windows PowerShell、Python 3.14、NumPy 2.5.5、Matplotlib 3.10.9。M27とその依存マイルストーンを配布時と同じ相対位置に置く。初期密度とハッシュは `../Milestone_26/results/m26_sources.csv`、F1の分岐に使う初回切替の状態は `../Milestone_27/stages/` にある。M27の旧F2は監査済み台帳を参照する。BLASは各ワーカー1スレッドで実行した。

```powershell
py -3.14 -m pip install 'numpy==2.5.5' 'matplotlib==3.10.9'
Set-Location Milestone_28
$env:OPENBLAS_NUM_THREADS = '1'
```

## 短縮計算と正式計算

短縮計算は経過100・120を保存点とし、計画上の期限を540に保つ。経過120までの連続計算と逐次射影による比較も再現できる。正式計算は150・300・540を保存する。`--workers` は使用可能なCPUとメモリに合わせる。Eの候補探索はワーカー当たりのメモリ使用量が大きい。

```powershell
py -3.14 -B run_m28.py main --stages redo/benchmark/stages --origins S0 --cutoffs 100 120 --workers 2
py -3.14 -B run_m28.py main --stages redo/benchmark/uninterrupted --origins S0 --cutoffs 120 --workers 2
py -3.14 -B run_m28.py main --stages redo/benchmark/reference_projector --origins S0 --cutoffs 120 --workers 2 --reference-projector
py -3.14 -B run_m28.py anchors --stages redo/benchmark/stages --anchors redo/benchmark/anchors --origins S0
py -3.14 -B run_m28.py matched --stages redo/benchmark/stages --anchors redo/benchmark/anchors --origins S0 --groups F2-R --cutoffs 100 120 --workers 4
py -3.14 -B run_m28_oracle.py --benchmark --stages redo/benchmark/stages --anchors redo/benchmark/anchors --cutoffs 100 120 --workers 2
py -3.14 -B verify_m28.py redo/benchmark/stages --origins S0 --cutoffs 100 120 --oneshot redo/benchmark/uninterrupted --reference-projector redo/benchmark/reference_projector --output redo/benchmark/audit_main.json
py -3.14 -B verify_m28.py redo/benchmark/stages --matched-only --anchors redo/benchmark/anchors --groups F2-R --origins S0 --cutoffs 100 120 --output redo/benchmark/audit_matched.json
py -3.14 -B run_m28.py main --stages redo/stages --workers 6
py -3.14 -B run_m28.py anchors --stages redo/stages --anchors redo/anchors
py -3.14 -B run_m28.py matched --stages redo/stages --anchors redo/anchors --groups F2-R --workers 6
py -3.14 -B reuse_m28_f1_history.py --stages redo/stages --anchors redo/anchors
py -3.14 -B run_m28.py matched --stages redo/stages --anchors redo/anchors --groups F1 --workers 6
py -3.14 -B run_m28_oracle.py --stages redo/stages --anchors redo/anchors --workers 3
py -3.14 -B run_m28_ablations.py --stages redo/stages --anchors redo/anchors --workers 2
py -3.14 -B analyze_m28_robustness.py --stages redo/stages --output redo/results --exploration redo/exploration
py -3.14 -B verify_m28.py redo/stages --sensitivity --workers 4 --output redo/results/audit_primary.json
py -3.14 -B verify_m28.py redo/stages --matched-only --anchors redo/anchors --policies R0 R1 R3 R6 RH RP --workers 4 --output redo/results/audit_matched.json
py -3.14 -B verify_m28.py redo/stages --matched-only --anchors redo/anchors --policies E --workers 3 --output redo/results/audit_oracle.json
py -3.14 -B verify_m28.py redo/stages --matched-only --anchors redo/anchors --groups F2-R --precisions coarse --policies Xphase Xamp Xcurrent Xinput --workers 3 --output redo/results/audit_ablations.json
py -3.14 -B collect_m28.py --stages redo/stages --output redo/results
py -3.14 -B plot_m28.py --data redo/results --output redo/figures
```

各段階は枝ごとに完了したとき保存する。同じ出力先に同じ条件で再実行すると、確定済みの段階を読み込み、保存境界の状態と予定を照合して次に進む。`anchor_coarse` と `anchor_half` は最後の完了試行直後、`coarse` と `half` はその保存境界の密度。`records` は分岐前に完了した試行と枝でその後完了した試行、`pending` は保存時までに確定した試行の再接続・抽出予定を含む。`anchors/` の密度は分岐前の主方式の確定台帳とハッシュで照合する。

分岐時刻、密度の両刻み、分岐前に完了した記録が完全一致する場合は、同じ方式の計算を再利用できる。該当する段階には `equivalent_anchor.json` を保存する。F1アンカーのRHはM27のF1が同じ時刻に待機へ移った後と同じ制御であり、監査済みの操作と観測を分岐からの台帳に再計上できる。該当する段階には `archived_wait_tail.json` を保存する。待機条件の除去で全判定が一致した枝は、該当する制御ログを照合して同じ操作系列を再利用できる。

## データの読み方

| 場所 | 内容 |
| --- | --- |
| `results/m28_time_comparison.csv`、`m28_endpoints.csv`、`m28_late_work.csv` | 旧F2、F2-R、同一状態分岐の共通時刻・終点・後半の比較 |
| `results/m28_sensitivity.csv`、`m28_perturbations.csv` | 増加率下限4水準、物理状態を変化させない符号判定の微小摂動 |
| `results/m28_step_chronology.csv`、`m28_step_states.csv` | 旧F2対F2-Rの精度別判断差と、8時刻の独立・時刻を揃えた状態距離 |
| `results/m28_phase_gain.csv`、`m28_ablation_summary.csv` | 位相規則の差分利得、観測数、許容追加観測コスト、単一条件除去の成績 |
| `stages/t*/.../m28_history.csv` | 全試行、正味仕事、切替入力、採否、状態のハッシュと状態量、使用位相観測数。Eには事後候補探索の証跡も含む |
| `stages/t*/.../m28_decisions.csv`、`m28_waits.csv`、`m28_wait_checks.csv` | 制御判定、切断・再接続での位相・電流、将来を参照せず消費した観測点 |
| `stages/t*/.../m28_observations.csv`、`m28_current.csv` | 接続格子の局所量、事後の電流積分・正電流時間・反転時刻と仕事 |
| `anchors/`、`stages/` | 分岐状態と由来、正式計算の全チェックポイントとログ |
| `benchmark/audit_*.json`、`results/audit_*.json` | 独立監査による判定時刻、状態・会計・境界の照合 |
| `experiment_manifest.json` | 物理・数値条件、登録条件と実行コードのハッシュ、入力の由来と保存数 |
| `figures/` | 主比較と感度・位相・電流の図 |

時刻は起点からのモデル経過。`fork_elapsed` から後の仕事だけを枝の累積に加える。`cut_on`、`reconnect_on` は系への正の入力、`net_work` は系からの正の回収。`pending_switch_net` は共通時刻で既に実行した切断・再接続のうち、試行の完了に伴う台帳計上を待つ量を示す。`coarse`／`half` は主刻み、`aligned` は同じ操作時刻を使った別刻みを示す。`used_by_control` は待機中のコヒーレンス観測のうち再接続判定に実際に用いたものを示す。
