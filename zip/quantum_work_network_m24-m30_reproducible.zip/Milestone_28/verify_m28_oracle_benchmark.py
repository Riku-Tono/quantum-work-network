"""Audit the reduced E projection against its recorded reference and exact dynamics."""

import argparse
import json
import os
from pathlib import Path
from statistics import median

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import numpy as np

from verify_m28 import ROOT, archived_origins, audit27, audit_matched_job, audited_anchor, folders_at, insist, table_m28


def candidate_key(row):
    return row["stage"], row["tau_tick"], row["connected_index"], row["candidate_count"]


def compare_trials(before, after, context):
    for field in ("elapsed_start", "elapsed_total", "tau", "elapsed_connected", "accepted", "net_work", "net_work_aligned",
                  "start_coarse_sha256", "start_half_sha256", "post_coarse_sha256", "post_half_sha256", "oracle_centers_json"):
        insist(before[field] == after[field], f"E benchmark work, physical handoff or clock differs at {context}/{field}")
    initial = json.loads(before["oracle_search_json"])
    reduced = json.loads(after["oracle_search_json"])
    insist(list(map(candidate_key, initial)) == list(map(candidate_key, reduced)), f"E wait grid or per-wait maximum differs at {context}")
    errors = [abs(left["max_net"] - right["max_net"]) for left, right in zip(initial, reduced, strict=True)]
    error = max(errors)
    for row in (before, after):
        insist(float(row["oracle_reference_seconds"]) > 0 and float(row["oracle_reference_max_error"]) <= 1e-14,
               f"E attempt was not checked against its sequential reference projection at {context}")
    insist(error <= 1e-14, f"E candidate work moved by {error:g} at {context}")
    return error, len(initial)


def verify(benchmark):
    full = benchmark / "stages"
    reduced = benchmark / "oracle_reduced"
    anchors = benchmark / "anchors"
    protocol = audit27.sha256(ROOT / "PROTOCOL_M28.md")
    for folder in (full, reduced):
        insist((folder / "protocol.sha256").read_text().strip() == protocol, "Incompatible E benchmark protocol digest")
    registry = audit27.read_unique(audit27.read_rows(anchors / "m28_anchors.csv"),
                                  lambda row: (row["group"], row["origin"], row["precision"]))
    sources, _ = archived_origins()
    result = {}
    cutoffs = (100_000, 120_000)
    for precision in audit27.RESOLUTIONS:
        anchor, _, _ = audited_anchor(full, anchors, registry, sources, "F2-R", "S0", precision)
        first = folders_at(full, "F2-R", ("S0", "E", precision), cutoffs)
        second = folders_at(reduced, "F2-R", ("S0", "E", precision), cutoffs)
        error = 0.0
        counts = []
        timing = []
        for tick in cutoffs:
            with np.load(first[tick] / "checkpoint.npz", allow_pickle=False) as original, np.load(
                    second[tick] / "checkpoint.npz", allow_pickle=False) as optimized:
                insist(set(original.files) == set(optimized.files) and all(
                    np.array_equal(value, optimized[name]) for name, value in original.items()),
                    f"E restart checkpoint differs at {precision}/{tick}")
            old = table_m28(first[tick] / "m28_history.csv")
            now = table_m28(second[tick] / "m28_history.csv")
            for before, after in zip(old, now, strict=True):
                measured, count = compare_trials(before, after, (precision, tick, after["attempt"]))
                counts.append(count)
                error = max(error, measured)
                timing.append([float(after[field]) for field in ("oracle_search_seconds", "oracle_reference_seconds")])
        tags = "F2-R", "S0", "E", precision
        hashes = {name: anchor[f"{name}_sha256"] for name in audit27.RESOLUTIONS}
        result[precision] = {"committed_attempts": len(counts), "wait_maxima_checked": sum(counts),
                             "candidate_work_max_difference": error, "identical_checkpoints": list(cutoffs),
                             "search_seconds": timing,
                             "warm_median_compact_seconds": median(row[0] for row in timing[1:]),
                             "warm_median_sequential_seconds": median(row[1] for row in timing[1:]),
                             "independent_replay": audit_matched_job(tags, second, anchors / anchor["anchor_file"],
                                                                     float(anchor["source_time"]), hashes)}
    return {"protocol_sha256": protocol, "origin": "S0", "anchor_group": "F2-R", "policy": "E", "steps": result}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--benchmark", type=Path, default=ROOT / "benchmark")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    audit = verify(args.benchmark)
    output = args.output or args.benchmark / "audit_oracle_reduced.json"
    output.write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")
    print(f"Verified E reference candidate work, event clocks, restart and independent physical replay: {output}")


if __name__ == "__main__":
    main()
