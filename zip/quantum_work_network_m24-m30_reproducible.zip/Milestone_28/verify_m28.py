"""Independently verify M28's passivation and control histories."""

import argparse
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor
from functools import partial
import json
import math
from pathlib import Path
import sys
from unittest.mock import patch


ROOT = Path(__file__).resolve().parent
M27 = ROOT.parent / "Milestone_27"
sys.path.insert(0, str(M27))

import verify_m27 as audit27

from verify_m27 import G, LOAD_LEVELS, ReplayModel, State, insist, np, reduced_load, terminal_state, tolerance


POLICY = "F2-R"
RATE_FLOOR = 1e-12
FLOORS = (0.0, 1e-14, RATE_FLOOR, 1e-10)
PRIMARY_CUTOFFS = (150_000, 300_000, 540_000)
MATCHED = ("R0", "R1", "R3", "R6", "RH", "RP", "E")
FIXED_WAIT = {"R0": 0, "R1": 1000, "R3": 3000, "R6": 6000}
ABLATIONS = {"Xphase": "phase", "Xamp": "amplitude", "Xcurrent": "current", "Xinput": "input"}
READ_CSV = audit27.read_rows
M27_GATE = audit27.gate_at


def registered_path(path):
    """Map unchanged M27 audit table schemas onto the M28 filenames."""
    return path.with_name(path.name.replace("m27_", "m28_", 1)) if path.name.startswith("m27_") else path


def read_m28_csv(path):
    return READ_CSV(registered_path(path))


def table_m28(path):
    mapped = registered_path(path)
    return READ_CSV(mapped) if mapped.is_file() else []


def robust_gate(decision, previous, accepted, floor=RATE_FLOOR):
    # Only the sign test in the supplying clause changes from the audited M27 gate.
    _, old_supply, rotated, micro = M27_GATE(decision, previous, accepted)
    supply = old_supply and audit27.number(decision, "load_ergotropy_rate") > floor
    admissible = audit27.number(decision, "c_abs") >= audit27.PHASE_AMPLITUDE and audit27.number(decision, "load_ergotropy") <= 1e-8
    return admissible and (supply or rotated or micro), supply, rotated, micro


def folders_at(root, group, key, boundaries):
    return {tick: root.joinpath(f"t{tick // 1000}", group, *key) for tick in boundaries}


def primary_job(key, source, folders, control_history, oneshot, rate_floor):
    with (patch.object(audit27, "read_rows", read_m28_csv), patch.object(audit27, "table", table_m28),
          patch.object(audit27, "gate_at", partial(robust_gate, floor=rate_floor))):
        result = audit27.audit_job(key, source, folders, control_history, None)
        if oneshot:
            # The M27 comparator expects its input root to put the origin immediately after the boundary.
            compare_oneshot(folders, oneshot)
    timeline = []
    for folder in folders.values():
        histories, decisions, waits, checks, observations, currents = stage_tables(folder)
        timeline.extend(histories)
        for row in histories:
            attempt = int(row["attempt"])
            decision = decisions[attempt]
            insist(all(entry["group"] == "main" and audit27.ticks(entry, "fork_elapsed") == 0
                       for entry in (row, decision, currents[attempt])), f"Incorrect primary provenance at {folder}/{attempt}")
            raw, gated = (audit27.number(decision, name) for name in ("load_ergotropy_rate", "load_ergotropy_rate_for_gate"))
            insist(audit27.number(decision, "rate_floor") == rate_floor, f"Unexpected primary rate floor at {folder}/{attempt}")
            insist(gated == (0.0 if 0 < raw <= rate_floor else raw), f"Primary gated derivative differs at {folder}/{attempt}")
            phase_used = row["mode"] == "wait"
            audit_current(currents[attempt], row, observations[attempt], checks[attempt], phase_used, (key, attempt))
    result[2]["max_common_state_error"] = audit_primary_probes(audit27.AUDIT_MODEL, source, folders, timeline)
    return result


def compare_oneshot(folders, direct):
    """Use only completed rows and exact final checkpoint values for staged comparison."""
    tables = ("history", "decisions", "observations", "wait_checks", "waits", "current")
    for name in tables:
        source = f"m28_{name}.csv"
        staged = [row for folder in folders.values() for row in table_m28(folder / source)]
        insist(staged == table_m28(direct / source), f"Uninterrupted and staged {source} differ at {direct}")
    final_folder = next(reversed(folders.values()))
    archive_pairs = [(final_folder / "checkpoint.npz", direct / "checkpoint.npz")]
    archive_pairs.extend((path, direct / path.name) for path in probe_paths(folders).values())
    for left, right in archive_pairs:
        with np.load(left, allow_pickle=False) as staged, np.load(right, allow_pickle=False) as uninterrupted:
            insist(staged.files == uninterrupted.files, f"Uninterrupted checkpoint keys differ at {direct}")
            for name in staged.files:
                insist(np.array_equal(staged[name], uninterrupted[name]), f"Uninterrupted checkpoint {name} differs at {direct}/{left.name}")


def compare_reference_projection(folders, reference):
    keys = {"history": ("elapsed_start", "elapsed_total", "tau", "decision_elapsed_total", "accepted", "net_work"),
            "decisions": ("elapsed_total", "observed_until", "mode_before", "mode_after", "phase_gate", "reason"),
            "wait_checks": ("elapsed_total", "phase_gate", "reconnect"),
            "observations": ("elapsed_total", "forecast_generated", "execute")}
    count = 0
    for name, columns in keys.items():
        ledger = f"m28_{name}.csv"
        main = [tuple(row[column] for column in columns) for folder in folders.values() for row in table_m28(folder / ledger)]
        direct = [tuple(row[column] for column in columns) for row in table_m28(reference / ledger)]
        insist(main == direct, f"Batched and sequential projection choices differ at {reference}/{name}")
        count += len(main)
    final = next(reversed(folders.values())) / "checkpoint.npz"
    with np.load(final, allow_pickle=False) as staged, np.load(reference / "checkpoint.npz", allow_pickle=False) as sequential:
        insist(all(np.array_equal(staged[name], sequential[name]) for name in ("coarse", "half", "work", "counters")),
               f"Batched and sequential projection final state differs at {reference}")
    return count


def archived_origins():
    source_dir = audit27.M26 / "results"
    sources = audit27.read_unique(READ_CSV(source_dir / "m26_sources.csv"), lambda row: row["origin"])
    a_histories = defaultdict(list)
    for row in READ_CSV(source_dir / "m26_history.csv"):
        if row["policy"] == "A":
            a_histories[row["origin"]].append(row)
    return sources, a_histories


def probe_paths(folders):
    observed = {}
    for folder in folders.values():
        for path in folder.glob("state_t*.npz"):
            tick = 1000 * int(path.stem[7:])
            insist(tick not in observed, f"Duplicate shared time {tick} under {folder}")
            observed[tick] = path
    expected = {1000 * time for time in audit27.COMMON if 1000 * time <= next(reversed(folders))}
    insist(set(observed) == expected, f"Missing or unexpected shared states: {set(observed) ^ expected}")
    return dict(sorted(observed.items()))


def audit_primary_probes(model, source, folders, timeline):
    probes = probe_paths(folders)
    needed = set(probes)
    clock = 0
    states = tuple(audit27.load_source(source, label) for label in audit27.RESOLUTIONS)
    expected = {}
    for row in timeline:
        start, tau, connected, end = (audit27.ticks(row, field) for field in ("elapsed_start", "tau", "elapsed_connected", "elapsed_total"))
        insist(clock == start, "Shared-time replay failed continuity")
        accepted = audit27.flag(row, "accepted")
        actions = tuple(audit27.exact_action(model, state, tau, connected, accepted) for state in states)
        for point in {tick for tick in needed if start <= tick < end}:
            outcomes = [audit27.action_snapshot(model, state, start, tau, connected, action, point)
                        for state, action in zip(states, actions, strict=True)]
            expected[point] = tuple(item[0] for item in outcomes), outcomes[0][1]
            needed.remove(point)
        states = tuple(action.after for action in actions)
        clock = end
    for tick in needed:
        if tick in folders:
            anchor = folders[tick] / "checkpoint.npz"
            with np.load(anchor, allow_pickle=False) as saved, np.load(probes[tick], allow_pickle=False) as shared:
                insist(float(saved["coupling"].item()) == float(shared["coupling"].item())
                       and all(np.array_equal(saved[label], shared[label]) for label in audit27.RESOLUTIONS),
                       f"Common state differs from independently audited checkpoint at {tick}")
        else:
            insist(tick >= clock, f"Missing action coverage at shared clock {tick}")
            expected[tick] = tuple(model.evolve(state, G, (tick - clock) / 1000) for state in states), G
    maximum = 0.0
    for tick, (pair, coupling) in expected.items():
        with np.load(probes[tick], allow_pickle=False) as saved:
            insist(int(saved["tick"].item()) == tick and float(saved["coupling"].item()) == coupling, f"Incorrect common coupling/clock at {tick}")
            for label, state in zip(audit27.RESOLUTIONS, pair, strict=True):
                matrix = saved[label]
                audit27.physical_state(State(matrix, state.time), (tick, label))
                difference = audit27.maxabs(matrix - state.matrix)
                tolerance(difference, 0.0, f"Independent shared-clock state at {tick}/{label}", audit27.HALF_TOL)
                maximum = max(maximum, difference)
    return maximum


def compare_probes(coarse, half):
    results = []
    half_paths = probe_paths(half)
    for tick, path in probe_paths(coarse).items():
        with np.load(path, allow_pickle=False) as left, np.load(half_paths[tick], allow_pickle=False) as right:
            results.append({"elapsed_total": tick / 1000,
                            "independent_trace_distance": audit27.trace_distance(left["coarse"], right["half"]),
                            "coarse_clock_aligned_trace_distance": audit27.trace_distance(left["coarse"], left["half"]),
                            "half_clock_aligned_trace_distance": audit27.trace_distance(right["half"], right["coarse"])})
    return results


def audit_primary(stages, boundaries, origins, precisions, workers, oneshot=None, *, rate_floor=RATE_FLOOR):
    sources, control_histories = archived_origins()
    keys = [(origin, POLICY, precision) for origin in origins for precision in precisions]
    folders = {key: folders_at(stages, "main", key, boundaries) for key in keys}
    uninterrupted = {}
    if oneshot:
        uninterrupted = {key: next(iter(folders_at(oneshot, "main", key, boundaries[-1:]).values())) for key in keys}
        uninterrupted = {key: folder for key, folder in uninterrupted.items() if folder.is_dir()}
        insist(uninterrupted, "An uninterrupted root was provided without any matching primary branch")
    args = {key: (key, sources[key[0]], folders[key], control_histories[key[0]], uninterrupted.get(key), rate_floor) for key in keys}
    if workers == 1:
        replays = {key: primary_job(*args[key]) for key in keys}
    else:
        with ProcessPoolExecutor(max_workers=workers) as pool:
            pending = {key: pool.submit(primary_job, *args[key]) for key in keys}
            replays = {key: pending[key].result() for key in keys}
    convergence = []
    for origin in origins:
        coarse = origin, POLICY, "coarse"
        half = origin, POLICY, "half"
        if coarse in replays and half in replays:
            item = audit27.convergence(origin, POLICY, replays[coarse], replays[half], folders[coarse], folders[half])
            item["common_state_distances"] = compare_probes(folders[coarse], folders[half])
            convergence.append(item)
    branch_results = {"/".join(key): replay[2] for key, replay in replays.items()}
    return {"rate_floor": rate_floor, "branch_results": branch_results, "totals": totals_for(branch_results.values()), "convergence": convergence,
            "one_shot_branches": ["/".join(key) for key in uninterrupted]}, folders


def first_switch_from_prefix(folders, floor, *, prefix, collect_perturbations=False):
    """Recompute the first switch from executed A events, stopping if the prefix breaks."""
    accepted = []
    previous = None
    baseline = None
    low_since = None
    low_count = 0
    perturbations = []
    for folder in folders.values():
        history = {int(row["attempt"]): row for row in READ_CSV(folder / f"{prefix}_history.csv")}
        for row in READ_CSV(folder / f"{prefix}_decisions.csv"):
            if row["mode_before"] != "forecast":
                break
            now = audit27.ticks(row, "elapsed_total")
            insist(audit27.ticks(row, "observed_until") == now and all(t <= now for t, _ in accepted),
                   "Sensitivity replay received future observations")
            if now >= audit27.BASELINE_END and baseline is None:
                baseline = math.fsum(w for t, w in accepted if t <= audit27.BASELINE_END) / 32
            moving = math.fsum(w for t, w in accepted if now - audit27.RATE_SPAN < t <= now) / 24
            if baseline is not None and baseline > 0 and now >= audit27.FIRST_SWITCH_TEST and moving <= .45 * baseline:
                low_since = now if low_since is None else low_since
                low_count += 1
            else:
                low_since, low_count = None, 0
            gate, _, _, _ = robust_gate(row, previous, accepted, floor)
            low_persistent = low_count >= 2 and now - low_since >= audit27.PERSISTENCE
            if collect_perturbations:
                rate = audit27.number(row, "load_ergotropy_rate")
                for delta in (-1e-12, -1e-14, 1e-14, 1e-12):
                    perturbed = {**row, "load_ergotropy_rate": str(rate + delta)}
                    altered, supplied, _, _ = robust_gate(perturbed, previous, accepted, floor)
                    perturbations.append({"elapsed_total": now / 1000, "rate": rate, "perturbation": delta,
                                          "observed_until": now / 1000, "low_persistent": low_persistent,
                                          "original_switch": bool(low_persistent and gate),
                                          "perturbed_switch": bool(low_persistent and altered), "perturbed_supplying": supplied})
            if low_persistent and gate:
                return now, perturbations
            if audit27.flag(row, "switched"):
                raise ValueError(f"Floor {floor:g} diverges at {now / 1000}; its unobserved trajectory requires independent simulation")
            completed = history[int(row["attempt"])]
            insist(audit27.ticks(completed, "elapsed_start") == now and audit27.ticks(completed, "tau") == 0,
                   "Sensitivity replay used a non-A action before the first switch")
            if audit27.flag(completed, "accepted"):
                accepted.append((audit27.ticks(completed, "elapsed_total"), audit27.number(completed, "net_work")))
            previous = row
    return None, perturbations


def audit_floor_sensitivity(primary, folders, boundaries):
    """Re-use native work only where a causal replay proves the same controller actions."""
    baseline = json.loads((M27 / "results" / "audit.json").read_text(encoding="utf-8"))
    results, perturbation_rows = [], []
    for key, stage_paths in folders.items():
        origin, _, precision = key
        label = "/".join(key)
        from_primary = primary["branch_results"][label]
        for floor in FLOORS:
            if floor == 0:
                old_key = origin, "F2", precision
                source_paths = audit27.branch_folders(M27 / "stages", old_key, boundaries)
                source = baseline["branch_results"]["/".join(old_key)]
                provenance = "M27 F2 independently audited zero-floor history"
                prefix = "m27"
            else:
                source_paths = stage_paths
                source = from_primary
                provenance = "F2-R identical causal choices through the first switch; one-way continuation is floor-independent"
                prefix = "m28"
            observed, perturbations = first_switch_from_prefix(source_paths, floor, prefix=prefix, collect_perturbations=True)
            switches = source["switches"]
            expected = round(switches[0]["time"] * 1000) if switches else None
            insist(observed == expected, f"Floor {floor:g} changes the first switch for {label}; reuse is invalid")
            insist(len(switches) <= 1, f"Sensitivity reused a controller with multiple switches at {label}")
            results.append({"origin": origin, "precision": precision, "threshold": floor,
                            "first_switch_time": observed / 1000 if observed is not None else None,
                            "cumulative_net_540": source["cumulative_net"], "extractions_540": source["accepted"],
                            "provenance": provenance})
            perturbation_rows.extend({"origin": origin, "precision": precision, "threshold": floor, **record}
                                     for record in perturbations)
    return results, perturbation_rows


def stage_tables(folder):
    history = table_m28(folder / "m28_history.csv")
    decisions = audit27.read_unique(table_m28(folder / "m28_decisions.csv"), lambda row: int(row["attempt"]))
    waits = audit27.read_unique(table_m28(folder / "m28_waits.csv"), lambda row: int(row["attempt"]))
    checks = audit27.group_attempt(table_m28(folder / "m28_wait_checks.csv"))
    observations = audit27.group_attempt(table_m28(folder / "m28_observations.csv"))
    currents = audit27.read_unique(table_m28(folder / "m28_current.csv"), lambda row: int(row["attempt"]))
    attempts = {int(row["attempt"]) for row in history}
    insist(attempts == set(decisions) == set(observations) == set(currents) and set(checks) <= attempts and set(waits) <= attempts,
           f"Unpaired observations in {folder}")
    return history, decisions, waits, checks, observations, currents


def audit_current(current, row, observations, checks, phase_used, context):
    """Recompute completed-window diagnostics without supplying them to a controller."""
    expected_phase_count = 1 + len(checks) if phase_used and audit27.ticks(row, "tau") > 0 else 0
    for record in checks:
        insist(audit27.flag(record, "used_by_control") == bool(expected_phase_count), f"Incorrect phase-use label at {context}")
    insist(int(current["phase_observations"]) == int(row["phase_observations"]) == expected_phase_count,
           f"Reported phase query count at {context}")
    insist(int(row["initial_phase_observations"]) == bool(expected_phase_count)
           and int(row["wait_phase_observations"]) == max(0, expected_phase_count - 1), f"Phase query count by stage at {context}")
    for name in ("elapsed_start", "elapsed_total", "tau", "accepted", "current_after", "cut_on", "reconnect_on", "net_work"):
        insist(current[name] == row[name], f"Current diagnostic provenance {context}/{name}")
    clocks = [audit27.ticks(sample, "elapsed_total") for sample in observations]
    currents = [audit27.number(sample, "load_current") for sample in observations]
    erg = [audit27.number(sample, "load_ergotropy") for sample in observations]
    chunks = [(b - a) / 1000 for a, b in zip(clocks[:-1], clocks[1:], strict=True)]
    insist(int(current["connected_sample_count"]) == len(clocks) and all(span == .02 for span in chunks),
           f"Current diagnostic uses different sample clocks at {context}")
    insist(clocks[0] == audit27.ticks(row, "reconnect_elapsed") and clocks[-1] == audit27.ticks(row, "elapsed_total"),
           f"Current diagnostic clocks exceed executed connected window at {context}")
    trapezoid = math.fsum(dt * (left + right) / 2 for dt, left, right in zip(chunks, currents[:-1], currents[1:], strict=True))
    positive = []
    for dt, left, right in zip(chunks, currents[:-1], currents[1:], strict=True):
        hi, low = max(left, right), min(left, right)
        positive.append(dt * (1 if low >= 0 else hi / (hi - low)) if hi > 0 else 0.0)
    nonzero = [(clock / 1000, value) for clock, value in zip(clocks, currents, strict=True) if value]
    flips = [(a_time * abs(b) + b_time * abs(a)) / (abs(a) + abs(b))
             for (a_time, a), (b_time, b) in zip(nonzero[:-1], nonzero[1:], strict=True) if a * b < 0]
    expected = {"integrated_current": trapezoid, "positive_current_duration": math.fsum(positive),
                "load_ergotropy_start": erg[0], "load_ergotropy_max": max(erg), "load_ergotropy_end": erg[-1]}
    for name, value in expected.items():
        tolerance(audit27.number(current, name), value, f"Executed-window {name} at {context}", 2e-13)
    insist(int(current["current_sign_changes"]) == len(flips), f"Current sign-change count at {context}")
    stored = [float(item) for item in current["current_sign_change_times"].split("|") if item]
    insist(len(stored) == len(flips), f"Current sign-change clock count at {context}")
    for actual, expected in zip(stored, flips, strict=True):
        tolerance(actual, expected, f"Rounded current sign-change clock at {context}", 5e-9)
    if flips:
        tolerance(audit27.number(current, "first_current_sign_change"), flips[0], f"First current crossing at {context}", 1e-12)
    else:
        insist(not current["first_current_sign_change"], f"Spurious current crossing at {context}")


def phase_components(initial, current):
    return {
        "phase": audit27.phase_band(audit27.phase_value(current)),
        "amplitude": audit27.number(current, "c_abs") >= 1e-5,
        "current": audit27.number(current, "load_current") >= .25 * (2 * G) * audit27.number(initial, "c_abs"),
        "input": audit27.number(current, "c_real") <= audit27.number(initial, "c_real") + 1e-10,
    }


def audit_wait_choice(model, row, checks, anchor, context):
    start, window, tau = (audit27.ticks(row, field) for field in ("elapsed_start", "window", "tau"))
    policy = row["policy"]
    phase_control = policy == "RP" or policy in ABLATIONS
    limit = min(6000, window - audit27.GRID) // 200 * 200
    if phase_control and limit >= 1000:
        insist(1000 <= tau <= limit, f"Phase branch missed an available detached observation at {context}")
    if not tau:
        insist(not checks, f"A no-wait execution owns detached samples at {context}")
        return
    first = 1000 if phase_control else 200
    witness_delays = list(range(first, tau + 1, 200))
    insist(len(checks) == len(witness_delays), f"Missing or extra detached prefix at {context}")
    start_c = complex(model.detached_c(anchor, 0))
    # The policy uses the logged register precision, not values from the independent unitary statics.
    initial = {"c_abs": row["c_abs_before"], "c_real": str(-audit27.number(row, "cut_on") / (2 * G))}
    tolerance(float(initial["c_abs"]), abs(start_c), f"Detached anchor coherence at {context}", audit27.HALF_TOL)
    tolerance(float(initial["c_real"]), start_c.real, f"Detached anchor real coherence at {context}", audit27.HALF_TOL)
    for i, (check, delay) in enumerate(zip(checks, witness_delays, strict=True)):
        now = start + delay
        insist(audit27.ticks(check, "elapsed_total") == audit27.ticks(check, "observed_until") == now
               and audit27.ticks(check, "wait_elapsed") == delay, f"Detached control reached a future observation at {context}")
        independent = complex(model.detached_c(anchor, delay))
        real, imag = (audit27.number(check, field) for field in ("c_real", "c_imag"))
        tolerance(real, independent.real, f"Detached coherence real witness at {context}/{delay}", audit27.HALF_TOL)
        tolerance(imag, independent.imag, f"Detached coherence imaginary witness at {context}/{delay}", audit27.HALF_TOL)
        tolerance(audit27.number(check, "load_current"), -2 * G * imag, f"Hypothetical reconnection current at {context}/{delay}", 1e-15)
        tolerance(audit27.number(check, "actual_current"), 0.0, f"Physical detached current at {context}/{delay}", 1e-15)
        tolerance(audit27.number(check, "c_abs"), math.hypot(real, imag), f"Detached coherence magnitude at {context}/{delay}", 1e-15)
        phase = audit27.number(check, "phase")
        tolerance(math.remainder(phase - math.atan2(imag, real), math.tau), 0.0, f"Detached phase at {context}/{delay}", 1e-12)
        conditions = phase_components(initial, check)
        allowed = phase_control and all(value for name, value in conditions.items() if name != ABLATIONS.get(policy))
        reached_limit = delay == (limit if phase_control else tau)
        reconnect = i == len(checks) - 1
        insist(audit27.flag(check, "phase_gate") == allowed and audit27.flag(check, "reconnect") == (allowed or reached_limit)
               and reconnect == (allowed or reached_limit), f"Wrong first reconnection clock at {context}/{delay}")


def compact(row):
    return {**{field: audit27.number(row, field) for field in ("elapsed_total", "duration", "tau", "net_work", "net_work_aligned")},
            "accepted": audit27.flag(row, "accepted")}


def audited_anchor(stages, anchors, registry, sources, group, origin, precision):
    key = group, origin, precision
    row = registry[key]
    path = anchors.joinpath(*key, "anchor.npz")
    insist((anchors / row["anchor_file"]).resolve() == path.resolve(), f"Anchor registry points elsewhere at {key}")
    source = sources[origin]
    tick = audit27.ticks(row, "fork_elapsed")
    source_time = audit27.number(source, "source_time")
    base = stages if group == POLICY else M27 / "stages"
    suffix = ("main", origin, group, precision) if group == POLICY else (origin, group, precision)
    folders = [folder.joinpath(*suffix) for folder in sorted((folder for folder in base.glob("t[0-9]*") if folder.is_dir()),
                                                            key=lambda folder: int(folder.name[1:]))]
    switches = sorted((item for folder in folders for item in folder.glob("switch_*.npz")), key=lambda item: int(item.stem.split("_")[1]))
    insist(switches and (ROOT / row["source_switch"]).resolve() == switches[0].resolve(), f"Wrong inherited first switch at {key}")
    prefix = "m28" if group == POLICY else "m27"
    history = [entry for folder in folders for entry in table_original(folder / f"{prefix}_history.csv")
               if audit27.ticks(entry, "elapsed_total") <= tick]
    expected_records = [compact(entry) for entry in history]
    insist(history and audit27.ticks(history[-1], "elapsed_total") == tick, f"Anchor lies outside executed history at {key}")
    with np.load(path, allow_pickle=False) as loaded, np.load(switches[0], allow_pickle=False) as reference:
        insist(int(loaded["tick"].item()) == int(reference["tick"].item()) == tick
               and float(loaded["source_time"].item()) == source_time == audit27.number(row, "source_time"),
               f"Anchor physical clock differs at {key}")
        records = json.loads(str(loaded["records"].item()))
        insist(records == expected_records and int(row["prefix_attempts"]) == len(records)
               and int(row["prefix_waits"]) == sum(entry["tau"] > 0 for entry in records), f"Wrong realized history at {key}")
        states = {}
        for label in audit27.RESOLUTIONS:
            matrix = loaded[label]
            digest = audit27.state_sha256(matrix)
            insist(digest == row[f"{label}_sha256"] == history[-1][f"post_{label}_sha256"]
                   and np.array_equal(matrix, reference[label]), f"Anchor matrix changed relative to source experiment at {key}/{label}")
            states[label] = State(matrix, source_time + tick / 1000)
            audit27.physical_state(states[label], (key, label))
    return row, states, records


def table_original(path):
    return READ_CSV(path) if path.is_file() else []


def audit_oracle(model, row, observations, states, action, context):
    start, window, selected_tau, selected_connected, end = (audit27.ticks(row, name) for name in
        ("elapsed_start", "window", "tau", "elapsed_connected", "elapsed_total"))
    insist(row["stop_reason"] == "retrospective" == row["mode"] and not row["decision_elapsed_total"],
           f"Retrospective search is labelled causal at {context}")
    candidates = json.loads(row["oracle_search_json"])
    insist(len(candidates) == int(row["oracle_wait_candidates"]) and all(item["stage"] in {"A", "C"} for item in candidates),
           f"Oracle search coverage at {context}")
    chosen, = [item for item in candidates if item["selected"]]
    winner = min(candidates, key=lambda item: (-item["max_net"], item["tau_tick"] + 20 * item["connected_index"], item["tau_tick"]))
    insist(chosen == winner and (chosen["tau_tick"], 20 * chosen["connected_index"]) == (selected_tau, selected_connected),
           f"Wrong maximizer, tie break, or operation clock at {context}")
    total = 0
    for candidate in candidates:
        tau = candidate["tau_tick"]
        first = int(tau == 0)
        last = (window - tau) // 20
        count = last - first + 1
        insist(first <= candidate["connected_index"] <= last and candidate["candidate_count"] == count > 0,
               f"Oracle connected grid is outside window at {context}/{tau}")
        total += count
    insist(total == int(row["oracle_candidates"]), f"Oracle projection count at {context}")
    coarse = [candidate for candidate in candidates if candidate["stage"] == "A"]
    insist([entry["tau_tick"] for entry in coarse] == list(range(0, min(6000, window) + 1, 250)), f"Wrong coarse grid at {context}")
    maxima = [entry for i, entry in enumerate(coarse)
              if (i == 0 or entry["max_net"] > coarse[i - 1]["max_net"])
              and (i + 1 == len(coarse) or entry["max_net"] >= coarse[i + 1]["max_net"])]
    centers = sorted(maxima, key=lambda item: (-item["max_net"], item["tau_tick"]))[:3]
    insist([entry["tau_tick"] for entry in centers] == json.loads(row["oracle_centers_json"]), f"Wrong refinement centers at {context}")
    refinements = [candidate["tau_tick"] for candidate in candidates if candidate["stage"] == "C"]
    extensions = any(tau > 6000 for tau in refinements)
    expected_refinements = set()
    for center in centers:
        tau = center["tau_tick"]
        bound = min(window, 6250 if tau == 6000 and extensions else 6000)
        expected_refinements.update(range(max(0, tau - 250), min(bound, tau + 250) + 1, 25))
    insist(refinements == sorted(expected_refinements), f"Wrong refined wait lattice at {context}")
    if extensions:
        insist(coarse[-1]["max_net"] - coarse[-2]["max_net"] > 1e-12 and 6000 in {item["tau_tick"] for item in centers},
               f"Refinement past the registered boundary has no gain witness at {context}")
    tolerance(chosen["max_net"], action.work, f"Independent oracle selected work at {context}")
    if candidates:
        # Check the nearest competing wait against full unitary dynamics independently.
        alternate = next((item for item in sorted(candidates, key=lambda item: -item["max_net"])
                          if (item["tau_tick"], item["connected_index"]) != (chosen["tau_tick"], chosen["connected_index"])), None)
        if alternate is not None:
            witness = audit27.exact_action(model, states[0], alternate["tau_tick"], 20 * alternate["connected_index"], True)
            tolerance(alternate["max_net"], witness.work, f"Independent competing oracle work at {context}")
    for i, sample in enumerate(observations):
        clock = start + selected_tau + 20 * i
        insist(int(sample["index"]) == i and audit27.ticks(sample, "elapsed_total") == audit27.ticks(sample, "observed_until") == clock
               and not audit27.flag(sample, "forecast_generated") and audit27.flag(sample, "execute") == (clock == end),
               f"Retrospective selected-prefix record at {context}/{i}")
    insist(len(observations) == selected_connected // 20 + 1, f"Oracle executed prefix has missing observations at {context}")
    for sample, state in ((observations[0], action.waited), (observations[-1], action.before)):
        audit27.verify_logged_observation(sample, audit27.observation(model, state), f"{context}/oracle measurement")


def pending_from_action(row, observations, checks, boundary):
    policy = row["policy"]
    if policy != "E":
        phase_control = policy == "RP" or policy in ABLATIONS
        return audit27.cross_boundary_pending(row if phase_control else {**row, "policy": "F1"}, observations, checks, boundary)
    start, tau, end = (audit27.ticks(row, field) for field in ("elapsed_start", "tau", "elapsed_total"))
    detached = boundary < start + tau
    observed = start if detached else start + tau + (boundary - start - tau) // 20 * 20
    return {"tau": tau, "forecast_tick": start, "execute_tick": end, "cut_applied": bool(tau),
            "reconnect_applied": bool(tau) and not detached, "last_observation_tick": observed,
            "switch_net": -audit27.number(row, "cut_on") - (0.0 if detached else audit27.number(row, "reconnect_on"))}


def verify_matched_boundary(model, row, folder, key, tick, fork, fingerprints, states, counters, work, records, expected):
    clock, count_attempts, count_accepted = counters
    labels = ordered_labels(key[-1])
    context = key, tick
    insist(audit27.ticks(row, "elapsed_total") == tick and audit27.ticks(row, "fork_elapsed") == fork
           and audit27.ticks(row, "anchor_elapsed") == clock and int(row["attempts"]) == count_attempts
           and int(row["count"]) == count_accepted, f"Boundary counters differ at {context}")
    expected_ending = ("time_cap" if clock == audit27.CAP else "time_cap_no_grid") if audit27.CAP - clock < 20 else "active"
    insist(row["ending"] == expected_ending, f"Boundary ended incorrectly at {context}")
    tolerance(row["boundary_physicality_error"], 0.0, f"Saved physicality at {context}")
    for name, value in zip(("cumulative_net", "cumulative_net_aligned", "cumulative_step_error_bound"), work, strict=True):
        tolerance(row[name], value, f"Checkpoint {name} at {context}")
    maximum_error = 0.0
    with np.load(folder / "checkpoint.npz", allow_pickle=False) as saved:
        insist(int(saved["tick"].item()) == tick and tuple(saved["counters"]) == counters
               and int(saved["fork_tick"].item()) == fork and str(saved["ending"].item()) == expected_ending,
               f"NPZ boundary signature mismatch at {context}")
        insist(json.loads(str(saved["records"].item())) == records, f"Checkpoint has unexecuted or missing history at {context}")
        for actual, expected_work in zip(saved["work"], work, strict=True):
            tolerance(actual, expected_work, f"NPZ ledger differs at {context}")
        actual_coupling = float(saved["coupling"].item())
        insist(actual_coupling == float(row["coupling"]) and str(saved["phase"].item()) == row["phase"], f"Boundary phase at {context}")
        condition = json.loads(str(saved["pending"].item()))
        if expected is not None:
            snapshots, coupling, pending = expected
            insist(actual_coupling == coupling, f"Independent phase at {context}")
            insist(condition.keys() == pending.keys(), f"Wrong pending controller evidence inventory at {context}")
            for name, value in pending.items():
                if name == "switch_net":
                    tolerance(condition[name], value, f"Pending switching work at {context}")
                else:
                    insist(condition[name] == value, f"Wrong pending {name} at {context}")
        else:
            # The benchmark end can be inside its final, uncommitted operation.
            tau = condition.get("tau") or 0
            if not actual_coupling:
                snapshots = tuple(model.evolve(state, 0.0, (tick - clock) / 1000) for state in states)
            else:
                insist(tick >= clock + tau, f"Boundary precedes registered reconnect at {context}")
                snapshots = tuple(model.evolve(model.evolve(state, 0.0, tau / 1000), G, (tick - clock - tau) / 1000) for state in states)
        if condition:
            observed = condition["last_observation_tick"]
            issued, execute = condition["forecast_tick"], condition["execute_tick"]
            insist(clock <= observed <= tick and (issued is None or clock <= issued <= observed <= tick < execute),
                   f"A saved control decision reads a future observation at {context}")
        else:
            insist(expected_ending != "active", f"Missing active checkpoint plan at {context}")
        for name in ("cut_applied", "reconnect_applied"):
            insist(audit27.flag(row, name) == condition.get(name, False), f"Summary pending {name} at {context}")
        for field, saved_name in (("pending_tau_tick", "tau"), ("forecast_tick", "forecast_tick"), ("execute_tick", "execute_tick"),
                                  ("last_observation_tick", "last_observation_tick")):
            insist((int(row[field]) if row[field] else None) == condition.get(saved_name), f"Summary pending {field} at {context}")
        tolerance(row["pending_switch_net"], condition.get("switch_net", 0), f"Checkpoint pending energy at {context}")
        tolerance(model.energy(snapshots[0], actual_coupling) + condition.get("switch_net", 0), model.energy(states[0]),
                  f"Boundary energy including pending operations at {context}")
        for label, exact_anchor, exact_state in zip(labels, states, snapshots, strict=True):
            insist(str(saved[f"fork_{label}_sha256"].item()) == row[f"fork_{label}_sha256"] == fingerprints[label],
                   f"A matched branch lost its shared seed at {context}/{label}")
            for prefix, name, exact in (("anchor", f"anchor_{label}", exact_anchor), ("boundary", label, exact_state)):
                matrix = saved[name]
                insist(audit27.state_sha256(matrix) == row[f"{prefix}_{label}_sha256"], f"State fingerprint differs at {context}/{name}")
                audit27.physical_state(State(matrix, exact.time), (context, name))
                error = audit27.maxabs(matrix - exact.matrix)
                tolerance(error, 0, f"Independent boundary density at {context}/{name}", audit27.HALF_TOL)
                maximum_error = max(maximum_error, error)
    return maximum_error


def ordered_labels(primary):
    return (primary, "coarse" if primary == "half" else "half")


def physics_statistics():
    return {"max_independent_work_error": 0.0, "max_energy_residual": 0.0, "max_trace_error": 0.0,
            "max_hermiticity_error": 0.0, "min_eigenvalue": 0.0, "max_post_ergotropy": 0.0,
            "max_candidate_step_error": 0.0}


def totals_for(branches):
    summaries = list(branches)
    totals = {"branches": len(summaries), "max_future_observation_lead_for_online_branches": 0.0}
    for name in ("attempts", "accepted", "rejected", "observations", "wait_checks", "connected_observations", "detached_observations",
                 "phase_observations", "boundary_count", "reused_equivalent_anchor_stages", "reused_ablation_stages", "reused_archived_wait_stages",
                 "oracle_candidate_projections", "oracle_wait_grid_entries"):
        if any(name in row for row in summaries):
            totals[name] = sum(row.get(name, 0) for row in summaries)
    for name in ("max_independent_work_error", "max_energy_residual", "max_trace_error", "max_hermiticity_error", "max_post_ergotropy",
                 "max_candidate_step_error", "max_boundary_state_error", "max_resume_error", "max_common_state_error", "max_forecast_lead"):
        if any(name in row for row in summaries):
            totals[name] = max(row[name] for row in summaries if name in row)
    totals["min_eigenvalue"] = min(row["min_eigenvalue"] for row in summaries)
    return totals


def audit_matched_job(key, folders, anchor_path, source_time, expected_fingerprints):
    group, origin, policy, precision = key
    model = ReplayModel()
    with np.load(anchor_path, allow_pickle=False) as anchor:
        fork = int(anchor["tick"].item())
        records = json.loads(str(anchor["records"].item()))
        states = tuple(State(anchor[label], source_time + fork / 1000) for label in ordered_labels(precision))
    initial_energy = tuple(model.energy(state) for state in states)
    hashes = dict(expected_fingerprints)
    work = (0.0, 0.0, 0.0)
    statistics = {**physics_statistics(), "attempts": 0, "accepted": 0, "connected_observations": 0,
                  "detached_observations": 0, "phase_observations": 0, "max_boundary_state_error": 0.0, "max_resume_error": 0.0,
                  "oracle_candidate_projections": 0, "oracle_wait_grid_entries": 0, "reused_equivalent_anchor_stages": 0,
                  "reused_ablation_stages": 0, "reused_archived_wait_stages": 0}
    control = audit27.DecisionReplay("F1")
    control.mode = "wait"
    for record in records:
        tau = round(record["tau"] * 1000)
        if tau:
            control.wait_number += 1
            control.commit(round(record["elapsed_total"] * 1000), tau, round(record["duration"] * 1000), record["net_work"], record["accepted"])
    clock, accepted_count = fork, 0
    target_folders = {tick: folder for tick, folder in folders.items() if tick > fork}
    checkpoint_rows = {tick: READ_CSV(folder / "m28_checkpoints.csv")[0] for tick, folder in target_folders.items()}
    evidence = {}
    for i, (cap, folder) in enumerate(target_folders.items()):
        histories, decisions, waits, checks, observations, currents = stage_tables(folder)
        checkpoint_row = checkpoint_rows[cap]
        if (folder / "equivalent_anchor.json").is_file():
            verify_equivalent_stage(folder, key, anchor_path)
            statistics["reused_equivalent_anchor_stages"] += 1
        if (folder / "ablation_reuse.json").is_file():
            verify_ablation_source(folder, key, fork, expected_fingerprints)
            statistics["reused_ablation_stages"] += 1
        if (folder / "archived_wait_tail.json").is_file():
            verify_archived_wait_stage(folder, key, cap, fork, expected_fingerprints, histories)
            statistics["reused_archived_wait_stages"] += 1
        insist(int(checkpoint_row["attempts_in_stage"]) == len(histories), f"Incomplete stage at {key}/{cap}")
        resumed = checkpoint_row["resumed_state_error"]
        insist(bool(resumed) == bool(i), f"Missing boundary restart at {key}/{cap}")
        if resumed:
            tolerance(resumed, 0, f"Reported resume error at {key}/{cap}")
            statistics["max_resume_error"] = max(statistics["max_resume_error"], abs(float(resumed)))
        for row in histories:
            attempt = int(row["attempt"])
            context = key, attempt
            insist(attempt == statistics["attempts"] + 1, f"Noncontiguous matched ledger at {context}")
            decision, wait_checks, samples = decisions[attempt], checks[attempt], observations[attempt]
            for entry in [row, decision, currents[attempt], *wait_checks, *samples, *([waits[attempt]] if attempt in waits else [])]:
                insist(tuple(entry[field] for field in ("group", "origin", "policy", "precision")) == key
                       and audit27.ticks(entry, "fork_elapsed") == fork, f"Mixed fork provenance at {context}")
            start, window, tau, duration, connected, end = (audit27.ticks(row, field) for field in
                ("elapsed_start", "window", "tau", "duration", "elapsed_connected", "elapsed_total"))
            insist(start == clock and window == min(audit27.HORIZON, audit27.CAP - start) and 0 < end - start == duration == tau + connected <= window
                   and end <= cap and connected >= 0 and connected % 20 == 0 and (policy == "E" or connected >= 20),
                   f"Matched branch made an unavailable or mismatched-clock action at {context}")
            tolerance(row["absolute_time"], source_time + end / 1000, f"Matched physical time at {context}")
            insist(all(row[f"start_{label}_sha256"] == digest for label, digest in hashes.items()), f"State hash gap at {context}")
            hashes = {label: row[f"post_{label}_sha256"] for label in audit27.RESOLUTIONS}
            approved = audit27.flag(row, "accepted")
            actions = tuple(audit27.exact_action(model, state, tau, connected, approved) for state in states)
            is_oracle = policy == "E"
            insist(audit27.ticks(decision, "elapsed_total") == start and not audit27.flag(decision, "switched"), f"False mode switch at {context}")
            if is_oracle:
                insist(decision["observed_until"] == "" and not wait_checks and decision["reason"] == "retrospective"
                       and decision["mode_before"] == decision["mode_after"] == "retrospective",
                       f"Oracle was labelled as an observed online choice at {context}")
                audit_oracle(model, row, samples, states, actions[0], context)
                statistics["oracle_candidate_projections"] += int(row["oracle_candidates"])
                statistics["oracle_wait_grid_entries"] += int(row["oracle_wait_candidates"])
            else:
                insist(audit27.ticks(decision, "observed_until") == start, f"Online wait used future data at {context}")
                expected_mode = "forecast" if policy == "R0" else "wait"
                insist(decision["reason"] == policy and decision["mode_before"] == decision["mode_after"] == row["mode"] == expected_mode,
                       f"Unexpected matched control mode at {context}")
                if policy in FIXED_WAIT:
                    fixed = FIXED_WAIT[policy]
                    insist(tau == (fixed if fixed + 20 <= window else 0), f"Wrong fixed wait or remaining-window fallback at {context}")
                elif policy == "RH":
                    insist((tau, row["wait_reason"]) == control.expected_learning_wait(window), f"RH used data outside its realized reward memory at {context}")
                else:
                    insist(policy == "RP" or policy in ABLATIONS, f"Unregistered online policy {policy}")
                audit_wait_choice(model, row, wait_checks, states[0], context)
                audit27.audit_connected(model, samples, actions[0], row, context)
                insist(not int(row.get("oracle_candidates") or 0), f"Online extraction used a retrospective search at {context}")
            audit27.audit_energy(model, row, *actions, states[0], context, statistics)
            pseudo_decision = {"c_abs": row["c_abs_before"], "phase": row["phase_before"], "load_current": row["current_before"]}
            audit27.verify_logged_observation(pseudo_decision, audit27.observation(model, states[0]), f"{context}/initial measurement")
            insist((attempt in waits) == bool(tau), f"Incorrect detached phase ledger membership at {context}")
            audit27.check_wait_summary(waits.get(attempt), row, pseudo_decision, samples, context)
            phase_used = policy == "RP" or policy in ABLATIONS
            audit_current(currents[attempt], row, samples, wait_checks, phase_used, context)

            for checkpoint in checkpoint_rows:
                if start <= checkpoint < end:
                    points = [audit27.action_snapshot(model, state, start, tau, connected, action, checkpoint)
                              for state, action in zip(states, actions, strict=True)]
                    snapshot = tuple(point[0] for point in points)
                    evidence[checkpoint] = (states, (start, statistics["attempts"], accepted_count), work, list(records),
                                            (snapshot, points[0][1], pending_from_action(row, samples, wait_checks, checkpoint)))
            net, aligned = (audit27.number(row, field) for field in ("net_work", "net_work_aligned"))
            work = work[0] + net, work[1] + aligned, work[2] + abs(net - aligned)
            for name, value in zip(("cumulative_net", "cumulative_net_aligned", "cumulative_step_error_bound"), work, strict=True):
                tolerance(row[name], value, f"Matched {name} at {context}")
            states = tuple(action.after for action in actions)
            for energy, state, recovered in zip(initial_energy, states, work[:2], strict=True):
                tolerance(model.energy(state) + recovered, energy, f"Matched cumulative conservation at {context}")
            accepted_count += int(approved)
            insist(int(row["count"]) == accepted_count, f"Match count at {context}")
            if policy == "RH":
                control.commit(end, tau, duration, net, approved)
            records.append(compact(row))
            clock = end
            statistics["attempts"] += 1
            statistics["accepted"] += int(approved)
            statistics["connected_observations"] += len(samples)
            statistics["detached_observations"] += len(wait_checks)
            statistics["phase_observations"] += int(row["phase_observations"])
        if cap not in evidence:
            evidence[cap] = (states, (clock, statistics["attempts"], accepted_count), work, list(records), None)
    for cap, folder in target_folders.items():
        difference = verify_matched_boundary(model, checkpoint_rows[cap], folder, key, cap, fork, expected_fingerprints, *evidence[cap])
        statistics["max_boundary_state_error"] = max(statistics["max_boundary_state_error"], difference)
    statistics.update(cumulative_net=work[0], fork_elapsed=fork / 1000, boundary_count=len(target_folders),
                      rejected=statistics["attempts"] - statistics["accepted"])
    print(f"PASS {'/'.join(key)}: {statistics['attempts']} repeated attempts from shared state at {fork / 1000:g}", flush=True)
    return statistics


def verify_equivalent_stage(folder, key, anchor_path):
    group, origin, policy, precision = key
    insist(group == "F1", f"Unexpected inherited stage at {key}")
    relative_path = Path(POLICY, origin, policy, precision)
    source = folder.parents[3] / relative_path
    metadata = json.loads((folder / "equivalent_anchor.json").read_text(encoding="utf-8"))
    insist(metadata == {"same_pair_and_completed_history": True, "reference": relative_path.as_posix()},
           f"Wrong equivalent-state stage provenance at {key}")
    peer = anchor_path.parents[3] / POLICY / origin / precision / "anchor.npz"
    with np.load(peer, allow_pickle=False) as reference, np.load(anchor_path, allow_pickle=False) as fork:
        insist(set(reference.files) == set(fork.files) and all(np.array_equal(reference[field], fork[field]) for field in fork.files),
               f"Reused branch did not start from the same matrices, clock and memory at {key}")
    insist(audit27.sha256(folder / "checkpoint.npz") == audit27.sha256(source / "checkpoint.npz"),
           f"Reused branch checkpoint differs at {key}")
    for name in ("history", "decisions", "waits", "wait_checks", "observations", "current", "checkpoints"):
        rows = f"m28_{name}.csv"
        relabelled = [{**row, "group": group} for row in table_m28(source / rows)]
        insist(table_m28(folder / rows) == relabelled, f"Inherited stage rows differ at {key}/{name}")


def verify_ablation_source(folder, key, fork, fingerprints):
    group, origin, policy, precision = key
    data = json.loads((folder / "ablation_reuse.json").read_text(encoding="utf-8"))
    expected = {"group": group, "origin": origin, "policy": policy, "precision": precision, "source_policy": "RP",
                "condition_removed": ABLATIONS[policy], "fork_tick": fork, "equal_at_every_observed_gate": True,
                "fork_sha256": [fingerprints[label] for label in audit27.RESOLUTIONS]}
    insist(all(data[name] == value for name, value in expected.items()), f"Wrong reuse certificate at {key}")
    source = folder.parents[3].joinpath(group, origin, "RP", precision)
    insist(audit27.sha256(folder / "checkpoint.npz") == audit27.sha256(source / "checkpoint.npz"),
           f"Ablation reuse changed physical checkpoint at {key}")
    checked, observations = 0, 0
    for entry in data["source_ledgers"]:
        path = folder.parents[4] / entry["stage"]
        insist(path.parts[-4:] == (group, origin, "RP", precision), f"Wrong traced RP source at {key}")
        for name, digest in entry.items():
            if name != "stage":
                insist(audit27.sha256(path / name) == digest, f"Reused trajectory evidence changed at {key}/{name}")
        checked += len(table_m28(path / "m28_history.csv"))
        observations += len(table_m28(path / "m28_wait_checks.csv"))
    insist(checked == data["attempts_checked"] and observations == data["observations_checked"], f"Reuse evidence count at {key}")


def verify_archived_wait_stage(folder, key, cap, fork, fingerprints, history):
    group, origin, policy, precision = key
    insist((group, policy) == ("F1", "RH"), f"Unexpected M27 wait-tail reuse at {key}")
    source = M27 / "stages" / f"t{cap // 1000}" / origin / "F1" / precision
    audit_path = M27 / "results" / "audit.json"
    metadata = json.loads((folder / "archived_wait_tail.json").read_text(encoding="utf-8"))
    insist((ROOT / metadata["archive"]).resolve() == source.resolve()
           and (ROOT / metadata["source_audit"]).resolve() == audit_path.resolve()
           and round(metadata["fork_elapsed"] * 1000) == fork
           and metadata["input_hashes"] == [fingerprints[label] for label in audit27.RESOLUTIONS],
           f"Wrong archived wait lineage at {key}/{cap}")
    official = json.loads(audit_path.read_text(encoding="utf-8"))
    prior = official["branch_results"][f"{origin}/F1/{precision}"]
    insist(official["protocol_sha256"] == audit27.sha256(M27 / "PROTOCOL_M27.md") and cap // 1000 in official["boundaries"]
           and round(prior["switches"][0]["time"] * 1000) == fork, f"Archived audit does not cover the reused F1 fork at {key}")
    prefix = metadata["source_prefix_trials"]
    archived = [row for row in READ_CSV(source / "m27_history.csv") if int(row["attempt"]) > prefix]
    insist(len(archived) == len(history), f"Archived wait-tail stage lost events at {key}")
    fields = ("elapsed_start", "elapsed_total", "tau", "decision_elapsed_total", "accepted", "net_work", "net_work_aligned", "cut_on",
              "reconnect_on", "start_coarse_sha256", "start_half_sha256", "post_coarse_sha256", "post_half_sha256")
    for old, new in zip(archived, history, strict=True):
        insist(int(old["attempt"]) == prefix + int(new["attempt"]) and all(old[field] == new[field] for field in fields),
               f"Copied archived wait event differs at {key}/{new['attempt']}")
    with np.load(source / "checkpoint.npz", allow_pickle=False) as old, np.load(folder / "checkpoint.npz", allow_pickle=False) as new:
        physical_entries = ("coarse", "half", "anchor_coarse", "anchor_half", "tick", "coupling", "phase", "ending", "pending", "records")
        insist(all(np.array_equal(old[field], new[field]) for field in physical_entries), f"Archived wait stage changes actual state at {key}/{cap}")


def audit_matched(stages, anchors, origins, precisions, boundaries, groups, policies, workers):
    sources, _ = archived_origins()
    registry = audit27.read_unique(READ_CSV(anchors / "m28_anchors.csv"), lambda row: (row["group"], row["origin"], row["precision"]))
    jobs = {}
    for group in groups:
        for origin in origins:
            for precision in precisions:
                anchor, _, _ = audited_anchor(stages, anchors, registry, sources, group, origin, precision)
                for policy in policies:
                    key = group, origin, policy, precision
                    fingerprints = {label: anchor[f"{label}_sha256"] for label in audit27.RESOLUTIONS}
                    folders = folders_at(stages, group, key[1:], boundaries)
                    jobs[key] = (key, folders, anchors / anchor["anchor_file"], audit27.number(anchor, "source_time"), fingerprints)
    if workers == 1:
        logs = {key: audit_matched_job(*args) for key, args in jobs.items()}
    else:
        with ProcessPoolExecutor(max_workers=workers) as pool:
            pending = {key: pool.submit(audit_matched_job, *args) for key, args in jobs.items()}
            logs = {key: pending[key].result() for key in jobs}
    reproductions = [verify_inherited_continuation(stages, jobs[key][1], key, boundaries[-1], stats["fork_elapsed"])
                     for key, stats in logs.items() if (key[0], key[2]) in {(POLICY, "RP"), ("F1", "RH")}]
    phase_work = []
    for key, stats in logs.items():
        group, origin, policy, precision = key
        if policy != "RP":
            continue
        for compare in ("R1", "RH"):
            other = logs.get((group, origin, compare, precision))
            if other:
                phase_work.append({"group": group, "origin": origin, "precision": precision, "comparator": compare,
                                  "work_delta": stats["cumulative_net"] - other["cumulative_net"],
                                  "phase_observation_delta": stats["phase_observations"] - other["phase_observations"]})
    ablation_witnesses = []
    for key, stats in logs.items():
        if key[2] in ABLATIONS:
            rp = folders_at(stages, key[0], (key[1], "RP", key[3]), boundaries)
            if all((folder / "checkpoint.npz").is_file() for folder in rp.values()):
                ablation_witnesses.append(audit_ablation_replay(key, stats, rp, jobs[key][1]))
    return {"branch_results": {"/".join(key): report for key, report in logs.items()},
            "totals": totals_for(logs.values()), "anchors": len(groups) * len(origins) * len(precisions), "inherited_continuation_parity": reproductions,
            "phase_gain_endpoint_checks": phase_work, "phase_ablation_replay": ablation_witnesses}


def verify_inherited_continuation(stages, new_folders, key, cutoff, fork_elapsed):
    group, origin, policy, precision = key
    if group == POLICY:
        archived = [folder / "main" / origin / group / precision for folder in stages.glob("t[0-9]*") if folder.is_dir()]
        ledger = "m28_history.csv"
    else:
        archived = [folder / origin / group / precision for folder in (M27 / "stages").glob("t[0-9]*") if folder.is_dir()]
        ledger = "m27_history.csv"
    fork = round(fork_elapsed * 1000)
    reference = sorted((row for folder in archived for row in table_original(folder / ledger)
                        if fork <= audit27.ticks(row, "elapsed_start") and audit27.ticks(row, "elapsed_total") <= cutoff),
                       key=lambda row: int(row["attempt"]))
    repeated = [row for folder in new_folders.values() for row in table_m28(folder / "m28_history.csv")]
    delta = 0.0
    first_difference = None
    fields = ("elapsed_start", "elapsed_total", "decision_elapsed_total", "tau", "accepted",
              "pre_coarse_sha256", "pre_half_sha256", "post_coarse_sha256", "post_half_sha256")
    for old, new in zip(reference, repeated, strict=False):
        differences = [name for name in fields if old[name] != new[name]]
        difference = abs(audit27.number(new, "net_work") - audit27.number(old, "net_work"))
        if differences or difference > audit27.TOL:
            first_difference = {"attempt": int(new["attempt"]), "fields": differences, "per_event_work_delta": difference}
            break
        delta = max(delta, difference)
    if first_difference is None and len(reference) != len(repeated):
        first_difference = {"attempt": min(len(reference), len(repeated)) + 1, "fields": ["attempt_count"]}
    if group == POLICY:
        insist(first_difference is None, f"Matched RP differs from its own main continuation at {key}: {first_difference}")
    return {"group": group, "origin": origin, "policy": policy, "precision": precision,
            "records": len(repeated), "max_per_record_work_delta_before_difference": delta,
            "identical_work_and_chronology": first_difference is None, "first_difference": first_difference}


def audit_ablation_replay(key, variant, rp_folders, ablation_folders):
    omitted = ABLATIONS[key[2]]
    baseline = []
    relevant = []
    for folder in rp_folders.values():
        history = table_m28(folder / "m28_history.csv")
        checks = audit27.group_attempt(table_m28(folder / "m28_wait_checks.csv"))
        for row in history:
            baseline.append(row)
            initial = {"c_abs": row["c_abs_before"], "c_real": str(-audit27.number(row, "cut_on") / (2 * G))}
            attempt = int(row["attempt"])
            for sampled in checks[attempt][:-1]:
                tests = phase_components(initial, sampled)
                if all(value for name, value in tests.items() if name != omitted):
                    relevant.append({"attempt": attempt, "start_elapsed": audit27.number(row, "elapsed_start"),
                                     "baseline_wait": audit27.number(row, "tau"), "replayed_wait": audit27.number(sampled, "wait_elapsed")})
                    break
    altered = [row for folder in ablation_folders.values() for row in table_m28(folder / "m28_history.csv")]
    first = relevant[0] if relevant else None
    for i, (old, new) in enumerate(zip(baseline, altered, strict=False), 1):
        clocks = ("elapsed_start", "tau", "elapsed_total", "decision_elapsed_total", "accepted")
        if first is not None and first["attempt"] == i:
            insist(audit27.number(new, "tau") == first["replayed_wait"], f"First observed ablation difference does not match causal replay at {key}/{i}")
            break
        insist(all(old[name] == new[name] for name in clocks), f"Ablation diverges before its first changed observed predicate at {key}/{i}")
    if first is None:
        insist(len(baseline) == len(altered), f"No-effect ablation differs in attempt count at {key}")
    old_total = audit27.number(baseline[-1], "cumulative_net") if baseline else 0.0
    return {"group": key[0], "origin": key[1], "policy": key[2], "precision": key[3], "omitted": omitted,
            "baseline_attempts_with_earlier_reconnect_in_recorded_prefix": len(relevant), "first_difference": first,
            "endpoint_work_difference_vs_rp": variant["cumulative_net"] - old_total}


def passive_derivatives(model, state):
    """Evaluate the load derivative independently by the full Hamiltonian commutator."""
    load = reduced_load(terminal_state(state.matrix))
    h_rho = model.h[G] @ state.matrix
    derivative = reduced_load(terminal_state(-1j * (h_rho - h_rho.conj().T)))
    values, vectors = np.linalg.eigh(load)
    values, vectors = values[::-1], vectors[:, ::-1]
    principal_rates = np.diag(vectors.conj().T @ derivative @ vectors).real
    passive = float(LOAD_LEVELS @ values)
    energy = float(LOAD_LEVELS @ np.diag(load).real)
    energy_rate = float(LOAD_LEVELS @ np.diag(derivative).real)
    passive_rate = float(LOAD_LEVELS @ principal_rates)
    # At a passive state the second-order change in the diagonal cancels from W''.
    gaps = values[:-1] - values[1:]
    insist(np.min(gaps) > audit27.TOL, "Load spectrum is degenerate at the passive-derivative witness")
    curvature = 2 * sum((LOAD_LEVELS[right] - LOAD_LEVELS[left]) * abs(derivative[left, right]) ** 2
                        / (values[left] - values[right])
                        for left in range(len(values)) for right in range(left + 1, len(values)))
    return {
        "load_ergotropy": energy - passive,
        "load_energy_rate": energy_rate,
        "passive_energy_rate": passive_rate,
        "load_ergotropy_rate": energy_rate - passive_rate,
        "passive_second_derivative": float(curvature),
        "load_min_spectral_gap": float(np.min(gaps)),
        "load_passive_matrix_error": float(np.max(np.abs(load - np.diag(values)))),
    }


def audit_m27_derivative_witness():
    """Check the C04 t=68.90 split in M27 using the saved state pair at the same clocks."""
    model = ReplayModel()
    switch = M27 / "stages" / "t150" / "C04" / "F2" / "half" / "switch_68900.npz"
    source, = (row for row in audit27.read_rows(audit27.M26 / "results" / "m26_sources.csv") if row["origin"] == "C04")
    audit = {"origin": "C04", "elapsed_total": 68.9, "policy": "F2", "relative_input": switch.relative_to(ROOT.parent).as_posix(),
             "input_sha256": audit27.sha256(switch), "precisions": {}}
    with np.load(switch, allow_pickle=False) as saved:
        insist(int(saved["tick"].item()) == 68_900, "Old witness saved at the wrong clock")
        for resolution in audit27.RESOLUTIONS:
            folder = switch.parent.parent / resolution
            rows = audit27.read_rows(folder / "m27_decisions.csv")
            decision, = (row for row in rows if audit27.ticks(row, "elapsed_total") == 68_900)
            history = audit27.read_rows(folder / "m27_history.csv")
            action, = (row for row in history if int(row["attempt"]) == int(decision["attempt"]))
            matrix = saved[resolution]
            insist(audit27.state_sha256(matrix) == action[f"start_{resolution}_sha256"], "Old same-clock state and decision hashes differ")
            physical_time = (audit27.ticks(source, "source_time") + 68_900) / 1000
            state = State(matrix, physical_time)
            measured = passive_derivatives(model, state)
            tolerance(measured["load_passive_matrix_error"], 0, f"Old switch passivity/{resolution}", 1e-15)
            tolerance(measured["load_ergotropy_rate"], 0, f"Analytical passive work derivative/{resolution}", 1e-16)
            tolerance(measured["load_energy_rate"], audit27.number(decision, "load_current"), f"Old load energy-rate identity/{resolution}", 1e-15)
            measured.update({"logged_load_ergotropy_rate": audit27.number(decision, "load_ergotropy_rate"),
                             "old_decision_supplied": audit27.flag(decision, "supplying"),
                             "old_switched": audit27.flag(decision, "switched"),
                             "old_gate": audit27.flag(decision, "phase_gate")})
            audit["precisions"][resolution] = measured
    return audit


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stages", nargs="?", type=Path)
    parser.add_argument("--cutoffs", nargs="+", type=int, default=tuple(time // 1000 for time in PRIMARY_CUTOFFS))
    parser.add_argument("--origins", nargs="+", choices=sorted(audit27.ORIGINS), default=sorted(audit27.ORIGINS))
    parser.add_argument("--precisions", nargs="+", choices=audit27.RESOLUTIONS, default=audit27.RESOLUTIONS)
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--oneshot", type=Path)
    parser.add_argument("--reference-projector", type=Path)
    parser.add_argument("--sensitivity", action="store_true")
    parser.add_argument("--gate-floor", type=float, choices=FLOORS, default=RATE_FLOOR)
    parser.add_argument("--anchors", type=Path)
    parser.add_argument("--matched-only", action="store_true")
    parser.add_argument("--groups", nargs="+", choices=("F2-R", "F1"), default=("F2-R", "F1"))
    parser.add_argument("--policies", nargs="+", choices=(*MATCHED, *ABLATIONS), default=MATCHED)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = {"analytical_passive_derivative": audit_m27_derivative_witness()}
    if args.stages:
        boundaries = tuple(elapsed * 1000 for elapsed in args.cutoffs)
        insist(boundaries and tuple(sorted(set(boundaries))) == boundaries and 0 < boundaries[0] <= boundaries[-1] <= audit27.CAP,
               "Invalid M28 increasing boundaries")
        insist(args.workers >= 1, "M28 audit needs a positive worker count")
        protocol = audit27.sha256(ROOT / "PROTOCOL_M28.md")
        for folder in (path for path in (args.stages, args.oneshot, args.reference_projector) if path):
            insist((folder / "protocol.sha256").read_text(encoding="utf-8").strip() == protocol,
                   f"Data were registered under another protocol at {folder}")
        result.update(protocol_sha256=protocol, boundaries=args.cutoffs)
        if not args.matched_only:
            primary, primary_folders = audit_primary(args.stages, boundaries, args.origins, args.precisions, args.workers,
                                                    args.oneshot, rate_floor=args.gate_floor)
            result["primary"] = primary
            if args.reference_projector:
                checks = {}
                for key, folders in primary_folders.items():
                    path = folders_at(args.reference_projector, "main", key, boundaries[-1:])[boundaries[-1]]
                    checks["/".join(key)] = compare_reference_projection(folders, path)
                result["reference_projection_checked_rows"] = checks
            if args.sensitivity:
                insist(boundaries == PRIMARY_CUTOFFS and args.gate_floor == RATE_FLOOR,
                       "Threshold sensitivity comparison uses the full horizon and registered primary floor")
                result["threshold_sensitivity"], result["local_perturbation_sensitivity"] = audit_floor_sensitivity(primary, primary_folders, boundaries)
        if args.anchors or args.matched_only:
            anchors = args.anchors or ROOT / "anchors"
            result["matched"] = audit_matched(args.stages, anchors, args.origins, args.precisions, boundaries,
                                               args.groups, args.policies, args.workers)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    else:
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
