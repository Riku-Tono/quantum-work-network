"""Run the four registered single-condition reconnect ablations."""

import argparse
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor, as_completed
import csv
import hashlib
import json
import math
from pathlib import Path
import shutil
from tempfile import TemporaryDirectory

from run_m28 import ABLATIONS, G, Job, ORIGINS, ROOT, TOTAL_LIMIT, ablated_gate, branch_seed, physics, register, run_job, source_for


def rows(path):
    if not path.is_file():
        return []
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def verify_reuse(job, stages, cutoffs):
    """Certify that dropping a gate leaves every consumed RP decision unchanged."""
    if cutoffs[-1] != TOTAL_LIMIT:
        return None
    pair, fork_tick, _ = branch_seed(job, source_for(job.origin))
    hashes = [physics.fingerprint(rho) for rho in pair]
    baseline = Job(job.group, job.origin, "RP", job.precision, job.anchor_root)
    sources = [stages / f"t{cap // 1000}" / baseline.relative_path() for cap in cutoffs if cap > fork_tick]
    if not sources or any(not (folder / "checkpoint.npz").is_file() for folder in sources):
        return None
    original = ablated_gate(None)
    relaxed = ablated_gate(ABLATIONS[job.policy])
    count = points = 0
    witness = []
    for folder in sources:
        checkpoint, = rows(folder / "m28_checkpoints.csv")
        if ([checkpoint[f"fork_{name}_sha256"] for name in ("coarse", "half")] != hashes
                or physics.tick(checkpoint, "fork_elapsed") != fork_tick):
            return None
        history_path = folder / "m28_history.csv"
        checks_path = folder / "m28_wait_checks.csv"
        checks = defaultdict(list)
        for sample in rows(checks_path):
            checks[int(sample["attempt"])].append(sample)
        for row in rows(history_path):
            count += 1
            tau = physics.tick(row, "tau")
            attempt = int(row["attempt"])
            observed = checks.pop(attempt, [])
            if [physics.tick(sample, "wait_elapsed") for sample in observed] != list(range(1000, tau + 1, 200)):
                return None
            before = {"c_abs": float(row["c_abs_before"]), "c_real": -float(row["cut_on"]) / (2 * G)}
            for sample in observed:
                now = {field: float(sample[field]) for field in ("phase", "c_abs", "load_current", "c_real")}
                passed = original(now, before, G)
                if passed != (sample["phase_gate"] == "True") or passed != relaxed(now, before, G):
                    return None
                if sample["used_by_control"] != "True":
                    return None
                points += 1
        if checks:
            return None
        witness.append({"stage": str(folder.relative_to(stages)),
                        **{name: hashlib.sha256((folder / name).read_bytes()).hexdigest()
                           for name in (history_path.name, checks_path.name, "m28_checkpoints.csv") if (folder / name).is_file()}})
    if not count or not points or checkpoint["ending"] not in ("time_cap", "time_cap_no_grid") or checkpoint["execute_tick"]:
        return None
    return sources, {"source_policy": "RP", "origin": job.origin, "group": job.group, "policy": job.policy,
                     "precision": job.precision, "condition_removed": ABLATIONS[job.policy], "fork_tick": fork_tick,
                     "fork_sha256": hashes, "attempts_checked": count, "observations_checked": points,
                     "source_ledgers": witness, "equal_at_every_observed_gate": True}


def copy_certified(source, destination, policy, evidence):
    """Publish an already verified identical trajectory under its ablation label."""
    if destination.exists():
        # A retry may encounter a fully computed preceding stage.
        import numpy as np

        with np.load(source / "checkpoint.npz", allow_pickle=False) as expected, np.load(
                destination / "checkpoint.npz", allow_pickle=False) as actual:
            if expected.files != actual.files or any(not np.array_equal(value, actual[key]) for key, value in expected.items()):
                raise ValueError(f"Computed ablation checkpoint differs from its exact replay: {destination}")
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix=".pending-reuse-", dir=destination.parent) as temporary:
        folder = Path(temporary) / "complete"
        folder.mkdir()
        for item in source.iterdir():
            if item.suffix == ".npz":
                shutil.copy2(item, folder / item.name)
            elif item.suffix == ".csv":
                with item.open(encoding="utf-8", newline="") as incoming, (folder / item.name).open(
                        "x", encoding="utf-8", newline="") as outgoing:
                    stream = csv.DictReader(incoming)
                    writer = csv.DictWriter(outgoing, fieldnames=stream.fieldnames)
                    writer.writeheader()
                    for row in stream:
                        row["policy"] = policy
                        if item.name == "m28_decisions.csv" and row["reason"] == "RP":
                            row["reason"] = policy
                        writer.writerow(row)
        (folder / "ablation_reuse.json").write_text(json.dumps(evidence, indent=2) + "\n", encoding="utf-8")
        folder.rename(destination)


def run_ablation(job, stages, cutoffs):
    last = stages / f"t{cutoffs[-1] // 1000}" / job.relative_path()
    if not (last / "checkpoint.npz").is_file():
        proof = verify_reuse(job, stages, cutoffs)
        if proof is not None:
            sources, evidence = proof
            for source in sources:
                stage = source.relative_to(stages).parts[0]
                copy_certified(source, stages / stage / job.relative_path(), job.policy, evidence)
            return "exact RP reuse"
    run_job(job, stages, cutoffs, phase_ablation=ABLATIONS[job.policy])
    return "direct"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stages", type=Path, default=ROOT / "stages")
    parser.add_argument("--anchors", type=Path, default=ROOT / "anchors")
    parser.add_argument("--origins", nargs="+", choices=ORIGINS, default=ORIGINS)
    parser.add_argument("--policies", nargs="+", choices=ABLATIONS, default=tuple(ABLATIONS))
    parser.add_argument("--cutoffs", nargs="+", type=int, default=(150, 300, 540))
    parser.add_argument("--workers", type=int, default=2)
    args = parser.parse_args()
    cutoffs = tuple(clock * 1000 for clock in args.cutoffs)
    if tuple(sorted(set(cutoffs))) != cutoffs or not 0 < cutoffs[0] <= cutoffs[-1] <= TOTAL_LIMIT:
        parser.error("Cutoffs must be increasing and inside (0, 540]")
    missing = [origin for origin in args.origins
               if not (args.anchors / "F2-R" / origin / "coarse" / "anchor.npz").is_file()]
    if missing:
        parser.error(f"Missing F2-R coarse anchor for {missing[0]}")
    register(args.stages)
    policies = sorted(args.policies, key=lambda policy: policy != "Xcurrent")
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        jobs = {pool.submit(run_ablation, Job("F2-R", origin, policy, "coarse", args.anchors), args.stages, cutoffs): (origin, policy)
                for policy in policies for origin in args.origins}
        for task in as_completed(jobs):
            label = task.result()
            print(f"Completed reconnect ablation {'/'.join(jobs[task])} ({label})", flush=True)


if __name__ == "__main__":
    main()
