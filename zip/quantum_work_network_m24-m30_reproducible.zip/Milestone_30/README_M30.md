# M30 再現手順

M29の切替アンカーと準備済みU01〜U06を用いて、二つの再接続条件を復元する。実験手順と判定幅は [事前固定プロトコル](PROTOCOL_M30.md)、研究結果は [正式報告書](MILESTONE_30_RECONNECTION_CONDITIONS_REPORT.md) に記載した。

## 実行環境

Windows PowerShell、Python 3.14.10、NumPy 2.5.5、Matplotlib 3.10.9。リポジトリルートで実行する。M23〜M29の上流コード、M28の `anchors` とM29の `anchors/unseen`・`unseen/sources.csv` が必要。等価再利用を有効にする場合はM28・M29の `stages` も元の位置に置く。`--workers` は利用可能なメモリに応じて変更できる。実行は経過150・300・540で各枝を確定し、同じ保存先から続行できる。

```powershell
py -3.14 -m pip install 'numpy==2.5.5' 'matplotlib==3.10.9'
$env:OPENBLAS_NUM_THREADS = '1'
$m30Dest = Join-Path (Get-Location) 'Milestone_30/redo'
py -3.14 -B Milestone_30/run_m30.py --output $m30Dest --origins U05 U06 --workers 6 --no-reuse
py -3.14 -B Milestone_30/run_m30.py --output $m30Dest --mode rk4 --origins S0 A04 B04 C04 U01 U02 U03 U04 --workers 4
py -3.14 -B Milestone_30/analyze_m30.py --root $m30Dest
py -3.14 -B Milestone_30/plot_m30.py --data "$m30Dest/results" --output "$m30Dest/figures"
py -3.14 -B Milestone_30/m30_u05.py --stages "$m30Dest/stages" --exact "$m30Dest/exact_online" --output "$m30Dest/u05"
py -3.14 -B Milestone_30/m30_causal_context.py --stages "$m30Dest/stages" --output "$m30Dest/results"
py -3.14 -B Milestone_30/m30_provenance.py --root $m30Dest --output "$m30Dest/results"
py -3.14 -B Milestone_30/run_m30.py --output $m30Dest --one-shot --mode rk4 --origins U05 --precisions coarse --policies RP P3 P1 P3+IA --workers 1
py -3.14 -B Milestone_30/verify_m30.py --stages "$m30Dest/stages" --online "$m30Dest/exact_online" --one-shot "$m30Dest/one_shot" --workers 4 --cache "$m30Dest/audit_cache" --output "$m30Dest/results/audit_independent.json"
py -3.14 -B Milestone_30/verify_m30_u05.py --root $m30Dest
py -3.14 -B Milestone_30/verify_m30_tables.py --root $m30Dest
```

同じ初期状態と操作列の再利用を使わない再現では、両方の `run_m30.py` に `--no-reuse` を付ける。等価再利用では、各観測を時計順に読み、次に実行する再接続が元の枝と一致するときにその操作後の同じ物理状態を引き継ぐ。保存境界の未完了操作は対象方式で再生成する。証明書は `equivalent_policy.json`、出典と照合結果は `m30_provenance.csv` に収録した。

U05の共通境界のみを再検証するには `m30_u05.py --local-only` を使う。共通の保存密度から540まで単独で全分岐を実行する選択肢は `--full`。既定の手順では第6・第7試行を保存密度から直接再実行し、その分岐前後の時計と状態の指紋を全期間枝に照合したうえで終点までの後続台帳を引く。

## 成果物とデータ定義

| 場所 | 内容 |
| --- | --- |
| `stages/<group>/<origin>/<policy>/<precision>/t{150,300,540}` | 粗刻み・半刻みの枝ごとの全試行、観測、保存時点の状態と再開情報 |
| `exact_online/recheck/{U05,U06}/<policy>/coarse/t{150,300,540}` | 粗刻み保存の**準備密度**を初期値とした厳密ユニタリのオンライン結果 |
| `m30_history.csv`、`m30_wait_checks.csv`、`m30_selector.csv` | 各枝内の試行収支、到達済みの待機観測、方式が判定に取得した値だけを抜き出した台帳 |
| `m30_observations.csv`、`m30_pending_*.csv` | 接続中の停止Aに渡された観測、保存時点で未完了の試行の観測 |
| `m30_checkpoints.csv`、`checkpoint.npz` | 完了試行の累積と実行済み収支、保存状態、最後に完了した試行の直後密度 `anchor_coarse`・`anchor_half`、再開に用いる未完了操作 |
| `results/m30_endpoints.csv`、`m30_group_metrics.csv` | 状態・方式・刻み別の終点、群平均・最小維持率、観測負担、強制再接続の成績 |
| `results/m30_timeline.csv`、`m30_work_events.csv`、`m30_trial_ledger.csv` | 共通経過時刻ごとの実行済み仕事、操作ごとの仕訳、統合試行台帳 |
| `results/m30_factorial.csv`、`m30_group_factorial.csv`、`m30_basis_contrasts.csv` | 条件復元の個別効果、相互作用とP3/P1基準の差 |
| `results/m30_information_design.csv`、`m30_wait_diagnostics.csv`、`m30_veto_summary.csv` | 保持量、式の負担、到達した観測における条件の重なりと赤字 |
| `results/m30_context_*.csv`、`m30_policy_divergences.csv` | 各試行で最初に観測した基準成立候補、場面ごとの条件余裕と、方式間で最初に分かれた物理操作 |
| `results/m30_numerical_comparison.csv`、`audit_independent.json` | 粗半比較とオンライン厳密比較、固定操作による厳密伝播、保存再開・因果性・閉合の独立監査 |
| `results/audit_u05_common_fork.json`、`results/audit_publication.json` | U05の保存密度と分岐後の接続、公開集計表の独立照合 |
| `u05/`、`figures/` | 共通の切断直前密度、分岐後の密度・観測・台帳、条件と収支の比較図 |

`group=recheck` はM29で使ったU01〜U06。`precision=coarse` は `propagation=exact` の行では初期密度の刻みを示す。正味仕事とイベント台帳の `work_to_user` は回収を正とする。`cut_on`・`reconnect_on` は系への入力を正とする。経過時計が同じ点で操作を実行した場合は、その操作を当該点の仕事に含める。`at_max_wait` はτ=6への到達、`fallback_limit` は当該方式の条件が不成立のまま上限で再接続したことを示す。実スカラー数は再接続判定に必要なコヒーレンスの実成分で数え、停止Aと事後診断の成分は別に扱う。

固定操作の厳密監査は、粗刻み・半刻みの実行台帳をその時刻のまま厳密ユニタリで追跡する。`audit_independent.json` の `fixed_operation_exact` に連続参照と保存値から再開した区間参照の差を記録した。`exact_online` の計算は、厳密伝播で得た各観測値に基づいて再接続と停止Aを決める。
