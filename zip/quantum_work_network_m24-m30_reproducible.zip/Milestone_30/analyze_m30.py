"""Build the M30 event ledgers, condition contrasts and numerical comparisons."""

import argparse
from collections import Counter, defaultdict
import csv
import json
import math
from pathlib import Path

import numpy as np

from run_m30 import CUTOFFS, GROUPS, POLICIES, PRECISIONS, ROOT, registered_protocol


COMMON = (50, 100, 150, 200, 300, 360, 450, 540)
TOL = 1e-10
METRICS = ("cut_on", "reconnect_on", "passivation", "net_work")
FACTORIAL = {"P3": ("P3", "P3+I", "P3+A", "P3+IA"),
             "P1": ("P1", "P1+I", "P1+A", "RP")}


def rows(path):
    if path.is_file():
        with path.open(encoding="utf-8-sig", newline="") as file:
            yield from csv.DictReader(file)


def table(path, data):
    data = list(data)
    if not data:
        raise ValueError(f"Empty result table {path}")
    with path.open("w", encoding="utf-8-sig", newline="") as file:
        output = csv.DictWriter(file, fieldnames=list(dict.fromkeys(key for row in data for key in row)))
        output.writeheader()
        output.writerows(data)


def tick(value):
    return round(1000 * float(value))


def truth(value):
    if value not in ("True", "False", True, False):
        raise ValueError(f"Invalid Boolean {value!r}")
    return value == "True" or value is True


def arg_condition(angle):
    return -3 * math.pi / 4 <= angle <= -math.pi / 4


def diagnostic(row, checks):
    start_re = float(row["c_real_before"]) if "c_real_before" in row else -float(row["cut_on"]) / 0.5
    q0 = float(row["current_before"]) / 0.5
    phase0, amplitude0 = float(row["phase_before"]), float(row["c_abs_before"])
    phase_gate_rows = [arg_condition(float(point["phase"])) for point in checks]
    input_gate_rows = [float(point["c_real"]) <= start_re + 1e-10 for point in checks]
    phase_first = next((float(point["wait_elapsed"]) for point, passed in zip(checks, phase_gate_rows) if passed), None)
    input_first = next((float(point["wait_elapsed"]) for point, passed in zip(checks, input_gate_rows) if passed), None)
    last = checks[-1]
    last_input = float(last["c_real"]) - start_re
    last_phase = float(last["phase"])
    status = (input_gate_rows[-1], phase_gate_rows[-1])
    return {"c0_real": start_re, "c0_imag": -q0, "c0_amplitude": amplitude0, "c0_phase": phase0,
            "c0_real_fraction_signed": start_re / amplitude0 if amplitude0 else None,
            "c0_real_fraction_abs": abs(start_re) / amplitude0 if amplitude0 else None,
            "first_input_pass_tau": input_first, "first_phase_pass_tau": phase_first,
            "input_pass_points_before_actual_reconnect": sum(input_gate_rows),
            "phase_pass_points_before_actual_reconnect": sum(phase_gate_rows),
            "at_reconnect_input_pass": status[0], "at_reconnect_phase_pass": status[1],
            "reconnect_veto": {(True, True): "none", (False, True): "I", (True, False): "A",
                               (False, False): "IA"}[status],
            "reconnect_re_minus_cut_re": last_input,
            "reconnect_phase_margin": min(last_phase + 3 * math.pi / 4, -math.pi / 4 - last_phase),
            "reconnect_q": -float(last["c_imag"])}


def summarize_waits(trials):
    positive = [row for row in trials if row["tau"] > 0]
    capped = [row for row in positive if row["at_max_wait"]]
    forced = [row for row in positive if row["forced"]]
    late_forced = [row for row in forced if not row["at_max_wait"]]
    counts = {"positive_wait_attempts": len(positive), "cap6_attempts": len(capped),
              "cap6_rate": len(capped) / len(positive) if positive else None,
              "forced_attempts": len(forced), "forced_rate": len(forced) / len(positive) if positive else None,
              "forced_cap6_attempts": len(forced) - len(late_forced),
              "forced_short_deadline_attempts": len(late_forced),
              "cap6_passed_attempts": len(capped) - len(forced) + len(late_forced)}
    for label, selection in (("forced", forced), ("forced_cap6", [row for row in forced if row["at_max_wait"]]),
                             ("forced_deadline", late_forced), ("condition_or_no_wait", [row for row in trials if not row["forced"]])):
        for measure in METRICS:
            counts[f"{label}_{measure}"] = math.fsum(row[measure] for row in selection)
        counts[f"{label}_loss_attempts"] = sum(row["net_work"] < 0 for row in selection)
        counts[f"{label}_gross_losses"] = math.fsum(-min(0, row["net_work"]) for row in selection)
    return counts


def read_branch(path, meta):
    trials, events, wait_diagnostics = [], [], []
    audit_sources = Counter()
    connected_points = Counter()
    wait_points = defaultdict(list)
    checkpoints = {}
    endpoint = None
    for cutoff in CUTOFFS:
        stage = path / f"t{cutoff // 1000}"
        checkpoint, = rows(stage / "m30_checkpoints.csv")
        if tick(checkpoint["elapsed_total"]) != cutoff:
            raise ValueError(f"Invalid checkpoint time in {stage}")
        checkpoints[cutoff] = checkpoint
        fork_tick = tick(checkpoint["fork_elapsed"])
        endpoint = checkpoint
        equivalent = (stage / "equivalent_policy.json").is_file()
        audit_sources["reused_stages" if equivalent else "direct_stages"] += 1
        for check in rows(stage / "m30_wait_checks.csv"):
            wait_points[int(check["attempt"])].append(check)
        observation_path = stage / "m30_observations.csv"
        if observation_path.is_file():
            for observation in rows(observation_path):
                connected_points[tick(observation["elapsed_total"])] += 1
        for entry in rows(stage / "m30_history.csv"):
            n = int(entry["attempt"])
            start, end, tau = tick(entry["elapsed_start"]), tick(entry["elapsed_total"]), tick(entry["tau"])
            if n != len(trials) + 1 or start != (trials[-1]["end_tick"] if trials else fork_tick):
                raise ValueError(f"Noncontiguous attempt counter or clock at {stage} #{n}")
            accepted = truth(entry["accepted"])
            cut_on, reconnect_on = float(entry["cut_on"]), float(entry["reconnect_on"])
            passivation = float(entry["direct_total_work"]) if accepted else 0.0
            net = float(entry["net_work"])
            if abs(passivation - cut_on - reconnect_on - net) > 1e-12:
                raise ValueError(f"Attempt account does not close at {stage} #{n}")
            forced = entry["wait_reason"] == "phase_limit"
            summaries = {**meta, "attempt": n, "start_tick": start, "end_tick": end, "reconnect_tick": start + tau,
                         "tau": tau / 1000, "accepted": accepted, "stop_reason": entry["stop_reason"],
                         "forecast_decision_tick": tick(entry["decision_elapsed_total"]),
                         "reconnect_reason": entry["wait_reason"], "forced": forced, "at_max_wait": tau == 6000,
                         "start_state_hash": entry[f'start_{meta["precision"]}_sha256'],
                         "post_state_hash": entry[f'post_{meta["precision"]}_sha256'],
                         "cut_on": cut_on, "reconnect_on": reconnect_on, "passivation": passivation, "net_work": net,
                         "observed_scalars": int(entry["observed_scalars"]),
                         "decision_observations": int(entry["decision_observations"]),
                         "wait_observations": int(entry["wait_phase_observations"]),
                         "initial_real_scalars": int(entry["initial_reconnect_scalars"]),
                         "wait_real_scalars": int(entry["wait_reconnect_scalars"]),
                         "amplitude_evaluations": int(entry["reconnect_abs_evaluations"]),
                         "angle_evaluations": int(entry["reconnect_atan2_evaluations"]),
                         "threshold_abs_initial": int(entry["reconnect_threshold_abs_evaluations"])}
            if tau:
                checks = wait_points.pop(n)
                details = diagnostic(entry, checks)
                wait_diagnostics.append({**summaries, **details})
                events.extend(((start, "cut", -cut_on, n), (start + tau, "reconnect", -reconnect_on, n)))
            if accepted:
                events.append((end, "passivation", passivation, n))
            trials.append(summaries)

    if endpoint is None or not trials:
        raise ValueError(f"No published trajectory {path}")
    if len(trials) != int(endpoint["attempts"]):
        raise ValueError(f"Checkpoint attempt count differs at {path}")
    current_end = trials[-1]["end_tick"]
    with np.load(path / "t540" / "checkpoint.npz", allow_pickle=False) as file:
        pending = json.loads(str(file["pending"].item()))
    if pending.get("cut_applied"):
        # The signed switch net can always be checked, and the dimensions remain explicit.
        cut = pending.get("cut_on", pending.get("cut_input"))
        reconnection = pending.get("reconnect_on", pending.get("reconnect_input"))
        if cut is None:
            if pending.get("reconnect_applied"):
                raise ValueError(f"Terminal pending reconnect needs component inputs in {path}")
            cut = -pending["switch_net"]
        events.append((current_end, "cut", -float(cut), len(trials) + 1))
        if pending.get("reconnect_applied"):
            events.append((current_end + pending["tau"], "reconnect", -float(reconnection), len(trials) + 1))
    events.sort(key=lambda event: (event[0], event[3], {"cut": 0, "reconnect": 1, "passivation": 2}[event[1]]))

    summaries = []
    for stop in COMMON:
        if stop * 1000 < fork_tick:
            continue
        elapsed = stop * 1000
        completed = [row for row in trials if row["end_tick"] <= elapsed]
        energy = {kind: math.fsum(value for event, name, value, _ in events if name == kind and event <= elapsed)
                  for kind in ("cut", "reconnect", "passivation")}
        work = math.fsum(energy.values())
        closed = math.fsum(row["net_work"] for row in completed)
        if elapsed in checkpoints:
            persisted = checkpoints[elapsed]
            if abs(work - float(persisted["cumulative_physical_net"])) > 1e-12:
                raise ValueError(f"Executed-event work differs at {path}, t={stop}")
        waited = sum(1 for event, name, _, _ in events if event <= elapsed and name == "cut")
        final = stop == 540
        summaries.append({**meta, "elapsed": stop, "fork_elapsed": fork_tick / 1000, "net_work": work,
                          "cut_on": -energy["cut"], "reconnect_on": -energy["reconnect"],
                          "passivation": energy["passivation"], "completed_trial_net": closed,
                          "executed_pending_switch_net": work - closed,
                          "rate": work / (stop - fork_tick / 1000) if elapsed > fork_tick else None,
                          "attempts": len(completed),
                          "positive_waits_started": waited, "accepted": sum(row["accepted"] for row in completed),
                          "connected_observation_points_completed_trials": sum(count for time, count in connected_points.items()
                                                                               if time <= elapsed),
                          "reconnect_control_observation_points_completed_trials": sum(row["decision_observations"] for row in completed),
                          "reconnect_real_scalars_completed_trials": sum(row["observed_scalars"] for row in completed),
                          **{measure: sum(row[measure] for row in completed) for measure in (
                              "initial_real_scalars", "wait_real_scalars", "amplitude_evaluations", "angle_evaluations", "threshold_abs_initial")},
                          **(summarize_waits(completed) | dict(audit_sources) if final else {})})
    end = summaries[-1]
    if abs(end["net_work"] - float(endpoint["cumulative_net"]) - float(endpoint["pending_switch_net"])) > 1e-12:
        raise ValueError(f"Endpoint differs from checkpoint account at {path}")
    source = [{**meta, "elapsed": time / 1000, "attempt": n, "operation": name, "work_to_user": value}
              for time, name, value, n in events]
    return trials, source, summaries, wait_diagnostics


def retention(value, ref, floor):
    if ref <= TOL:
        return None, ref - value <= TOL
    return value / ref, value >= floor * ref


def compare(summaries):
    keys = ("propagation", "group", "origin", "precision", "elapsed")
    ladders = defaultdict(dict)
    for row in summaries:
        ladders[tuple(row[key] for key in keys)][row["policy"]] = row
    effects, basis = [], []
    for identity, detail in ladders.items():
        context = dict(zip(keys, identity, strict=True))
        baseline = detail["RP"]["net_work"]
        for row in detail.values():
            ratio, passed = retention(row["net_work"], baseline, 0.90)
            row.update(rp_work=baseline, rp_delta=row["net_work"] - baseline, rp_retention=ratio, state90=passed)
        for component in METRICS:
            for base, policies in FACTORIAL.items():
                w0, wi, wa, wia = [detail[method][component] for method in policies]
                effects.append({**context, "base": base, "component": component,
                                "none": w0, "input_only": wi, "phase_only": wa, "both": wia,
                                "input_effect_no_phase": wi - w0, "phase_effect_no_input": wa - w0,
                                "input_effect_with_phase": wia - wa, "phase_effect_with_input": wia - wi,
                                "both_effect": wia - w0, "interaction": wia - wi - wa + w0})
            for label, p3, p1 in zip(("none", "input", "phase", "both"), FACTORIAL["P3"], FACTORIAL["P1"], strict=True):
                basis.append({**context, "restored": label, "component": component,
                              "p3": detail[p3][component], "p1": detail[p1][component],
                              "p3_minus_p1": detail[p3][component] - detail[p1][component]})
    return effects, basis


def group_means(summaries):
    groups = defaultdict(list)
    keys = ("propagation", "group", "precision", "policy", "elapsed")
    for row in summaries:
        groups[tuple(row[key] for key in keys)].append(row)
    result = []
    for identity, members in groups.items():
        mean = lambda key: math.fsum(row[key] for row in members) / len(members)
        ratio, passed = retention(mean("net_work"), mean("rp_work"), 0.95)
        numeric_ratios = [row["rp_retention"] for row in members if row["rp_retention"] is not None]
        failed = [row["origin"] for row in members if not row["state90"]]
        result.append({**dict(zip(keys, identity, strict=True)), "states": len(members), "mean_work": mean("net_work"),
                       "mean_rp_work": mean("rp_work"), "mean_rp_retention": ratio, "mean95": passed,
                       "min_state_rp_retention": min(numeric_ratios, default=None), "all_states90": not failed,
                       "passes_both": passed and not failed, "states_below90": " ".join(failed),
                       "mean_executed_cut_on": mean("cut_on"), "mean_executed_reconnect_on": mean("reconnect_on"),
                       "mean_executed_passivation": mean("passivation"),
                       "mean_wait_real_scalars": mean("reconnect_real_scalars_completed_trials"),
                       "mean_wait_observations": mean("reconnect_control_observation_points_completed_trials"),
                       "mean_connected_observations": mean("connected_observation_points_completed_trials"),
                       **({"pooled_cap6_rate": sum(row["cap6_attempts"] for row in members) /
                                               sum(row["positive_wait_attempts"] for row in members),
                           "pooled_forced_rate": sum(row["forced_attempts"] for row in members) /
                                                 sum(row["positive_wait_attempts"] for row in members),
                           "mean_forced_net": mean("forced_net_work"),
                           "mean_forced_gross_losses": mean("forced_gross_losses")}
                          if identity[-1] == 540 else {})})
    return result


def group_effects(effects, dimension):
    keys = ("propagation", "group", "precision", "elapsed", dimension, "component")
    groups = defaultdict(list)
    for row in effects:
        groups[tuple(row[key] for key in keys)].append(row)
    for identity, members in groups.items():
        context = dict(zip(keys, identity, strict=True))
        measures = (key for key in members[0] if key not in context and key != "origin")
        yield {**context, "states": len(members),
               **{key: math.fsum(member[key] for member in members) / len(members) for key in measures}}


def gate_diagnostics(waits):
    buckets = defaultdict(list)
    keys = ("propagation", "group", "origin", "precision", "policy", "forced", "reconnect_veto")
    for row in waits:
        buckets[tuple(row[key] for key in keys)].append(row)
    for identity, members in buckets.items():
        count = len(members)
        yield {**dict(zip(keys, identity, strict=True)), "reconnections": count,
               "first_attempt": min(row["attempt"] for row in members),
               "last_attempt": max(row["attempt"] for row in members),
               "loss_attempts": sum(row["net_work"] < 0 for row in members),
               "gross_losses": math.fsum(-min(0, row["net_work"]) for row in members),
               "work": math.fsum(row["net_work"] for row in members),
               "mean_c0_real_fraction_abs": math.fsum(row["c0_real_fraction_abs"] or 0 for row in members) / count,
               "mean_delta_real": math.fsum(row["reconnect_re_minus_cut_re"] for row in members) / count}


def numerical_comparison(endpoints, trials):
    index = {(row["propagation"], row["group"], row["origin"], row["policy"], row["precision"]): row for row in endpoints}
    chronology = defaultdict(list)
    for row in trials:
        key = tuple(row[name] for name in ("propagation", "group", "origin", "policy", "precision"))
        chronology[key].append(tuple(row[name] for name in ("start_tick", "reconnect_tick", "forecast_decision_tick",
                                                            "end_tick", "accepted", "reconnect_reason", "stop_reason")))
    for group, origins in GROUPS.items():
        for origin in origins:
            for policy in POLICIES:
                base = ("rk4", group, origin, policy, "coarse")
                for label, alternate in (("half", ("rk4", group, origin, policy, "half")),
                                         ("exact_online", ("exact", group, origin, policy, "coarse"))):
                    if base not in index or alternate not in index:
                        continue
                    left, right = index[base], index[alternate]
                    path1, path2 = chronology[base], chronology[alternate]
                    first = next((i for i, pair in enumerate(zip(path1, path2), 1) if pair[0] != pair[1]), None)
                    if first is None and len(path1) != len(path2):
                        first = min(len(path1), len(path2)) + 1
                    yield {"group": group, "origin": origin, "policy": policy, "comparison": label,
                           "coarse_work": left["net_work"], "comparison_work": right["net_work"],
                           "work_difference": right["net_work"] - left["net_work"],
                           "same_work_sign": np.sign(left["net_work"]) == np.sign(right["net_work"]),
                           "same_state90": left["state90"] == right["state90"],
                           "same_chronology": first is None, "first_mismatch_attempt": first,
                           "coarse_at_first_mismatch": path1[first - 1] if first and first <= len(path1) else None,
                           "comparison_at_first_mismatch": path2[first - 1] if first and first <= len(path2) else None}


def policy_divergences(trials):
    keys = ("propagation", "group", "origin", "precision")
    lanes = defaultdict(lambda: defaultdict(list))
    for trial in trials:
        lanes[tuple(trial[name] for name in keys)][trial["policy"]].append(trial)
    contrasts = []
    for baseline, input_only, angle_only, both in FACTORIAL.values():
        contrasts.extend(((baseline, input_only), (baseline, angle_only), (baseline, both), (input_only, both), (angle_only, both)))
    contrasts.extend(zip(FACTORIAL["P3"], FACTORIAL["P1"], strict=True))
    action_fields = ("start_tick", "reconnect_tick", "end_tick", "accepted")
    description = (*action_fields, "tau", "forced", "cut_on", "reconnect_on", "passivation", "net_work")
    for identity, lane in lanes.items():
        context = dict(zip(keys, identity, strict=True))
        for left, right in contrasts:
            pairs = zip(lane[left], lane[right], strict=False)
            first = next(((a, b) for a, b in pairs if any(a[field] != b[field] for field in action_fields)), None)
            if first is None and len(lane[left]) != len(lane[right]):
                raise ValueError(f"Attempt counts differ without an earlier physical split in {context}")
            yield {**context, "left": left, "right": right, "same_physical_schedule": first is None,
                   "first_split_attempt": first[0]["attempt"] if first else None,
                   "common_start_hash": (first[0]["start_state_hash"] == first[1]["start_state_hash"]) if first else None,
                   **{f"{side}_{field}": first[i][field] if first else None
                      for i, side in enumerate(("left", "right")) for field in description}}


def m29_controls(endpoints):
    source = ROOT.parent / "Milestone_29" / "results" / "m29_endpoints.csv"
    previous = {(row["group"], row["origin"], row["policy"], row["precision"]): row for row in rows(source)}
    for row in endpoints:
        if row["propagation"] != "rk4" or row["policy"] not in ("RP", "P1", "P3"):
            continue
        group = "unseen" if row["group"] == "recheck" else row["group"]
        old = previous[group, row["origin"], row["policy"], row["precision"]]
        work = float(old["cumulative_physical_net"])
        yield {**{key: row[key] for key in ("group", "origin", "policy", "precision")},
               "m29_work": work, "m30_work": row["net_work"], "difference": row["net_work"] - work,
               "m29_attempts": int(old["attempts"]), "m30_attempts": row["attempts"]}


def information_design():
    for policy in POLICIES:
        p3 = policy.startswith("P3")
        has_input = policy.endswith(("+I", "+IA")) or policy == "RP"
        has_angle = policy.endswith(("+A", "+IA")) or policy == "RP"
        yield {"policy": policy, "precut_real_components": 1 if p3 and not has_input else 2,
               "wait_real_components_per_point": 1 if p3 and not (has_input or has_angle) else 2,
               "retained_reference_scalars": 1 + int(has_input),
               "retained_information": ("q0" if p3 else "c0_abs") + (" and c0_real" if has_input else ""),
               "equivalent_cached_values": "relative q threshold" + (" and admissible Re(c) maximum" if has_input else ""),
               "precut_hypot": int(not p3), "precut_abs": int(p3), "precut_multiply": 1,
               "precut_max": int(p3), "precut_add": int(has_input),
               "wait_hypot": int(not p3), "wait_atan2": int(has_angle),
               "wait_comparisons": 1 + int(not p3) + int(has_input) + 2 * int(has_angle),
               "wait_boolean_and": int(not p3) + int(has_input) + 2 * int(has_angle)}


def analyze(root, output, selected):
    trials, events, results, waits = [], [], [], []
    for group, origins in GROUPS.items():
        for origin in origins:
            if selected and origin not in selected:
                continue
            for propagation, parent, steps in (("rk4", "stages", PRECISIONS), ("exact", "exact_online", ("coarse",))):
                if propagation == "exact" and (group != "recheck" or origin not in ("U05", "U06")):
                    continue
                for precision in steps:
                    for policy in POLICIES:
                        path = root / parent / group / origin / policy / precision
                        meta = {"propagation": propagation, "group": group, "origin": origin, "precision": precision, "policy": policy}
                        a, b, c, d = read_branch(path, meta)
                        trials.extend(a)
                        events.extend(b)
                        results.extend(c)
                        waits.extend(d)
    output.mkdir(parents=True, exist_ok=True)
    effects, basis = compare(results)
    groups = group_means(results)
    endpoints = [row for row in results if row["elapsed"] == 540]
    for name, contents in (("endpoints", endpoints), ("timeline", results), ("group_metrics", groups),
                           ("factorial", effects), ("basis_contrasts", basis), ("trial_ledger", trials),
                           ("group_factorial", group_effects(effects, "base")),
                           ("group_basis_contrasts", group_effects(basis, "restored")),
                           ("work_events", events), ("wait_diagnostics", waits), ("veto_summary", gate_diagnostics(waits)),
                           ("numerical_comparison", numerical_comparison(endpoints, trials)),
                           ("policy_divergences", policy_divergences(trials)),
                           ("historical_controls", m29_controls(endpoints)), ("information_design", information_design())):
        table(output / f"m30_{name}.csv", contents)
    print(json.dumps({"endpoints": len(endpoints), "trials": len(trials), "work_events": len(events),
                      "wait_trials": len(waits), "protocol_sha256": registered_protocol()}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--origins", nargs="+")
    args = parser.parse_args()
    analyze(args.root, args.output or args.root / "results", args.origins)
