"""Inventory direct and causally certified stage outputs and verify source hashes."""

import argparse
from collections import Counter
import csv
from functools import lru_cache
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
REGISTERED_STAGES = ("150", "300", "540")


@lru_cache(maxsize=None)
def sha256(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def checkpoint_row(folder):
    with (folder / "m30_checkpoints.csv").open(encoding="utf-8", newline="") as stream:
        row, = csv.DictReader(stream)
    return row


def stage_origin(folder, row):
    manifest_path = folder / "equivalent_policy.json"
    if not manifest_path.is_file():
        role = "online_exact" if row["propagation"] == "exact" else "online_rk4"
        return dict(role=role, source_stage="", source_prefix="", source_checkpoint_sha256="",
                    source_history_sha256="", certified_completed_attempts=0, certified_wait_samples=0,
                    regenerated_cutoff=0, regenerated_pending_attempt=0,
                    regenerated_boundary_density_max_error="")
    proof = json.loads(manifest_path.read_text(encoding="utf-8"))
    source = (ROOT / proof["source"]).resolve()
    prefix = proof["source_prefix"]
    if sha256(source / "checkpoint.npz") != proof["source_checkpoint_sha256"]:
        raise ValueError(f"Source checkpoint differs from the certificate in {folder}")
    expected_history = proof["source_history_sha256"]
    if expected_history and sha256(source / f"{prefix}_history.csv") != expected_history:
        raise ValueError(f"Source trial ledger differs from the certificate in {folder}")
    if int(row["attempts_in_stage"]) != proof["same_first_choice_attempts"]:
        raise ValueError(f"Certified trial count differs from the target ledger in {folder}")
    return dict(role="certified_m30_peer" if prefix == "m30" else f"certified_{prefix}_archive",
                source_stage=Path(proof["source"]).as_posix(), source_prefix=prefix,
                source_checkpoint_sha256=proof["source_checkpoint_sha256"], source_history_sha256=expected_history,
                certified_completed_attempts=proof["same_first_choice_attempts"],
                certified_wait_samples=proof["scalar_samples"], regenerated_cutoff=1,
                regenerated_pending_attempt=int(bool(row["pending_attempt_elapsed"])),
                regenerated_boundary_density_max_error=proof["pending_direct_reproduction_density_max_error"])


def inventory(root):
    rows = []
    for category in ("stages", "exact_online"):
        for path in sorted((root / category).glob("*/*/*/*/t*/checkpoint.npz")):
            folder = path.parent
            if folder.name[1:] not in REGISTERED_STAGES:
                continue
            row = checkpoint_row(folder)
            rows.append({"result_set": category,
                         **{field: row[field] for field in ("group", "origin", "policy", "precision", "elapsed_total")},
                         "target_stage": folder.relative_to(root).as_posix(), **stage_origin(folder, row)})
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--output", type=Path, default=ROOT / "results")
    args = parser.parse_args()
    rows = inventory(args.root)
    if not rows:
        raise ValueError(f"No registered stage outputs found under {args.root}")
    args.output.mkdir(parents=True, exist_ok=True)
    with (args.output / "m30_provenance.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=rows[0])
        writer.writeheader()
        writer.writerows(rows)
    summary = {"stages": len(rows), "by_role": dict(Counter(row["role"] for row in rows)),
               **{field: sum(row[field] for row in rows) for field in ("regenerated_cutoff", "regenerated_pending_attempt",
                                                                     "certified_completed_attempts", "certified_wait_samples")}}
    (args.output / "m30_provenance.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
