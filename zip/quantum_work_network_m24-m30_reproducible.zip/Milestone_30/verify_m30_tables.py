"""Independently verify M30 publication tables against the operation ledgers."""

import argparse
from collections import Counter, defaultdict
import csv
import hashlib
from itertools import zip_longest
import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parent
ORIGINS = {
    "F2-R": ("S0", "A04", "B04", "C04"),
    "F1": ("S0", "A04", "B04", "C04"),
    "recheck": tuple(f"U{n:02}" for n in range(1, 7)),
}
MATRICES = {"P3": ("P3", "P3+I", "P3+A", "P3+IA"), "P1": ("P1", "P1+I", "P1+A", "RP")}
MODES = tuple(mode for matrix in MATRICES.values() for mode in matrix)
TIMEPOINTS = (50, 100, 150, 200, 300, 360, 450, 540)
STAGES = (150, 300, 540)
LANE = ("propagation", "group", "origin", "policy", "precision")
AMOUNTS = ("net_work", "cut_on", "reconnect_on", "passivation")
COUNTS = ("initial_real_scalars", "wait_real_scalars", "amplitude_evaluations", "angle_evaluations", "threshold_abs_initial")


def read(path):
    if path.is_file():
        with path.open(encoding="utf-8-sig", newline="") as stream:
            yield from csv.DictReader(stream)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def flag(value):
    require(value in ("True", "False"), f"Invalid boolean flag {value!r}")
    return value == "True"


def tick(value):
    milliseconds = round(float(value) * 1000)
    require(math.isclose(float(value), milliseconds / 1000, rel_tol=0, abs_tol=1e-10), f"Off-lattice clock {value}")
    return milliseconds


class Audit:
    def __init__(self, results):
        self.results = results
        self.rows = Counter()
        self.maximum_numeric_error = defaultdict(float)

    def match(self, expected, archived, name, context):
        for field, value in expected.items():
            require(field in archived, f"Missing {name}/{field} at {context}")
            observed = archived[field]
            if isinstance(value, float):
                difference = abs(value - float(observed))
                self.maximum_numeric_error[name] = max(self.maximum_numeric_error[name], difference)
                ok = math.isclose(value, float(observed), rel_tol=2e-13, abs_tol=2e-14)
            elif field == "states_below90":
                ok = sorted(value.split()) == sorted(observed.split())
            else:
                ok = ("" if value is None else str(value)) == observed
            require(ok, f"Mismatch {name}/{field} at {context}: expected {value!r}, got {observed!r}")

    def table(self, name, key, expected):
        actual = {}
        for row in read(self.results / f"m30_{name}.csv"):
            identity = tuple(row[field] for field in key)
            require(identity not in actual, f"Duplicate identity {name}/{identity}")
            actual[identity] = row
        count = 0
        for row in expected:
            identity = tuple(str(row[field]) for field in key)
            require(identity in actual, f"Missing {name}/{identity}")
            self.match(row, actual.pop(identity), name, identity)
            count += 1
        require(not actual, f"Unexpected {name} rows: {list(actual)[:3]}")
        self.rows[name] = count


def static_cost(mode):
    reduced = mode.startswith("P3")
    requires_input = mode in ("P3+I", "P3+IA", "P1+I", "RP")
    requires_angle = mode in ("P3+A", "P3+IA", "P1+A", "RP")
    return reduced, requires_input, requires_angle


def information_plan():
    for mode in MODES:
        reduced, with_input, with_angle = static_cost(mode)
        references = ("q0" if reduced else "c0_abs") + (" and c0_real" if with_input else "")
        cached = "relative q threshold" + (" and admissible Re(c) maximum" if with_input else "")
        field_count = 1 + (not reduced or with_input or with_angle)
        yield dict(policy=mode, precut_real_components=1 + (not reduced or with_input),
                   wait_real_components_per_point=field_count, retained_reference_scalars=1 + with_input,
                   retained_information=references, equivalent_cached_values=cached, precut_hypot=int(not reduced),
                   precut_abs=int(reduced), precut_multiply=1, precut_max=int(reduced), precut_add=int(with_input),
                   wait_hypot=int(not reduced), wait_atan2=int(with_angle),
                   wait_comparisons=1 + (not reduced) + with_input + 2 * with_angle,
                   wait_boolean_and=(not reduced) + with_input + 2 * with_angle)


def observed_veto(attempt, raw, witnesses):
    c0_real = -2 * attempt["cut_on"]
    c0_imag = -2 * float(raw["current_before"])
    magnitude = float(raw["c_abs_before"])
    lower, upper = -3 * math.pi / 4, -math.pi / 4
    after = [(float(point["c_real"]), float(point["c_imag"]), float(point["phase"]), float(point["wait_elapsed"]))
             for point in witnesses]
    input_clocks = [elapsed for real, _, _, elapsed in after if real <= c0_real + 1e-10]
    phase_clocks = [elapsed for _, _, phase, elapsed in after if lower <= phase <= upper]
    real, imag, phase, delay = after[-1]
    allow_input = delay in input_clocks
    allow_phase = delay in phase_clocks
    return {**attempt, "c0_real": c0_real, "c0_imag": c0_imag, "c0_amplitude": magnitude, "c0_phase": float(raw["phase_before"]),
            "c0_real_fraction_signed": c0_real / magnitude if magnitude else None,
            "c0_real_fraction_abs": abs(c0_real) / magnitude if magnitude else None,
            "first_input_pass_tau": min(input_clocks, default=None), "first_phase_pass_tau": min(phase_clocks, default=None),
            "input_pass_points_before_actual_reconnect": len(input_clocks), "phase_pass_points_before_actual_reconnect": len(phase_clocks),
            "at_reconnect_input_pass": allow_input, "at_reconnect_phase_pass": allow_phase,
            "reconnect_veto": ("" if allow_input else "I") + ("" if allow_phase else "A") or "none",
            "reconnect_re_minus_cut_re": real - c0_real, "reconnect_phase_margin": min(phase - lower, upper - phase),
            "reconnect_q": -imag}


def veto_counts(waits):
    group = defaultdict(list)
    labels = (*LANE, "forced", "reconnect_veto")
    for row in waits:
        group[tuple(row[key] for key in labels)].append(row)
    for identity, rows in group.items():
        ids = [row["attempt"] for row in rows]
        deficits = [row["net_work"] for row in rows if row["net_work"] < 0]
        yield {**dict(zip(labels, identity, strict=True)), "reconnections": len(rows),
               "first_attempt": min(ids), "last_attempt": max(ids), "loss_attempts": len(deficits),
               "gross_losses": -math.fsum(deficits), "work": math.fsum(row["net_work"] for row in rows),
               "mean_c0_real_fraction_abs": math.fsum(row["c0_real_fraction_abs"] or 0 for row in rows) / len(rows),
               "mean_delta_real": math.fsum(row["reconnect_re_minus_cut_re"] for row in rows) / len(rows)}


def branch(root, meta, audit):
    prop, group, origin, mode, precision = (meta[field] for field in LANE)
    directory = root / ("stages" if prop == "rk4" else "exact_online") / group / origin / mode / precision
    reduced, with_input, with_angle = static_cost(mode)
    through, attempts, waits, pending, source_counts = {}, [], [], [], Counter()
    last, fork = None, None
    for stage in STAGES:
        leaf = directory / f"t{stage}"
        summary, = read(leaf / "m30_checkpoints.csv")
        require(tick(summary["elapsed_total"]) == stage * 1000, f"Wrong checkpoint cutoff in {leaf}")
        start = tick(summary["fork_elapsed"])
        require(fork is None or fork == start, f"Fork differs across stages in {leaf}")
        if fork is None:
            last, fork = start, start
        source_counts["reused_stages" if (leaf / "equivalent_policy.json").is_file() else "direct_stages"] += 1
        checks = defaultdict(list)
        for point in read(leaf / "m30_wait_checks.csv"):
            checks[int(point["attempt"])].append(point)
        initial_count = len(attempts)
        for row in read(leaf / "m30_history.csv"):
            n = len(attempts) + 1
            require(n == int(row["attempt"]), f"Wrong trial number {leaf}/{n}")
            cut, delay, stop = (tick(row[field]) for field in ("elapsed_start", "tau", "elapsed_total"))
            rejoin = cut + delay
            require(cut == last and rejoin <= stop <= stage * 1000, f"Inconsistent operation timing {leaf}/{n}")
            last = stop
            accepted = flag(row["accepted"])
            cut_in, join_in, load = (float(row[field]) for field in ("cut_on", "reconnect_on", "direct_total_work"))
            load = load if accepted else 0.0
            recorded_net = float(row["net_work"])
            residual = abs(math.fsum((load, -cut_in, -join_in)) - recorded_net)
            require(residual <= 1e-12, f"Trial work does not close {leaf}/{n}: {residual}")
            witnesses = checks.pop(n, [])
            require(bool(witnesses) == bool(delay), f"Wrong wait witness presence {leaf}/{n}")
            if delay:
                delays = tuple(tick(sample["wait_elapsed"]) for sample in witnesses)
                require(delays == tuple(range(1000, delay + 1, 200))
                        and all(tick(sample["elapsed_total"]) == cut + elapsed for sample, elapsed in zip(witnesses, delays, strict=True)),
                        f"Incomplete wait observations {leaf}/{n}")
            force = bool(witnesses and not flag(witnesses[-1]["phase_gate"]))
            cap6 = delay == 6000
            if force:
                limit = 200 * (min(6000, tick(row["window"]) - 20) // 200)
                require(delay == limit, f"Forced reconnect happened before its available limit {leaf}/{n}")
            require(force == flag(row["fallback_limit"]) == (row["wait_reason"] == "phase_limit")
                    and (force and cap6) == flag(row["fallback_max_wait"]) and (force and not cap6) == flag(row["fallback_window_limit"]),
                    f"Force flags disagree {leaf}/{n}")
            begin_width = 1 + (not reduced or with_input)
            repeat_width = 1 + (not reduced or with_input or with_angle)
            observations = len(witnesses) + bool(delay)
            begin, repeat = int(bool(delay)) * begin_width, len(witnesses) * repeat_width
            attempt = {**meta, "attempt": n, "start_tick": cut, "reconnect_tick": rejoin, "end_tick": stop,
                       "tau": delay / 1000, "accepted": accepted, "stop_reason": row["stop_reason"],
                       "reconnect_reason": row["wait_reason"], "forced": force, "at_max_wait": cap6,
                       "cut_on": cut_in, "reconnect_on": join_in, "passivation": load, "net_work": recorded_net,
                       "observed_scalars": begin + repeat, "decision_observations": observations,
                       "wait_observations": len(witnesses), "initial_real_scalars": begin, "wait_real_scalars": repeat,
                       "amplitude_evaluations": observations if not reduced else 0,
                       "angle_evaluations": len(witnesses) if with_angle else 0,
                       "threshold_abs_initial": int(reduced and bool(delay))}
            audit.match({"observed_scalars": begin + repeat, "decision_observations": observations,
                         "initial_reconnect_scalars": begin, "wait_reconnect_scalars": repeat,
                         "wait_phase_observations": len(witnesses), "reconnect_a_observations": (stop - rejoin) // 20 + 1},
                        row, "raw_trial_acquisition", (str(leaf), n))
            audit.rows["raw_trial_acquisition"] += 1
            attempts.append(attempt)
            if witnesses:
                waits.append(observed_veto(attempt, row, witnesses))
        require(not checks, f"Wait witnesses remain without trials in {leaf}")
        require(len(attempts) == int(summary["attempts"]) and len(attempts) - initial_count == int(summary["attempts_in_stage"]),
                f"Trial count differs at {leaf}")
        checkpoint_net = math.fsum(row["net_work"] for row in attempts)
        switch = float(summary["pending_switch_net"])
        audit.match({"cumulative_net": checkpoint_net, "cumulative_physical_net": checkpoint_net + switch}, summary,
                    "checkpoint_work", str(leaf))
        audit.rows["checkpoint_work"] += 1
        through[stage] = checkpoint_net + switch
        if stage == 540:
            pending_start = tick(summary["pending_attempt_elapsed"]) if summary["pending_attempt_elapsed"] else None
            if flag(summary["cut_applied"]):
                require(pending_start is not None, f"Pending switch has no attempt clock at {leaf}")
                if flag(summary["reconnect_applied"]):
                    starting = -float(summary["pending_cut_on"])
                    pending.extend(((pending_start, "cut", starting, len(attempts) + 1),
                                    (pending_start + int(summary["pending_tau_tick"]), "reconnect", switch - starting, len(attempts) + 1)))
                else:
                    pending.append((pending_start, "cut", switch, len(attempts) + 1))
    return fork, attempts, waits, pending, source_counts, through


def endpoint_force(attempts):
    waiters = sum(row["tau"] > 0 for row in attempts)
    cap6 = sum(row["at_max_wait"] for row in attempts)
    forced = sum(row["forced"] for row in attempts)
    forced6 = sum(row["forced"] and row["at_max_wait"] for row in attempts)
    output = {"positive_wait_attempts": waiters, "cap6_attempts": cap6, "forced_attempts": forced,
              "cap6_rate": cap6 / waiters if waiters else None, "forced_rate": forced / waiters if waiters else None,
              "forced_cap6_attempts": forced6, "forced_short_deadline_attempts": forced - forced6,
              "cap6_passed_attempts": cap6 - forced6}
    buckets = {"forced": [row for row in attempts if row["forced"]],
               "forced_cap6": [row for row in attempts if row["forced"] and row["at_max_wait"]],
               "forced_deadline": [row for row in attempts if row["forced"] and not row["at_max_wait"]],
               "condition_or_no_wait": [row for row in attempts if not row["forced"]]}
    for name, rows in buckets.items():
        output.update({f"{name}_{key}": math.fsum(row[key] for row in rows) for key in AMOUNTS})
        deficits = [row["net_work"] for row in rows if row["net_work"] < 0]
        output.update({f"{name}_loss_attempts": len(deficits), f"{name}_gross_losses": -math.fsum(deficits)})
    return output


def timeline(meta, fork, attempts, pending, source_counts, through):
    events = list(pending)
    for row in attempts:
        if row["tau"]:
            events.extend(((row["start_tick"], "cut", -row["cut_on"], row["attempt"]),
                           (row["reconnect_tick"], "reconnect", -row["reconnect_on"], row["attempt"])))
        if row["accepted"]:
            events.append((row["end_tick"], "passivation", row["passivation"], row["attempt"]))
    summaries = []
    for elapsed in TIMEPOINTS:
        cutoff = 1000 * elapsed
        if cutoff < fork:
            continue
        closed = [row for row in attempts if row["end_tick"] <= cutoff]
        work = {event: math.fsum(amount for when, operation, amount, _ in events if when <= cutoff and operation == event)
                for event in ("cut", "reconnect", "passivation")}
        physical = math.fsum(work.values())
        if elapsed in through:
            require(abs(through[elapsed] - physical) <= 1e-12, f"Event prefix differs from physical checkpoint {meta}/{elapsed}")
        closed_work = math.fsum(row["net_work"] for row in closed)
        connected_points = sum(1 + (min(cutoff, row["end_tick"]) - row["reconnect_tick"]) // 20
                               for row in attempts if row["reconnect_tick"] <= cutoff)
        started = sum(event == "cut" and when <= cutoff for when, event, _, _ in events)
        fields = {**meta, "elapsed": elapsed, "fork_elapsed": fork / 1000, "net_work": physical, "cut_on": -work["cut"],
                  "reconnect_on": -work["reconnect"], "passivation": work["passivation"], "completed_trial_net": closed_work,
                  "executed_pending_switch_net": physical - closed_work,
                  "rate": physical / ((cutoff - fork) / 1000) if cutoff > fork else None,
                  "attempts": len(closed), "accepted": sum(row["accepted"] for row in closed), "positive_waits_started": started,
                  "connected_observation_points_completed_trials": connected_points,
                  "reconnect_control_observation_points_completed_trials": sum(row["decision_observations"] for row in closed),
                  "reconnect_real_scalars_completed_trials": sum(row["observed_scalars"] for row in closed),
                  **{key: sum(row[key] for row in closed) for key in COUNTS}}
        if elapsed == 540:
            fields.update(endpoint_force(closed))
            fields.update(source_counts)
        summaries.append(fields)
    output_events = [{**meta, "elapsed": when / 1000, "operation": operation, "work_to_user": amount, "attempt": n}
                     for when, operation, amount, n in events]
    return summaries, output_events


def passes(work, ref, fraction):
    return (None, work + 1e-10 >= ref) if ref <= 1e-10 else (work / ref, work >= fraction * ref)


def contrasts(row_index):
    effects, basis = [], []
    for (prop, group, origin, precision, elapsed), values in row_index.items():
        identity = dict(propagation=prop, group=group, origin=origin, precision=precision, elapsed=elapsed)
        rp = values["RP"]["net_work"]
        for row in values.values():
            work = row["net_work"]
            ratio, meets = passes(work, rp, 0.9)
            row.update(rp_work=rp, rp_delta=work - rp, rp_retention=ratio, state90=meets)
        for measure in AMOUNTS:
            for base, modes in MATRICES.items():
                zero, input_only, angle_only, joint = (values[method][measure] for method in modes)
                effect_input = input_only - zero
                effect_after_angle = joint - angle_only
                effects.append({**identity, "base": base, "component": measure,
                                "none": zero, "input_only": input_only, "phase_only": angle_only, "both": joint,
                                "input_effect_no_phase": effect_input, "input_effect_with_phase": effect_after_angle,
                                "phase_effect_no_input": angle_only - zero, "phase_effect_with_input": joint - input_only,
                                "both_effect": joint - zero, "interaction": effect_after_angle - effect_input})
            for i, label in enumerate(("none", "input", "phase", "both")):
                p3, p1 = (values[MATRICES[name][i]][measure] for name in ("P3", "P1"))
                basis.append({**identity, "restored": label, "component": measure, "p3": p3, "p1": p1, "p3_minus_p1": p3 - p1})
    return effects, basis


def group_results(summaries):
    grouped = defaultdict(list)
    fields = ("propagation", "group", "precision", "policy", "elapsed")
    for row in summaries:
        grouped[tuple(row[key] for key in fields)].append(row)
    for key, rows in grouped.items():
        def average(column):
            return math.fsum(row[column] for row in rows) / len(rows)

        mean, reference = average("net_work"), average("rp_work")
        ratio, group95 = passes(mean, reference, 0.95)
        all90 = all(row["state90"] for row in rows)
        ratios = [row["rp_retention"] for row in rows if row["rp_retention"] is not None]
        expected = {**dict(zip(fields, key, strict=True)), "states": len(rows), "mean_work": mean, "mean_rp_work": reference,
                    "mean_rp_retention": ratio, "mean95": group95, "all_states90": all90, "passes_both": group95 and all90,
                    "min_state_rp_retention": min(ratios, default=None),
                    "states_below90": " ".join(row["origin"] for row in rows if not row["state90"]),
                    "mean_executed_cut_on": average("cut_on"), "mean_executed_reconnect_on": average("reconnect_on"),
                    "mean_executed_passivation": average("passivation"),
                    "mean_wait_real_scalars": average("reconnect_real_scalars_completed_trials"),
                    "mean_wait_observations": average("reconnect_control_observation_points_completed_trials"),
                    "mean_connected_observations": average("connected_observation_points_completed_trials")}
        if key[-1] == 540:
            total = sum(row["positive_wait_attempts"] for row in rows)
            expected.update(pooled_cap6_rate=sum(row["cap6_attempts"] for row in rows) / total,
                            pooled_forced_rate=sum(row["forced_attempts"] for row in rows) / total,
                            mean_forced_net=average("forced_net_work"), mean_forced_gross_losses=average("forced_gross_losses"))
        yield expected


def group_contrasts(contrasts, dimension):
    columns = ("propagation", "group", "precision", "elapsed", dimension, "component")
    grouped = defaultdict(list)
    for row in contrasts:
        grouped[tuple(row[key] for key in columns)].append(row)
    for key, rows in grouped.items():
        context = dict(zip(columns, key, strict=True))
        numeric = set(rows[0]).difference(context, {"origin"})
        yield {**context, "states": len(rows), **{key: math.fsum(row[key] for row in rows) / len(rows) for key in numeric}}


def convergence(ends, paths):
    for identity, coarse in ends.items():
        prop, group, origin, mode, precision = identity
        if (prop, precision) != ("rk4", "coarse"):
            continue
        for label, sibling in (("half", ("rk4", group, origin, mode, "half")),
                               ("exact_online", ("exact", group, origin, mode, "coarse"))):
            if sibling not in ends:
                continue
            other = ends[sibling]
            first, left, right = None, None, None
            for n, (a, b) in enumerate(zip_longest(paths[identity], paths[sibling]), 1):
                if a != b:
                    first, left, right = n, a, b
                    break
            x, y = coarse["net_work"], other["net_work"]
            same_sign = (x > 0, x < 0) == (y > 0, y < 0)
            yield dict(group=group, origin=origin, policy=mode, comparison=label, coarse_work=x, comparison_work=y,
                       work_difference=y - x, same_work_sign=same_sign, same_state90=coarse["state90"] == other["state90"],
                       same_chronology=first is None, first_mismatch_attempt=first,
                       coarse_at_first_mismatch=left, comparison_at_first_mismatch=right)


def verify(root, results, origins):
    protocol = hashlib.sha256((ROOT / "PROTOCOL_M30.md").read_bytes()).hexdigest()
    require((ROOT / "protocol.sha256").read_text(encoding="ascii").strip() == protocol, "Protocol digest disagrees")
    if (root / "protocol.sha256").is_file():
        require((root / "protocol.sha256").read_text(encoding="ascii").strip() == protocol, "Output protocol digest disagrees")
    audit = Audit(results)
    timeline_rows, trial_rows, events, waits, histories = [], [], [], [], {}
    for group, names in ORIGINS.items():
        for origin in names:
            if origins and origin not in origins:
                continue
            choices = [("rk4", "coarse"), ("rk4", "half")]
            if group == "recheck" and origin in ("U05", "U06"):
                choices.append(("exact", "coarse"))
            for prop, precision in choices:
                for policy in MODES:
                    meta = dict(propagation=prop, group=group, origin=origin, policy=policy, precision=precision)
                    fork, attempts, witnesses, pending, sources, through = branch(root, meta, audit)
                    times, operations = timeline(meta, fork, attempts, pending, sources, through)
                    timeline_rows.extend(times)
                    trial_rows.extend(attempts)
                    events.extend(operations)
                    waits.extend(witnesses)
                    histories[tuple(meta[key] for key in LANE)] = [tuple(row[field] for field in (
                        "start_tick", "reconnect_tick", "end_tick", "accepted")) for row in attempts]
    require(bool(histories), "No branches selected")
    ladders = defaultdict(dict)
    for row in timeline_rows:
        key = tuple(row[field] for field in ("propagation", "group", "origin", "precision", "elapsed"))
        ladders[key][row["policy"]] = row
    effects, basis = contrasts(ladders)
    ends = {tuple(row[field] for field in LANE): row for row in timeline_rows if row["elapsed"] == 540}
    require(ends.keys() == histories.keys(), "Endpoint coverage differs from branch coverage")
    if not origins:
        require(len(ends) == 240, f"Expected 224 RK4 and 16 exact endpoints, found {len(ends)}")
    group_keys = ("propagation", "group", "precision", "policy", "elapsed")
    contrast_keys = ("propagation", "group", "precision", "elapsed", "component")
    audit.table("trial_ledger", (*LANE, "attempt"), trial_rows)
    # Floating clock representations may be formatted differently in the two CSV paths.
    audit.table("work_events", (*LANE, "attempt", "operation"), events)
    audit.table("wait_diagnostics", (*LANE, "attempt"), waits)
    audit.table("veto_summary", (*LANE, "forced", "reconnect_veto"), veto_counts(waits))
    audit.table("timeline", (*LANE, "elapsed"), timeline_rows)
    audit.table("endpoints", (*LANE, "elapsed"), ends.values())
    audit.table("group_metrics", group_keys, group_results(timeline_rows))
    audit.table("factorial", (*contrast_keys, "origin", "base"), effects)
    audit.table("basis_contrasts", (*contrast_keys, "origin", "restored"), basis)
    audit.table("group_factorial", (*contrast_keys, "base"), group_contrasts(effects, "base"))
    audit.table("group_basis_contrasts", (*contrast_keys, "restored"), group_contrasts(basis, "restored"))
    comparisons = list(convergence(ends, histories))
    audit.table("numerical_comparison", ("group", "origin", "policy", "comparison"), comparisons)
    audit.table("information_design", ("policy",), information_plan())
    return dict(status="passed", protocol_sha256=protocol, origins=origins or "all", trajectories=len(ends), rows_checked=dict(audit.rows),
                maximum_numeric_error=dict(audit.maximum_numeric_error),
                numerical_comparisons=dict(Counter(row["comparison"] for row in comparisons)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--origins", nargs="+")
    args = parser.parse_args()
    results = args.results or args.root / "results"
    output = args.output or results / "audit_publication.json"
    summary = verify(args.root, results, args.origins)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
