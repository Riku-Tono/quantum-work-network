"""Independently reproduce the U05 fork and check the archived continuations."""

import argparse
from collections import defaultdict
import json
import math
from pathlib import Path

import verify_m30 as audit


ROOT = audit.ROOT
READ = audit.a27.read_rows
INSIST, TOLERANCE = audit.INSIST, audit.TOLERANCE
TICKS, NUMBER, FLAG = audit.TICKS, audit.NUMBER, audit.FLAG
RESOLUTIONS = audit.RESOLUTIONS
IDENTITY = ("propagation", "precision", "policy")


def by_identity(path):
    return audit.a27.read_unique(READ(path), lambda row: tuple(row[key] for key in IDENTITY))


def archive_separations(data):
    cases = READ(data / "first_separation_m29.csv")
    INSIST({(row["comparison"], row["precision"]) for row in cases} ==
           {(comparison, resolution) for comparison in ("RP–P1", "RP–P3") for resolution in RESOLUTIONS},
           "Missing M29 U05 first separation cases")
    for row in cases:
        _, policy = row["comparison"].split("–")
        resolution = row["precision"]
        archive = audit.M29 / "stages" / "t150" / "unseen" / "U05"
        rp, changed = (READ(archive / method / resolution / "m29_history.csv") for method in ("RP", policy))
        names = ("tau", "elapsed_start", "elapsed_total", "decision_elapsed_total", "accepted")
        first = next((index for index, (a, b) in enumerate(zip(rp, changed, strict=False))
                      if any(a[field] != b[field] for field in names)), None)
        INSIST(first is not None and first + 1 == int(row["attempt"]), f"Wrong first U05 divergence for {policy}/{resolution}")
        for label in RESOLUTIONS:
            field = f"start_{label}_sha256"
            INSIST(row[field] == rp[first][field] == changed[first][field], f"U05 separation source differs for {policy}/{resolution}")
    return cases


def check_wait(model, state, row, samples, policy, context):
    start, tau = TICKS(row, "elapsed_start"), TICKS(row, "tau")
    clocks = (0, *range(1000, tau + 1, 200))
    INSIST(len(samples) == len(clocks), f"Wrong number of U05 wait records at {context}")
    first = complex(model.detached_c(state, 0))
    first_row = samples[0]
    before = (-NUMBER(first_row, "c_imag"), NUMBER(first_row, "c_abs"), NUMBER(first_row, "c_real"))
    for point, delay in zip(samples, clocks, strict=True):
        clock = start + delay
        INSIST(TICKS(point, "elapsed_total") == TICKS(point, "observed_until") == clock
               and TICKS(point, "wait_elapsed") == delay and FLAG(point, "condition_evaluated") == (delay > 0),
               f"U05 wait witness uses future data at {context}/{delay}")
        c = first if delay == 0 else complex(model.detached_c(state, delay))
        real, imag, amplitude, angle = (NUMBER(point, field) for field in ("c_real", "c_imag", "c_abs", "phase"))
        TOLERANCE(real, c.real, f"Independent U05 real coherence at {context}/{delay}", 1e-12)
        TOLERANCE(imag, c.imag, f"Independent U05 imaginary coherence at {context}/{delay}", 1e-12)
        TOLERANCE(amplitude, abs(c), f"Independent U05 coherence magnitude at {context}/{delay}", 1e-12)
        TOLERANCE(math.remainder(angle - math.atan2(c.imag, c.real), math.tau), 0.0,
                  f"Independent U05 phase at {context}/{delay}", 1e-8)
        checks = audit.components(before, (real, imag, amplitude, angle))
        check_fields = ("input_pass", "phase_pass", "amplitude_pass", "p1_current_pass", "p3_current_pass")
        passed = audit.gate(policy, checks)
        forced = delay == 6000 and not passed
        INSIST(tuple(FLAG(point, field) for field in check_fields) == checks
               and FLAG(point, "rp_pass") == audit.gate("RP", checks)
               and FLAG(point, "policy_pass") == passed and FLAG(point, "reconnect") == (delay == tau)
               and (delay == 0 or (passed or forced) == (delay == tau))
               and FLAG(point, "forced_reconnect") == forced, f"U05 gate, first reconnection or fallback differs at {context}/{delay}")


def check_trajectory(data, base, mode, precision, policy, row, transition, continuation, samples):
    track = data / mode / precision
    current = track / policy
    model = audit.audited_model(mode == "exact")
    marker = precision if mode == "rk4" else ""
    ctx = mode, precision, policy
    with audit.a27.np.load(track / "fork_pre_cut.npz", allow_pickle=False) as start:
        fork = int(start["tick"].item())
        t0 = float(start["source_time"].item())
        initial = audit.a27.State(start[precision], t0 + fork / 1000, marker)
        INSIST(fork == TICKS(row, "elapsed_start"), f"U05 first attempt starts from a different clock at {ctx}")
        for label in RESOLUTIONS:
            INSIST(audit.a27.state_sha256(start[label]) == row[f"start_{label}_sha256"],
                   f"U05 common fork density changed at {ctx}/{label}")
    check_wait(model, initial, row, samples, policy, ctx)
    approved = FLAG(row, "accepted")
    wait, connected = (TICKS(row, field) for field in ("tau", "connected_duration"))
    action = audit.a27.exact_action(model, initial, wait, connected, approved)
    with audit.a27.np.load(current / "next_pre_cut.npz", allow_pickle=False) as saved:
        INSIST(int(saved["tick"].item()) == TICKS(row, "elapsed_total"), f"U05 next trial starts at another clock at {ctx}")
        for label in RESOLUTIONS:
            INSIST(audit.a27.state_sha256(saved[label]) == row[f"post_{label}_sha256"],
                   f"U05 first-trial exit density changed at {ctx}/{label}")
        actual = saved[precision]
        error = audit.a27.maxabs(actual - action.after.matrix)
        TOLERANCE(error, 0.0, f"Independent U05 first trial exit density at {ctx}", 1e-12)
        after = audit.a27.State(actual, action.after.time, marker)
    passivation = model.energy(action.before) - model.energy(action.after)
    expected_net = passivation - action.cut - action.reconnect
    for field, value in (("cut_input", action.cut), ("reconnect_input", action.reconnect),
                         ("passivation_work", passivation), ("net_work", expected_net)):
        TOLERANCE(row[field], value, f"Independently replayed U05 {field} at {ctx}", 1e-12)
    end = TICKS(row, "elapsed_total")
    next_wait = TICKS(transition, "next_trial_tau")
    next_connected = TICKS(transition, "next_trial_end_elapsed") - end - next_wait
    next_action = audit.a27.exact_action(model, after, next_wait, next_connected, FLAG(transition, "next_trial_passivation_accepted"))
    TOLERANCE(transition["next_trial_net_work"], next_action.observed_work, f"U05 next trial work at {ctx}", 1e-12)
    TOLERANCE(transition["next_trial_reconnect_input"], next_action.reconnect, f"U05 next trial reconnect input at {ctx}", 1e-12)
    native = base / ("stages" if mode == "rk4" else "exact_online") / "recheck" / "U05" / policy / precision
    relative = current / "standalone" if continuation["method"] == "standalone_from_saved_fork" else native
    INSIST(continuation["method"] in ("standalone_from_saved_fork", "matched_native_continuation"),
           f"Unknown U05 continuation provenance at {ctx}")
    checkpoint, = READ(relative / "t540" / "m30_checkpoints.csv")
    absolute = NUMBER(continuation, "absolute_through_540_work")
    from_fork = NUMBER(continuation, "fork_to_540_work")
    prefix_work = NUMBER(continuation, "absolute_prefix_work")
    independent_checkpoint = NUMBER(checkpoint, "cumulative_net") + NUMBER(checkpoint, "pending_switch_net")
    if continuation["method"] == "standalone_from_saved_fork":
        independent_checkpoint += prefix_work
    TOLERANCE(absolute, independent_checkpoint, f"U05 continuation endpoint at {ctx}", 1e-12)
    TOLERANCE(absolute, prefix_work + from_fork, f"U05 full work event partition at {ctx}", 1e-12)
    TOLERANCE(from_fork, expected_net + NUMBER(continuation, "post_trial_to_540_work"),
              f"U05 trial and downstream work partition at {ctx}", 1e-12)
    if continuation["method"] == "matched_native_continuation":
        first_rows = READ(native / "t150" / "m30_history.csv")
        index = int(row["attempt"]) - 1
        INSIST(first_rows[index]["start_coarse_sha256"] == row["start_coarse_sha256"]
               and first_rows[index]["post_coarse_sha256"] == row["post_coarse_sha256"]
               and first_rows[index + 1]["start_coarse_sha256"] == row["post_coarse_sha256"],
               f"U05 continuation seam differs at {ctx}")
    return {"fork_elapsed": fork / 1000, "first_trial_exit_density_max_element_error": error,
            "audited_wait_records": len(samples), "endpoint_work": absolute}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--u05", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    data = args.u05 or args.root / "u05"
    cases = archive_separations(data)
    trial = by_identity(data / "trial6_summary.csv")
    transitions = by_identity(data / "trial7_pre_cut_and_transition.csv")
    continuations = by_identity(data / "continuation_to_540.csv")
    waits = defaultdict(list)
    for row in READ(data / "trial6_wait_samples.csv"):
        waits[tuple(row[key] for key in IDENTITY)].append(row)
    inventory = {(mode, precision, policy) for mode, precision in (("rk4", "coarse"), ("rk4", "half"), ("exact", "coarse"))
                 for policy in audit.METHODS}
    INSIST(trial.keys() == transitions.keys() == continuations.keys() == waits.keys() == inventory,
           "Incomplete U05 fork or continuation table")
    validated = {"/".join(key): check_trajectory(data, args.root, *key, trial[key], transitions[key], continuations[key], waits[key])
                 for key in trial}
    output = args.output or args.root / "results" / "audit_u05_common_fork.json"
    audit.write_json(output, {"protocol_sha256": audit.a27.sha256(ROOT / "PROTOCOL_M30.md"),
                              "archived_first_separation_count": len(cases), "verified_trajectories": validated})
    print(json.dumps({"audited_trajectories": len(validated), "archive_divergences": len(cases)}))


if __name__ == "__main__":
    main()
