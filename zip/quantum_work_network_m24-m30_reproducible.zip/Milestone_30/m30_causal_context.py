"""Describe the first observed baseline-eligible wait samples without threshold fitting."""

import argparse
from collections import Counter, defaultdict
import csv
from itertools import groupby
from pathlib import Path
from math import fsum, pi
from statistics import median

from run_m30 import CUTOFFS, GROUPS, POLICIES, PRECISIONS, registered_protocol

ROOT = Path(__file__).resolve().parent
G = 0.25
WORK_FLOOR = 1e-12
EARLY_ELAPSED = 50.0
PATTERNS = ("both_pass", "input_only_veto", "angle_only_veto", "both_veto", "no_baseline_point")
FEATURES = ("precut_real", "precut_q", "precut_abs", "precut_real_fraction",
            "candidate_wait", "candidate_q", "candidate_switch_input", "candidate_phase_margin")


def read_rows(path):
    if path.exists():
        with path.open(encoding="utf-8", newline="") as stream:
            yield from csv.DictReader(stream)


def write_rows(path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def flag(row, key):
    return row[key] == "True"


def baseline_pass(check, policy):
    if policy.startswith("P3"):
        return flag(check, "gate_current_p3")
    return flag(check, "gate_current_p1") and flag(check, "gate_amplitude")


def pattern(check):
    if check is None:
        return "no_baseline_point"
    passed_i = flag(check, "gate_input")
    passed_a = flag(check, "gate_angle")
    if passed_i and passed_a:
        return "both_pass"
    if passed_a:
        return "input_only_veto"
    if passed_i:
        return "angle_only_veto"
    return "both_veto"


def candidate_row(trial, checks):
    policy = trial["policy"]
    if any(float(check["observed_until"]) > float(check["elapsed_total"]) for check in checks):
        raise ValueError("A recorded wait observation is in the future")
    if (not flag(checks[-1], "reconnect") or any(flag(check, "reconnect") for check in checks[:-1])
            or float(checks[-1]["wait_elapsed"]) != float(trial["tau"])):
        raise ValueError("The wait log does not end at the only reconnect sample")
    first = next((check for check in checks if baseline_pass(check, policy)), None)
    real, imag = float(trial["c_real_before"]), float(trial["c_imag_before"])
    absolute = float(trial["c_abs_before"])
    elapsed = float(trial["elapsed_start"])
    elapsed_after_fork = (round(1000 * elapsed) - round(1000 * float(trial["fork_elapsed"]))) / 1000
    proposed_switch = None if first is None else 2 * G * (float(first["c_real"]) - real)
    phase = None if first is None else float(first["phase"])
    reconnect_at_candidate = first is not None and flag(first, "reconnect")
    other_base = "P1" if policy.startswith("P3") else "P3"
    return {**{key: trial[key] for key in ("group", "origin", "policy", "precision", "propagation", "attempt")},
            "base": "P3" if policy.startswith("P3") else "P1",
            "precut_elapsed": elapsed, "elapsed_from_fork": elapsed_after_fork,
            "precut_real": real, "precut_q": -imag, "precut_abs": absolute,
            "precut_real_fraction": abs(real) / absolute if absolute else None,
            "during_first_50": elapsed_after_fork < EARLY_ELAPSED,
            "candidate_pattern": pattern(first),
            "candidate_wait": float(first["wait_elapsed"]) if first is not None else None,
            "candidate_q": -float(first["c_imag"]) if first is not None else None,
            "candidate_real": float(first["c_real"]) if first is not None else None,
            "candidate_abs": float(first["c_abs"]) if first is not None else None,
            "candidate_phase": phase,
            "candidate_phase_margin": min(phase + 3 * pi / 4, -pi / 4 - phase) if phase is not None else None,
            "candidate_input_margin": float(first["input_margin"]) if first is not None else None,
            "candidate_switch_input": proposed_switch,
            "candidate_other_baseline_pass": baseline_pass(first, other_base) if first is not None else None,
            "actual_reconnect_at_candidate": reconnect_at_candidate,
            "actual_reconnect_wait": float(trial["tau"]),
            "actual_reconnect_forced": flag(trial, "fallback_limit"),
            "actual_trial_net": float(trial["net_work"]),
            "actual_trial_passivation_work": float(trial["passivation_work"])}


def collect(path):
    for cutoff in CUTOFFS:
        folder = path / f"t{cutoff // 1000}"
        if not (folder / "m30_checkpoints.csv").is_file():
            raise FileNotFoundError(f"Missing completed M30 stage {folder}")
        attempts = dict(groupby_waits(folder / "m30_wait_checks.csv"))
        for trial in read_rows(folder / "m30_history.csv"):
            waiting = attempts.pop(trial["attempt"], None)
            if float(trial["tau"]) > 0:
                if waiting is None:
                    raise ValueError(f"Positive wait without observations: {folder}, trial {trial['attempt']}")
                yield candidate_row(trial, waiting)
            elif waiting is not None:
                raise ValueError(f"Nonwaiting trial has observations: {folder}, trial {trial['attempt']}")
        if attempts:
            raise ValueError(f"Orphaned wait observations: {folder}")


def groupby_waits(path):
    for attempt, checks in groupby(read_rows(path), key=lambda row: row["attempt"]):
        yield attempt, list(checks)


def stratified(rows):
    for key, grouped in sorted(rows.items()):
        propagation, precision, group, origin, policy = key
        for period, selected in (
                ("all", grouped), ("first_50", [r for r in grouped if r["during_first_50"]]),
                ("after_50", [r for r in grouped if not r["during_first_50"]])):
            counts = Counter(r["candidate_pattern"] for r in selected)
            connected_at_first = [r for r in selected if r["actual_reconnect_at_candidate"]]
            input_deficit = [r for r in connected_at_first
                             if r["candidate_switch_input"] > WORK_FLOOR and r["actual_trial_net"] < -WORK_FLOOR]
            yield {"propagation": propagation, "precision": precision, "group": group,
                   "origin": origin, "policy": policy, "elapsed_from_fork_window": period,
                   "waiting_trials": len(selected), **{name: counts[name] for name in PATTERNS},
                   "observed_baseline_candidates": len(selected) - counts["no_baseline_point"],
                   "actual_reconnect_at_candidate": len(connected_at_first),
                   "actual_reconnect_at_candidate_with_switch_input_and_net_loss": len(input_deficit),
                   "actual_reconnect_at_candidate_with_switch_input_and_net_loss_sum": fsum(r["actual_trial_net"] for r in input_deficit)}


def feature_ranges(rows):
    grouped = defaultdict(list)
    for row in rows:
        if row["policy"] not in ("P1", "P3"):
            continue
        meta = tuple(row[key] for key in ("propagation", "precision", "group", "policy"))
        for period in ("all", "first_50" if row["during_first_50"] else "after_50"):
            grouped[(*meta, period, row["candidate_pattern"])].append(row)
    for key, selected in sorted(grouped.items()):
        meta = dict(zip(("propagation", "precision", "group", "policy", "elapsed_from_fork_window", "candidate_pattern"),
                        key, strict=True))
        for feature in FEATURES:
            values = [row[feature] for row in selected if row[feature] is not None]
            yield {**meta, "feature": feature, "count": len(values),
                   "minimum": min(values, default=None), "median": median(values) if values else None,
                   "maximum": max(values, default=None)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stages", type=Path, default=ROOT / "stages")
    parser.add_argument("--output", type=Path, default=ROOT / "results")
    parser.add_argument("--groups", nargs="+", choices=GROUPS, default=tuple(GROUPS))
    parser.add_argument("--origins", nargs="+")
    parser.add_argument("--policies", nargs="+", choices=POLICIES, default=POLICIES)
    parser.add_argument("--precisions", nargs="+", choices=PRECISIONS, default=PRECISIONS)
    args = parser.parse_args()
    registered_protocol()
    all_rows = defaultdict(list)
    for group in args.groups:
        for origin in GROUPS[group]:
            if args.origins is not None and origin not in args.origins:
                continue
            for policy in args.policies:
                for precision in args.precisions:
                    path = args.stages / group / origin / policy / precision
                    rows = list(collect(path))
                    if rows:
                        all_rows[(rows[0]["propagation"], precision, group, origin, policy)] = rows
    rows = [row for lane in all_rows.values() for row in lane]
    if not rows:
        parser.error("No completed waiting trial matches the requested lanes")
    args.output.mkdir(parents=True, exist_ok=True)
    write_rows(args.output / "m30_context_candidates.csv", rows)
    write_rows(args.output / "m30_context_by_state.csv", list(stratified(all_rows)))
    ranges = list(feature_ranges(rows))
    if ranges:
        write_rows(args.output / "m30_context_feature_ranges.csv", ranges)


if __name__ == "__main__":
    main()
