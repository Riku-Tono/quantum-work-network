"""Render figures from the preregistered comparison tables."""

import argparse
import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
import numpy as np

from run_m30 import GROUPS, POLICIES, ROOT


COLORS = dict(zip(POLICIES, ("#b6692d", "#17816f", "#6178ae", "#294873", "#d58a55", "#53a894", "#a994cc", "#22272c"), strict=True))
LABELS = {"F2-R": "F2-R anchors", "F1": "F1 anchors", "recheck": "Known recheck states U01-U06"}


def read(data, label):
    with (data / f"m30_{label}.csv").open(encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))


def save(fig, output, filename):
    fig.savefig(output / filename, dpi=185, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def retention(endpoints, output):
    key = {(row["group"], row["origin"], row["policy"], row["precision"]): float(row["rp_retention"]) * 100
           for row in endpoints if row["propagation"] == "rk4" and row["rp_retention"]}
    order = ("F2-R", "F1", "recheck")
    fig, axes = plt.subplots(1, len(order), figsize=(14, 4.7), sharey=True, layout="constrained",
                            gridspec_kw={"width_ratios": (4, 4, 6)})
    for group, axis in zip(order, axes, strict=True):
        origins = tuple(sorted(GROUPS[group])) if group == "recheck" else GROUPS[group]
        for position, method in enumerate(POLICIES):
            x = np.arange(len(origins)) + (position - 3.5) * 0.093
            coarse, half = ([key.get((group, origin, method, step), np.nan) for origin in origins]
                            for step in ("coarse", "half"))
            axis.scatter(x, coarse, color=COLORS[method], s=30, zorder=3, label=method)
            axis.scatter(x + 0.018, half, facecolors="white", edgecolors=COLORS[method], s=13, zorder=4)
        axis.axhline(90, color="#927b70", linestyle="--", lw=1.0)
        axis.axhline(0, color="#a3a4a0", lw=0.8)
        axis.set_xticks(range(len(origins)), origins)
        axis.set_title(LABELS[group])
        axis.grid(axis="y", alpha=0.15)
    axes[0].set_ylabel("State-wise retention against RP (%)")
    axes[0].legend(ncols=2, loc="lower left", frameon=False, fontsize=8)
    fig.suptitle("Endpoint retention at elapsed 540  |  Filled: coarse · Open: half · Dashed: 90% floor")
    save(fig, output, "m30_01_statewise_retention.png")


def u05_trajectory(events, output):
    fig, (left, right) = plt.subplots(1, 2, figsize=(13, 4.5), layout="constrained")
    for method in POLICIES:
        curve = [row for row in events if row["group"] == "recheck" and row["origin"] == "U05"
                 and row["policy"] == method and row["precision"] == "coarse" and row["propagation"] == "rk4"]
        t = [0] + [float(row["elapsed"]) for row in curve] + [540]
        w = [0] + [float(row["work_to_user"]) * 1e6 for row in curve] + [0]
        style = "--" if method.startswith("P1+") else "-"
        for axis in (left, right):
            axis.step(t, np.cumsum(w), where="post", color=COLORS[method], lw=1.25, linestyle=style, label=method)
    for axis in (left, right):
        axis.axhline(0, color="#a3a4a0", lw=0.8)
        axis.set_xlabel("Elapsed time from prepared U05 state")
        axis.grid(axis="y", alpha=0.2)
    left.set_xlim(0, 540)
    left.set_ylabel("Executed net work (×10⁻⁶ model energy)")
    left.set_title("Full trajectory")
    right.set_xlim(42, 58)
    right.set_ylim(-1000, 70)
    right.axvline(44.44, color="#7a7a7a", linestyle=":", lw=1)
    right.set_title("Common boundary and first differing operation")
    handles, labels = left.get_legend_handles_labels()
    fig.legend(handles, labels, loc="outside lower center", ncols=8, frameon=False, fontsize=8)
    fig.suptitle("U05 cumulative balance at the instant each operation is executed")
    save(fig, output, "m30_02_U05_executed_work.png")


def factorial(effects, output):
    metrics = ("input_effect_no_phase", "phase_effect_no_input", "both_effect", "interaction")
    labels = ("Input only − none", "Angle only − none", "Both − none", "Interaction")
    detail = {(row["base"], row["group"], row["origin"]): row for row in effects
              if row["propagation"] == "rk4" and row["precision"] == "coarse" and row["component"] == "net_work"
              and row["elapsed"] == "540"}
    states = [(group, origin) for group in ("F2-R", "F1", "recheck") for origin in sorted(GROUPS[group])]
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 7), layout="constrained", sharey=True)
    matrices = {base: np.array([[float(detail[base, group, origin][metric]) * 1e6 for metric in metrics]
                                for group, origin in states]) for base in ("P3", "P1")}
    peak = max(float(np.max(np.abs(value))) for value in matrices.values())
    for axis, (base, matrix) in zip(axes, matrices.items(), strict=True):
        image = axis.imshow(matrix, cmap="RdBu", norm=TwoSlopeNorm(0, -peak, peak), aspect="auto")
        axis.set_title(f"{base} baseline")
        axis.set_yticks(range(len(states)), [f"{group} / {origin}" if group != "recheck" else origin for group, origin in states])
        axis.set_xticks(range(len(labels)), labels, rotation=32, ha="right")
        for row, column in np.ndindex(matrix.shape):
            number = matrix[row, column]
            axis.text(column, row, f"{0 if abs(number) < 0.5 else number:.0f}", ha="center", va="center",
                      color="white" if abs(number) > 0.60 * peak else "#202025", fontsize=7)
        for boundary in (3.5, 7.5):
            axis.axhline(boundary, color="#3f3f42", lw=0.65)
    fig.colorbar(image, ax=axes, label="Net-work contrast (×10⁻⁶ model energy)", shrink=0.8)
    fig.suptitle("Single-condition effects and interaction by state at elapsed 540")
    save(fig, output, "m30_03_condition_interaction.png")


def information(groups, output):
    fig, axes = plt.subplots(1, 3, figsize=(13, 4.4), layout="constrained", sharey=True)
    for axis, group in zip(axes, ("F2-R", "F1", "recheck"), strict=True):
        for row in groups:
            if row["group"] != group or row["elapsed"] != "540" or row["propagation"] != "rk4":
                continue
            method, step = row["policy"], row["precision"]
            scalar = float(row["mean_wait_real_scalars"])
            ratio = 100 * float(row["mean_rp_retention"])
            axis.scatter(scalar, ratio, s=54 if step == "coarse" else 20, edgecolors=COLORS[method],
                         facecolors=COLORS[method] if step == "coarse" else "white", label=method if step == "coarse" else None)
        axis.axhline(95, color="#907b70", ls="--", lw=1)
        axis.set_xlabel("Reconnection real components per state")
        axis.set_title(LABELS[group])
        axis.grid(alpha=0.15)
    axes[0].set_ylabel("Group mean work / RP group mean (%)")
    axes[0].legend(ncols=2, frameon=False, fontsize=8, loc="lower left")
    fig.suptitle("Observation load and group-level retention  |  Filled: coarse · Open: half")
    save(fig, output, "m30_04_information_and_work.png")


def forced(endpoints, output):
    fig, axes = plt.subplots(2, 2, figsize=(12, 6), layout="constrained", sharex=True)
    x = np.arange(len(POLICIES))
    for index, origin in enumerate(("U05", "U06")):
        data = {row["policy"]: row for row in endpoints if row["group"] == "recheck" and row["origin"] == origin
                and row["propagation"] == "rk4" and row["precision"] == "coarse"}
        cap = [float(data[method]["cap6_rate"]) * 100 for method in POLICIES]
        forced_rates = [float(data[method]["forced_rate"]) * 100 for method in POLICIES]
        axes[0, index].bar(x - 0.17, cap, width=0.33, color="#8ea0ae", label="Reached τ=6")
        axes[0, index].bar(x + 0.17, forced_rates, width=0.33, color="#454d62", label="Forced, incl. deadline cap")
        forced_nets = [float(data[method]["forced_net_work"]) * 1e6 for method in POLICIES]
        gross_losses = [-float(data[method]["forced_gross_losses"]) * 1e6 for method in POLICIES]
        axes[1, index].bar(x - 0.17, forced_nets, width=0.33, color="#17816f", label="Forced net total")
        axes[1, index].bar(x + 0.17, gross_losses, width=0.33, color="#b6692d", label="Gross losses in forced trials")
        axes[0, index].set_title(origin)
        axes[0, index].set_ylim(0, 100)
        axes[1, index].set_xticks(x, POLICIES)
        axes[1, index].axhline(0, color="#777777", lw=0.8)
    axes[0, 0].set_ylabel("Positive-wait trials (%)")
    axes[1, 0].set_ylabel("Net work (×10⁻⁶ model energy)")
    axes[0, 0].legend(frameon=False, fontsize=8)
    axes[1, 0].legend(frameon=False, fontsize=8)
    fig.suptitle("Wait caps and the work booked on forced-reconnection trials")
    save(fig, output, "m30_05_forced_reconnections.png")


def online_precision(comparisons, output):
    fig, axes = plt.subplots(1, 2, figsize=(11, 4), layout="constrained", sharey=True)
    for axis, origin in zip(axes, ("U05", "U06"), strict=True):
        for name, label, marker, displacement in (("half", "Half − coarse", "o", -0.08),
                                                   ("exact_online", "Exact online − coarse", "D", 0.08)):
            difference = {row["policy"]: float(row["work_difference"]) * 1e12 for row in comparisons
                          if row["origin"] == origin and row["comparison"] == name}
            axis.scatter(np.arange(len(POLICIES)) + displacement, [difference[method] for method in POLICIES],
                         s=35, marker=marker, label=label)
        axis.axhline(0, color="#a3a4a0", lw=0.8)
        axis.set_xticks(range(len(POLICIES)), POLICIES)
        axis.set_title(origin)
        axis.grid(axis="y", alpha=0.2)
    axes[0].set_ylabel("Change in final net work (×10⁻¹² model energy)")
    axes[0].legend(frameon=False, fontsize=8)
    fig.suptitle("Precision check with reconnection and A re-evaluated online")
    save(fig, output, "m30_06_online_precision.png")


def main(data, output):
    output.mkdir(parents=True, exist_ok=True)
    endpoints = read(data, "endpoints")
    retention(endpoints, output)
    u05_trajectory(read(data, "work_events"), output)
    factorial(read(data, "factorial"), output)
    information(read(data, "group_metrics"), output)
    forced(endpoints, output)
    online_precision(read(data, "numerical_comparison"), output)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=ROOT / "results")
    parser.add_argument("--output", type=Path, default=ROOT / "figures")
    args = parser.parse_args()
    main(args.data, args.output)
