"""Reproduce U05's first separation and the eight common-state continuations."""

import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import numpy as np

import m30_control as engine

ROOT = Path(__file__).resolve().parent
M29 = ROOT.parent / "Milestone_29"
POLICIES = ("P3", "P3+I", "P3+A", "P3+IA", "P1", "P1+I", "P1+A", "RP")
TRACKS = (("rk4", "coarse"), ("rk4", "half"), ("exact", "coarse"))
PRECISIONS = ("coarse", "half")
CUTOFF = 540_000
FIELDS = ("c_real", "c_imag", "c_abs", "phase")
PHASE_BOUNDS = (-3 * math.pi / 4, -math.pi / 4)
PHYSICAL = engine.physics


def read_rows(path):
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def write_rows(path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def tick(row, key="elapsed_total"):
    return round(1000 * float(row[key]))


def accepted(value):
    return value is True or value == "True"


def signature(row):
    return tick(row, "elapsed_start"), tick(row, "tau"), tick(row), accepted(row["accepted"])


def hashes(row, when):
    return tuple(row[f"{when}_{precision}_sha256"] for precision in PRECISIONS)


def fingerprints(pair):
    return tuple(PHYSICAL.fingerprint(state) for state in pair)


def archive_pair(filename, pair, clock, **metadata):
    filename.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(filename, coarse=pair[0], half=pair[1], tick=clock, **metadata)


def existing_separations():
    data = M29 / "stages" / "t150" / "unseen" / "U05"
    evidence = []
    for precision in PRECISIONS:
        rp = read_rows(data / "RP" / precision / "m29_history.csv")
        for policy in ("P1", "P3"):
            alternate = read_rows(data / policy / precision / "m29_history.csv")
            for before, after in zip(rp, alternate):
                if hashes(before, "start") != hashes(after, "start"):
                    raise ValueError(f"M29 lost its common start before a recorded separation: {policy}/{precision}")
                if signature(before) != signature(after):
                    evidence.append({
                        "precision": precision, "comparison": f"RP–{policy}",
                        "attempt": int(before["attempt"]), "elapsed_start": float(before["elapsed_start"]),
                        "rp_tau": float(before["tau"]), "alternate_tau": float(after["tau"]),
                        "rp_elapsed_total": float(before["elapsed_total"]),
                        "alternate_elapsed_total": float(after["elapsed_total"]),
                        "rp_accepted": accepted(before["accepted"]), "alternate_accepted": accepted(after["accepted"]),
                        "start_coarse_sha256": before["start_coarse_sha256"],
                        "start_half_sha256": before["start_half_sha256"],
                    })
                    break
                if hashes(before, "post") != hashes(after, "post"):
                    raise ValueError(f"M29 prefix exit densities differ with equal operations: {policy}/{precision}")
            else:
                raise ValueError(f"No M29 physical separation within the archived prefix: {policy}/{precision}")
    clocks = {tick(row, "elapsed_start") for row in evidence}
    attempts = {row["attempt"] for row in evidence}
    starts = {hashes(row, "start") for row in evidence}
    if len(clocks) != 1 or len(attempts) != 1 or len(starts) != 1:
        raise ValueError("The two M29 comparisons do not share the same saved trial boundary")
    return evidence, clocks.pop(), attempts.pop(), starts.pop()


def common_prefix(root, propagation, precision, fork, attempt, expected):
    source, _ = engine.seed_for("recheck", "U05", precision)
    stage = root / "common_prefix"
    engine.run_branch("recheck", "U05", "RP", precision, stage, [fork], propagation=propagation)
    folder = stage / f"t{fork / 1000:g}"
    with np.load(folder / "checkpoint.npz", allow_pickle=False) as saved:
        pair = tuple(saved[f"anchor_{name}"] for name in PRECISIONS)
        clock, completed, _ = map(int, saved["counters"])
        records = json.loads(str(saved["records"].item()))
        prefix_work = float(saved["work"][0])
    if clock != fork or completed != attempt - 1 or len(records) != completed:
        raise ValueError(f"Checkpoint does not anchor the end of attempt {attempt - 1}: {folder}")
    observed_hashes = fingerprints(pair)
    if propagation == "rk4" and observed_hashes != expected:
        raise ValueError(f"The regenerated M29 divergence state does not reproduce its stored hashes: {folder}")
    # At this exact clock the stage also sees the immediate next cut. The anchor
    # is the density before that event and owns only the completed prefix work.
    archive_pair(root / "fork_pre_cut.npz", pair, clock, coupling=PHYSICAL.G,
                 prefix_work=prefix_work, records=json.dumps(records, sort_keys=True),
                 source_time=float(source["source_time"]), fingerprints=observed_hashes)
    return source, (pair, clock, records), prefix_work, folder


def physical_sample(rho):
    measured = PHYSICAL.observation(PHYSICAL.observe_local(PHYSICAL.partial(rho)))
    return {key: measured[key] for key in (*FIELDS, "load_current", "load_ergotropy", "total_work")}


def gate_diagnostics(sample, initial, policy):
    q = -float(sample["c_imag"])
    q0 = -float(initial["c_imag"])
    baseline_p3 = max(0.25 * abs(q0), 1e-11)
    baseline_p1 = 0.25 * float(initial["c_abs"])
    amplitude = float(sample["c_abs"]) >= 1e-5
    p1_current = q >= baseline_p1
    p3_current = q >= baseline_p3
    real_delta = float(sample["c_real"]) - float(initial["c_real"])
    input_gate = float(sample["c_real"]) <= float(initial["c_real"]) + 1e-10
    lower, upper = PHASE_BOUNDS
    phase = float(sample["phase"])
    phase_gate = lower <= phase <= upper
    rp = amplitude and p1_current and input_gate and phase_gate
    gate = rp
    if policy != "RP":
        gate = (p3_current if policy.startswith("P3") else amplitude and p1_current)
        addition = policy.partition("+")[2]
        gate = gate and ("I" not in addition or input_gate) and ("A" not in addition or phase_gate)
    return {"q": q, "q0": q0, "p1_q_floor": baseline_p1, "p3_q_floor": baseline_p3,
            "amplitude_pass": amplitude, "p1_current_pass": p1_current, "p3_current_pass": p3_current,
            "input_pass": input_gate, "phase_pass": phase_gate, "rp_pass": rp, "policy_pass": gate,
            "input_condition_margin": 1e-10 - real_delta, "phase_condition_margin": min(phase - lower, upper - phase),
            "switch_input_if_reconnected": 2 * PHYSICAL.G * real_delta}


def wait_evidence(meta, start, trial, initial):
    def row(kind, sample, tau, now, reconnect):
        gates = gate_diagnostics(sample, initial, meta["policy"])
        return {**meta, "event": kind, "wait_elapsed": tau, "elapsed_total": now, "observed_until": now,
                **{key: float(sample[key]) for key in FIELDS}, **gates,
                "load_current_if_coupled": float(sample["load_current"]),
                "actual_load_current_at_observation": float(sample["load_current"]) if kind == "pre_cut" else 0.0,
                "condition_evaluated": kind == "wait_sample", "reconnect": reconnect,
                "forced_reconnect": reconnect and not gates["policy_pass"]}

    yield row("pre_cut", initial, 0.0, start / 1000, False)
    for check in trial.wait_checks:
        item = row("wait_sample", check, check["wait_elapsed"], check["elapsed_total"], check["reconnect"])
        if item["policy_pass"] != check["phase_gate"]:
            raise ValueError(f"Independent reconstruction of the wait condition diverges: {meta}, {check}")
        yield item


def trace_distance(left, right):
    return float(np.abs(np.linalg.eigvalsh(left - right)).sum() / 2)


def trial_summary(meta, trial, initial, last, state):
    row = trial.row
    work = float(row["net_work"])
    passivation = float(row["direct_total_work"]) if row["accepted"] else 0.0
    switch_input = float(row["cut_on"]) + float(row["reconnect_on"])
    balance = work - (passivation - switch_input)
    if abs(balance) > PHYSICAL.FLOOR:
        raise ValueError(f"Trial work accounting failed: {meta}, {balance}")
    return {**meta, "elapsed_start": row["elapsed_start"], "tau": row["tau"],
            "reconnect_elapsed": last["elapsed_total"], "elapsed_total": row["elapsed_total"],
            "connected_duration": row["elapsed_connected"], "accepted": row["accepted"],
            "at_max_wait": row["tau"] == 6.0, "forced_reconnect": last["forced_reconnect"],
            "wait_reason": row["wait_reason"], "cut_work_recovered": -row["cut_on"],
            "cut_input": row["cut_on"], "reconnect_input": row["reconnect_on"],
            "switch_input": switch_input, "passivation_work": passivation, "net_work": work,
            "balance_residual": balance,
            **{f"precut_{key}": initial[key] for key in FIELDS},
            **{f"reconnect_{key}": last[key] for key in FIELDS},
            **{f"reconnect_{key}": last[key] for key in ("input_pass", "phase_pass", "p1_current_pass", "p3_current_pass",
                                                        "amplitude_pass", "policy_pass")},
            **{f"next_precut_{key}": state[key] for key in state},
            **{f"{when}_{name}_sha256": row[f"{when}_{name}_sha256"]
               for when in ("start", "post") for name in PRECISIONS}}


def stage_history(path, table="history"):
    stages = sorted(path.glob("t*"), key=lambda folder: float(folder.name[1:]))
    rows = []
    for folder in stages:
        history = folder / f"m30_{table}.csv"
        if history.exists():
            rows.extend(read_rows(history))
    return rows


def first_basis_separations(trajectories, directories, attempt, propagation, precision):
    """Find the first physical consequence of the P3 baseline within each pair."""
    comparisons = (("P3", "P1"), ("P3+I", "P1+I"), ("P3+A", "P1+A"), ("P3+IA", "RP"))
    for p3, p1 in comparisons:
        result = {"propagation": propagation, "precision": precision, "p3_policy": p3, "p1_policy": p1,
                  "separated": False, "shared_trials_from_fork": 0, "first_attempt": None, "elapsed_start": None,
                  "p3_tau": None, "p1_tau": None, "p3_trial_work": None, "p1_trial_work": None,
                  "common_start_coarse_sha256": None, "common_start_half_sha256": None,
                  "earlier_reconnect_policy": None, "wait_at_earlier_reconnect": None,
                  "c_real": None, "c_imag": None, "c_abs": None, "phase": None, "q": None, "p3_q_floor": None,
                  "p1_q_floor": None, "input_pass": None, "phase_pass": None, "amplitude_pass": None,
                  "p3_current_pass": None, "p1_current_pass": None}
        a, b = trajectories[p3], trajectories[p1]
        for i, (p3_row, p1_row) in enumerate(zip(a, b)):
            start = hashes(p3_row, "start")
            if start != hashes(p1_row, "start"):
                raise ValueError(f"Different baseline inputs before any physical separation: {p3}/{p1}")
            if signature(p3_row) == signature(p1_row):
                if hashes(p3_row, "post") != hashes(p1_row, "post"):
                    raise ValueError(f"The same physical actions led to different states: {p3}/{p1}")
                continue
            p3_tau, p1_tau = float(p3_row["tau"]), float(p1_row["tau"])
            if p3_tau == p1_tau:
                raise ValueError(f"Unexpected first divergence at the same reconnect time: {p3}/{p1}")
            earlier, later = (p3, p1) if p3_tau < p1_tau else (p1, p3)
            later_row = p1_row if later == p1 else p3_row
            at = min(p3_tau, p1_tau)
            sample, = (row for row in stage_history(directories[later], "wait_checks")
                       if row["attempt"] == later_row["attempt"] and float(row["wait_elapsed"]) == at)
            initial = {key: float(later_row[f"{key}_before"]) for key in ("c_real", "c_imag", "c_abs")}
            measured = {key: float(sample[key]) for key in FIELDS}
            gates = gate_diagnostics(measured, initial, later)
            result.update(separated=True, shared_trials_from_fork=i, first_attempt=attempt + i,
                          elapsed_start=float(p3_row["elapsed_start"]), p3_tau=p3_tau, p1_tau=p1_tau,
                          p3_trial_work=float(p3_row["net_work"]), p1_trial_work=float(p1_row["net_work"]),
                          common_start_coarse_sha256=start[0], common_start_half_sha256=start[1],
                          earlier_reconnect_policy=earlier, wait_at_earlier_reconnect=at, **measured,
                          **{key: gates[key] for key in ("q", "p3_q_floor", "p1_q_floor", "input_pass", "phase_pass",
                                                        "amplitude_pass", "p3_current_pass", "p1_current_pass")})
            break
        else:
            if len(a) != len(b):
                raise ValueError(f"Trajectory lengths differ without any preceding physical separation: {p3}/{p1}")
            result.update(shared_trials_from_fork=len(a))
        yield result


def native_path(stages, exact, propagation, precision, policy):
    return (stages if propagation == "rk4" else exact) / "recheck" / "U05" / policy / precision


def common_state_branches(root, stages, exact, propagation, precision, fork, attempt, expected, full, local_only):
    track = root / propagation / precision
    source, seed, prefix_work, prefix_stage = common_prefix(track, propagation, precision, fork, attempt, expected)
    pair, clock, records = seed
    primary = PRECISIONS.index(precision)
    initial = physical_sample(pair[primary])
    first_trials, second_trials, samples, summaries, next_states = {}, {}, [], [], []
    for policy in POLICIES:
        meta = {"propagation": propagation, "precision": precision, "policy": policy, "attempt": attempt}
        first = engine.trial_at(pair, clock, policy, precision, records=records, propagation=propagation)
        if first.row is None or hashes(first.row, "start") != fingerprints(pair):
            raise ValueError(f"First branch trial did not start at the saved fork: {meta}")
        following = [*records, PHYSICAL.compact_record(first.row)]
        second = engine.trial_at(first.after, first.boundary.tick, policy, precision,
                                 records=following, propagation=propagation)
        if second.row is None or hashes(second.row, "start") != fingerprints(first.after):
            raise ValueError(f"Next trial did not start at the saved branch exit: {meta}")
        archive_pair(track / policy / "next_pre_cut.npz", first.after, first.boundary.tick, coupling=PHYSICAL.G,
                     fingerprints=fingerprints(first.after))
        now = physical_sample(first.after[primary])
        evidence = list(wait_evidence(meta, clock, first, initial))
        summaries.append(trial_summary(meta, first, initial, evidence[-1], now))
        samples.extend(evidence)
        first_trials[policy], second_trials[policy] = first, second
        next_reconnect = gate_diagnostics(second.wait_checks[-1], now, policy)
        next_states.append({**meta, "trial_end_elapsed": first.boundary.tick / 1000, **now,
                            "next_trial_tau": second.row["tau"], "next_trial_end_elapsed": second.row["elapsed_total"],
                            "next_trial_forced_reconnect": second.row["fallback_limit"],
                            "next_trial_reconnect_input_pass": next_reconnect["input_pass"],
                            "next_trial_reconnect_phase_pass": next_reconnect["phase_pass"],
                            "next_trial_reconnect_input": second.row["reconnect_input"],
                            "next_trial_switch_input": -second.row["switch_net"],
                            "next_trial_passivation_accepted": second.row["accepted"],
                            "next_trial_net_work": second.row["net_work"],
                            "two_trial_net_work": first.row["net_work"] + second.row["net_work"]})

    align_tick = max(trial.boundary.tick for trial in first_trials.values())
    aligned = {}
    for policy, first in first_trials.items():
        following = [*records, PHYSICAL.compact_record(first.row)]
        partial = engine.trial_at(first.after, first.boundary.tick, policy, precision,
                                  cap=align_tick, records=following, propagation=propagation)
        if partial.row is not None:
            raise ValueError("Common-clock diagnostic would need to traverse another complete trial")
        aligned[policy] = (partial.boundary.pair[primary], partial.boundary.coupling, partial.pending["switch_net"])
    for row in next_states:
        rho, coupling, pending_next_switch = aligned[row["policy"]]
        row.update(common_elapsed=align_tick / 1000, common_coupling=coupling, next_switch_net_at_common_clock=pending_next_switch,
                   common_trace_distance_to_rp=trace_distance(rho, aligned["RP"][0]),
                   common_fingerprint=PHYSICAL.fingerprint(rho),
                   **{f"common_{key}": value for key, value in physical_sample(rho).items()})
    long, basis_separations = [], []
    if not local_only:
        trajectories, directories = {}, {}
        prefix = stage_history(prefix_stage.parent)
        for policy in POLICIES:
            native = native_path(stages, exact, propagation, precision, policy)
            if full:
                destination = track / policy / "standalone"
                engine.run_branch("recheck", "U05", policy, precision, destination, [150_000, 300_000, CUTOFF],
                                  source=source, seed=seed, propagation=propagation)
                continuation = stage_history(destination)
                summary = endpoint(destination)
                prefix_in_endpoint = 0.0
                method = "standalone_from_saved_fork"
            else:
                native_rows = stage_history(native)
                if (len(native_rows) < attempt + 1 or len(prefix) != attempt - 1
                        or any(signature(first) != signature(second) or hashes(first, "start") != hashes(second, "start")
                               or hashes(first, "post") != hashes(second, "post")
                               for first, second in zip(prefix, native_rows[:attempt - 1], strict=True))):
                    raise ValueError(f"Native path does not share the entire pre-fork U05 prefix: {native}")
                continuation = native_rows[attempt - 1:]
                summary = endpoint(native)
                prefix_in_endpoint = prefix_work
                method = "matched_native_continuation"
                destination = native
            for direct, logged in zip((first_trials[policy].row, second_trials[policy].row), continuation[:2], strict=True):
                if (signature(direct) != signature(logged) or hashes(direct, "start") != hashes(logged, "start")
                        or hashes(direct, "post") != hashes(logged, "post")
                        or abs(float(direct["net_work"]) - float(logged["net_work"])) > PHYSICAL.FLOOR):
                    raise ValueError(f"Short common-fork and full continuation do not match: {policy}/{track}")
            total_through_540 = summary - prefix_in_endpoint + prefix_work
            from_fork = summary - prefix_in_endpoint
            trial_work = float(first_trials[policy].row["net_work"])
            through_common_clock = trial_work + aligned[policy][2]
            trajectories[policy], directories[policy] = continuation, destination
            long.append({"propagation": propagation, "precision": precision, "policy": policy, "attempt": attempt,
                         "method": method, "absolute_prefix_work": prefix_work, "trial_work": trial_work,
                         "post_trial_to_540_work": from_fork - trial_work, "common_elapsed": align_tick / 1000,
                         "fork_to_common_clock_work": through_common_clock,
                         "common_clock_to_540_work": from_fork - through_common_clock, "fork_to_540_work": from_fork,
                         "absolute_through_540_work": total_through_540, "continuation_trials": len(continuation),
                         "first_trial_post_coarse_sha256": first_trials[policy].row["post_coarse_sha256"],
                         "second_trial_post_coarse_sha256": second_trials[policy].row["post_coarse_sha256"]})
        basis_separations.extend(first_basis_separations(trajectories, directories, attempt, propagation, precision))
    return summaries, samples, next_states, long, basis_separations


def endpoint(path):
    with np.load(path / "t540" / "checkpoint.npz", allow_pickle=False) as checkpoint:
        pending = json.loads(str(checkpoint["pending"].item()))
        return float(checkpoint["work"][0]) + float(pending.get("switch_net", 0.0))


def add_effects(rows):
    by_policy = {row["policy"]: row for row in rows}
    pairs = ((("P3", "P3+I", "P3+A", "P3+IA"), "P3"), (("P1", "P1+I", "P1+A", "RP"), "P1"))
    for ids, base in pairs:
        for metric in ("trial_work", "post_trial_to_540_work", "common_clock_to_540_work", "fork_to_540_work"):
            neither, only_i, only_a, both = (float(by_policy[policy][metric]) for policy in ids)
            row = by_policy[base]
            row.update({f"{metric}_input_effect": only_i - neither, f"{metric}_phase_effect": only_a - neither,
                        f"{metric}_both_effect": both - neither,
                        f"{metric}_interaction": both - only_i - only_a + neither})
    keys = tuple(key for key in by_policy["P3"] if key.endswith(("_effect", "_interaction")))
    for row in rows:
        for key in keys:
            row.setdefault(key, None)


def plot_wait(samples, output):
    import matplotlib.pyplot as plt

    selected = [r for r in samples if (r["propagation"], r["precision"], r["policy"]) == ("rk4", "coarse", "RP")]
    tau = np.array([r["wait_elapsed"] for r in selected])
    phases = np.array([r["phase"] for r in selected])
    q = np.array([r["q"] for r in selected]) * 1e6
    switch_input = np.array([r["switch_input_if_reconnected"] for r in selected]) * 1e6
    figure, axes = plt.subplots(3, 1, sharex=True, figsize=(8.0, 7.1), layout="constrained")
    for axis, data in zip(axes, (q, phases, switch_input), strict=True):
        axis.plot(tau[1:], data[1:], "o-", color="#236A99", markersize=3)
        axis.scatter(tau[0], data[0], facecolors="white", edgecolors="#236A99", s=22, zorder=3)
    axes[0].axhline(selected[0]["p1_q_floor"] * 1e6, color="#906436", linestyle="--", label="P1 current floor")
    axes[0].axhline(selected[0]["p3_q_floor"] * 1e6, color="#A84246", linestyle=":", label="P3 current floor")
    axes[0].set_ylabel("q × 10⁶")
    axes[0].legend(loc="upper right", frameon=False)
    axes[1].axhspan(*PHASE_BOUNDS, color="#B8D9C9", alpha=0.7, label="RP phase interval")
    axes[1].legend(loc="upper left", frameon=False)
    axes[1].set_ylabel("Phase (rad)")
    closest = int(np.argmin(np.abs(phases[1:] - PHASE_BOUNDS[1]))) + 1
    axes[1].annotate(f"{phases[closest]:.5f} rad", xy=(tau[closest], phases[closest]),
                     xytext=(tau[closest], 0.15), ha="center", fontsize=9,
                     arrowprops={"arrowstyle": "-", "color": "#606971"})
    axes[2].axhline(0, color="#6B7074", linewidth=0.9)
    axes[2].set_ylabel("Switch input × 10⁶")
    axes[2].set_xlabel("Wait after the cut (model time)")
    early = next(r["wait_elapsed"] for r in samples if r["propagation"] == "rk4" and r["precision"] == "coarse"
                 and r["policy"] == "P3" and r["reconnect"])
    for ax in axes:
        ax.axvline(early, color="#A84246", linewidth=1.3, linestyle="--")
        ax.axvline(tau[-1], color="#3E7061", linewidth=1.3, linestyle="--")
        ax.grid(axis="y", alpha=0.16)
        ax.set_xlim(-0.1, 6.12)
    axes[2].text(early + 0.07, 0.10, "P1 / P3", transform=axes[2].get_xaxis_transform(),
                 color="#A84246", va="bottom")
    axes[2].text(tau[-1] - 0.08, 0.86, "Forced reconnect", transform=axes[2].get_xaxis_transform(),
                 color="#3E7061", ha="right", va="bottom")
    figure.suptitle("U05 trial 6 | Coherence along the common disconnected state", fontsize=13)
    figure.savefig(output / "u05_01_common_wait.png", dpi=175)
    plt.close(figure)


def plot_continuation(rows, output):
    import matplotlib.pyplot as plt

    selected = [r for r in rows if (r["propagation"], r["precision"]) == ("rk4", "coarse")]
    if not selected:
        return
    trial = np.array([r["trial_work"] for r in selected]) * 1e6
    following = np.array([r["post_trial_to_540_work"] for r in selected]) * 1e6
    total = trial + following
    x = np.arange(len(selected))
    figure, ax = plt.subplots(figsize=(9.2, 4.4), layout="constrained")
    width = 0.26
    ax.bar(x - width, trial, width=width, color="#236A99", label="Trial 6")
    ax.bar(x, following, width=width, color="#B35C47", label="After trial 6 to 540")
    ax.bar(x + width, total, width=width, color="#3E7061", label="Common fork to 540")
    ax.axhline(0, color="#54595D", linewidth=0.9)
    ax.set_xticks(x, [r["policy"] for r in selected])
    ax.set_ylabel("Net work × 10⁶")
    ax.set_ylim(top=float(max(trial.max(), following.max(), total.max())) + 400)
    ax.legend(frameon=False, ncols=3, loc="upper left")
    ax.set_title("U05 | Work from the common pre-cut state at elapsed 44.44")
    ax.grid(axis="y", alpha=0.16)
    figure.savefig(output / "u05_02_trial_and_continuation.png", dpi=175)
    plt.close(figure)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "u05")
    parser.add_argument("--stages", type=Path, default=ROOT / "stages")
    parser.add_argument("--exact", type=Path, default=ROOT / "exact_online")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--full", action="store_true", help="Run all eight continuations from the saved fork to 540")
    mode.add_argument("--local-only", action="store_true", help="Record the two local trials without the endpoint table")
    args = parser.parse_args()
    digest = hashlib.sha256((ROOT / "PROTOCOL_M30.md").read_bytes()).hexdigest()
    if digest != (ROOT / "protocol.sha256").read_text(encoding="ascii").strip():
        raise ValueError("M30 protocol does not match the pre-registered hash")
    args.output.mkdir(parents=True, exist_ok=True)
    figures = args.output / "figures"
    figures.mkdir(exist_ok=True)
    evidence, fork, attempt, expected = existing_separations()
    write_rows(args.output / "first_separation_m29.csv", evidence)
    summaries, samples, next_states, long, basis = [], [], [], [], []
    for propagation, precision in TRACKS:
        summary, waits, states, continuation, separation = common_state_branches(
            args.output, args.stages, args.exact, propagation, precision, fork, attempt, expected, args.full, args.local_only)
        summaries.extend(summary)
        samples.extend(waits)
        next_states.extend(states)
        if continuation:
            add_effects(continuation)
            long.extend(continuation)
            basis.extend(separation)
        print(f"Recorded U05 common-state trials for {propagation}/{precision}", flush=True)
    write_rows(args.output / "trial6_summary.csv", summaries)
    write_rows(args.output / "trial6_wait_samples.csv", samples)
    write_rows(args.output / "trial7_pre_cut_and_transition.csv", next_states)
    plot_wait(samples, figures)
    if long:
        write_rows(args.output / "continuation_to_540.csv", long)
        write_rows(args.output / "first_basis_separation.csv", basis)
        plot_continuation(long, figures)


if __name__ == "__main__":
    main()
