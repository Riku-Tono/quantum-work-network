"""Same-state reconnection experiments with the frozen M29 and RP rules."""

from contextlib import contextmanager
from functools import lru_cache
import json
import os
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import time

ROOT = Path(__file__).resolve().parent
M29 = ROOT.parent / "Milestone_29"
sys.path.insert(0, str(M29))
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import run_m29 as m29
from m27_control import PHASE_MIN, phase_reconnect, supply_phase
from m29_control import EPSILON_Q, RELATIVE, p1, p3
import numpy as np

stage = m29.stage
physics = m29.physics
G, FLOOR = physics.G, physics.FLOOR
GRID, HORIZON, TOTAL_LIMIT = m29.GRID, m29.HORIZON, m29.TOTAL_LIMIT
PRECISIONS = stage.PRECISIONS
POLICIES = ("P3", "P3+I", "P3+A", "P3+IA", "P1", "P1+I", "P1+A", "RP")
WAIT_MIN, WAIT_MAX, WAIT_GRID = 1000, 6000, 200
INPUT_TOLERANCE = 1e-10


def condition_flags(policy):
    basis, _, restored = policy.partition("+")
    if policy not in POLICIES:
        raise ValueError(f"Unknown M30 policy {policy!r}")
    return basis == "P3", "I" in restored or policy == "RP", "A" in restored or policy == "RP"


def eligible_sample(policy, initial, measured):
    """Return the gate and the values used, confined to the method's inputs."""
    reduced, with_input, with_angle = condition_flags(policy)
    q = -float(measured["c_imag"])
    inputs = {"q": q}
    if reduced:
        q0 = -float(initial["c_imag"])
        base = p3(q, q0)
        inputs.update(q0=q0, threshold_q=max(RELATIVE * abs(q0), EPSILON_Q))
    else:
        initial_amplitude = float(initial["c_abs"])
        amplitude = float(measured["c_abs"])
        base = p1(amplitude, q, initial_amplitude)
        inputs.update(amplitude=amplitude, c0_abs=initial_amplitude, threshold_q=RELATIVE * initial_amplitude)
    allow_input = allow_angle = True
    if with_input:
        early, current = float(initial["c_real"]), float(measured["c_real"])
        allow_input = current <= early + INPUT_TOLERANCE
        inputs.update(c0_real=early, c_real=current)
    if with_angle:
        angle = float(measured["phase"])
        allow_angle = supply_phase(angle)
        inputs["angle"] = angle
    return base and allow_input and allow_angle, inputs


def condition_diagnostics(initial, measured):
    """Record all witnesses for later analysis, independent of the gate's inputs."""
    q, q0 = -measured["c_imag"], -initial["c_imag"]
    p1_threshold = RELATIVE * initial["c_abs"]
    p3_threshold = max(RELATIVE * abs(q0), EPSILON_Q)
    return {"gate_input": measured["c_real"] <= initial["c_real"] + INPUT_TOLERANCE,
            "gate_angle": supply_phase(measured["phase"]),
            "gate_amplitude": measured["c_abs"] >= PHASE_MIN,
            "gate_current_p1": q >= p1_threshold,
            "gate_current_p3": q >= p3_threshold,
            "gate_rp": phase_reconnect(measured, initial, G),
            "input_margin": initial["c_real"] + INPUT_TOLERANCE - measured["c_real"],
            "p1_current_margin": q - p1_threshold,
            "p3_current_margin": q - p3_threshold,
            "amplitude_margin": measured["c_abs"] - PHASE_MIN}


def wait_until(model, pair, primary, start, window, policy, mode, records, cap, fixed_tau, initial):
    """Expose the current sample and stop at the first eligible or final clock."""
    last = min(WAIT_MAX, window - GRID) // WAIT_GRID * WAIT_GRID
    if last < WAIT_MIN:
        return 0, "no_wait_fits", []
    observe = physics.phase_observer(model, pair[primary], physics.DT[primary])
    checks = []
    for delay in range(WAIT_MIN, last + 1, WAIT_GRID):
        if start + delay > cap:
            return None, "phase_limit", checks
        measured = observe(delay)
        gate, _ = eligible_sample(policy, initial, measured)
        forced = delay == last and not gate
        checks.append({"elapsed_total": (start + delay) / 1000, "observed_until": (start + delay) / 1000,
                       "wait_elapsed": delay / 1000, "phase_gate": gate, "reconnect": gate or forced,
                       "actual_current": 0.0, **measured, **condition_diagnostics(initial, measured),
                       "at_max_wait": delay == WAIT_MAX, "at_window_limit": delay == last,
                       "fallback_limit": forced, "fallback_max_wait": forced and delay == WAIT_MAX,
                       "fallback_window_limit": forced and delay < WAIT_MAX, "used_by_control": True})
        if gate or forced:
            return delay, "phase_gate" if gate else "phase_limit", checks
    raise RuntimeError("Registered wait lattice exhausted without a decision")


@lru_cache(maxsize=2)
def model_instance(propagation="rk4"):
    if propagation == "rk4":
        return physics.model_instance()
    if propagation != "exact":
        raise ValueError(f"Unknown propagation {propagation!r}")
    model = physics.Dynamics(HORIZON)
    for basis in model.bases.values():
        difference = basis.eigenvalues[:, None] - basis.eigenvalues[None, :]
        # The inherited duration multipliers work in RK4-step units. This
        # phase advances exactly across that elapsed time, including A samples.
        basis.logs = {step: -1j * difference * step for step in physics.DT}
    return model


@contextmanager
def adapters():
    old_wait = physics.wait_until
    old_projector = physics.ConnectedObservations
    physics.wait_until = wait_until
    physics.ConnectedObservations = m29.ReducedProjection
    try:
        yield
    finally:
        physics.wait_until = old_wait
        physics.ConnectedObservations = old_projector


def seed_for(group, origin, precision):
    archive_group = "unseen" if group == "recheck" else group
    archive_root = (M29 if archive_group == "unseen" else m29.M28) / "anchors"
    return m29.get_seed(stage.Job(archive_group, origin, "RP", precision, archive_root))


def _next_trial(model, pair, primary, elapsed, policy, records, cap):
    if TOTAL_LIMIT - elapsed < GRID:
        snapshot = physics.Snapshot(pair, G, elapsed, "operation_end")
        return None, physics.continue_passively(model, snapshot, cap), {}
    window = min(HORIZON, TOTAL_LIMIT - elapsed)
    trial = physics.attempt(model, pair, primary, elapsed, window, policy, "wait", records, cap)
    return trial, trial.boundary, trial.pending


def trial_at(pair, elapsed, policy, precision, *, cap=None, records=(), propagation="rk4"):
    """Evaluate a single attempt from a saved connected pair of state matrices."""
    model = model_instance(propagation)
    primary = PRECISIONS.index(precision)
    cap = min(elapsed + HORIZON, TOTAL_LIMIT) if cap is None else cap
    with adapters():
        trial, _, _ = _next_trial(model, pair, primary, elapsed, policy, records, cap)
    if trial is not None and trial.row is not None:
        add_diagnostics(policy, trial)
    return trial


def initial_coherence(row, trial):
    real = -row["cut_on"] / (2 * G) if row["tau"] else trial.observations[0]["c_real"]
    return {"c_real": real, "c_imag": -row["current_before"] / (2 * G),
            "c_abs": row["c_abs_before"], "phase": row["phase_before"], "load_current": row["current_before"]}


def add_diagnostics(policy, trial):
    row = trial.row
    reduced, with_input, with_angle = condition_flags(policy)
    has_wait = row["tau"] > 0
    before = initial_coherence(row, trial)
    at_reconnect = trial.observations[0]
    initial_count, wait_count = int(has_wait), len(trial.wait_checks)
    initial_width = 1 if reduced and not with_input else 2
    wait_width = 1 if reduced and not with_input and not with_angle else 2
    last = trial.wait_checks[-1] if has_wait else None
    row.update({
        "c_real_before": before["c_real"], "c_imag_before": before["c_imag"],
        "c_real_after": at_reconnect["c_real"], "c_imag_after": at_reconnect["c_imag"],
        "reconnect_elapsed": row["elapsed_start"] + row["tau"],
        "cut_work": -row["cut_on"], "reconnect_input": row["reconnect_on"],
        "passivation_work": row["direct_total_work"] if row["accepted"] else 0.0,
        "switch_net": -row["cut_on"] - row["reconnect_on"],
        "fallback_limit": bool(last and last["fallback_limit"]),
        "fallback_max_wait": bool(last and last["fallback_max_wait"]),
        "fallback_window_limit": bool(last and last["fallback_window_limit"]),
        "at_max_wait": bool(last and last["at_max_wait"]),
        "at_window_limit": bool(last and last["at_window_limit"]),
        "initial_phase_observations": initial_count, "wait_phase_observations": wait_count,
        "phase_observations": initial_count + wait_count, "decision_observations": initial_count + wait_count,
        "observed_scalars": initial_count * initial_width + wait_count * wait_width,
        "initial_reconnect_scalars": initial_count * initial_width, "wait_reconnect_scalars": wait_count * wait_width,
        "retained_reference_scalars": initial_count * (1 + with_input),
        "retained_references": ("q0" if reduced else "c0_abs") + ("|c0_real" if with_input else "") if has_wait else "",
        "reconnect_abs_evaluations": 0 if reduced else initial_count + wait_count,
        "reconnect_threshold_abs_evaluations": initial_count if reduced else 0,
        "reconnect_atan2_evaluations": wait_count if with_angle else 0,
        "reconnect_a_observations": len(trial.observations),
    })
    for key in ("gate_input", "gate_angle", "gate_amplitude", "gate_current_p1", "gate_current_p3", "gate_rp"):
        row[key + "_at_reconnect"] = last[key] if last else None


class Ledger(physics.Tables):
    def add(self, name, row):
        if name == "m27_history":
            row["cumulative_rate"] = row["cumulative_net"] / (row["elapsed_total"] - row["fork_elapsed"])
            row["record_source"] = "m30"
        super().add(name.replace("m27_", "m30_"), row)


def _commit(tables, meta, trial, work, companion, bound, count, source_time):
    row, policy = trial.row, meta["policy"]
    add_diagnostics(policy, trial)
    if trial.wait_checks:
        initial = initial_coherence(row, trial)
        for check in trial.wait_checks:
            gate, inputs = eligible_sample(policy, initial, check)
            if gate != check["phase_gate"]:
                raise ValueError("The recorded permitted values do not reproduce the reconnect gate")
            selectors = ("q", "q0", "threshold_q", "amplitude", "c0_abs", "c0_real", "c_real", "angle")
            tables.add("m30_selector", {**meta, **{key: check[key] for key in ("elapsed_total", "observed_until", "wait_elapsed")},
                                        **{name: inputs.get(name) for name in selectors}, "gate": gate,
                                        "reconnect": check["reconnect"], "limit": check["fallback_limit"]})
    decision = {"elapsed_total": row["elapsed_start"], "observed_until": row["elapsed_start"], "reason": policy,
                "mode_before": "wait", "mode_after": "wait", "switched": False}
    return physics.add_attempt(tables, meta, decision, trial, work, companion, bound, count, source_time)


def cutoff_folder(cap):
    return f"t{cap / 1000:g}"


def _stage(model, meta, source, seed, destination, cap, previous):
    started = time.perf_counter()
    initial, fork, records = seed
    records = list(records)
    pair = initial
    clock, completed, count = fork, 0, 0
    work = companion = bound = 0.0
    resume_error = None
    precision, policy = meta["precision"], meta["policy"]
    primary = PRECISIONS.index(precision)

    if previous is not None:
        with np.load(previous / "checkpoint.npz", allow_pickle=False) as old:
            pair = tuple(old[f"anchor_{label}"] for label in PRECISIONS)
            clock, completed, count = map(int, old["counters"])
            work, companion, bound = map(float, old["work"])
            records = json.loads(str(old["records"].item()))
            old_tick = int(old["tick"].item())
            _, boundary, pending = _next_trial(model, pair, primary, clock, policy, records, old_tick)
            resume_error = max(physics.maxabs(state - old[label]) for state, label in zip(boundary.pair, PRECISIONS, strict=True))
            if (resume_error > FLOOR or boundary.coupling != float(old["coupling"].item())
                    or pending != json.loads(str(old["pending"].item()))):
                raise ValueError(f"Restart disagrees with the physical state or pending operations in {previous}")

    def energy(state, coupling):
        return float(np.einsum("ij,ji->", state, model.h[coupling]).real)

    origin_energy = tuple(energy(state, G) for state in initial)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix=".pending-", dir=destination.parent) as temporary:
        folder = Path(temporary) / "complete"
        folder.mkdir()
        tables = Ledger(folder)
        before_stage = completed
        try:
            while True:
                trial, boundary, pending = _next_trial(model, pair, primary, clock, policy, records, cap)
                if trial is None or trial.row is None:
                    if trial is not None:
                        attempt_meta = {**meta, "attempt": completed + 1}
                        for check in trial.wait_checks:
                            tables.add("m30_pending_wait_checks", {**attempt_meta, **check})
                        for observation in trial.observations:
                            tables.add("m30_pending_observations", {**attempt_meta, **observation})
                    break
                completed += 1
                work, companion, bound, count = _commit(tables, {**meta, "attempt": completed}, trial,
                                                         work, companion, bound, count, float(source["source_time"]))
                clock, pair = boundary.tick, trial.after
                records.append(physics.compact_record(trial.row))
                pair_work = (work, companion) if primary == 0 else (companion, work)
                residual = max(abs(energy(state, G) + collected - baseline)
                               for state, collected, baseline in zip(pair, pair_work, origin_energy, strict=True))
                if residual > FLOOR:
                    raise ValueError(f"Completed energy account failed {meta} at {clock}: {residual:g}")

            physicality = max(physics.half_physicality(state) for state in boundary.pair)
            if physicality > FLOOR:
                raise ValueError(f"Nonphysical boundary {cap} for {meta}: {physicality:g}")
            physical_work = work + pending.get("switch_net", 0.0)
            boundary_residual = energy(boundary.pair[primary], boundary.coupling) + physical_work - origin_energy[primary]
            if abs(boundary_residual) > FLOOR:
                raise ValueError(f"Pending energy account failed {meta} at {cap}: {boundary_residual:g}")
            ending = "time_cap" if clock == TOTAL_LIMIT else "time_cap_no_grid" if TOTAL_LIMIT - clock < GRID else "active"
            controller = json.dumps(vars(physics.Controller()), sort_keys=True)
            hashes = {f"{which}_{label}_sha256": physics.fingerprint(state)
                      for which, states in (("boundary", boundary.pair), ("anchor", pair), ("fork", initial))
                      for label, state in zip(PRECISIONS, states, strict=True)}
            np.savez_compressed(folder / "checkpoint.npz", coarse=boundary.pair[0], half=boundary.pair[1],
                                anchor_coarse=pair[0], anchor_half=pair[1], counters=(clock, completed, count),
                                tick=cap, coupling=boundary.coupling, phase=boundary.phase, source_time=float(source["source_time"]),
                                controller=controller, records=json.dumps(records, sort_keys=True),
                                pending=json.dumps(pending, sort_keys=True), work=(work, companion, bound), ending=ending,
                                fork_tick=fork, propagation=meta["propagation"], policy=policy,
                                fork_coarse_sha256=hashes["fork_coarse_sha256"], fork_half_sha256=hashes["fork_half_sha256"])
            summary = {**meta, "elapsed_total": cap / 1000, "anchor_elapsed": clock / 1000, "attempts": completed,
                       "attempts_in_stage": completed - before_stage, "count": count, "ending": ending,
                       "coupling": boundary.coupling, "phase": boundary.phase, "mode": "forecast",
                       "cumulative_net": work, "cumulative_net_aligned": companion,
                       "cumulative_physical_net": physical_work, "boundary_energy_residual": boundary_residual,
                       "cumulative_step_error_bound": bound, "boundary_physicality_error": physicality,
                       "resumed_state_error": resume_error, "cut_applied": pending.get("cut_applied", False),
                       "reconnect_applied": pending.get("reconnect_applied", False),
                       "pending_attempt_elapsed": clock / 1000 if trial is not None else None,
                       "pending_switch_net": pending.get("switch_net", 0.0), "pending_tau_tick": pending.get("tau"),
                       "forecast_tick": pending.get("forecast_tick"), "execute_tick": pending.get("execute_tick"),
                       "last_observation_tick": pending.get("last_observation_tick"), **hashes}
            tables.add("m30_checkpoints", summary)
        finally:
            tables.close()
        stage.publish_stage(folder, destination)
    return {**summary, "seconds": time.perf_counter() - started}


def run_branch(group, origin, policy, precision, destination, cutoffs, *, source=None, seed=None, propagation="rk4"):
    """Run online control, save physical boundaries, and verify restart equality."""
    condition_flags(policy)
    if source is None or seed is None:
        archived_source, archived_seed = seed_for(group, origin, precision)
        source = archived_source if source is None else source
        seed = archived_seed if seed is None else seed
    pair, fork, _ = seed
    cutoffs = tuple(cutoffs)
    if not cutoffs or tuple(sorted(set(cutoffs))) != cutoffs or not fork < cutoffs[-1] <= TOTAL_LIMIT:
        raise ValueError("Cutoffs must be distinct increasing ticks and end after the seed within 540")
    model = model_instance(propagation)
    if getattr(model, "m30_kernel_precision", None) != precision:
        model.time_kernel.cache_clear()
        model.m30_kernel_precision = precision
    meta = {"group": group, "origin": origin, "policy": policy, "precision": precision,
            "fork_elapsed": fork / 1000, "propagation": propagation}
    hashes = tuple(physics.fingerprint(state) for state in pair)
    previous, summaries = None, []
    with adapters():
        for cap in cutoffs:
            if cap <= fork:
                continue
            output = Path(destination) / cutoff_folder(cap)
            if output.exists():
                with np.load(output / "checkpoint.npz", allow_pickle=False) as saved:
                    if (saved["propagation"].item() != propagation or saved["policy"].item() != policy
                            or saved["fork_tick"].item() != fork or saved["tick"].item() != cap
                            or tuple(saved[f"fork_{label}_sha256"].item() for label in PRECISIONS) != hashes):
                        raise ValueError(f"Incompatible saved branch {output}")
                summary, = physics.csv_rows(output / "m30_checkpoints.csv")
            else:
                summary = _stage(model, meta, source, seed, output, cap, previous)
            summaries.append(summary)
            previous = output
    return summaries
