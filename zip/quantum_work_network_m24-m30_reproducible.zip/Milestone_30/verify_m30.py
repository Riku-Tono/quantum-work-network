"""Check M30's causal selection, energy accounts and numerical reference independently."""

import argparse
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor, as_completed
from contextlib import ExitStack
from functools import lru_cache
from itertools import product
import json
import math
import os
from pathlib import Path
import sys
from unittest.mock import patch


ROOT = Path(__file__).resolve().parent
M29 = ROOT.parent / "Milestone_29"
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
sys.path.insert(0, str(M29))
import verify_m29 as a29


a28, a27 = a29.a28, a29.a27
G, GRID = a27.G, a27.GRID
TICKS, NUMBER, FLAG = a27.ticks, a27.number, a27.flag
INSIST, TOLERANCE = a27.insist, a27.tolerance
RESOLUTIONS = ("coarse", "half")
METHODS = ("P3", "P3+I", "P3+A", "P3+IA", "P1", "P1+I", "P1+A", "RP")
GROUP_ORIGINS = {
    "F2-R": ("S0", "A04", "B04", "C04"),
    "F1": ("S0", "A04", "B04", "C04"),
    "recheck": ("U05", "U06", "U01", "U02", "U03", "U04"),
}
BOUNDARIES = (150_000, 300_000, 540_000)
COMMON = (50_000, 100_000, 150_000, 200_000, 300_000, 360_000, 450_000, 540_000)
GATE_FIELDS = ("gate_input", "gate_angle", "gate_amplitude", "gate_current_p1", "gate_current_p3")
INPUT_RESTORE = {"P3+I", "P3+IA", "P1+I", "RP"}
ANGLE_RESTORE = {"P3+A", "P3+IA", "P1+A", "RP"}
EPSILON_Q = 1e-11
# The pre-optimization verifier performed full independent replay for every
# direct branch. Verified results from it remain eligible under the same data hashes.
COMPATIBLE_AUDIT_SHA256 = {
    "dfad68dc1cee7cd06a66efce363a83ce3e2631f3d7626f55025147f3af9bd4c3",
    "f97be99b55f8dd3987c26735a3f3c3ace0ab8e54c4bf577a2feffa55c17b79eb",
}


def components(before, sample):
    q0, c0_abs, re0 = before
    real, imag, amplitude, phase = sample
    q = -imag
    return (
        real <= re0 + 1e-10,
        -3 * math.pi / 4 <= phase <= -math.pi / 4,
        amplitude >= 1e-5,
        q >= c0_abs / 4,
        q >= max(abs(q0) / 4, EPSILON_Q),
    )


def gate(policy, checks):
    inputs, angle, amplitude, p1_current, p3_current = checks
    baseline = p3_current if policy.startswith("P3") else amplitude and p1_current
    return baseline and (policy not in INPUT_RESTORE or inputs) and (policy not in ANGLE_RESTORE or angle)


def control_sentinels():
    from m30_control import condition_diagnostics, eligible_sample, physics, wait_until

    class Restricted(dict):
        def __getitem__(self, name):
            INSIST(name in self, f"Controller acquired undeclared {name}")
            return super().__getitem__(name)

        def get(self, name, default=None):
            return self[name]

    report = {}
    before = {"c_imag": 2e-5, "c_abs": 2e-4, "c_real": 2e-4}
    target = {"c_imag": -2e-4, "c_abs": 2e-4, "c_real": 0.0, "phase": -math.pi / 2, "load_current": 2 * G * 2e-4}
    fails = {**target, "c_imag": 2e-4, "phase": math.pi / 2, "load_current": -2 * G * 2e-4}
    levels = (math.nextafter(-3 * math.pi / 4, -math.inf), -3 * math.pi / 4, -math.pi / 4,
              math.nextafter(-math.pi / 4, math.inf), -math.pi / 2)
    re_bound = before["c_real"] + 1e-10
    for policy in METHODS:
        p3 = policy.startswith("P3")
        initial_keys = {"c_imag" if p3 else "c_abs"}
        measurement_keys = {"c_imag"} if p3 else {"c_imag", "c_abs"}
        if policy in INPUT_RESTORE:
            initial_keys |= {"c_real"}
            measurement_keys |= {"c_real"}
        if policy in ANGLE_RESTORE:
            measurement_keys |= {"phase"}
        restricted_initial = Restricted({name: before[name] for name in initial_keys})
        boundary_checks = 0
        for real, amplitude, angle, q in product(
            (re_bound, math.nextafter(re_bound, math.inf), 0.0), (1e-5, math.nextafter(1e-5, 0.0)), levels,
            (1e-11, 5e-6, math.nextafter(5e-6, 0.0), 5e-5, math.nextafter(5e-5, 0.0), 2e-4),
        ):
            values = {"c_real": real, "c_imag": -q, "c_abs": amplitude, "phase": angle, "load_current": 2 * G * q}
            allowed = Restricted({name: values[name] for name in measurement_keys})
            expected = components((-before["c_imag"], before["c_abs"], before["c_real"]), (real, -q, amplitude, angle))
            actual, _ = eligible_sample(policy, restricted_initial, allowed)
            INSIST(actual is gate(policy, expected), f"Acquisition adapter or boundary differs for {policy}")
            diagnostics = condition_diagnostics(before, values)
            INSIST(tuple(diagnostics[field] for field in GATE_FIELDS) == expected
                   and diagnostics["gate_rp"] == gate("RP", expected), f"Diagnostic boundary differs for {policy}")
            boundary_checks += 1
        cap_checks = []
        for cutoff, successful, window, until, last, reason in (
            (1199, True, 18_000, (1000,), None, "phase_limit"),
            (1200, True, 18_000, (1000, 1200), 1200, "phase_gate"),
            (6000, True, 18_000, (1000, 1200), 1200, "phase_gate"),
            (6000, False, 18_000, tuple(range(1000, 6001, 200)), 6000, "phase_limit"),
            (1400, False, 1430, (1000, 1200, 1400), 1400, "phase_limit"),
            (1000, False, 1000, (), 0, "no_wait_fits"),
        ):
            visits = []

            def observe(tick):
                INSIST(tick in until and tick <= cutoff and tick not in visits,
                       f"Control read an unavailable observation at {policy}/{cutoff}/{tick}")
                visits.append(tick)
                return target if successful and tick == 1200 else fails

            with patch.object(physics, "phase_observer", lambda *_: observe):
                received, actual_reason, points = wait_until(object(), (object(),), 0, 0, window, policy, "wait", (), cutoff, None, before)
            INSIST(tuple(visits) == until and received == last and actual_reason == reason
                   and len(points) == len(visits), f"Wrong online prefix, gate termination or timeout at {policy}/{cutoff}")
            if received not in (None, 0):
                final = points[-1]
                INSIST(final["reconnect"] and final["fallback_limit"] == (actual_reason == "phase_limit")
                       and final["fallback_window_limit"] == (actual_reason == "phase_limit" and window == 1430),
                       f"Forced reconnect audit failed for {policy}/{cutoff}")
            cap_checks.append({"cutoff": cutoff / 1000, "window": window / 1000, "decision": actual_reason,
                               "samples": len(visits)})
        report[policy] = {"truth_table_cases": boundary_checks, "restricted_initial_fields": sorted(initial_keys),
                          "restricted_wait_fields": sorted(measurement_keys), "time_prefix_exercises": cap_checks}
    return report


def path_m30(path):
    return path.with_name(path.name.replace("m28_", "m30_", 1).replace("m29_", "m30_", 1))


def read(path):
    return a27.read_rows(path_m30(path))


def table(path):
    return read(path) if path_m30(path).is_file() else []


def stage_tables(folder):
    history = table(folder / "m30_history.csv")
    decisions = a27.read_unique(table(folder / "m30_decisions.csv"), lambda row: int(row["attempt"]))
    waits = a27.read_unique(table(folder / "m30_waits.csv"), lambda row: int(row["attempt"]))
    checks = a27.group_attempt(table(folder / "m30_wait_checks.csv"))
    observations = a27.group_attempt(table(folder / "m30_observations.csv"))
    selectors = a27.group_attempt(table(folder / "m30_selector.csv"))
    attempts = {int(row["attempt"]) for row in history}
    INSIST(attempts == set(decisions) == set(observations) and set(checks) <= attempts
           and set(waits) <= attempts and checks.keys() == selectors.keys(),
           f"Mismatched trial inventories {folder}")
    return history, decisions, waits, checks, observations, {int(row["attempt"]): {**row, "selectors": selectors[int(row["attempt"])]}
                                                            for row in history}


def audit_wait(model, row, witnesses, anchor, context):
    start, tau, window = (TICKS(row, field) for field in ("elapsed_start", "tau", "window"))
    policy = row["policy"]
    limit = min(6000, window - GRID) // 200 * 200
    if limit < 1000:
        INSIST(tau == 0 and not witnesses and row["wait_reason"] == "no_wait_fits",
               f"Wait unexpectedly fits at {context}")
        return
    delays = tuple(range(1000, tau + 1, 200))
    INSIST(1000 <= tau <= limit and tau % 200 == 0 and len(witnesses) == len(delays),
           f"Bad detached sampling prefix at {context}")
    before = (-NUMBER(row, "c_imag_before"), NUMBER(row, "c_abs_before"), NUMBER(row, "c_real_before"))
    TOLERANCE(row["current_before"], 2 * G * before[0], f"Cut coherence/current at {context}", 1e-15)
    TOLERANCE(row["cut_on"], -2 * G * before[2], f"Cut coherence/work at {context}", 1e-15)
    if model is not None:
        before_exact = complex(model.detached_c(anchor, 0))
        for actual, expected in zip(before, (-before_exact.imag, abs(before_exact), before_exact.real), strict=True):
            TOLERANCE(actual, expected, f"Initial physical coherence {context}", a27.HALF_TOL)
    for point, delay in zip(witnesses, delays, strict=True):
        clock = start + delay
        INSIST(TICKS(point, "elapsed_total") == TICKS(point, "observed_until") == clock
               and TICKS(point, "wait_elapsed") == delay, f"Unavailable detached sample at {context}/{delay}")
        real, imag, magnitude, phase = (NUMBER(point, field) for field in ("c_real", "c_imag", "c_abs", "phase"))
        if model is not None:
            independent = complex(model.detached_c(anchor, delay))
            TOLERANCE(real, independent.real, f"Detached real part at {context}/{delay}", a27.HALF_TOL)
            TOLERANCE(imag, independent.imag, f"Detached imaginary part at {context}/{delay}", a27.HALF_TOL)
        TOLERANCE(magnitude, math.hypot(real, imag), f"Detached magnitude at {context}/{delay}", 1e-15)
        TOLERANCE(math.remainder(phase - math.atan2(imag, real), math.tau), 0,
                  f"Detached phase at {context}/{delay}", 1e-12)
        TOLERANCE(point["load_current"], -2 * G * imag, f"Potential loaded current at {context}/{delay}", 1e-15)
        TOLERANCE(point["actual_current"], 0.0, f"Physical detached current at {context}/{delay}", 1e-15)
        checks = components(before, (real, imag, magnitude, phase))
        passed = gate(policy, checks)
        forced = delay == limit and not passed
        INSIST(tuple(FLAG(point, name) for name in GATE_FIELDS) == checks and FLAG(point, "phase_gate") == passed,
               f"Logged search conditions differ at {context}/{delay}")
        INSIST(FLAG(point, "gate_rp") == gate("RP", checks)
               and FLAG(point, "at_window_limit") == (delay == limit) and FLAG(point, "at_max_wait") == (delay == 6000),
               f"Diagnostic rule or wait limits differ at {context}/{delay}")
        INSIST(FLAG(point, "reconnect") == (passed or forced) == (delay == tau)
               and FLAG(point, "fallback_limit") == forced, f"First reconnect or forced limit differs at {context}/{delay}")
    INSIST(row["wait_reason"] == ("phase_limit" if forced else "phase_gate"),
           f"Wrong reconnect reason at {context}")


def audit_counts(row, selectors, checks, observations, context):
    policy = row["policy"]
    start, tau, window = (TICKS(row, field) for field in ("elapsed_start", "tau", "window"))
    saw_start = int(tau > 0)
    p3 = policy.startswith("P3")
    width_start = 1 if p3 and policy not in INPUT_RESTORE else 2
    width_wait = 1 if policy == "P3" else 2
    samples = len(checks)
    expected = {
        "decision_observations": saw_start + samples,
        "phase_observations": saw_start + samples,
        "initial_phase_observations": saw_start,
        "wait_phase_observations": samples,
        "observed_scalars": saw_start * width_start + samples * width_wait,
        "initial_reconnect_scalars": saw_start * width_start,
        "wait_reconnect_scalars": samples * width_wait,
        "retained_reference_scalars": saw_start * (1 + (policy in INPUT_RESTORE)),
        "reconnect_abs_evaluations": 0 if p3 else saw_start + samples,
        "reconnect_threshold_abs_evaluations": saw_start if p3 else 0,
        "reconnect_atan2_evaluations": samples if policy in ANGLE_RESTORE else 0,
        "reconnect_a_observations": len(observations),
    }
    for name, count in expected.items():
        INSIST(int(row[name]) == count, f"Acquisition count differs at {context}/{name}")
    INSIST(all(FLAG(point, "used_by_control") for point in checks), f"Detached measurement marked unused at {context}")
    INSIST(FLAG(row, "fallback_limit") == (row["wait_reason"] == "phase_limit")
           and FLAG(row, "at_max_wait") == (tau == 6000), f"Limit bookkeeping differs at {context}")
    INSIST(TICKS(row, "reconnect_elapsed") == start + tau, f"Reconnection time disagrees at {context}")
    INSIST(FLAG(row, "fallback_max_wait") == (FLAG(row, "fallback_limit") and tau == 6000)
           and FLAG(row, "fallback_window_limit") == (FLAG(row, "fallback_limit") and tau < 6000),
           f"Forced 6 vs shortened deadline classification differs at {context}")
    if "at_window_limit" in row:
        INSIST(FLAG(row, "at_window_limit") == bool(tau and tau == min(6000, window - GRID) // 200 * 200),
               f"Feasible last clock differs at {context}")
    before = (-NUMBER(row, "c_imag_before"), NUMBER(row, "c_abs_before"), NUMBER(row, "c_real_before"))
    selectors_fields = ("q", "q0", "threshold_q", "amplitude", "c0_abs", "c0_real", "c_real", "angle")
    for log, point in zip(selectors, checks, strict=True):
        real, imag, magnitude, phase = (NUMBER(point, field) for field in ("c_real", "c_imag", "c_abs", "phase"))
        expected_inputs = {"q": -imag}
        if p3:
            expected_inputs.update(q0=before[0], threshold_q=max(abs(before[0]) / 4, EPSILON_Q))
        else:
            expected_inputs.update(amplitude=magnitude, c0_abs=before[1], threshold_q=before[1] / 4)
        if policy in INPUT_RESTORE:
            expected_inputs.update(c0_real=before[2], c_real=real)
        if policy in ANGLE_RESTORE:
            expected_inputs["angle"] = phase
        for name in selectors_fields:
            if name in expected_inputs:
                TOLERANCE(log[name], expected_inputs[name], f"Selector physical input at {context}/{name}", 1e-15)
            else:
                INSIST(not log[name], f"Unexpected selector input at {context}/{name}")
        INSIST(all(log[name] == point[name] for name in ("elapsed_total", "observed_until", "wait_elapsed"))
               and FLAG(log, "gate") == FLAG(point, "phase_gate")
               and FLAG(log, "reconnect") == FLAG(point, "reconnect")
               and FLAG(log, "limit") == FLAG(point, "fallback_limit"), f"Selector/wait evidence differs at {context}")
    for field, expected_value in (("cut_work", -NUMBER(row, "cut_on")), ("reconnect_input", NUMBER(row, "reconnect_on")),
                                  ("passivation_work", NUMBER(row, "direct_total_work") if FLAG(row, "accepted") else 0.0)):
        TOLERANCE(row[field], expected_value, f"Signed operation work at {context}/{field}", 1e-15)
    TOLERANCE(NUMBER(row, "cut_work") - NUMBER(row, "reconnect_input") + NUMBER(row, "passivation_work"),
              NUMBER(row, "net_work"), f"Event decomposition at {context}", 1e-12)


def assemble(folders):
    history, wait, connected = [], defaultdict(list), defaultdict(list)
    for folder in folders.values():
        rows, _, _, checks, observations, _ = stage_tables(folder)
        history.extend(rows)
        wait.update(checks)
        connected.update(observations)
    return history, wait, connected


def account_at(history, tick):
    completed_work, switch_work, load_work = [], [], []
    for row in history:
        start, tau, end = (TICKS(row, field) for field in ("elapsed_start", "tau", "elapsed_total"))
        cut, reconnect, net = (NUMBER(row, field) for field in ("cut_on", "reconnect_on", "net_work"))
        if start <= tick and tau:
            switch_work.append(-cut)
            if start + tau <= tick:
                switch_work.append(-reconnect)
        if end <= tick:
            completed_work.append(net)
            if FLAG(row, "accepted"):
                load_work.append(NUMBER(row, "direct_total_work"))
    switched = math.fsum(switch_work)
    extracted = math.fsum(load_work)
    return math.fsum(completed_work), switched + extracted


def audit_pending(folders, history, wait, connected):
    pending_count = 0
    projection_error = 0.0
    for cap, folder in folders.items():
        pending = next((row for row in history if TICKS(row, "elapsed_start") <= cap < TICKS(row, "elapsed_total")), None)
        attempt = int(pending["attempt"]) if pending else None
        for name, completed in (("wait_checks", wait), ("observations", connected)):
            rows = table(folder / f"m30_pending_{name}.csv")
            available = [row for row in completed.get(attempt, ()) if TICKS(row, "elapsed_total") <= cap]
            INSIST(len(rows) == len(available), f"Pending {name} does not reproduce complete trajectory prefix at {folder}")
            for witness, full in zip(rows, available, strict=True):
                for field in witness.keys() & full.keys():
                    if witness[field] == full[field] or field == "used_by_control":
                        continue
                    if field in ("load_ergotropy", "load_ergotropy_rate", "total_work", "c_real", "c_imag",
                                 "c_abs", "phase", "load_current"):
                        # At a reused boundary the fresh bounded projection may use
                        # a different reduction from the archived completed sample.
                        difference = NUMBER(witness, field) - NUMBER(full, field)
                        if field == "phase":
                            difference = math.remainder(difference, math.tau) * NUMBER(full, "c_abs")
                        projection_error = max(projection_error, abs(difference))
                        TOLERANCE(difference, 0.0, f"Pending physical projection differs at {folder}/{field}", 1e-15)
                    else:
                        raise ValueError(f"Pending {name} control clock or flags changed at {folder}/{field}")
            pending_count += len(rows)
    return pending_count, projection_error


def archive_match(key, history):
    if key[2] not in ("P1", "P3", "RP"):
        return None
    archive_key = (("unseen" if key[0] == "recheck" else key[0]), *key[1:])
    legacy_rp = key[0] != "recheck" and key[2] == "RP"
    directory, prefix = (a29.M28, "m28") if legacy_rp else (M29, "m29")
    files = [directory / "stages" / f"t{cap // 1000}" / Path(*archive_key) / f"{prefix}_history.csv" for cap in BOUNDARIES]
    rows = [row for file in files if file.is_file() for row in a27.read_rows(file)]
    INSIST(len(rows) == len(history), f"Inherited {key} attempts differ from M29")
    fields = ("elapsed_start", "tau", "decision_elapsed_total", "elapsed_total", "accepted",
              "start_coarse_sha256", "start_half_sha256", "post_coarse_sha256", "post_half_sha256")
    for old, new in zip(rows, history, strict=True):
        INSIST(all(old[field] == new[field] for field in fields), f"Inherited {key} action/state differs at {new['attempt']}")
        TOLERANCE(old["net_work"], float(new["net_work"]), f"Inherited {key} trial work", 1e-14)
    return {"identical_operation_and_density_hashes": True, "attempts": len(rows), "reference_milestone": prefix.upper()}


def fixed_operation(key, folders, seed, source_time):
    with patch.object(a29, "table_m29", table):
        report = a29.exact_drift_diagnostic(key, folders, seed, source_time)
    report["old_continuous_threshold_exceeded"] = (
        report["continuous"]["max_global_energy_error"] > a27.EXACT_WORK_TOL
        or any(row["continuous_max_density_element_error"] > a27.HALF_TOL for row in report["anchor_comparisons"])
    )
    return report


class SectorRK4(a29.DiscreteReplay):
    """Apply the independent M29 RK4 polynomial after a blockwise basis change."""

    def evolve(self, state, coupling, elapsed):
        if not elapsed:
            return state
        rate = {"coarse": 400, "half": 800}[state.sha256]
        count = round(elapsed * rate)
        INSIST(abs(count - elapsed * rate) < 1e-7, "Independent RK4 sample is outside its step lattice")
        vectors = tuple(system[1] for system in self.sector_spectra[coupling])
        scratch = a27.np.empty_like(state.matrix)
        represented = a27.np.empty_like(state.matrix)
        for sector, vector in zip(self.sectors, vectors, strict=True):
            scratch[sector, :] = vector.T @ state.matrix[sector, :]
        for sector, vector in zip(self.sectors, vectors, strict=True):
            represented[:, sector] = scratch[:, sector] @ vector
        represented *= a27.np.exp(count * self.logarithm(coupling, rate))
        for sector, vector in zip(self.sectors, vectors, strict=True):
            scratch[sector, :] = vector @ represented[sector, :]
        for sector, vector in zip(self.sectors, vectors, strict=True):
            represented[:, sector] = scratch[:, sector] @ vector.T
        return a27.State(represented, state.time + elapsed, state.sha256)


@lru_cache(maxsize=2)
def audited_model(exact):
    return a27.ReplayModel() if exact else SectorRK4()


def audit_reuse(key, folders, fingerprints):
    matches = []
    for cap, folder in folders.items():
        proof_path = folder / "equivalent_policy.json"
        if not proof_path.is_file():
            continue
        proof = json.loads(proof_path.read_text(encoding="utf-8"))
        prefix = proof["source_prefix"]
        source = (ROOT / proof["source"]).resolve()
        current_stage_root = folder.resolve().parents[4]
        allowed = {"m28": a29.M28.resolve(), "m29": M29.resolve(), "m30": current_stage_root}
        INSIST(prefix in allowed and source.is_relative_to(allowed[prefix]) and source != folder.resolve(),
               f"Unregistered equivalence source at {folder}")
        chain = {folder.resolve()}
        ancestor = source
        while ancestor.is_relative_to(current_stage_root) and (archive := ancestor / "equivalent_policy.json").is_file():
            INSIST(ancestor not in chain, f"Circular equivalent-policy proof at {folder}")
            chain.add(ancestor)
            predecessor = json.loads(archive.read_text(encoding="utf-8"))["source"]
            ancestor = (ROOT / predecessor).resolve()
        source_checkpoint = source / "checkpoint.npz"
        source_history = source / f"{prefix}_history.csv"
        INSIST(a27.sha256(source_checkpoint) == proof["source_checkpoint_sha256"]
               and (a27.sha256(source_history) if source_history.is_file() else None) == proof["source_history_sha256"]
               and proof["fork_hashes"] == [fingerprints[label] for label in RESOLUTIONS],
               f"Equivalent-policy source changed at {folder}")
        history = table(folder / "m30_history.csv")
        source_rows = a27.read_rows(source_history) if source_history.is_file() else []
        source_checks_path = source / f"{prefix}_wait_checks.csv"
        source_checks = a27.read_rows(source_checks_path) if source_checks_path.is_file() else []
        checks = table(folder / "m30_wait_checks.csv")
        INSIST(len(source_rows) == len(history) == proof["same_first_choice_attempts"]
               and len(source_checks) == len(checks) == proof["scalar_samples"],
               f"Incomplete equivalent-policy proof at {folder}")
        operations = ("attempt", "tau", "elapsed_start", "elapsed_total", "decision_elapsed_total", "accepted",
                      "start_coarse_sha256", "start_half_sha256", "post_coarse_sha256", "post_half_sha256")
        for old, new in zip(source_rows, history, strict=True):
            INSIST(all(old[name] == new[name] for name in operations), f"Equivalence alters executed operations at {folder}")
            for field in ("net_work", "cut_on", "reconnect_on"):
                TOLERANCE(old[field], float(new[field]), f"Equivalent-policy work at {folder}/{field}", 1e-15)
        for old, new in zip(source_checks, checks, strict=True):
            INSIST(TICKS(old, "elapsed_total") == TICKS(new, "elapsed_total") <= cap,
                   f"Equivalence uses another observation clock at {folder}")
            for field in ("c_real", "c_imag", "c_abs", "phase"):
                TOLERANCE(old[field], float(new[field]), f"Equivalent-policy measurement at {folder}/{field}", 1e-15)
        with a27.np.load(source_checkpoint, allow_pickle=False) as old:
            with a27.np.load(folder / "checkpoint.npz", allow_pickle=False) as new:
                INSIST(int(old["tick"].item()) == int(new["tick"].item()) == cap
                       and int(old["fork_tick"].item()) == int(new["fork_tick"].item()) == proof["fork_tick"]
                       and all(a27.np.array_equal(old[name], new[name]) for name in
                               ("coarse", "half", "anchor_coarse", "anchor_half", "pending", "counters", "work")),
                       f"Equivalent-policy archive state differs at {folder}")
        ancestor_path = os.path.relpath(ancestor, ROOT)
        matches.append({"boundary": cap / 1000, "source": proof["source"], "source_digest": proof["source_checkpoint_sha256"],
                        "ultimate_source": ancestor_path, "attempts": len(history), "detached_observations": len(checks)})
    return matches


@lru_cache(maxsize=1)
def prior_audits():
    inventory = {}
    specs = ((a29.M28, ("audit_matched.json", "audit_ablations.json")),
             (M29, ("audit_f1.json", "audit_f2r.json", "audit_unseen.json")))
    for root, filenames in specs:
        generation = root.name.rsplit("_", 1)[-1]
        for filename in filenames:
            path = root / "results" / filename
            data = json.loads(path.read_text(encoding="utf-8"))
            INSIST(data["protocol_sha256"] == a27.sha256(root / f"PROTOCOL_M{generation}.md")
                   and data.get("boundaries", data.get("cutoffs")) == [150, 300, 540], f"Prior audit envelope differs at {path}")
            branches = data["matched"]["branch_results"] if generation == "28" else data["stage_audit"]["branches"]
            for label, statistics in branches.items():
                inventory[root.resolve(), tuple(label.split("/"))] = (path, a27.sha256(path), statistics)
    return inventory


def inherited_audit(key, folders, sources, history, wait, observed):
    if len(sources) != len(folders):
        return None
    source_paths = [(ROOT / record["ultimate_source"]).resolve() for record in sources]
    owners = [next((root.resolve() for root in (a29.M28, M29) if path.is_relative_to(root.resolve())), None)
              for path in source_paths]
    identity = tuple(source_paths[0].parts[-4:])
    if owners[0] is None or len(set(owners)) != 1 or any(tuple(path.parts[-4:]) != identity for path in source_paths):
        return None
    reference = prior_audits().get((owners[0], identity))
    if reference is None:
        return None
    audit_path, digest, previous = reference
    if (int(previous["attempts"]) != len(history)
            or int(previous["connected_observations"]) != sum(map(len, observed.values()))
            or int(previous["detached_observations"]) != sum(map(len, wait.values()))):
        return None
    expected = ("attempt", "elapsed_start", "tau", "elapsed_total", "elapsed_connected", "decision_elapsed_total",
                "observed_until", "accepted", "stop_reason", "window", "start_coarse_sha256", "start_half_sha256",
                "post_coarse_sha256", "post_half_sha256")
    prior_prefix = "m28" if owners[0] == a29.M28.resolve() else "m29"
    state_model = audited_model(True)
    energy_residual = 0.0
    origin_energy = None
    completed = []
    for (cap, folder), archived in zip(folders.items(), source_paths, strict=True):
        archived_history_path = archived / f"{prior_prefix}_history.csv"
        archived_wait_path = archived / f"{prior_prefix}_wait_checks.csv"
        archived_connected_path = archived / f"{prior_prefix}_observations.csv"
        archived_history = a27.read_rows(archived_history_path) if archived_history_path.is_file() else []
        archived_wait = a27.read_rows(archived_wait_path) if archived_wait_path.is_file() else []
        archived_connected = a27.read_rows(archived_connected_path) if archived_connected_path.is_file() else []
        rows, decisions, _, checks, observations, diagnostics = stage_tables(folder)
        INSIST(len(archived_history) == len(rows) and len(archived_wait) == sum(map(len, checks.values()))
               and len(archived_connected) == sum(map(len, observations.values())),
               f"Prior and inherited physics inventories differ at {key}/{cap}")
        for old, row in zip(archived_history, rows, strict=True):
            attempt = int(row["attempt"])
            context = key, attempt
            INSIST(all(old[field] == row[field] for field in expected), f"Prior operation replay differs at {context}")
            for field in ("start_global_energy", "post_global_energy", "net_work", "cut_on", "reconnect_on", "direct_total_work"):
                TOLERANCE(old[field], float(row[field]), f"Prior physical quantity differs at {context}/{field}", 1e-15)
            decision = decisions[attempt]
            start = TICKS(row, "elapsed_start")
            INSIST(TICKS(decision, "observed_until") == TICKS(decision, "elapsed_total") == start
                   and decision["reason"] == key[2] and not FLAG(decision, "switched"),
                   f"Inherited branch decision uses future data for {context}")
            audit_wait(None, row, checks[attempt], None, context)
            audit_counts(row, diagnostics[attempt]["selectors"], checks[attempt], observations[attempt], context)
            samples = observations[attempt]
            tau = TICKS(row, "tau")
            connected = TICKS(row, "elapsed_connected")
            window = TICKS(row, "window")
            sample_work = [(NUMBER(w, "load_ergotropy"), NUMBER(w, "load_ergotropy_rate")) for w in samples]
            decided, executed, reason = a27.first_a_forecast(sample_work, (window - tau) // GRID)
            INSIST(executed == connected // GRID and TICKS(row, "decision_elapsed_total") == start + tau + decided * GRID
                   and row["stop_reason"] == reason, f"Independent A prefix replay differs at {context}")
            for index, sample in enumerate(samples):
                INSIST(TICKS(sample, "observed_until") == TICKS(sample, "elapsed_total") == start + tau + index * GRID
                       and FLAG(sample, "forecast_generated") == (index == decided)
                       and FLAG(sample, "execute") == (index == executed), f"Noncausal A witness at {context}/{index}")
            if origin_energy is None:
                origin_energy = NUMBER(row, "start_global_energy")
            completed.append(NUMBER(row, "net_work"))
        for archived_points, published_points, fields in (
            (archived_wait, (point for values in checks.values() for point in values), ("c_real", "c_imag", "c_abs", "phase")),
            (archived_connected, (point for values in observations.values() for point in values),
             ("c_real", "c_imag", "load_ergotropy", "load_ergotropy_rate", "total_work")),
        ):
            for old, new in zip(archived_points, published_points, strict=True):
                INSIST(TICKS(old, "elapsed_total") == TICKS(new, "elapsed_total"), f"Archived physical signal clock differs at {folder}")
                for field in fields:
                    TOLERANCE(old[field], float(new[field]), f"Archived physical signal differs at {folder}/{field}", 1e-15)
        if origin_energy is None:
            return None
        checkpoint, = table(folder / "m30_checkpoints.csv")
        with a27.np.load(folder / "checkpoint.npz", allow_pickle=False) as saved:
            with a27.np.load(archived / "checkpoint.npz", allow_pickle=False) as reference_state:
                INSIST(all(a27.np.array_equal(saved[field], reference_state[field])
                           for field in ("coarse", "half", "anchor_coarse", "anchor_half", "tick", "coupling", "work", "pending")),
                       f"Inherited saved density, clock or pending state changed at {folder}")
            rho = saved[key[-1]]
            coupling = float(saved["coupling"].item())
            a27.physical_state(a27.State(rho, cap / 1000), str(folder))
            closed = state_model.energy(a27.State(rho, cap / 1000), coupling) + math.fsum(completed) + NUMBER(checkpoint, "pending_switch_net")
            energy_residual = max(energy_residual, abs(closed - origin_energy))
            TOLERANCE(closed, origin_energy, f"Inherited saved physical energy closure at {folder}", 1e-12)
    return {**previous, "max_energy_residual": max(previous["max_energy_residual"], energy_residual),
            "propagation_audit": "archived_independent_physics_and_M30_independent_causal_replay",
            "prior_audit": {"file": os.path.relpath(audit_path, ROOT), "sha256": digest, "branch": "/".join(identity)}}


def replay_direct(key, folders, seed, source_time, fingerprints, exact, counts):
    def pending_from_action(row, observations, checks, cutoff):
        return a27.cross_boundary_pending({**row, "policy": "RP"}, observations, checks, cutoff)

    with ExitStack() as patches:
        for name, function in (("READ_CSV", read), ("table_m28", table), ("stage_tables", stage_tables),
                               ("audit_wait_choice", audit_wait), ("audit_current", counts),
                               ("ABLATIONS", {policy: None for policy in METHODS}), ("pending_from_action", pending_from_action)):
            patches.enter_context(patch.object(a28, name, function))
        patches.enter_context(patch.object(a28, "ReplayModel", lambda: audited_model(exact)))
        if not exact:
            patches.enter_context(patch.object(a27, "exact_action", a29.discrete_actions(key[-1])))
        report = a28.audit_matched_job(key, folders, seed, source_time, fingerprints)
    report["propagation_audit"] = "independent_exact_unitary" if exact else "independent_same_step_RK4"
    return report


def audit_branch(key, folders, seed, source_time, fingerprints, exact, fixed, old_archive):
    def counts(current, row, connected, checks, phase_used, context):
        INSIST(phase_used, f"Method registry lost phase control at {context}")
        audit_counts(row, current["selectors"], checks, connected, context)
    history, wait, observed = assemble(folders)
    sources = audit_reuse(key, folders, fingerprints) if old_archive else []
    archive = archive_match(key, history) if old_archive else None
    same_trajectory = sources
    if old_archive and not sources and archive and key[0] == "recheck":
        same_trajectory = [{"ultimate_source": M29 / "stages" / f"t{cap // 1000}" / "unseen" / Path(*key[1:])}
                           for cap in folders]
    report = inherited_audit(key, folders, same_trajectory, history, wait, observed) if old_archive else None
    if report is None:
        report = replay_direct(key, folders, seed, source_time, fingerprints, exact, counts)
    report.update({field: sum(int(row[field]) for row in history) for field in
                   ("observed_scalars", "decision_observations", "phase_observations")})
    report["forced_limits"] = sum(FLAG(row, "fallback_limit") for row in history)
    report["max_waits"] = sum(FLAG(row, "at_max_wait") for row in history)
    report["pending_prefix_samples_reproduced"], report["max_pending_projection_error"] = audit_pending(folders, history, wait, observed)
    report["event_ledgers"] = {}
    for tick in COMMON:
        if tick < round(report["fork_elapsed"] * 1000):
            continue
        committed, executed = account_at(history, tick)
        report["event_ledgers"][str(tick // 1000)] = {"completed_net": committed, "physical_net": executed}
        if tick in folders:
            summary, = read(folders[tick] / "m30_checkpoints.csv")
            TOLERANCE(summary["cumulative_net"], committed, f"Completed checkpoint work at {key}/{tick}", 1e-12)
            TOLERANCE(NUMBER(summary, "cumulative_net") + NUMBER(summary, "pending_switch_net"), executed,
                      f"Executed cut/reconnect/passivation account at {key}/{tick}", 1e-12)
    if old_archive:
        report["M29_reproduction"] = archive
        report["equivalence_sources"] = sources
    if fixed:
        inherited_reference = report.get("exact_vs_discrete_diagnostic")
        if inherited_reference:
            diagnostic = dict(inherited_reference)
            diagnostic["old_continuous_threshold_exceeded"] = (
                diagnostic["continuous"]["max_global_energy_error"] > a27.EXACT_WORK_TOL or
                any(point["continuous_max_density_element_error"] > a27.HALF_TOL for point in diagnostic["anchor_comparisons"])
            )
            diagnostic["reference_inherited_from"] = report["prior_audit"]
            report["fixed_operation_exact"] = diagnostic
        else:
            report["fixed_operation_exact"] = fixed_operation(key, folders, seed, source_time)
    return report


def anchor_registry():
    legacy_root = a29.M28 / "anchors"
    prepared_root = M29 / "anchors"
    previous = json.loads((M29 / "results" / "audit_unseen_preparations.json").read_text(encoding="utf-8"))
    previous_states = previous.get("unseen_preparations", previous)["states"]
    result = {}
    for base, name in ((legacy_root, "m28_anchors.csv"), (prepared_root, "m29_unseen_anchors.csv")):
        for row in a27.read_rows(base / name):
            group, origin, precision = (row[field] for field in ("group", "origin", "precision"))
            anchor = (base / row["anchor_file"]).resolve()
            hashes = {label: row[f"{label}_sha256"] for label in RESOLUTIONS}
            with a27.np.load(anchor, allow_pickle=False) as data:
                INSIST(int(data["tick"].item()) == TICKS(row, "fork_elapsed")
                       and float(data["source_time"].item()) == NUMBER(row, "source_time"),
                       f"Anchor clock disagrees with archived registry for {group}/{origin}/{precision}")
                for label, digest in hashes.items():
                    INSIST(a27.state_sha256(data[label]) == digest, f"Anchor matrix hash differs at {anchor}/{label}")
                    a27.physical_state(a27.State(data[label], NUMBER(row, "source_time")), f"{anchor}/{label}")
            if group == "unseen":
                expected = previous_states[origin]["physical"][precision]["archive_hash"]
                INSIST(a27.sha256(anchor) == row["archive_sha256"] and hashes[precision] == expected,
                       f"Known U-state hash not bound to M29 preparation audit for {origin}/{precision}")
                group = "recheck"
            result[group, origin, precision] = anchor, NUMBER(row, "source_time"), hashes
    return result


def branch_folders(path, key, boundaries):
    return {clock: path.joinpath(*key, f"t{clock // 1000}") for clock in boundaries}


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(data, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def audit_branches(path, selected, boundaries, workers, exact, partial, digest, cache):
    initial = anchor_registry()
    inputs = {}
    results = {}
    for key in selected:
        folders = branch_folders(path, key, boundaries)
        if any(not (folder / "checkpoint.npz").is_file() for folder in folders.values()):
            INSIST(partial, f"Missing saved branch {'/'.join(key)} in {path}")
            continue
        fixed = not exact and key[:2] in (("recheck", "U05"), ("recheck", "U06"))
        cache_file = cache / ("_".join(key) + ".json")
        # Hash inputs and the audit implementation so a previous invocation can be resumed safely.
        source = {str(file.relative_to(path)): a27.sha256(file) for folder in folders.values()
                  for file in sorted(folder.iterdir()) if file.name in ("checkpoint.npz", "equivalent_policy.json")
                  or file.suffix == ".csv"}
        metadata = {"protocol_sha256": digest, "audit_sha256": a27.sha256(Path(__file__)),
                    "precision_mode": "exact" if exact else "rk4", "inputs": source}
        if cache_file.is_file():
            saved = json.loads(cache_file.read_text(encoding="utf-8"))
            previous_metadata = saved["metadata"]
            same_verification = (previous_metadata["audit_sha256"] in COMPATIBLE_AUDIT_SHA256 and
                                 {**previous_metadata, "audit_sha256": metadata["audit_sha256"]} == metadata)
            if previous_metadata == metadata or same_verification:
                results[key] = saved["audit"]
                continue
        inputs[key] = (key, folders, *initial[key[0], key[1], key[-1]], exact, fixed, not exact), cache_file, metadata

    def store(key, report):
        _, destination, metadata = inputs[key]
        write_json(destination, {"metadata": metadata, "audit": report})
        results[key] = report

    if workers == 1:
        for key, (inputs_for_key, _, _) in inputs.items():
            store(key, audit_branch(*inputs_for_key))
    else:
        failures = []
        with ProcessPoolExecutor(max_workers=workers) as executor:
            pending = {executor.submit(audit_branch, *arg): key for key, (arg, _, _) in inputs.items()}
            for future in as_completed(pending):
                try:
                    store(pending[future], future.result())
                except Exception as error:
                    failures.append((pending[future], error))
        if failures:
            raise ValueError(f"Independent replay failed for {[key for key, _ in failures]}") from failures[0][1]
    ordered = [key for key in selected if key in results]
    INSIST(ordered, f"No complete branches at {path}")
    totals = a28.totals_for(results.values())
    totals["max_pending_projection_error"] = max(row.get("max_pending_projection_error", 0.0) for row in results.values())
    totals["certified_reuse_stages"] = sum(len(row.get("equivalence_sources", ())) for row in results.values())
    for name in ("decision_observations", "observed_scalars", "forced_limits", "max_waits", "pending_prefix_samples_reproduced"):
        totals[name] = sum(row.get(name, 0) for row in results.values())
    fixed = [row["fixed_operation_exact"] for row in results.values() if "fixed_operation_exact" in row]
    if fixed:
        totals.update(
            fixed_operation_cases=len(fixed),
            old_continuous_threshold_exceeded=sum(row["old_continuous_threshold_exceeded"] for row in fixed),
            max_fixed_continuous_absolute_energy_error=max(row["continuous"]["max_global_energy_error"] for row in fixed),
            max_fixed_segment_absolute_energy_error=max(row["checkpoint_reanchored"]["max_global_energy_error"] for row in fixed),
            max_fixed_continuous_anchor_element_error=max(point["continuous_max_density_element_error"]
                for row in fixed for point in row["anchor_comparisons"]),
            max_fixed_segment_anchor_element_error=max(point["segment_max_density_element_error"]
                for row in fixed for point in row["anchor_comparisons"]),
        )
    return {"expected_branches": len(selected), "totals": totals,
            "branches": {"/".join(key): results[key] for key in ordered}}


def selected_branches(groups, origins, policies, precisions):
    return [(group, origin, policy, precision) for group in groups
            for origin in (origins or GROUP_ORIGINS[group]) if origin in GROUP_ORIGINS[group]
            for policy, precision in product(policies, precisions)]


def audit_one_shot(direct, staged, available_keys):
    results = {}
    for key in available_keys:
        reference = branch_folders(direct, key, BOUNDARIES[-1:])[BOUNDARIES[-1]]
        if not (reference / "checkpoint.npz").is_file():
            continue
        folders = branch_folders(staged, key, BOUNDARIES)
        signatures = {}
        for artifact in ("history", "wait_checks", "selector", "observations", "decisions", "waits"):
            filename = f"m30_{artifact}.csv"
            continuous = table(reference / filename)
            split = [row for folder in folders.values() for row in table(folder / filename)]
            INSIST(continuous == split, f"Uninterrupted {artifact} does not match staged results at {key}")
            signatures[artifact] = len(split)
        with a27.np.load(reference / "checkpoint.npz", allow_pickle=False) as full:
            with a27.np.load(folders[BOUNDARIES[-1]] / "checkpoint.npz", allow_pickle=False) as resumed:
                INSIST(full.files == resumed.files
                       and all(a27.np.array_equal(full[name], resumed[name]) for name in full.files),
                       f"One-shot and staged boundary arrays differ at {key}")
        results["/".join(key)] = signatures
    INSIST(results, f"No matching uninterrupted runs at {direct}")
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stages", type=Path, default=ROOT / "stages")
    parser.add_argument("--online", type=Path)
    parser.add_argument("--only-online", action="store_true")
    parser.add_argument("--one-shot", type=Path)
    parser.add_argument("--groups", nargs="+", choices=GROUP_ORIGINS, default=("recheck", "F2-R", "F1"))
    parser.add_argument("--origins", nargs="+")
    parser.add_argument("--methods", nargs="+", choices=METHODS, default=METHODS)
    parser.add_argument("--precisions", nargs="+", choices=RESOLUTIONS, default=RESOLUTIONS)
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--partial", action="store_true")
    parser.add_argument("--output", type=Path, default=ROOT / "results" / "audit_independent.json")
    parser.add_argument("--cache", type=Path, default=ROOT / "audit_cache")
    options = parser.parse_args()
    if options.only_online and not options.online:
        parser.error("--only-online requires --online")
    digest = a27.sha256(ROOT / "PROTOCOL_M30.md")
    INSIST(digest == (ROOT / "protocol.sha256").read_text().strip(), "M30 protocol digest mismatch")
    report = {
        "protocol_sha256": digest,
        "thresholds": {"absolute_energy": a27.EXACT_WORK_TOL, "maximum_density_element": a27.HALF_TOL},
        "registered_boundaries": [tick / 1000 for tick in BOUNDARIES],
        "M29_exact_reference_exceedances": {"U05": ["RP", "P3", "RH"], "U06": ["RP", "P1", "P2", "P3", "P4", "R3", "RH"],
                                            "precisions": list(RESOLUTIONS)},
    }
    report["control_adapter_sentinels"] = control_sentinels()
    keys = selected_branches(options.groups, options.origins, options.methods, options.precisions)
    if not options.only_online:
        report["native"] = audit_branches(options.stages, keys, BOUNDARIES, options.workers, False, options.partial, digest,
                                          options.cache / "native")
    if options.online:
        online_keys = selected_branches(("recheck",), ("U05", "U06"), options.methods, ("coarse",))
        report["exact_online"] = audit_branches(options.online, online_keys, BOUNDARIES, options.workers, True, options.partial,
                                                digest, options.cache / "exact_online")
    if options.one_shot:
        report["one_shot_vs_staged"] = audit_one_shot(options.one_shot, options.stages, keys)
    write_json(options.output, report)


if __name__ == "__main__":
    main()
