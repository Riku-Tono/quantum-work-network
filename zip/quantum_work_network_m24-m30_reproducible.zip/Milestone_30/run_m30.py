"""Run the preregistered M30 trajectories. Run from any working directory."""

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import hashlib
import json
import os
from pathlib import Path

os.environ["OPENBLAS_NUM_THREADS"] = "1"

ROOT = Path(__file__).resolve().parent
ORIGINS = ("S0", "A04", "B04", "C04")
GROUPS = {
    "recheck": ("U05", "U06", "U01", "U02", "U03", "U04"),
    "F2-R": ORIGINS,
    "F1": ORIGINS,
}
POLICIES = ("P3", "P3+I", "P3+A", "P3+IA", "P1", "P1+I", "P1+A", "RP")
PRECISIONS = ("coarse", "half")
CUTOFFS = (150_000, 300_000, 540_000)


def registered_protocol():
    protocol = hashlib.sha256((ROOT / "PROTOCOL_M30.md").read_bytes()).hexdigest()
    if protocol != (ROOT / "protocol.sha256").read_text(encoding="ascii").strip():
        raise ValueError("M30 protocol does not match its registered digest")
    return protocol


def run_lane(job):
    from m30_control import POLICIES as ENGINE_POLICIES, run_branch

    if ENGINE_POLICIES != POLICIES:
        raise ValueError("The engine does not match the eight registered policies")
    group, origin, precision, propagation, output, policies, cutoffs, reuse = job
    branch_root = output / group / origin
    for policy in policies:
        destination = branch_root / policy / precision
        if reuse and propagation == "rk4":
            from reuse_m30 import reuse_or_none

            if reuse_or_none(group, origin, policy, precision, destination, cutoffs):
                print(f"Certified equivalent {group}/{origin}/{policy}/{precision}", flush=True)
                continue
        checkpoints = run_branch(group, origin, policy, precision, destination, cutoffs, propagation=propagation)
        end = checkpoints[-1]
        print(json.dumps({"completed_branch": [group, origin, policy, precision, propagation],
                          "elapsed": float(end["elapsed_total"]), "work": float(end["cumulative_physical_net"])}), flush=True)
    return group, origin, precision, propagation


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT)
    parser.add_argument("--mode", choices=("rk4", "exact", "both"), default="both")
    parser.add_argument("--groups", nargs="+", choices=GROUPS, default=tuple(GROUPS))
    parser.add_argument("--origins", nargs="+")
    parser.add_argument("--policies", nargs="+", choices=POLICIES, default=POLICIES)
    parser.add_argument("--precisions", nargs="+", choices=PRECISIONS, default=PRECISIONS)
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--no-reuse", action="store_true")
    parser.add_argument("--one-shot", action="store_true", help="Write uninterrupted 540 witnesses to one_shot")
    args = parser.parse_args()
    if args.one_shot and args.mode != "rk4":
        parser.error("--one-shot is for the RK4 saved-boundary witnesses, use --mode rk4")

    protocol = registered_protocol()
    print(json.dumps({"protocol_sha256": protocol, "mode": args.mode, "groups": args.groups,
                      "origin_filter": args.origins, "policies": args.policies, "workers": args.workers,
                      "causal_equivalence_reuse": not (args.no_reuse or args.one_shot), "one_shot": args.one_shot}), flush=True)
    args.output.mkdir(parents=True, exist_ok=True)
    protocol_copy = args.output / "protocol.sha256"
    if protocol_copy.exists() and protocol_copy.read_text(encoding="ascii").strip() != protocol:
        raise ValueError("Output directory belongs to another protocol")
    if not protocol_copy.exists():
        protocol_copy.write_text(protocol + "\n", encoding="ascii")

    evaluation_order = ("RP", "P1", "P3", "P1+I", "P1+A", "P3+I", "P3+A", "P3+IA")
    policies = tuple(policy for policy in evaluation_order if policy in args.policies)
    jobs = []
    staged_root = args.output / ("one_shot" if args.one_shot else "stages")
    staged_cutoffs = CUTOFFS[-1:] if args.one_shot else CUTOFFS
    for group in args.groups:
        for origin in GROUPS[group]:
            if args.origins is not None and origin not in args.origins:
                continue
            if args.mode != "exact":
                for precision in args.precisions:
                    jobs.append((group, origin, precision, "rk4", staged_root, policies, staged_cutoffs,
                                 not (args.no_reuse or args.one_shot)))
            if args.mode != "rk4" and group == "recheck" and origin in ("U05", "U06"):
                jobs.append((group, origin, "coarse", "exact", args.output / "exact_online", policies, CUTOFFS, False))
    if not jobs:
        parser.error("No registered lanes match these arguments")
    if args.workers == 1:
        for job in jobs:
            print(json.dumps({"lane_finished": run_lane(job)}), flush=True)
        return
    with ProcessPoolExecutor(max_workers=args.workers) as executor:
        futures = [executor.submit(run_lane, job) for job in jobs]
        for future in as_completed(futures):
            print(json.dumps({"lane_finished": future.result()}), flush=True)


if __name__ == "__main__":
    main()
