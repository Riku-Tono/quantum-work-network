"""Reuse a saved trajectory only after replaying each causal reconnect choice."""

import hashlib
import itertools
import json
import os
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace

import m30_control as control
import numpy as np

physics = control.physics
ROOT = control.ROOT
LABELS = control.PRECISIONS
OLD_CAPS = (150_000, 300_000, 540_000)
MEASURED_FIELDS = ("elapsed_total", "observed_until", "wait_elapsed", "actual_current",
                   "c_real", "c_imag", "c_abs", "phase", "load_current")
PREFERRED_REFERENCE = {"P1+I": "Xphase", "P1+A": "Xinput", "P3+IA": "Xamp"}


def read_table(folder, prefix, name):
    path = folder / f"{prefix}_{name}.csv"
    return physics.csv_rows(path) if path.is_file() else []


def by_attempt(rows):
    grouped = {}
    for row in rows:
        grouped.setdefault(int(row["attempt"]), []).append(row)
    return grouped


def locations(group, origin, policy, precision, destination, cutoffs):
    policy_root = destination.parent.parent
    for peer in itertools.chain((policy,), control.POLICIES):
        if peer != policy:
            base = policy_root / peer / precision
            yield "m30", tuple(base / control.cutoff_folder(cap) for cap in cutoffs)
    if group in ("F2-R", "F1"):
        alternate = "F1" if group == "F2-R" else "F2-R"
        base = policy_root.parent.parent / alternate / origin / policy / precision
        yield "m30", tuple(base / control.cutoff_folder(cap) for cap in cutoffs)

    groups = ("unseen",) if group == "recheck" else (group, "F1" if group == "F2-R" else "F2-R")
    rules = dict.fromkeys((policy, PREFERRED_REFERENCE.get(policy), policy.split("+")[0], "RP", "P1", "P3", "Xamp", "Xphase", "Xinput"))
    for label in groups:
        for rule in rules:
            if rule in ("P1", "P2", "P3", "P4") or label == "unseen" and rule == "RP":
                root, prefix = control.M29, "m29"
            elif label != "unseen" and rule in ("RP", "Xamp", "Xphase", "Xinput"):
                root, prefix = control.m29.M28, "m28"
            else:
                continue
            suffix = Path(label, origin, rule, precision)
            yield prefix, tuple(root / "stages" / control.cutoff_folder(cap) / suffix for cap in cutoffs)


def matches_checkpoint(art, cap, fork, records, hashes):
    return (int(art["fork_tick"].item()) == fork and int(art["tick"].item()) == cap
            and all(art[f"fork_{label}_sha256"].item() == target for label, target in zip(LABELS, hashes, strict=True))
            and json.loads(art["records"].item())[:len(records)] == records)


def certify(folder, prefix, cap, policy, fork, records, hashes, previous_hashes, previous_count, previous_time):
    """Check the application of the new rule in clock order on the saved state path."""
    checkpoint = folder / "checkpoint.npz"
    if not checkpoint.is_file():
        return None
    with np.load(checkpoint, allow_pickle=False) as art:
        if not matches_checkpoint(art, cap, fork, records, hashes):
            return None
        anchor_tick, attempt_count, _ = map(int, art["counters"])
        archive_pending = json.loads(art["pending"].item())
    history = read_table(folder, prefix, "history")
    wait_groups = by_attempt(read_table(folder, prefix, "wait_checks"))
    new_waits = {}
    for ordinal, row in enumerate(history, previous_count + 1):
        start, tau, window = (physics.tick(row, field) for field in ("elapsed_start", "tau", "window"))
        if (int(row["attempt"]) != ordinal or start != previous_time or
                tuple(row[f"start_{label}_sha256"] for label in LABELS) != previous_hashes):
            return None
        maximum = min(control.WAIT_MAX, window - control.GRID) // control.WAIT_GRID * control.WAIT_GRID
        checks = [{field: float(sample[field]) for field in MEASURED_FIELDS} for sample in wait_groups.get(ordinal, ())]
        if maximum < control.WAIT_MIN:
            if tau or checks:
                return None
        elif not control.WAIT_MIN <= tau <= maximum or [physics.tick(sample, "wait_elapsed") for sample in checks] != list(range(control.WAIT_MIN, tau + 1, control.WAIT_GRID)):
            return None
        initial = {"c_abs": float(row["c_abs_before"]), "c_imag": -float(row["current_before"]) / (2 * control.G),
                   "c_real": -float(row["cut_on"]) / (2 * control.G)}
        for sample in checks:
            delay = physics.tick(sample, "wait_elapsed")
            if (physics.tick(sample) != start + delay or physics.tick(sample, "observed_until") != start + delay
                    or start + delay > cap):
                return None
            hit, _ = control.eligible_sample(policy, initial, sample)
            forced = delay == maximum and not hit
            if (hit or forced) != (delay == tau):
                return None
            sample.update(phase_gate=hit, reconnect=hit or forced, **control.condition_diagnostics(initial, sample),
                          at_max_wait=delay == control.WAIT_MAX, at_window_limit=delay == maximum,
                          fallback_limit=forced, fallback_max_wait=forced and delay == control.WAIT_MAX,
                          fallback_window_limit=forced and delay < control.WAIT_MAX, used_by_control=True)
        new_waits[ordinal] = checks
        previous_hashes = tuple(row[f"post_{label}_sha256"] for label in LABELS)
        previous_time = physics.tick(row)
    if (attempt_count != previous_count + len(history) or anchor_tick != previous_time
            or set(wait_groups) - set(new_waits)):
        return None
    return (history, new_waits, anchor_tick, attempt_count, previous_hashes, archive_pending)


def pending_and_state(folder, cap, policy, precision, proof):
    """Rerun the bounded unfinished attempt so saved boundaries can be resumed."""
    _, _, anchor_tick, _, anchor_hashes, expected_pending = proof
    path = folder / "checkpoint.npz"
    with np.load(path, allow_pickle=False) as archive:
        data = {key: archive[key] for key in archive.files}
    pair = tuple(data[f"anchor_{label}"] for label in LABELS)
    if tuple(physics.fingerprint(state) for state in pair) != anchor_hashes:
        return None
    records = json.loads(data["records"].item())
    primary = LABELS.index(precision)
    model = control.model_instance("rk4")
    if getattr(model, "m30_kernel_precision", None) != precision:
        model.time_kernel.cache_clear()
        model.m30_kernel_precision = precision
    with control.adapters():
        trial, boundary, pending = control._next_trial(model, pair, primary, anchor_tick, policy, records, cap)
    if trial is not None and trial.row is not None:
        return None
    if (pending != expected_pending or boundary.coupling != float(data["coupling"].item())
            or boundary.phase != data["phase"].item()):
        return None
    differences = [physics.maxabs(value - data[label]) for value, label in zip(boundary.pair, LABELS, strict=True)]
    if max(differences) > control.FLOOR:
        return None
    return data, trial, max(differences)


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def publish(target, source, prefix, meta, source_row, seed, proof, pending_state):
    history, waits, tick, count, _, pending = proof
    data, pending_trial, state_difference = pending_state
    data.update(propagation="rk4", policy=meta["policy"], source_time=float(source_row["source_time"]))
    primary = LABELS.index(meta["precision"])
    observations = read_table(source, prefix, "observations")
    start_observations = {int(row["attempt"]): row for row in observations if row["index"] == "0"}
    end_observation_counts = {int(row["attempt"]): int(row["index"]) + 1 for row in observations}
    expected, = read_table(source, prefix, "checkpoints")
    target.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix=".equivalent-", dir=target.parent) as temporary:
        folder = Path(temporary) / "complete"
        folder.mkdir()
        tables = control.Ledger(folder)
        try:
            for row in history:
                attempt = int(row["attempt"])
                checks = waits[attempt]
                current = {**row, "accepted": row["accepted"] == "True"}
                numeric = ("tau", "elapsed_start", "elapsed_total", "cut_on", "reconnect_on", "direct_total_work",
                           "current_before", "c_abs_before", "phase_before")
                current.update({field: float(row[field]) for field in numeric}, **meta)
                if checks:
                    current["wait_reason"] = "phase_limit" if checks[-1]["fallback_limit"] else "phase_gate"
                connected0 = start_observations[attempt]
                at_reconnect = {"c_real": float(connected0["c_real"]), "c_imag": float(connected0["c_imag"])}
                samples = [at_reconnect] * end_observation_counts[attempt]
                control.add_diagnostics(meta["policy"], SimpleNamespace(row=current, wait_checks=checks, observations=samples))
                current.update(record_source="m30", cumulative_rate=float(row["cumulative_net"]) / (current["elapsed_total"] - meta["fork_elapsed"]))
                tables.add("m30_history", current)
                attempt_meta = {**meta, "attempt": attempt}
                initial = control.initial_coherence(current, SimpleNamespace(observations=samples))
                for check in checks:
                    tables.add("m30_wait_checks", {**attempt_meta, **check})
                    gate, inputs = control.eligible_sample(meta["policy"], initial, check)
                    selectors = ("q", "q0", "threshold_q", "amplitude", "c0_abs", "c0_real", "c_real", "angle")
                    tables.add("m30_selector", {**attempt_meta, **{key: check[key] for key in ("elapsed_total", "observed_until", "wait_elapsed")},
                                                **{name: inputs.get(name) for name in selectors}, "gate": gate,
                                                "reconnect": check["reconnect"], "limit": check["fallback_limit"]})
                decision = {"elapsed_total": current["elapsed_start"], "observed_until": current["elapsed_start"],
                            "reason": meta["policy"], "mode_before": "wait", "mode_after": "wait", "switched": False}
                tables.add("m30_decisions", {**attempt_meta, **decision})
                if current["tau"]:
                    names = ("tau", "elapsed_start", "phase_before", "phase_after", "phase_change", "current_before", "current_after",
                             "sign_reversal", "c_abs_before", "c_abs_after", "wait_reason", "net_work", "accepted", "cut_on", "reconnect_on")
                    tables.add("m30_waits", {**attempt_meta, **{name: current[name] for name in names},
                                              "elapsed_total": current["reconnect_elapsed"], "extraction_elapsed": current["elapsed_total"],
                                              "wait_start_observed_until": current["elapsed_start"], "observed_until": current["reconnect_elapsed"]})
            for row in observations:
                tables.add("m30_observations", {**row, **meta})
            if pending_trial is not None:
                pending_meta = {**meta, "attempt": count + 1}
                for check in pending_trial.wait_checks:
                    tables.add("m30_pending_wait_checks", {**pending_meta, **check})
                for sample in pending_trial.observations:
                    tables.add("m30_pending_observations", {**pending_meta, **sample})
            model = control.model_instance("rk4")
            initial_energy = np.einsum("ij,ji->", seed[0][primary], model.h[control.G]).real
            boundary_energy = np.einsum("ij,ji->", data[LABELS[primary]], model.h[float(data["coupling"].item())]).real
            physical = float(expected["cumulative_net"]) + pending.get("switch_net", 0.0)
            residual = float(boundary_energy + physical - initial_energy)
            if abs(residual) > control.FLOOR:
                raise ValueError(f"Archived physical boundary account failed at {source}: {residual}")
            tables.add("m30_checkpoints", {**expected, **meta, "mode": "forecast",
                                           "cumulative_physical_net": physical, "boundary_energy_residual": residual,
                                           "pending_attempt_elapsed": tick / 1000 if pending_trial is not None else None})
        finally:
            tables.close()
        np.savez_compressed(folder / "checkpoint.npz", **data)
        manifest = {"source": os.path.relpath(source, ROOT), "source_prefix": prefix, "fork_tick": seed[1],
                    "fork_hashes": [data[f"fork_{label}_sha256"].item() for label in LABELS],
                    "same_first_choice_attempts": len(history), "scalar_samples": sum(map(len, waits.values())),
                    "source_checkpoint_sha256": digest(source / "checkpoint.npz"),
                    "source_history_sha256": digest(source / f"{prefix}_history.csv") if history else None,
                    "pending_direct_reproduction_density_max_error": state_difference}
        (folder / "equivalent_policy.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
        control.stage.publish_stage(folder, target)


def reuse_or_none(group, origin, policy, precision, destination, cutoffs):
    if tuple(cutoffs) != OLD_CAPS:
        return False
    destination = Path(destination)
    needed = tuple(destination / control.cutoff_folder(cap) for cap in cutoffs)
    if any(path.exists() for path in needed):
        return False
    source_row, seed = control.seed_for(group, origin, precision)
    pair, fork, records = seed
    hashes = tuple(physics.fingerprint(state) for state in pair)
    best = []
    seen = set()
    for prefix, sources in locations(group, origin, policy, precision, destination, cutoffs):
        if sources in seen or not (sources[0] / "checkpoint.npz").is_file():
            continue
        seen.add(sources)
        previous_hashes, previous_count, previous_time = hashes, 0, fork
        checked = []
        for cap, path in zip(cutoffs, sources, strict=True):
            proof = certify(path, prefix, cap, policy, fork, records, hashes, previous_hashes, previous_count, previous_time)
            if proof is None:
                break
            pending = pending_and_state(path, cap, policy, precision, proof)
            if pending is None:
                break
            _, _, previous_time, previous_count, previous_hashes, _ = proof
            checked.append((path, prefix, proof, pending))
        if len(checked) > len(best):
            best = checked
        if len(best) == len(needed):
            break
    meta = {"group": group, "origin": origin, "policy": policy, "precision": precision,
            "fork_elapsed": fork / 1000, "propagation": "rk4"}
    for target, (source, prefix, proof, pending) in zip(needed, best):
        publish(target, source, prefix, meta, source_row, seed, proof, pending)
    return len(best) == len(needed)
