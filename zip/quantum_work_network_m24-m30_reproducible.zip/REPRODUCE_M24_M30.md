# Reproduce M24–M30

Extract the package into a new folder and run these commands in Windows PowerShell from that folder. Python 3.14 x64 is the reference runtime. The requirements pin the NumPy, SciPy, and Matplotlib versions used by the study. The initial density matrices are frozen inputs, so reproducing M24–M30 starts after the earlier Rust calculations.

```powershell
py -3.14 -m pip install -r requirements-m24-m30.txt
py -3.14 -B verify_bundle_m23_inputs.py
```

## Check the extracted package

The manifest records the SHA-256 of each distributed file other than the manifest. This native PowerShell check only reads the extracted files.

```powershell
Get-Content -LiteralPath SHA256SUMS | ForEach-Object {
    if ($_ -notmatch '^(?<digest>[a-f0-9]{64})  (?<path>.+)$') {
        throw "Malformed manifest row $_"
    }
    $qwnExpectedHash = $Matches.digest
    $qwnRelativePath = $Matches.path
    $qwnObservedHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $qwnRelativePath).Hash
    if ($qwnObservedHash -ne $qwnExpectedHash) {
        throw "SHA-256 mismatch for $qwnRelativePath"
    }
}
```

The compact M23 verifier checks all 21 distributed matrix files against the registered source tables and checks their headers, dimensions, clocks, and finite values. The optional archive check compares those inputs with the exact upstream M23 ZIP.

```powershell
py -3.14 -B verify_bundle_m23_inputs.py --official-zip <path-to-M23_all_results.zip>
```

For the original M24 and M25 independent audits, provide the exact official archive as `Milestone_23/M23_all_results.zip`. Its registered digest is in [M23_all_results.sha256](Milestone_23/M23_all_results.sha256). The compact package contains the inputs used for the numerical reproduction. The original ZIP checks additionally verify extraction from that whole archived release. The earlier M15B–M23 reproduction package is a separate distribution with its own checksum.

## Short M30 replay

The quick command regenerates U05's common pre-cut state and the next two trials for all eight controls using coarse RK4, half-step RK4, and exact online propagation. It uses the archived M29 U05 inputs and the six archived M29 trial histories included in the package. The resulting tables identify the first divergence, record reached wait observations and actual work events, and distinguish a condition-triggered reconnection from a forced reconnection at the wait limit.

```powershell
$qwnQuickDir = Join-Path (Split-Path -Parent (Get-Location).Path) 'qwn-m24-m30-quick'
py -3.14 -B reproduce_m24_m30.py quick --workspace $qwnQuickDir
```

The comparison to the full elapsed-540 results is in the included [U05 continuation table](Milestone_30/u05/continuation_to_540.csv). The short replay itself ends at the local trial-7 diagnosis. To replay all eight U05 continuations from the saved fork through 540, use a separate output directory.

```powershell
$qwnU05Full = Join-Path (Split-Path -Parent (Get-Location).Path) 'qwn-u05-full'
py -3.14 -B Milestone_30/m30_u05.py --full --output $qwnU05Full
```

## Formal calculations

The staged driver creates a separate working copy with the relative paths required by the original source. Each stage writes its own results and figures there. The driver writes new M25–M29 checkpoints under each milestone's `stages/`, prepares new M28 anchors, regenerates all six M29 preparations, and places M30's exact-online outputs under `Milestone_30/exact_online/`. The extracted package remains the frozen reference. Plan for tens of gigabytes of workspace for the full sequence. The largest outputs are the trial observations and aligned state checkpoints.

```powershell
$qwnWorkDir = Join-Path (Split-Path -Parent (Get-Location).Path) 'qwn-m24-m30-work'
py -3.14 -B reproduce_m24_m30.py formal --workspace $qwnWorkDir --workers 2 --plan
py -3.14 -B reproduce_m24_m30.py formal --workspace $qwnWorkDir --workers 2
```

Use `--through-stage 26` to stop after M26. After the preceding milestone has finished in the same workspace, use `--from-stage 27` to continue. The individual programs describe how to restart at a saved checkpoint if a stage was interrupted. You can execute the printed commands from their listed working directories, adjusting the worker count to available RAM. Each worker uses one OpenBLAS thread.

| Step | What the driver computes | Main dependency |
| --- | --- | --- |
| M24 | Wait comparators, causal timing rules, and figures | Frozen M23 inputs and registered comparison tables |
| M25 | Two-round benchmark and 10-, 20-, and 30-round stages | M24 source registry and the frozen M23 densities |
| M26 | Uncapped continuations at 150, 300, and 540 | M25 round-30 checkpoints and results |
| M27 | Adaptive branches, stage-boundary audit, and diagnostics | M26 source and control ledgers |
| M28 | F2-R, same-state comparisons, condition ablations, and anchor registration | M27 audit and switch states, M26 source registry |
| M29 | Six preparations and information-reduction comparisons | Regenerated M28 anchors and control branches |
| M30 | Eight policies on both grids, exact-online U05/U06, and U05 fork certificates | Regenerated M28 anchors, M29 preparations, and M29 U05 timing histories |

M30's driver evaluates policies directly with `--no-reuse`. The registered numerical rules and decision deadlines are the same as the archived comparison. Equivalent-policy provenance certificates in the published results describe the original run. An exact-online row with the coarse label starts from the coarse prepared density and advances by exact unitary propagation.

## Independent computations and published values

Use `--audit` to add the formal independent audit commands. The driver also runs some audits without this flag because later stages consume those audit artifacts. M24 and M25's upstream-ZIP checks run when the exact original ZIP is present in the corresponding working copy. After the workspace already exists, copy that archive to the workspace's own `Milestone_23/`.

```powershell
py -3.14 -B reproduce_m24_m30.py formal --workspace $qwnWorkDir --workers 2 --audit --plan
```

The source-stage READMEs in the [stage index](README.md) list the optional short benchmarks, exploration runs and additional audit workflows. When running those commands in the working copy, keep the canonical `stages/`, `results/`, and `anchors/` locations for stages consumed by downstream programs. Optional benchmarks can use new output folders.

Compare the new endpoints, operation clocks, work accounts, and stated audit tolerances against the included reports and selected tables. The M29 and M30 reports record fixed-operation exact-reference deviations separately from reselected exact-online control. A completed same-step replay and an integration-reference deviation measure different quantities. Follow the stated criterion for each. File hashes identify the distributed inputs and results. Regenerated numerical tables can differ in their final digits across runtimes or hardware.

M24–M30 use a seven-site chain with a three-level load and simulation-defined observations. Their retrospective oracle comparisons, independent online-control lanes, and archived prepared states retain their different roles. U01–U06 were prepared as additional states in M29 and were reused as a known set in M30.
