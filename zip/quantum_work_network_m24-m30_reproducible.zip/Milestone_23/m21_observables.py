"""Add excitation-sector and full-state diagnostics to saved M21 snapshots."""

import argparse
import csv
import os
from pathlib import Path
import struct

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import numpy as np


CHAIN_SITES = 7
CHAIN_DIM = 1 << CHAIN_SITES
LOAD_DIM = 3
DIM = CHAIN_DIM * LOAD_DIM
HEADER = struct.Struct("<8sQd")
TOLERANCE = 1e-12
LOAD_LEVELS = np.arange(LOAD_DIM)
CHAIN_OCCUPATION = np.array([basis.bit_count() for basis in range(CHAIN_DIM)])
OCCUPATION = (CHAIN_OCCUPATION[:, None] + LOAD_LEVELS).ravel()
SECTOR_NUMBERS = np.arange(CHAIN_SITES + LOAD_DIM)


def read_state(path, expected_time):
    data = path.read_bytes()
    if len(data) != HEADER.size + DIM * DIM * np.dtype("<c16").itemsize:
        raise ValueError(f"Unexpected density-matrix size: {path}")
    magic, dimension, time = HEADER.unpack_from(data)
    if magic != b"QWNRHO1\0" or dimension != DIM:
        raise ValueError(f"Invalid QWNRHO1 density header: {path}")
    if not np.isfinite(time) or abs(time - expected_time) > TOLERANCE:
        raise ValueError(f"Snapshot time {time} differs from {expected_time}: {path}")
    density = np.frombuffer(data, dtype="<c16", offset=HEADER.size).reshape(DIM, DIM)
    if not np.isfinite(density).all():
        raise ValueError(f"Nonfinite density entries: {path}")
    return density


def expectation(density, operator):
    return float(np.einsum("ij,ji->", density, operator).real)


def spectrum(matrix):
    return np.linalg.eigvalsh((matrix + matrix.conj().T) * 0.5)


class Observables:
    def __init__(self):
        # Tensor order is |q1, ..., q7, load>, with the load index varying fastest.
        chain_h = np.diag(CHAIN_OCCUPATION.astype(float))
        for basis in range(CHAIN_DIM):
            for site in range(CHAIN_SITES - 1):
                if ((basis >> site) ^ (basis >> (site + 1))) & 1:
                    chain_h[basis ^ (3 << site), basis] = 1.0

        load_h = np.diag(LOAD_LEVELS)
        terminal_raise = np.array([[0, 0], [1, 0]])
        load_lower = np.diag(np.sqrt(LOAD_LEVELS[1:]), k=1)
        exchange = np.kron(terminal_raise, load_lower)
        self.terminal_exchange = exchange + exchange.T
        terminal_load_h = np.kron(np.eye(2), load_h)
        self.terminal_current = 1j * (
            self.terminal_exchange @ terminal_load_h - terminal_load_h @ self.terminal_exchange
        )
        self.bare_h = np.kron(chain_h, np.eye(LOAD_DIM)) + np.kron(np.eye(CHAIN_DIM), load_h)
        self.exchange_h = np.kron(np.eye(CHAIN_DIM // 2), self.terminal_exchange)
        sector_indices = [np.flatnonzero(OCCUPATION == number) for number in SECTOR_NUMBERS]
        self.sectors = [np.ix_(indices, indices) for indices in sector_indices]
        self.hamiltonians = {}

    def hamiltonian(self, coupling):
        if coupling not in self.hamiltonians:
            full_h = self.bare_h + coupling * self.exchange_h
            off_sector = OCCUPATION[:, None] != OCCUPATION[None, :]
            if np.any(full_h[off_sector] != 0):
                raise ValueError(f"Hamiltonian mixes excitation sectors at g={coupling}")
            block_levels = [np.linalg.eigvalsh(full_h[sector]) for sector in self.sectors]
            levels = np.sort(np.concatenate(block_levels))
            self.hamiltonians[coupling] = (full_h, block_levels, levels)
        return self.hamiltonians[coupling]

    def measure(self, density, coupling):
        terminal_dim = 2 * LOAD_DIM
        terminal_blocks = density.reshape(CHAIN_DIM // 2, terminal_dim, CHAIN_DIM // 2, terminal_dim)
        terminal = np.trace(terminal_blocks, axis1=0, axis2=2)
        load = terminal[:LOAD_DIM, :LOAD_DIM] + terminal[LOAD_DIM:, LOAD_DIM:]
        full_h, block_levels, levels = self.hamiltonian(coupling)
        full_eigenvalues = spectrum(density)
        full_passive = float(levels @ full_eigenvalues[::-1])
        load_passive = float(LOAD_LEVELS @ spectrum(load)[::-1])

        # The block spectra retain their weights Tr(Π_n ρ). A unitary commuting
        # with total excitation can reorder eigenvalues only within each block.
        sector_passive = sum(float(energies @ spectrum(density[sector])[::-1])
                             for sector, energies in zip(self.sectors, block_levels, strict=True))
        probabilities = np.bincount(OCCUPATION, weights=density.diagonal().real)
        full_energy = expectation(density, full_h)
        sector_ergotropy = full_energy - sector_passive
        if not -TOLERANCE <= sector_ergotropy <= full_energy - full_passive + TOLERANCE:
            raise ValueError(f"Sector ergotropy outside [0, unrestricted]: {sector_ergotropy}")
        if probabilities.min() < -TOLERANCE or abs(probabilities.sum() - 1) > TOLERANCE:
            raise ValueError("Invalid excitation-sector probabilities")

        exchange = expectation(terminal, self.terminal_exchange)
        load_ergotropy = expectation(load, np.diag(LOAD_LEVELS)) - load_passive
        # For any load unitary, preserve the trace norm of the terminal cross
        # block. Hölder bounds the magnitude of the resulting exchange energy.
        cross_block = terminal[:LOAD_DIM, LOAD_DIM:]
        exchange_bound = 2 * np.sqrt(LOAD_DIM - 1) * np.linalg.svd(cross_block, compute_uv=False).sum()
        local_work_bound = max(0.0, load_ergotropy) + coupling * (exchange + exchange_bound)

        return {
            "global_purity": float(np.vdot(density.ravel(), density.ravel()).real),
            "global_passive_energy": full_passive,
            "load_passive_energy": load_passive,
            "sector_ergotropy": sector_ergotropy,
            "sector_passive_energy": sector_passive,
            "load_current": coupling * expectation(terminal, self.terminal_current),
            "total_excitation": float(SECTOR_NUMBERS @ probabilities),
            "terminal_exchange_expectation": exchange,
            "any_local_unitary_full_work_upper_bound": local_work_bound,
            **{f"sector_probability_{number}": p for number, p in enumerate(probabilities)},
        }


def enrich(directory):
    input_path = directory / "m21_state_basic.csv"
    with input_path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        fields = reader.fieldnames or []
        if not {"protocol", "gamma", "cycle", "phase", "time", "g", "filename"}.issubset(fields):
            raise ValueError(f"Missing snapshot columns in {input_path}")
        basic_rows = list(reader)
    if not basic_rows:
        raise ValueError(f"No snapshots in {input_path}")

    model = Observables()
    enriched_rows = []
    previous_source = None
    for row in basic_rows:
        path = directory / row["filename"]
        time = float(row["time"])
        source = (path, time)
        if source != previous_source:
            density = read_state(path, time)
            previous_source = source
        values = model.measure(density, float(row["g"]))
        enriched_rows.append({**row, **values})

    path = directory / "m21_state_metrics.csv"
    with path.open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(enriched_rows[0]))
        writer.writeheader()
        writer.writerows(enriched_rows)
    return len(enriched_rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path, help="M21 results directory")
    args = parser.parse_args()
    print(f"Wrote M21 observables for {enrich(args.directory)} snapshots.")


if __name__ == "__main__":
    main()
