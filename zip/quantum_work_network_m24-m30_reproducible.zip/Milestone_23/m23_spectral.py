"""M23 γ=0 sector propagation with the two registered RK4 step sizes."""
from functools import lru_cache
from pathlib import Path
import hashlib
import struct

import numpy as np

from m21_observables import (
    CHAIN_DIM, DIM, HEADER, LOAD_DIM, LOAD_LEVELS, OCCUPATION, Observables, expectation, spectrum,
)

G = 0.25
DT = (0.0025, 0.00125)
FLOOR = 1e-12
HALF_TOL = 1e-10
GRID = 20
DIM_LOCAL = 2 * LOAD_DIM
HORIZON = 18_000
SOURCE_TIME = 15_900
OCC_LOCAL = OCCUPATION[:DIM_LOCAL]
EXCHANGE_LOWER = np.tril(Observables().terminal_exchange, -1)


def maxabs(matrix):
    return float(np.max(np.abs(matrix)))


def entropy(probabilities):
    values = np.maximum(probabilities, 0)
    values = values[values > 0]
    values /= values.sum()
    return float(-values @ np.log(values))


def partial(matrix):
    return np.trace(matrix.reshape(CHAIN_DIM // 2, DIM_LOCAL, CHAIN_DIM // 2, DIM_LOCAL), axis1=0, axis2=2)


def passive_load(terminal):
    load = terminal[..., :LOAD_DIM, :LOAD_DIM] + terminal[..., LOAD_DIM:, LOAD_DIM:]
    values, vectors = np.linalg.eigh(load)
    if np.any(np.diff(values, axis=-1) <= FLOOR):
        raise ValueError("Load spectrum falls inside inherited extraction degeneracy tolerance")
    values, vectors = values[..., ::-1], vectors[..., :, ::-1]
    # Match the Rust phase rule: a highest-index pivot breaks a magnitude tie.
    column = np.swapaxes(vectors, -1, -2)
    pivot_indices = LOAD_DIM - 1 - np.argmax(np.abs(column[..., ::-1]), axis=-1)
    pivots = np.take_along_axis(column, pivot_indices[..., None], axis=-1)
    column *= pivots.conj() / np.abs(pivots)
    unitary = column.conj()
    return load, values, unitary


def local_diagnostics(terminal):
    load, values, unitary = passive_load(terminal)
    diagonal = load.diagonal(axis1=-2, axis2=-1).real
    load_energy = diagonal @ LOAD_LEVELS
    passive_energy = values @ LOAD_LEVELS
    gross = load_energy - passive_energy
    c = np.einsum("...ij,ji->...", terminal, EXCHANGE_LOWER)
    block = terminal[..., :LOAD_DIM, LOAD_DIM:]
    rotated = unitary @ block @ unitary.conj().swapaxes(-1, -2)
    c_after = np.einsum("...ij,ji->...", rotated, EXCHANGE_LOWER[LOAD_DIM:, :LOAD_DIM])
    jump = 2 * G * (c_after.real - c.real)
    return {
        "load_energy": load_energy, "load_passive_energy": passive_energy, "load_ergotropy": gross,
        "load_purity": np.sum(abs(load)**2, axis=(-2, -1)),
        "load_p0": diagonal[..., 0], "load_p1": diagonal[..., 1], "load_p2": diagonal[..., 2],
        "load_coherence_01_real": load[..., 0, 1].real, "load_coherence_01_imag": load[..., 0, 1].imag,
        "load_coherence_02_real": load[..., 0, 2].real, "load_coherence_02_imag": load[..., 0, 2].imag,
        "load_coherence_12_real": load[..., 1, 2].real, "load_coherence_12_imag": load[..., 1, 2].imag,
        "load_coherence_frobenius": np.sqrt(2 * (abs(load[..., 0, 1])**2 + abs(load[..., 0, 2])**2 + abs(load[..., 1, 2])**2)),
        "terminal_population": terminal[..., LOAD_DIM:, LOAD_DIM:].trace(axis1=-2, axis2=-1).real,
        "c_real": c.real, "c_imag": c.imag, "c_abs": abs(c),
        "load_current": -2 * G * c.imag, "gross_work": gross,
        "interaction_jump": jump, "total_work": gross - jump,
    }


def extraction(rho):
    _, _, op = passive_load(partial(rho))
    local = np.kron(np.eye(CHAIN_DIM), op)
    return local @ rho @ local.conj().T


def log_rk4(delta, dt):
    x = delta * dt
    # |R4(-ix)|² = 1 - x⁶/72 + x⁸/576. Preserve the tiny damping
    # across many steps without subtracting nearly equal floating-point numbers.
    amp = 0.5 * np.log1p(-x**6 / 72 + x**8 / 576)
    phi = np.arctan2(-x + x**3 / 6, 1 - x*x/2 + x**4/24)
    return amp + 1j * phi


def rk_steps(milliseconds, dt):
    num = milliseconds * (400 if dt == DT[0] else 800)
    if num % 1000:
        raise ValueError(f"Duration {milliseconds} ms is off the RK4 lattice")
    return num // 1000


class SectorBasis:
    def __init__(self, h):
        self.vectors = np.zeros((DIM, DIM))
        self.eigenvalues = np.zeros(DIM)
        for sector in np.unique(OCCUPATION):
            index = np.flatnonzero(OCCUPATION == sector)
            block = np.ix_(index, index)
            self.eigenvalues[index], self.vectors[block] = np.linalg.eigh(h[block])
        delta = self.eigenvalues[:, None] - self.eigenvalues[None, :]
        self.logs = {dt: log_rk4(delta, dt) for dt in DT}
        self.tr = self.vectors.T

    def to_basis(self, rho):
        return self.tr @ rho @ self.vectors

    def from_basis(self, rho):
        return self.vectors @ rho @ self.tr

    def step_spectral(self, rho, milliseconds, dt):
        if milliseconds == 0:
            return rho
        return rho * np.exp(self.logs[dt] * rk_steps(milliseconds, dt))

    def evolve(self, rho, milliseconds, dt):
        if milliseconds == 0:
            return rho.copy()
        return self.from_basis(self.step_spectral(self.to_basis(rho), milliseconds, dt))


class Dynamics:
    def __init__(self, horizon):
        self.horizon = horizon
        self.obs = Observables()
        self.h = {g: self.obs.hamiltonian(g)[0] for g in (0, G)}
        self.bases = {g: SectorBasis(h) for g, h in self.h.items()}
        self.connected = self.bases[G]
        selected = []
        for a, b in zip(*np.triu_indices(DIM_LOCAL)):
            if OCC_LOCAL[a] > OCC_LOCAL[b]:
                a, b = b, a
            selected.append((int(a), int(b)))
        change = OCCUPATION[:, None] - OCCUPATION[None, :]
        self.groups = []
        vectors = self.connected.vectors
        for delta in sorted(set(OCC_LOCAL[a] - OCC_LOCAL[b] for a, b in selected)):
            left, right = np.where(change == delta)
            pairs = [(a,b) for a,b in selected if OCC_LOCAL[a] - OCC_LOCAL[b] == delta]
            overlaps = np.array([(vectors[a::DIM_LOCAL].T @ vectors[b::DIM_LOCAL])[left,right]
                                 for a,b in pairs]).T
            self.groups.append((left, right, pairs, np.ascontiguousarray(overlaps)))

    @lru_cache(maxsize=8)
    def time_kernel(self, group, dt):
        left, right, _, _ = self.groups[group]
        eigen_advance = self.connected.logs[dt][left,right] * rk_steps(GRID, dt)
        times = self.horizon // GRID + 1
        # Build each cached kernel in chunks to limit transient allocation.
        result = np.empty((times, len(left)), dtype=np.complex128)
        for first in range(0, times, 64):
            last = min(first + 64, times)
            np.exp(np.arange(first, last)[:,None] * eigen_advance, out=result[first:last])
        return result

    def terminal_grid(self, spectra, dt, length):
        result = np.empty((len(spectra), length, DIM_LOCAL, DIM_LOCAL), dtype=np.complex128)
        for group, (left, right, pairs, weights) in enumerate(self.groups):
            multiplier = spectra[:, left, right].T
            coefficient = np.ascontiguousarray((multiplier[:,:,None] * weights[:,None,:]).reshape(len(left), -1))
            out = (self.time_kernel(group, dt)[:length] @ coefficient).reshape(length, len(spectra), len(pairs))
            for j, (a,b) in enumerate(pairs):
                result[...,a,b] = out[...,j].T
                result[...,b,a] = out[...,j].conjugate().T
        return result

    def metrics(self, rho, g):
        extras = self.obs.measure(rho, g)
        terminal = partial(rho)
        load = terminal[:LOAD_DIM,:LOAD_DIM] + terminal[LOAD_DIM:,LOAD_DIM:]
        chain = np.trace(rho.reshape(CHAIN_DIM,LOAD_DIM,CHAIN_DIM,LOAD_DIM),axis1=1,axis2=3)
        spectral = spectrum(rho)
        local = local_diagnostics(terminal)
        extra = {
            "load_energy": float(local["load_energy"]), "load_ergotropy": float(local["load_ergotropy"]),
            "load_purity": float(local["load_purity"]), "global_energy": expectation(rho, self.h[g]),
            "mutual_information": entropy(spectrum(chain)) + entropy(spectrum(load)) - entropy(spectral),
            "trace_error": float(abs(np.trace(rho) - 1)), "hermiticity_error": maxabs(rho - rho.conj().T),
            "minimum_eigenvalue": float(spectral[0]),
        }
        if max(extra["trace_error"], extra["hermiticity_error"], -extra["minimum_eigenvalue"]) > FLOOR:
            raise ValueError(f"Density physicality failed: {extra}")
        return {**extras, **extra, "global_ergotropy": extra["global_energy"] - extras["global_passive_energy"]}


def store_density(path, matrix, time_ms):
    path.parent.mkdir(exist_ok=True, parents=True)
    blob = HEADER.pack(b"QWNRHO1\0", DIM, time_ms / 1000) + np.asarray(matrix, dtype="<c16", order="C").tobytes()
    with path.open("xb") as written:
        written.write(blob)
    return hashlib.sha256(blob).hexdigest().upper()
