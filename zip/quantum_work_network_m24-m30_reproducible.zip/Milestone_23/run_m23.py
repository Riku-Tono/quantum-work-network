"""Registered M23 sweeps, candidate evaluation, and repeated operations."""
import argparse
import csv
from dataclasses import dataclass
from pathlib import Path
import time

import numpy as np

from m21_observables import read_state, expectation, spectrum
from m23_spectral import DT, FLOOR, G, GRID, HALF_TOL, HORIZON, SOURCE_TIME, Dynamics, extraction, local_diagnostics, maxabs, partial, store_density

ROOT = Path(__file__).resolve().parent
COARSE_TAUS = tuple(range(0, 6001, 250))


def csv_rows(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def ms(value):
    return round(float(value) * 1000)


class Tables:
    def __init__(self, destination):
        self.directory = destination
        self.files = {}

    def add(self, name, row):
        if name not in self.files:
            path = self.directory / (name + ".csv")
            stream = path.open("x", encoding="utf8", newline="")
            writer = csv.DictWriter(stream, fieldnames=list(row))
            writer.writeheader()
            self.files[name] = (stream, writer)
        self.files[name][1].writerow(row)

    def flush(self):
        for stream, _ in self.files.values():
            stream.flush()

    def close(self):
        for stream, _ in self.files.values():
            stream.close()


@dataclass
class Trial:
    data: dict
    coarse: dict
    half: dict
    spectra: tuple
    rho_wait: tuple
    selection_index: int
    tau: int

    @property
    def net(self):
        return float(self.data["max_net"])

    @property
    def error(self):
        return abs(self.net - float(self.data["max_net_half"]))


def largest(trials):
    return max(trials, key=lambda x: (x.net, -x.data["best_elapsed_total"], -x.tau))


def refine_trials(coarse):
    ordered = sorted(coarse, key=lambda t:t.tau)
    maxima = [
        t for index, t in enumerate(ordered)
        if (index == 0 or t.net > ordered[index-1].net)
        and (index == len(ordered)-1 or t.net >= ordered[index+1].net)
    ]
    ranked = sorted(maxima, key=lambda t: (-t.net, t.tau))[:3]
    taus = set()
    for t in ranked:
        upper = 6000
        if t.tau == 6000 and t.net - ordered[-2].net > FLOOR + t.error + ordered[-2].error:
            upper = 6250
        taus.update(range(max(0, t.tau-250), min(upper, t.tau+250)+1, 25))
    return ranked, sorted(taus)


def selected_snapshots(model, rho_wait, spectra, connected_ms):
    return tuple(rho if connected_ms == 0 else model.connected.from_basis(
        model.connected.step_spectral(r, connected_ms, dt))
        for rho, r, dt in zip(rho_wait, spectra, DT, strict=True))


def account(model, initial, wait, before, candidate, tau, cut, reconnect):
    E = lambda rho, g: expectation(rho, model.h[g])
    virtual = extraction(before)
    actual = E(before, G) - E(virtual, G)
    net = actual - cut - reconnect
    start, end = E(initial, G), E(virtual, G)
    err = end - (start - net)
    waiting_energy_drift = E(wait, 0.0) - E(initial, 0.0)
    connected_energy_drift = E(before, G) - E(wait, G)
    cut_error = E(initial,0.0)-start-cut if tau else 0.0
    reconnect_error = E(wait,G)-E(wait,0.0)-reconnect if tau else 0.0
    if max(map(abs, (net-candidate, err, waiting_energy_drift, connected_energy_drift))) > FLOOR or max(abs(cut_error),abs(reconnect_error)) > 1e-15:
        raise ValueError(f"Energy or direct-vs-candidate mismatch: {(tau, net, candidate, err, cut_error, reconnect_error)}")
    return {
        "start_global_energy": start, "pre_global_energy": E(before,G), "post_global_energy": end,
        "direct_total_work": actual, "direct_net": net, "balance_residual": err,
        "waiting_energy_drift": waiting_energy_drift, "connected_energy_drift": connected_energy_drift,
        "cut_linear_residual": cut_error, "reconnect_linear_residual": reconnect_error,
    }, virtual


def scan(model, tables, tag, source, cycle, initial_time, initial, taus, full, candidate_table=None, scan_table=True):
    """Project each independent wait onto the connected basis, then batch candidates."""
    metadata = lambda t: {"scan":tag, "source":source, "cycle":cycle, "tau":t/1000}
    wait_spectral = [model.bases[0].to_basis(r) for r in initial]
    initial_c = [float(local_diagnostics(partial(r))["c_real"]) for r in initial]
    trials = []
    # Keep batches small enough that BLAS temporaries do not dominate the fixed kernels.
    for begin in range(0, len(taus), 10):
        batch = taus[begin:begin+10]
        counts = [(model.horizon-t)//GRID + 1 for t in batch]
        waiting = tuple(
            [model.bases[0].from_basis(model.bases[0].step_spectral(r, tau, dt)) if tau else initial[i]
             for tau in batch] for i, (r,dt) in enumerate(zip(wait_spectral,DT,strict=True))
        )
        spectral = tuple(np.array([model.connected.to_basis(r) for r in ws]) for ws in waiting)
        terminal = [model.terminal_grid(s, dt, max(counts)) for s,dt in zip(spectral,DT,strict=True)]
        evaluations = [local_diagnostics(t) for t in terminal]
        for i, (tau, count) in enumerate(zip(batch, counts, strict=True)):
            meta = metadata(tau)
            coarse, fine = ({k:v[i,:count].copy() for k,v in ev.items()} for ev in evaluations)
            spectra = tuple(s[i].copy() for s in spectral)
            wait = tuple(ws[i] for ws in waiting)
            cut, cut_half = (-2 * G * c if tau else 0.0 for c in initial_c)
            connect, connect_half = (2 * G * r["c_real"][0] if tau else 0.0 for r in (coarse,fine))
            for r, wcut, wconn in ((coarse,cut,connect),(fine,cut_half,connect_half)):
                r["net_work"] = r["total_work"] - wcut - wconn
                r["integrated_load_current"] = r["load_energy"] - r["load_energy"][0]
            chosen = int(np.argmax(coarse["net_work"]))
            half_chosen = int(np.argmax(fine["net_work"]))
            erg_chosen = int(np.argmax(coarse["load_ergotropy"]))
            connected_ms = chosen * GRID
            total_ms = tau + connected_ms
            indices = np.arange(count)
            total = (indices*GRID+tau)/1000
            difference = np.abs(coarse["net_work"]-fine["net_work"])
            supported = (coarse["net_work"]-difference>FLOOR) & (total>0)
            rates = np.divide(coarse["net_work"],total,out=np.zeros(count),where=total>0)
            rate_choice = int(np.argmax(np.where(supported,rates,-np.inf))) if supported.any() else None
            for field in ("net_work","load_current","load_ergotropy","load_energy","integrated_load_current"):
                if maxabs(coarse[field]-fine[field]) > HALF_TOL:
                    raise ValueError(f"Convergence failed {tag}/{source}/{tau}/{field}")
            c = complex(coarse["c_real"][0], coarse["c_imag"][0])
            info = {
                **meta, "anchor_time": initial_time/1000,
                "max_net": coarse["net_work"][chosen], "max_net_half": fine["net_work"][chosen],
                "max_net_half_own": fine["net_work"][half_chosen],
                "best_elapsed_connected": connected_ms/1000, "best_elapsed_total": total_ms/1000,
                "best_half_elapsed_connected": half_chosen * GRID / 1000,
                "best_net_at_grid_endpoint": chosen in (0,count-1),
                "candidate_count":count,
                "rate_at_best_net": float(rates[chosen]) if total_ms else "",
                "best_rate": float(rates[rate_choice]) if rate_choice is not None else "",
                "best_rate_elapsed_total": total[rate_choice] if rate_choice is not None else "",
                "best_rate_net": coarse["net_work"][rate_choice] if rate_choice is not None else "",
                "max_load_ergotropy": coarse["load_ergotropy"][erg_chosen],
                "max_load_ergotropy_elapsed_total": total[erg_chosen],
                "integrated_current_at_best": coarse["integrated_load_current"][chosen],
                "integrated_current_at_last_grid": coarse["integrated_load_current"][-1],
                "cut_on":cut, "reconnect_on":connect, "cut_on_half":cut_half, "reconnect_on_half":connect_half,
                "gross_at_best":coarse["gross_work"][chosen],
                "interaction_jump_at_best":coarse["interaction_jump"][chosen],
                "total_work_at_best":coarse["total_work"][chosen],
                "reconnect_c_real":c.real, "reconnect_c_imag":c.imag, "reconnect_c_abs":abs(c),
                "reconnect_c_phase":float(np.angle(c)) if abs(c)>FLOOR else "",
                "reconnect_c_abs_half":fine["c_abs"][0],
                "reconnect_current":coarse["load_current"][0],
                "reconnect_current_half":fine["load_current"][0],
                "actual_current_before_reconnect":0.0 if tau else coarse["load_current"][0],
                "hypothetical_current_before_reconnect":coarse["load_current"][0],
                "reconnect_terminal_population":coarse["terminal_population"][0],
                **{f"reconnect_{x}":coarse[x][0] for x in (
                    "load_energy","load_purity","load_ergotropy","load_passive_energy","load_p0","load_p1","load_p2",
                    "load_coherence_frobenius")},
            }
            signs = np.sign(coarse["load_current"][np.abs(coarse["load_current"])>FLOOR])
            info["current_sign_reversals"] = int(np.count_nonzero(signs[1:] != signs[:-1]))
            if full:
                best = selected_snapshots(model,wait,spectra,connected_ms)
                horizon = selected_snapshots(model,wait,spectra,model.horizon-tau)
                checks = get_checkpoints(model, initial, wait, best, horizon, info)
                info.update(checks)
            elif scan_table:
                # Future-blind variables eligible for a repeated prediction rule.
                present = model.metrics(wait[0],G)
                info.update({f"reconnect_{k}":present[k] for k in (
                    "global_energy","global_ergotropy","sector_ergotropy","mutual_information","total_excitation")})
            if scan_table:
                tables.add("m23_wait_summary" if full else "m23_repeated_search", info)
            trial = Trial(info,coarse,fine,spectra,wait,chosen,tau)
            if candidate_table is not None:
                emit_candidates(tables, candidate_table, trial)
            trials.append(trial)
        tables.flush()
    return trials


def emit_candidates(tables, table, trial):
    a,b,meta = trial.coarse,trial.half,trial.data
    for i in range(len(a["net_work"])):
        s = i * GRID
        tables.add(table, {
            **{k:meta[k] for k in ("scan","source","cycle","tau")},
            "elapsed_connected":s/1000, "elapsed_total":(trial.tau+s)/1000,
            "time":(ms(meta["anchor_time"])+trial.tau+s)/1000,
            **{k:values[i] for k,values in a.items()},
            "net_half": b["net_work"][i],
            **{f"{k}_half":b[k][i] for k in ("load_energy","load_ergotropy","load_current","integrated_load_current")},
            "cut_on":meta["cut_on"], "reconnect_on":meta["reconnect_on"],
        })


def get_checkpoints(model, initial, wait, best, horizon, info):
    tau = ms(info["tau"])
    acct, after = account(model, initial[0],wait[0],best[0],info["max_net"],tau,info["cut_on"],info["reconnect_on"])
    acct_f, _ = account(model, initial[1],wait[1],best[1],info["max_net_half"],tau,info["cut_on_half"],info["reconnect_on_half"])
    metrics = [model.metrics(r,G) for r in (wait[0],best[0],horizon[0],after)]
    fields = ["global_energy","global_ergotropy","sector_ergotropy","mutual_information","total_excitation",
              "global_purity","load_purity","global_passive_energy","load_ergotropy","load_passive_energy"]
    extra = {f"{phase}_{k}":point[k] for phase,point in zip(("reconnect","best","horizon","virtual_after"),metrics,strict=True)
             for k in fields if not (phase=="reconnect" and f"reconnect_{k}" in info)}
    errors = {f"{name}_matrix_half_error":maxabs(r[0]-r[1]) for name,r in (("reconnect",wait),("best",best),("horizon",horizon))}
    if max(errors.values()) > HALF_TOL:
        raise ValueError("Full-state convergence tolerance failed")
    reconnect_erg, selected_erg, horizon_erg = [v["global_ergotropy"] for v in metrics[:3]]
    if max(abs(reconnect_erg-selected_erg),abs(reconnect_erg-horizon_erg)) > FLOOR:
        raise ValueError("Fixed-H whole-system ergotropy drift")
    return {
        **extra, **errors, **acct, "direct_net_half":acct_f["direct_net"],
        "integrated_current_horizon": metrics[2]["load_energy"] - metrics[0]["load_energy"],
        "accepted_best": bool(info["max_net"]-abs(info["max_net"]-info["max_net_half"])>FLOOR and acct["direct_net"]>FLOOR),
    }


def save_selection(model, tables, trial, initial, index, commit):
    meta=trial.data
    t0=ms(meta["anchor_time"])
    tau=trial.tau
    s=index*GRID
    before=selected_snapshots(model,trial.rho_wait,trial.spectra,s)
    horizon=selected_snapshots(model,trial.rho_wait,trial.spectra,model.horizon-tau)
    after = tuple(extraction(r) for r in before)
    names={}
    phase_after = "after" if commit else "virtual_after"
    snapshots=(
        ("reconnect", t0+tau, trial.rho_wait),("before",t0+tau+s,before),
        ("horizon",t0+model.horizon,horizon),(phase_after,t0+tau+s,after),
    )
    for phase, when, pair in snapshots:
        for label, matrix in zip(("coarse","half"),pair,strict=True):
            path = f"states/{meta['scan']}_{meta['source']}_c{meta['cycle']:02}_tau{tau:04}_{phase}_{label}.bin"
            sha=store_density(tables.directory/path,matrix,when)
            props=model.metrics(matrix,G)
            record={
                **{k: meta[k] for k in ("scan","source","cycle","tau")},
                "phase":phase,"resolution":label,"time":when/1000,"g":G,"filename":path,"sha256":sha,
            }
            tables.add("m23_state_manifest",record)
            tables.add("m23_state_metrics",{**record,**props})
            names[phase,label]=path
    after_err=maxabs(after[0]-after[1])
    if after_err>HALF_TOL:
        raise ValueError(f"Post-extraction half state difference {after_err}")
    return before,after,names,after_err


def comparisons(tables, source, coarse, fine, top):
    opt=largest(coarse+fine)
    choices=[("A",next(x for x in coarse if x.tau==0)),("B",next(x for x in coarse if x.tau==2000)),("C",opt)]
    usable=[t for t in coarse+fine if t.data["best_rate"]!=""]
    time_opt=max(usable,key=lambda t:(float(t.data["best_rate"]),-t.tau))
    status=all(opt.net-base.net > opt.error+base.error+FLOOR for _,base in choices[:2])
    for tag,t in choices:
        data=t.data
        tables.add("m23_policy_comparison",{
            "source":source,"strategy":tag,"tau":t.tau/1000,"max_net":t.net,"net_half_error":t.error,
            "best_elapsed_total":data["best_elapsed_total"],"rate_at_best_net":data["rate_at_best_net"],
            "within_policy_best_rate":data["best_rate"] if tag!="C" else time_opt.data["best_rate"],
            "rate_optimal_tau":t.tau/1000 if tag!="C" else time_opt.tau/1000,
            "best_rate_elapsed_total":data["best_rate_elapsed_total"] if tag!="C" else time_opt.data["best_rate_elapsed_total"],
            "cut_on":data["cut_on"],"reconnect_on":data["reconnect_on"],
            "optimal_exceeds_both_resolved":status,"coarse_centers":" ".join(f"{c.tau/1000:.3f}" for c in top),
            "registered_stage":data["scan"],
        })
    by_tau = {t.tau:t for t in coarse+fine}
    for offset in (-250,-100,-50,-25,0,25,50,100,250):
        candidate=by_tau.get(opt.tau+offset)
        if candidate:
            tables.add("m23_robustness",{"source":source,"optimal_tau":opt.tau/1000,"nearby_tau":candidate.tau/1000,
                       "offset":offset/1000,"max_net":candidate.net,"fraction_of_optimal":candidate.net/opt.net})
    return choices,status


def run_single(root, destination, short):
    horizon = 2500 if short else HORIZON
    start=time.perf_counter()
    model=Dynamics(horizon)
    tables=Tables(destination)
    durations=[]
    for row in csv_rows(root/"m23_sources.csv"):
        source=row["source"]
        saved=ms(row["source_time"])
        rho=read_state(root/row["filename"],saved/1000)
        initial=(rho,rho)
        cycle=int(row["source_cycle"])+1
        t=time.perf_counter()
        coarse=scan(model,tables,"A",source,cycle,saved,initial,(0,250,2000) if short else COARSE_TAUS,
                   True,"m23_candidates")
        durations.append(("phase_A",source,len(coarse),time.perf_counter()-t))
        if short:
            if source == "S0":
                example = coarse[-1]
                save_selection(model,tables,example,initial,example.selection_index,False)
            continue
        t=time.perf_counter()
        top,lattice=refine_trials(coarse)
        fine=scan(model,tables,"C",source,cycle,saved,initial,lattice,True,"m23_candidates")
        for rank,center in enumerate(top,1):
            tables.add("m23_refinement_centers",{"source":source,"cycle":cycle,"rank":rank,
                        "center_tau":center.tau/1000,"coarse_max_net":center.net,"edge":center.tau in (0,6000)})
        options,status=comparisons(tables,source,coarse,fine,top)
        unique=set()
        for (_,w) in options:
            key=w.data["scan"],w.tau
            if key in unique:
                continue
            unique.add(key)
            save_selection(model,tables,w,initial,w.selection_index,False)
        durations.append(("phase_C",source,len(fine),time.perf_counter()-t))
        print(f"{source}: A/C completed, peak {options[-1][1].net:.9e} tau={options[-1][1].tau/1000:.3f}, E gate {status}",flush=True)
    for stage, source, trajectories, elapsed in durations:
        tables.add("m23_runtime",{"stage":stage,"source":source,"trajectories":trajectories,"elapsed_seconds":elapsed})
    tables.add("m23_runtime",{"stage":"total","source":"all","trajectories":sum(r[2] for r in durations),
               "elapsed_seconds":time.perf_counter()-start})
    tables.close()
    print(f"{destination.name}: {time.perf_counter()-start:.2f} seconds",flush=True)


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode",choices=("benchmark","single"))
    parser.add_argument("destination",type=Path)
    parser.add_argument("--inputs",type=Path,default=ROOT)
    args=parser.parse_args()
    args.destination.mkdir()
    run_single(args.inputs,args.destination,args.mode=="benchmark")
