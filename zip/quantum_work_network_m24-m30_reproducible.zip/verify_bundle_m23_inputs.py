"""Verify the bundled M23 prerequisites for reproducing M24–M30."""

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import struct
from zipfile import ZipFile


ROOT = Path(__file__).resolve().parent / "Milestone_23"
MANIFEST = "compact_input_manifest.json"
ZIP_NAME = "M23_all_results.zip"
CHECKSUM = "M23_all_results.sha256"
HEADER = struct.Struct("<8sQd")


def checked_path(root, name):
    member = PurePosixPath(name)
    if not member.parts or member.is_absolute() or ".." in member.parts or chr(92) in name or ":" in name:
        raise ValueError(f"Unsafe path in manifest: {name}")
    path = (root / member).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError(f"Manifest path leaves input directory: {name}")
    return path


def file_sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def check_subset(root):
    metadata = json.loads((root / MANIFEST).read_text(encoding="utf-8"))
    archive = metadata["official_archive"]
    official = (root / CHECKSUM).read_text(encoding="ascii").split()
    if official != [archive["sha256"], ZIP_NAME]:
        raise ValueError("An unexpected SHA-256 is recorded for the official M23 archive")
    for item in metadata["members"]:
        path = checked_path(root, item["path"])
        if path.stat().st_size != item["bytes"] or file_sha(path) != item["sha256"]:
            raise ValueError(f"Packaged M23 prerequisite changed: {item['path']}")
    registered = {item["path"]: item for item in metadata["members"]}
    for state in metadata["seeds"]:
        item = registered[state["path"]]
        path = checked_path(root, state["path"])
        with path.open("rb") as stream:
            magic, dimension, time = HEADER.unpack(stream.read(HEADER.size))
        if (magic != b"QWNRHO1" + bytes(1) or dimension != 384
                or item["bytes"] != HEADER.size + 16 * dimension ** 2
                or item["sha256"] != state["sha256"]
                or abs(time - state["source_time"]) > 1e-12):
            raise ValueError(f"Registered M24 state header or digest differs: {state['origin']}/{state['precision']}")
    return metadata


def check_archive(archive_path, metadata):
    official = metadata["official_archive"]
    if archive_path.stat().st_size != official["bytes"] or file_sha(archive_path) != official["sha256"]:
        raise ValueError("The whole official M23 archive SHA-256 does not match")
    with ZipFile(archive_path) as archive:
        for item in metadata["members"]:
            with archive.open("Milestone_23/" + item["path"]) as stream:
                digest = hashlib.file_digest(stream, "sha256").hexdigest()
            if digest != item["sha256"]:
                raise ValueError(f"Official M23 member differs: {item['path']}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--m23", type=Path, default=ROOT)
    parser.add_argument("--official-zip", type=Path,
                        help="also verify the whole original M23 archive and matching members")
    args = parser.parse_args()
    metadata = check_subset(args.m23)
    print(f"PASS packaged input SHA-256: {len(metadata['members'])} M23 files, "
          f"{len(metadata['seeds'])} registered coarse/half source assignments")
    archive = args.official_zip
    if archive is None and (args.m23 / ZIP_NAME).is_file():
        archive = args.m23 / ZIP_NAME
    if archive is not None:
        check_archive(archive, metadata)
        print(f"PASS official M23 archive SHA-256 and packaged member hashes: {archive}")


if __name__ == "__main__":
    main()
