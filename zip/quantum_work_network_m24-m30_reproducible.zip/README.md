# Quantum Work Network | M24–M30 reproduction package

These Python experiments trace repeated local work extraction from saved states of the seven-site quantum chain with a three-level load. They progress from a causal forecast of extraction timing to the effects of phase and work-input checks on reconnection.

- [Reproduction guide](REPRODUCE_M24_M30.md) gives a short U05 run, the full stage sequence, and the independent audit commands.
- [M30 report](Milestone_30/MILESTONE_30_RECONNECTION_CONDITIONS_REPORT.md) summarizes the condition comparison at elapsed model time 540, including the U05 sign reversal and exact-online numerical check.
- [M23 input provenance](Milestone_23/compact_input_manifest.json) records the frozen matrix inputs carried forward into M24–M30.

The package includes source, preregistration files, stage reports, selected reference tables and figures, frozen M23 inputs, and the frozen M29 U05 state and trial histories used in the short run. The formal reproduction regenerates the large observation logs, checkpoints, and remaining M29 preparations. Some links in the original reports refer to these generated files.

| Milestone | Focus | Stage instructions |
| --- | --- | --- |
| M24 | Forecast extraction timing from load energy and passive energy | [M24](Milestone_24/README_M24.md) |
| M25 | Extend the timing rules to repeated extraction | [M25](Milestone_25/README_M25.md) |
| M26 | Compare controls through a common elapsed time of 540 | [M26](Milestone_26/README_M26.md) |
| M27 | Evaluate causal adaptive waiting and extraction controls | [M27](Milestone_27/README_M27.md) |
| M28 | Audit time-step robustness and isolate reconnection conditions | [M28](Milestone_28/README_M28.md) |
| M29 | Reduce measurement requirements and evaluate six additional states | [M29](Milestone_29/README_M29.md) |
| M30 | Restore removed conditions individually and measure their interaction | [M30](Milestone_30/README_M30.md) |

Use Windows PowerShell and Python 3.14 x64. Stage clocks are expressed in model time. The results apply to the specified simulated states, control rules, and finite horizons.

[Project README and earlier archives](https://github.com/Riku-Tono/quantum-work-network) · [License](LICENSE)
