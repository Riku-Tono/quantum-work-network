"""Render the eight M25 repeated-extraction figures from the merged results."""

import argparse
from collections import defaultdict
import csv
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator


ROOT = Path(__file__).resolve().parent
PRIMARY = "S0"
INK = "#172D40"
MUTED = "#4B6477"
GRID = "#E0E8EF"
BLUE = "#215B89"
TEAL = "#00766E"
ORANGE = "#B94B22"
PURPLE = "#754582"

POLICIES = {
    "A": (TEAL, "D", "-", "Forecast"),
    "B": (BLUE, "o", "-", "Ergotropy turn"),
    "C25": ("#93641B", "^", "--", "Prior-work floor 25%"),
    "C": (ORANGE, "v", "-", "Prior-work floor 50%"),
    "D": ("#565F69", "x", ":", "Fixed delay"),
    "E": (PURPLE, "s", "-.", "M23 variable-wait maximum"),
    "F": (INK, "P", "--", "Connected grid maximum"),
}
ORIGINS = {"S0": (BLUE, "o"), "A04": (ORANGE, "^"), "B04": (TEAL, "D"), "C04": (PURPLE, "s")}
ENERGIES = (
    ("load_energy", r"Load energy $E_L$"),
    ("load_passive_energy", r"Passive energy $E_{\mathrm{p}}$"),
    ("load_ergotropy", r"Ergotropy $\mathcal{W}_L$"),
)


def csv_rows(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        yield from csv.DictReader(stream)


def number(row, field):
    return float(row[field]) if row[field] else math.nan


def grouped(rows, order):
    groups = defaultdict(list)
    for row in rows:
        groups[row["origin"], row["policy"]].append(row)
    for group in groups.values():
        group.sort(key=lambda row: number(row, order))
    return groups


def accepted(rows):
    return [row for row in rows if row["accepted"].casefold() == "true"]


def policy_handles(policies):
    handles = []
    for policy in policies:
        color, marker, pattern, name = POLICIES[policy]
        handles.append(Line2D([], [], color=color, marker=marker, markerfacecolor="white",
                              linestyle=pattern, linewidth=1.4, label=f"{policy}  {name}"))
    return handles


def page_title(fig, title, caption, handles, *, columns=4):
    height = fig.get_figheight()
    fig.text(0.105, 1 - 0.26 / height, title, fontweight="bold", fontsize=18, va="top")
    fig.text(0.105, 1 - 0.67 / height, caption, fontsize=10, color=MUTED, va="top")
    if handles:
        fig.legend(handles=handles, loc="upper left", bbox_to_anchor=(0.100, 1 - 0.97 / height),
                   ncols=columns, frameon=False, handlelength=2.2, columnspacing=1.55)


def panel_title(fig, axis, title):
    box = axis.get_position()
    fig.text(box.x0, box.y1 + 0.23 / fig.get_figheight(), title, fontweight="bold", va="bottom")


def style_axis(axis, *, xlabel=None, ylabel=None, scientific=False, compact=False):
    axis.set_axisbelow(True)
    axis.yaxis.grid(color=GRID, linewidth=0.8)
    axis.spines[["top", "right"]].set_visible(False)
    axis.spines[["bottom", "left"]].set_color(MUTED)
    axis.tick_params(color=MUTED, labelcolor=INK, labelsize=8 if compact else 9)
    if scientific:
        axis.ticklabel_format(axis="y", style="sci", scilimits=(-2, 2), useMathText=True, useOffset=False)
        axis.yaxis.offsetText.set(fontsize=8, color=MUTED)
    if compact:
        axis.yaxis.set_major_locator(MaxNLocator(3))
    if xlabel:
        axis.set_xlabel(xlabel)
    if ylabel:
        axis.set_ylabel(ylabel)


def finish(fig, output, name):
    fig.savefig(output / f"m25_{name}.png", dpi=205, facecolor="white")
    plt.close(fig)


def plot_policy(axis, policy, x, y, *, step=False, horizon=None):
    if not x:
        return
    color, marker, pattern, _ = POLICIES[policy]
    axis.plot(x, y, color=color, linestyle=pattern, linewidth=1.45,
              marker=None if step else marker, markersize=4.1, markerfacecolor="white",
              markeredgewidth=0.95, markevery=max(1, len(x) // 9),
              drawstyle="steps-post" if step else "default")
    if step:
        axis.scatter(x[-1], y[-1], s=21, marker=marker, c=color, linewidths=0.9, zorder=4)
        if horizon is not None and x[-1] < horizon:
            axis.plot((x[-1], horizon), (y[-1], y[-1]), color=color, linestyle=":", linewidth=1.2, alpha=0.53)


def work_by_count(rows):
    rows = accepted(rows)
    return [0, *(number(row, "count") for row in rows)], [0, *(number(row, "cumulative_net") for row in rows)]


def work_by_time(rows):
    completions = accepted(rows)
    elapsed = [0, *(number(row, "elapsed_total") for row in completions)]
    work = [0, *(number(row, "cumulative_net") for row in completions)]
    last_attempt = number(rows[-1], "elapsed_total")
    if last_attempt > elapsed[-1]:
        elapsed.append(last_attempt)
        work.append(work[-1])
    return elapsed, work


def rate_by_count(rows):
    rows = accepted(rows)
    return [number(row, "count") for row in rows], [number(row, "cumulative_rate") for row in rows]


def future_by_count(rows):
    return [number(row, "count") for row in rows], [number(row, "diagnostic_work") for row in rows]


def plot_across_origins(groups, output, name, title, caption, ylabel, profile, *, step=False, ticks=None,
                        horizon=None):
    fig, axes = plt.subplots(2, 2, figsize=(12.3, 8.15), sharex=True)
    fig.subplots_adjust(left=0.105, right=0.965, top=0.77, bottom=0.105, wspace=0.28, hspace=0.45)
    policies = [policy for policy in POLICIES if any((origin, policy) in groups for origin in ORIGINS)]
    page_title(fig, title, caption, policy_handles(policies))
    xlabel = "Total elapsed time" if step else "Accepted extractions"
    for index, (origin, axis) in enumerate(zip(ORIGINS, axes.flat, strict=True)):
        for policy in policies:
            rows = groups.get((origin, policy))
            if rows:
                plot_policy(axis, policy, *profile(rows), step=step, horizon=horizon)
        panel_title(fig, axis, origin)
        style_axis(axis, xlabel=xlabel if index >= 2 else None,
                   ylabel=ylabel if index % 2 == 0 else None, scientific=True)
        axis.set_ylim(bottom=0)
    axes[1, 0].set_xlim(left=0, right=horizon)
    if ticks:
        axes[1, 0].set_xticks(ticks)
    elif not step:
        axes[1, 0].xaxis.set_major_locator(MaxNLocator(integer=True, nbins=7))
    finish(fig, output, name)


def plot_cycle_work(groups, output):
    fig, axes = plt.subplots(2, 1, figsize=(11.8, 7.5), sharex=True)
    fig.subplots_adjust(left=0.115, right=0.962, top=0.75, bottom=0.115, hspace=0.32)
    policies = [policy for policy in POLICIES if (PRIMARY, policy) in groups]
    page_title(fig, "Work and timing of each extraction at S0",
               "Only accepted operations are shown. Each interval is measured from the previous accepted state.",
               policy_handles(policies))
    for policy in policies:
        rows = accepted(groups[PRIMARY, policy])
        count = [number(row, "count") for row in rows]
        plot_policy(axes[0], policy, count, [number(row, "net_work") for row in rows])
        plot_policy(axes[1], policy, count, [number(row, "duration") for row in rows])
    axes[0].set_yscale("log")
    style_axis(axes[0], ylabel="Net work (log scale)")
    style_axis(axes[1], xlabel="Accepted extractions", ylabel="Extraction interval")
    axes[1].set_ylim(bottom=0)
    axes[1].xaxis.set_major_locator(MaxNLocator(integer=True, nbins=9))
    finish(fig, output, "04_cycle_work_intervals")


def load_paths(path):
    phases = {"wait": 0, "connected": 1, "post": 2}
    paths = defaultdict(list)
    for row in csv_rows(path):
        if row["origin"] != PRIMARY:
            continue
        paths[row["policy"]].append((number(row, "elapsed_total"), int(row["attempt"]), phases[row["phase"]],
                                     *(number(row, field) for field, _ in ENERGIES)))
    for rows in paths.values():
        rows.sort(key=lambda row: row[:3])
    return paths


def plot_load_trajectories(paths, output):
    policies = [policy for policy in POLICIES if policy in paths]
    fig, axes = plt.subplots(len(policies), 3, figsize=(12.9, 2.55 + 1.54 * len(policies)),
                             sharex="row", sharey="col", squeeze=False)
    fig.subplots_adjust(left=0.12, right=0.967, top=1 - 1.85 / fig.get_figheight(),
                        bottom=0.075, wspace=0.33, hspace=0.44)
    page_title(fig, "Load-energy trajectories during repeated extraction at S0",
               "Each row has its own time scale. Columns share energy scales. Vertical segments mark the extraction jumps.",
               policy_handles(policies))
    for col, (_, title) in enumerate(ENERGIES):
        panel_title(fig, axes[0, col], title)
    for index, policy in enumerate(policies):
        color, _, _, _ = POLICIES[policy]
        points = paths[policy]
        elapsed = [point[0] for point in points]
        for col, axis in enumerate(axes[index]):
            energy = [point[3 + col] for point in points]
            axis.plot(elapsed, energy, color=color, linewidth=1.05)
            style_axis(axis, xlabel="Total elapsed time" if index == len(policies) - 1 else None,
                       ylabel=policy if col == 0 else None, scientific=True, compact=True)
        axes[index, 0].set_xlim(left=0)
        axes[index, 0].xaxis.set_major_locator(MaxNLocator(nbins=6))
    finish(fig, output, "05_load_trajectories")


def plot_exchange(groups, output):
    policies = [policy for policy in POLICIES if (PRIMARY, policy) in groups]
    fig, axes = plt.subplots(len(policies), 2, figsize=(12.2, 2.1 + 1.57 * len(policies)),
                             sharex=True, squeeze=False)
    fig.subplots_adjust(left=0.12, right=0.961, top=1 - 1.76 / fig.get_figheight(),
                        bottom=0.078, wspace=0.24, hspace=0.40)
    styles = (("pre", BLUE, "o", "Before extraction"), ("post", ORANGE, "D", "After extraction"))
    handles = [Line2D([], [], color=color, marker=marker, label=label, linestyle="none")
               for _, color, marker, label in styles]
    page_title(fig, "Exchange coherence across extractions at S0",
               "Markers separate before and after within each count. Phase is shown above the amplitude tolerance.", handles)
    panel_title(fig, axes[0, 0], r"Amplitude $|C|$")
    panel_title(fig, axes[0, 1], r"Phase $\arg C$")
    for index, policy in enumerate(policies):
        amplitude, phase = axes[index]
        rows = accepted(groups[PRIMARY, policy])
        counts = [number(row, "count") for row in rows]
        for (stage, color, marker, _), offset in zip(styles, (-0.17, 0.17), strict=True):
            magnitude = [number(row, f"{stage}_c_abs") for row in rows]
            angle = [number(row, f"{stage}_c_phase") for row in rows]
            marker_counts = [count + offset for count in counts]
            amplitude.plot(counts, magnitude, color=color, linewidth=1.05,
                           linestyle="--" if stage == "pre" else "-")
            amplitude.scatter(marker_counts, magnitude, marker=marker, c=color, s=15, linewidths=0, zorder=3)
            phase.scatter(marker_counts, angle, marker=marker, c=color, s=15, linewidths=0)
        xlabel = "Accepted extractions" if index == len(policies) - 1 else None
        style_axis(amplitude, xlabel=xlabel, ylabel=policy, scientific=True, compact=True)
        style_axis(phase, xlabel=xlabel, compact=True)
        amplitude.set_ylim(bottom=0)
        phase.set_ylim(-math.pi * 1.07, math.pi * 1.07)
        phase.set_yticks((-math.pi, -math.pi / 2, 0, math.pi / 2, math.pi),
                         (r"$-\pi$", r"$-\pi/2$", "0", r"$\pi/2$", r"$\pi$"))
    axes[-1, 0].xaxis.set_major_locator(MaxNLocator(integer=True, nbins=9))
    finish(fig, output, "06_exchange_pre_post")


def plot_thresholds(groups, output):
    fig, axes = plt.subplots(2, 2, figsize=(11.6, 7.3), sharex=True)
    fig.subplots_adjust(left=0.108, right=0.966, top=0.77, bottom=0.13, wspace=0.30, hspace=0.43)
    handles = [Line2D([], [], color=color, marker=marker, markerfacecolor="white", label=origin)
               for origin, (color, marker) in ORIGINS.items()]
    page_title(fig, "Effect of the prior-work floor on realized performance",
               "Each point is the final recorded outcome for its policy and origin. B is the zero-floor control.", handles)
    panels = (
        ("cumulative_net", "Cumulative net work", True),
        ("elapsed_total", "Total elapsed time", False),
        ("cumulative_rate", "Cumulative work per time", True),
        ("count", "Accepted extractions", False),
    )
    thresholds = ((0, "B"), (25, "C25"), (50, "C"))
    for origin, (color, marker) in ORIGINS.items():
        available = [(threshold, groups[origin, policy][-1]) for threshold, policy in thresholds
                     if (origin, policy) in groups]
        for axis, (field, _, _) in zip(axes.flat, panels, strict=True):
            axis.plot([threshold for threshold, _ in available], [number(row, field) for _, row in available],
                      color=color, marker=marker, markerfacecolor="white", linewidth=1.4, markersize=5)
    for index, (axis, (_, label, scientific)) in enumerate(zip(axes.flat, panels, strict=True)):
        panel_title(fig, axis, label)
        style_axis(axis, xlabel="Prior-work floor" if index >= 2 else None, scientific=scientific)
        finite_values = [value for line in axis.lines for value in line.get_ydata() if math.isfinite(value)]
        upper = max(axis.get_ylim()[1], 1.08 * max(finite_values, default=0))
        axis.set_ylim(bottom=0, top=upper)
    axes[1, 1].yaxis.set_major_locator(MaxNLocator(integer=True, nbins=5))
    axes[1, 0].set_xticks((0, 25, 50), ("0% (B)", "25% (C25)", "50% (C)"))
    axes[1, 0].set_xlim(-4, 54)
    finish(fig, output, "07_threshold_comparison")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, help="Directory containing the merged CSV results, defaulting to results")
    parser.add_argument("--output", type=Path, help="Figure directory, defaulting to figures in the milestone or --data")
    args = parser.parse_args()
    data = args.data or ROOT / "results"
    output = args.output or (args.data or ROOT) / "figures"
    output.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "text.color": INK,
                         "axes.labelcolor": INK, "legend.labelcolor": INK})

    history = grouped(csv_rows(data / "m25_history.csv"), "attempt")
    plot_across_origins(history, output, "01_cumulative_work_count", "Cumulative work by extraction count",
                        "Count starts at zero for each origin. Each line ends at the last accepted extraction.",
                        "Cumulative net work", work_by_count)
    comparison = data / "m25_time_comparison.csv"
    time_ticks = sorted({number(row, "elapsed_total") for row in csv_rows(comparison)
                         if row["time_label"].startswith("t")}) if comparison.is_file() else []
    horizon = time_ticks[-1] if time_ticks else None
    time_caption = ("Markers show branch endpoints. Faint tails hold credited work constant after the last observed time."
                    if horizon is not None else "Steps mark accepted extractions. Markers show branch endpoints.")
    plot_across_origins(history, output, "02_cumulative_work_time", "Cumulative work over elapsed time",
                        time_caption, "Cumulative net work", work_by_time, step=True, horizon=horizon,
                        ticks=[0, *time_ticks] if time_ticks else None)
    plot_across_origins(history, output, "03_cumulative_rate_count", "Cumulative work per time by extraction count",
                        "At each accepted event, cumulative net work is divided by total elapsed time, including waits.",
                        "Cumulative work per time", rate_by_count)
    plot_cycle_work(history, output)
    plot_load_trajectories(load_paths(data / "m25_trajectories.csv"), output)
    plot_exchange(history, output)
    plot_thresholds(history, output)
    future = grouped(csv_rows(data / "m25_future.csv"), "count")
    diagnostic_counts = sorted({int(row["count"]) for series in future.values() for row in series})
    plot_across_origins(future, output, "08_future_work", "Maximum future work from each extracted state",
                        "At marked extraction counts, a fresh 18.00 time window is evaluated with the system connected.",
                        "Future maximum net work", future_by_count, ticks=diagnostic_counts)


if __name__ == "__main__":
    main()
