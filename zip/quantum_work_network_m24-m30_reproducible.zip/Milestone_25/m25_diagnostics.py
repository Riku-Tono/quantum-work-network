"""State audits and the common connected future-work diagnostic for M25."""

from operator import index

import numpy as np

from m21_observables import (
    CHAIN_DIM, LOAD_DIM, OCCUPATION, SECTOR_NUMBERS, expectation, spectrum,
)
from m23_spectral import (
    DT, FLOOR, G, GRID, HALF_TOL, HORIZON, entropy, local_diagnostics, maxabs, partial,
)
from run_m23 import account, selected_snapshots


def state_metrics(model, rho):
    """Measure a state using the connected Hamiltonian and the inherited tolerances."""
    if not np.isfinite(rho).all():
        raise ValueError("Nonfinite state in M25 diagnostics")
    trace_error = abs(np.trace(rho) - 1)
    hermiticity_error = maxabs(rho - rho.conj().T)
    values = spectrum(rho)
    if max(trace_error, hermiticity_error, -values[0]) > FLOOR:
        raise ValueError(f"M25 density physicality failed: {trace_error=}, {hermiticity_error=}, "
                         f"minimum_eigenvalue={values[0]:g}")

    terminal = partial(rho)
    local = local_diagnostics(terminal)
    coherence = complex(local["c_real"], local["c_imag"])
    load = terminal[:LOAD_DIM, :LOAD_DIM] + terminal[LOAD_DIM:, LOAD_DIM:]
    cross_block = terminal[:LOAD_DIM, LOAD_DIM:]
    exchange_bound = 2 * np.sqrt(LOAD_DIM - 1) * np.linalg.svd(cross_block, compute_uv=False).sum()
    chain = np.trace(rho.reshape(CHAIN_DIM, LOAD_DIM, CHAIN_DIM, LOAD_DIM), axis1=1, axis2=3)
    hamiltonian, block_levels, levels = model.obs.hamiltonian(G)
    energy = expectation(rho, hamiltonian)
    passive_energy = float(levels @ values[::-1])
    sector_passive_energy = sum(float(e @ spectrum(rho[indices])[::-1])
                                for indices, e in zip(model.obs.sectors, block_levels, strict=True))
    ergotropy = energy - passive_energy
    sector_ergotropy = energy - sector_passive_energy
    probabilities = np.bincount(OCCUPATION, weights=rho.diagonal().real)
    if not -FLOOR <= sector_ergotropy <= ergotropy + FLOOR:
        raise ValueError(f"M25 sector ergotropy outside [0, unrestricted]: {sector_ergotropy:g}")
    if probabilities.min() < -FLOOR or abs(probabilities.sum() - 1) > FLOOR:
        raise ValueError("M25 excitation-sector probabilities outside their allowed range")

    bare_total = expectation(rho, model.h[0])
    exchange_energy = 2 * G * coherence.real
    energy_split_error = abs(energy - (bare_total + exchange_energy))
    if energy_split_error > FLOOR:
        raise ValueError(f"Connected Hamiltonian energy decomposition failed by {energy_split_error:g}")
    return {
        "global_energy": energy,
        "global_passive_energy": passive_energy,
        "global_ergotropy": ergotropy,
        "global_purity": float(np.vdot(rho, rho).real),
        "sector_passive_energy": sector_passive_energy,
        "sector_ergotropy": sector_ergotropy,
        "total_excitation": float(SECTOR_NUMBERS @ probabilities),
        "mutual_information": entropy(spectrum(chain)) + entropy(spectrum(load)) - entropy(values),
        "trace_error": float(trace_error),
        "hermiticity_error": hermiticity_error,
        "minimum_eigenvalue": float(values[0]),
        "bare_total_energy": bare_total,
        "bare_chain_energy": bare_total - float(local["load_energy"]),
        "exchange_energy": exchange_energy,
        "energy_split_error": energy_split_error,
        "c_real": coherence.real,
        "c_imag": coherence.imag,
        "c_abs": abs(coherence),
        "c_phase": float(np.angle(coherence)) if abs(coherence) > FLOOR else None,
        "load_energy": float(local["load_energy"]),
        "load_passive_energy": float(local["load_passive_energy"]),
        "load_ergotropy": float(local["load_ergotropy"]),
        "load_purity": float(local["load_purity"]),
        "load_current": float(local["load_current"]),
        "terminal_population": float(local["terminal_population"]),
        "terminal_exchange_expectation": 2 * coherence.real,
        "any_local_unitary_full_work_upper_bound": (max(0.0, float(local["load_ergotropy"]))
                                                    + exchange_energy + G * exchange_bound),
        **{f"sector_probability_{n}": float(p) for n, p in enumerate(probabilities)},
    }


def future_work_many(model, pairs, *, horizon=HORIZON):
    """Look ahead at fixed coupling on independent coarse/half state pairs.

    The state pairs are read-only. Each optimum uses the coarse-step net work on
    the M23 grid, the first candidate in an exact tie, and a direct energy audit
    at the selected time. The common time origin is the supplied state's time.
    """
    horizon = index(horizon)
    if not 0 <= horizon <= model.horizon:
        raise ValueError(f"Diagnostic window must be in [0, {model.horizon}] milliseconds")
    count = horizon // GRID + 1
    pairs = list(pairs)
    records = []
    # Match M23's projection batch size to limit the connected-kernel temporaries.
    for first in range(0, len(pairs), 10):
        batch = pairs[first:first + 10]
        coarse_rhos, half_rhos = zip(*batch, strict=True)
        spectra = tuple(np.stack([model.connected.to_basis(rho) for rho in rhos])
                        for rhos in (coarse_rhos, half_rhos))
        coarse, half = (local_diagnostics(model.terminal_grid(spectrum, dt, count))["total_work"]
                        for spectrum, dt in zip(spectra, DT, strict=True))
        for row, pair in enumerate(batch):
            step_errors = np.abs(coarse[row] - half[row])
            max_step_error = float(step_errors.max())
            if max_step_error > HALF_TOL:
                raise ValueError(f"Future-work grid convergence failed by {max_step_error:g}")
            chosen = int(np.argmax(coarse[row]))
            elapsed = chosen * GRID
            net = float(coarse[row, chosen])
            net_half = float(half[row, chosen])
            step_error = float(step_errors[chosen])
            before = selected_snapshots(model, pair, tuple(a[row] for a in spectra), elapsed)
            checks = [account(model, start, start, pre, work, 0, 0.0, 0.0)[0]
                      for start, pre, work in zip(pair, before, (net, net_half), strict=True)]
            direct, direct_half = (check["direct_net"] for check in checks)
            accepted = net - step_error > FLOOR and direct > FLOOR
            records.append({
                "max_net": net,
                "max_net_half": net_half,
                "direct_max_net": direct,
                "direct_max_net_half": direct_half,
                "diagnostic_work": direct if accepted else 0.0,
                "accepted": accepted,
                "elapsed_connected": elapsed / 1000,
                "candidate_count": count,
                "step_error": step_error,
                "max_grid_step_error": max_step_error,
                "max_direct_residual": max(abs(direct - net), abs(direct_half - net_half)),
                "max_balance_residual": max(abs(check["balance_residual"]) for check in checks),
            })
    return records


def future_work(model, pair, *, horizon=HORIZON):
    """Return one common-window future-work diagnostic."""
    return future_work_many(model, (pair,), horizon=horizon)[0]
