# M25 再現手順

M24 の予報型停止規則を、抽出後の状態を引き継ぐ反復に適用する。共通起点は S0・A04・B04・C04。比較の設定、採択条件、時間上限、相対閾値は [正式計算の条件](PROTOCOL_M25.md) に記載した。 [報告書](MILESTONE_25_REPEATED_ERGOTROPY_CONTROL_REPORT.md)

## 実行

Windows PowerShell から `Milestone_25` をカレントディレクトリにする。Python 3.14、NumPy 2.5.5、Matplotlib 3.10.9 を使用した。隣の `Milestone_23` と `Milestone_24` の正式成果物が必要。再計算先には新しいディレクトリ名を指定する。

```powershell
py -3.14 -m pip install -r ../Milestone_23/requirements.txt
$env:OPENBLAS_NUM_THREADS = '2'
py -3.14 -B run_m25.py redo/benchmark --rounds 2 --origins S0 --workers 1
py -3.14 -B verify_m25.py redo/benchmark --benchmark
py -3.14 -B run_m25.py redo/n10 --rounds 10 --workers 4
py -3.14 -B collect_m25.py redo/check10 redo/n10 --benchmark redo/benchmark
py -3.14 -B verify_m25.py redo/check10 --rounds 10 --stage-root redo
py -3.14 -B run_m25.py redo/n20 --rounds 20 --previous redo/n10 --workers 4
py -3.14 -B collect_m25.py redo/check20 redo/n10 redo/n20 --benchmark redo/benchmark
py -3.14 -B verify_m25.py redo/check20 --rounds 20 --stage-root redo
py -3.14 -B run_m25.py redo/n30 --rounds 30 --previous redo/n20 --workers 4
py -3.14 -B collect_m25.py redo/results redo/n10 redo/n20 redo/n30 --benchmark redo/benchmark
py -3.14 -B verify_m25.py redo/results --stage-root redo
py -3.14 -B plot_m25.py --data redo/results --output redo/figures
```

各段階では粗・半刻みの状態を `checkpoint.npz` に保存する。次の段階は `--previous` の採択状態と台帳を引き継ぐ。途中終了した枝は、次の段階で抽出を再開しない。メモリに余裕がない場合は `--workers 1` で逐次実行できる。

配布済みの結果は `py -3.14 -B verify_m25.py` で監査する。独立監査の伝播は全行列での時間発展を使い、CSVの候補仕事、採否、同一時刻の集計、段階チェック点と照合する。

## データ・数値の定義

`results/` に全方式・全起点の結果がある。

| ファイル | 内容 |
| --- | --- |
| `m25_sources.csv` | M24の起点名、時刻、粗・半状態の相対ファイル名とSHA-256 |
| `m25_benchmark.csv` | S0で各方式を2回走らせた時間と、同条件下での単純外挿 |
| `m25_stage_runtime.csv` | 10・20・30回段階の枝別計時と終了理由 |
| `m25_history.csv` | 採否、決定と実行時刻、候補と直接仕事、見送り閾値、抽出前後の診断と状態ハッシュ |
| `m25_trajectories.csv` | 実際に経過した接続区間の0.02観測格子と抽出後の点。切断中は自由発展で不変の負荷エネルギー量を記録 |
| `m25_search.csv` | E・Fの候補待機・候補数・各待機の最大仕事と採択候補 |
| `m25_future.csv` | 代表採択後の状態から、τ=0・18.00窓で計算した単回最大仕事 |
| `m25_count_comparison.csv` | 同一採択回数に初めて到達した時点での累積仕事と累積時間率 |
| `m25_time_comparison.csv` | 共通の経過時刻までの実行済み累積仕事、採択回数、累積時間率 |
| `m25_endpoints.csv` | 各枝の終了理由、終了時と最後の採択時刻、最終累積値 |

`elapsed_total` は起点からの待機込み経過、`duration` はその試行の経過。`elapsed_connected` は当該試行の再接続後の経過。ただし `m25_future.csv` の `elapsed_total` は診断元の採択時刻、`elapsed_connected` はそこから診断最大までの遅延。`count` は実採択の累計、`attempt` は候補の採否を判定した回数。位相は振幅が \(10^{-12}\) 以下なら空欄。`half_replay_duration` は粗の採択時刻で引き継いだ半刻み状態に対する、当該回だけの時刻感度。E/F では粗で選ばれた待機を固定して半刻みの窓内最大を求める。

## 図

1. [抽出回数と累積正味仕事](figures/m25_01_cumulative_work_count.png)
2. [総経過時間と実行済み累積仕事](figures/m25_02_cumulative_work_time.png)
3. [抽出回数と累積時間率](figures/m25_03_cumulative_rate_count.png)
4. [各回の正味仕事と抽出間隔](figures/m25_04_cycle_work_intervals.png)
5. [負荷エネルギー・受動エネルギー・エルゴトロピーの時間発展](figures/m25_05_load_trajectories.png)
6. [抽出前後の交換コヒーレンス](figures/m25_06_exchange_pre_post.png)
7. [見送り閾値と終了時の実績](figures/m25_07_threshold_comparison.png)
8. [抽出後の共通窓での最大回収余地](figures/m25_08_future_work.png)
