"""Independently audit M25 repeated extraction ledgers and physical state handoffs."""

import argparse
from collections import defaultdict
import csv
from dataclasses import dataclass
from functools import cached_property
import hashlib
import io
from itertools import groupby
import math
import os
from pathlib import Path, PurePosixPath
import sys
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
M23 = ROOT.parent / "Milestone_23"
M24 = ROOT.parent / "Milestone_24"
TOL = 1e-12
HALF_TOL = 1e-10
GRID = 20
HORIZON = 18_000
CAP = 540_000
ORIGINS = {"S0", "A04", "B04", "C04"}
POLICIES = {"A", "B", "C25", "C", "D", "E", "F"}
STAGES = (10, 20, 30)
FIXED_DELAY = 16_340
DIAGNOSTIC_COUNTS = {1, 5, 10, 20, 30}
ONLINE = {"A", "B", "C25", "C"}
FIXED_TIMES = (25, 50, 100, 150, 250, 360, 500, 540)

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
sys.path.insert(0, str(M24))
sys.path.insert(0, str(M23))

import numpy as np

from m21_observables import DIM, HEADER, LOAD_DIM, LOAD_LEVELS, OCCUPATION, Observables

G = 0.25


def insist(condition, context):
    if not condition:
        raise ValueError(context)


def read_rows(path):
    with path.open(encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))


def read_unique(rows, make_key):
    result = {}
    for row in rows:
        key = make_key(row)
        insist(key not in result, f"Duplicate row key {key!r}")
        result[key] = row
    return result


def number(row, field):
    value = float(row[field])
    if not math.isfinite(value):
        raise ValueError(f"Non-finite {field}: {row}")
    return value


def ticks(row, field):
    value = number(row, field)
    rounded = round(value * 1000)
    if abs(value - rounded / 1000) > TOL:
        raise ValueError(f"Off-lattice {field}: {row}")
    return rounded


def flag(row, field):
    value = row[field].casefold()
    if value not in {"true", "false"}:
        raise ValueError(f"Invalid flag {field}: {row}")
    return value == "true"


def close(actual, expected, context, limit=TOL):
    if not abs(actual - expected) <= limit:
        raise ValueError(f"{context}: {actual!r} != {expected!r} within {limit:g}")


def safe_path(root, path):
    name = PurePosixPath(path)
    insist(name.parts and not name.is_absolute() and ".." not in name.parts and "\\" not in path and ":" not in path,
           f"Invalid relative file path {path!r}")
    return root.joinpath(*name.parts)


def file_hash(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest().upper()


def archive_rows(archive, directory, filename):
    data = archive.read(f"Milestone_23/{filename}")
    insist(data == safe_path(directory, filename).read_bytes(), f"Archive and local M23 tables differ for {filename}")
    return list(csv.DictReader(io.StringIO(data.decode("utf-8-sig"), newline="")))


def state_file(directory, name, expected_sha, clock):
    data = safe_path(directory, name).read_bytes()
    digest = hashlib.sha256(data).hexdigest().upper()
    insist(digest == expected_sha.upper(), f"State checksum differs for {name}")
    insist(len(data) == HEADER.size + DIM * DIM * 16, f"Wrong state byte count for {name}")
    magic, dimension, actual_time = HEADER.unpack_from(data)
    insist((magic, dimension) == (b"QWNRHO1\0", DIM), f"Wrong state header for {name}")
    close(actual_time, clock / 1000, f"Wrong state clock for {name}")
    matrix = np.frombuffer(data, dtype="<c16", offset=HEADER.size).reshape(DIM, DIM)
    insist(np.isfinite(matrix).all(), f"Non-finite state in {name}")
    return State(matrix, actual_time, digest)


def maxabs(matrix):
    return float(np.max(np.abs(matrix)))


@dataclass(frozen=True)
class State:
    matrix: np.ndarray
    time: float
    sha256: str = ""

    @cached_property
    def eigenvalues(self):
        return np.linalg.eigvalsh((self.matrix + self.matrix.conj().T) / 2)


def terminal_state(matrix):
    local_dim = 2 * LOAD_DIM
    blocks = matrix.reshape(DIM // local_dim, local_dim, DIM // local_dim, local_dim)
    return np.trace(blocks, axis1=0, axis2=2)


def reduced_load(terminal):
    return terminal[:LOAD_DIM, :LOAD_DIM] + terminal[LOAD_DIM:, LOAD_DIM:]


class ExactModel:
    """Use direct full Hamiltonian exponentiation, independent of the projected RK4 steps."""

    def __init__(self):
        obs = Observables()
        self.h = {g: obs.hamiltonian(g)[0] for g in (0.0, G)}
        self.eigensystems = {g: np.linalg.eigh(matrix) for g, matrix in self.h.items()}
        self.exchange = obs.terminal_exchange

    def evolve(self, state, g, elapsed):
        if elapsed == 0:
            return state
        values, vectors = self.eigensystems[g]
        unitary = (vectors * np.exp(-1j * values * elapsed)) @ vectors.T
        return State(unitary @ state.matrix @ unitary.conj().T, state.time + elapsed)

    def energy(self, state, g=G):
        return float(np.einsum("ij,ji->", self.h[g], state.matrix).real)

    def exchange_expectation(self, state):
        return float(np.einsum("ij,ji->", self.exchange, terminal_state(state.matrix)).real)


def physical_state(state, context):
    close(abs(np.trace(state.matrix) - 1), 0.0, f"State trace for {context}")
    close(maxabs(state.matrix - state.matrix.conj().T), 0.0, f"State Hermiticity for {context}")
    insist(state.eigenvalues[0] >= -TOL, f"Negative density eigenvalue for {context}: {state.eigenvalues[0]}")


def dynamics_step(model, start, tau, connected):
    waited = model.evolve(start, 0.0, tau / 1000)
    before = model.evolve(waited, G, connected / 1000)
    cut = -G * model.exchange_expectation(start) if tau else 0.0
    reconnect = G * model.exchange_expectation(waited) if tau else 0.0
    load = reduced_load(terminal_state(before.matrix))
    values, vectors = np.linalg.eigh(load)
    insist(np.min(np.diff(values)) > TOL, "Degenerate reduced load at extraction")
    largest_pivot = [max(range(LOAD_DIM), key=lambda i: (abs(column[i]), i)) for column in vectors.T]
    phases = vectors[largest_pivot, range(LOAD_DIM)]
    unitary = np.kron(np.eye(DIM // LOAD_DIM), (vectors * (phases.conj() / np.abs(phases))).conj().T[::-1, :])
    after = State(unitary @ before.matrix @ unitary.conj().T, before.time)
    return waited, before, after, cut, reconnect


def published_inputs(m23, m24):
    m24_sources = read_unique((row for row in read_rows(m24 / "results" / "m24_sources.csv") if row["origin"] in ORIGINS),
                              lambda row: row["origin"])
    insist(m24_sources.keys() == ORIGINS, "M24 origin coverage differs from M25")
    zip_path = m23 / "M23_all_results.zip"
    expected_zip = (m23 / "M23_all_results.sha256").read_text(encoding="utf-8-sig").split()[0]
    insist(file_hash(zip_path) == expected_zip.upper(), "M23 published ZIP checksum differs")
    histories = read_unique(read_rows(m23 / "repeat" / "m23_repeated.csv"),
                            lambda row: (row["strategy"], int(row["cycle"])))
    states = {}
    with ZipFile(zip_path) as archive:
        table = archive_rows(archive, m23, "repeat/m23_repeated.csv")
        insist(list(histories.values()) == table, "M23 repeat order is inconsistent")
        single = read_unique(archive_rows(archive, m23, "m23_sources.csv"), lambda row: row["source"])
        after_states = read_unique(
            (row for row in archive_rows(archive, m23, "repeat/m23_state_manifest.csv") if row["phase"] == "after"),
            lambda row: (row["scan"], int(row["cycle"]), row["resolution"]),
        )
        for origin, source in m24_sources.items():
            for resolution in ("coarse", "half"):
                name = source[f"{resolution}_path"]
                clock = ticks(source, "source_time")
                sha256 = source[f"{resolution}_sha256"]
                if origin == "S0":
                    archived = single[origin]
                    expected = archived["filename"], ticks(archived, "source_time"), archived["sha256"]
                else:
                    cycle = int(origin[1:])
                    history = histories[origin[0], cycle]
                    insist(flag(history, "accepted"), f"M23 origin {origin} is not an accepted extraction")
                    archived = after_states[history["scan"], cycle, resolution]
                    expected = f"repeat/{archived['filename']}", ticks(archived, "time"), archived["sha256"]
                insist((name, clock, sha256) == expected, f"M24 {origin}/{resolution} identifies the wrong M23 state")
                insist(hashlib.sha256(archive.read(f"Milestone_23/{name}")).hexdigest().upper() == sha256,
                       f"M24 {origin}/{resolution} archive fingerprint differs")
                states[origin, resolution] = state_file(m23, name, sha256, clock)
    fixed = read_unique(read_rows(m24 / "results" / "m24_fixed_delay.csv"), lambda row: ticks(row, "tau"))
    insist(ticks(fixed[0], "elapsed_connected") == 16_340 and fixed[0]["training_origins"].split() == ["S0", "S1", "S2"],
           "M24 fixed-delay constant or reference set changed")
    return m24_sources, states, histories


def check_m23_parity(branches, published, limit=8):
    for current, previous in (("E", "C"), ("F", "A")):
        accepted = [row for row in branches["S0", current] if flag(row, "accepted")]
        insist(len(accepted) >= limit, f"S0/{current} has fewer than {limit} archived comparable events")
        for number_in_branch, row in enumerate(accepted[:limit], 1):
            reference = published[previous, number_in_branch + 2]
            context = f"S0/{current}/{number_in_branch} vs M23 {previous}"
            insist(flag(reference, "accepted"), f"Archived extraction was unaccepted for {context}")
            for present, historical in (("tau", "tau"), ("duration", "elapsed_total"), ("elapsed_total", "elapsed_since_anchor")):
                insist(ticks(row, present) == ticks(reference, historical), f"Timing differs for {context}/{present}")
            for field in ("net_work", "cumulative_net"):
                close(number(row, field), number(reference, field), f"Work differs for {context}/{field}")


def expected_online(samples, count, policy, threshold):
    """Independent replay of the first causal decision on the recorded prefix."""
    previous_rate = number(samples[0], "load_ergotropy_rate")
    skipped = []
    for step, row in enumerate(samples[1:], 1):
        rate = number(row, "load_ergotropy_rate")
        resolved = number(row, "load_ergotropy") > TOL
        if resolved and policy == "A" and 0 < rate < previous_rate:
            intervals = rate / (previous_rate - rate)
            target = step + max(1, math.floor(intervals + 0.5))
            if intervals <= 5 and target < count:
                return target, step, "forecast", tuple(skipped)
        if resolved and policy in {"B", "C25", "C"} and previous_rate > 0 >= rate:
            if number(row, "total_work") >= threshold:
                return step, step, "turn", tuple(skipped)
            skipped.append(step)
        if step == count - 1:
            return step, step, "horizon", tuple(skipped)
        previous_rate = rate
    raise ValueError(f"No {policy} decision found in stored prefix")


def check_suffix_sentinels():
    from m25_control import online_stop

    def guarded_samples(rates, works):
        for rate, work in zip(rates, works, strict=True):
            yield {"load_ergotropy_rate": rate, "load_ergotropy": 1.0, "load_current": 1.0, "total_work": work}
        raise ValueError("Online policy consumed an observation after its extraction")

    cases = (
        ("A", 0.0, (10, 8, -3, 5, 6, 7), (0, 1, 2, 3, 4, 5), (5, 1, "forecast", ())),
        ("B", 0.0, (2, -1), (0, 0.5), (1, 1, "turn", ())),
        ("C25", 1.0, (2, -1, 3, -3), (0, 0.5, 0.6, 1.5), (3, 3, "turn", (1,))),
        ("C", 1.0, (2, -1, 3, -3), (0, 0.5, 0.6, 1.5), (3, 3, "turn", (1,))),
    )
    for policy, threshold, rates, works, expected in cases:
        stop = online_stop(guarded_samples(rates, works), 9, policy, threshold)
        insist((stop.index, stop.decided, stop.reason, stop.skipped) == expected,
               f"Unexpected decision in suffix sentinel for policy {policy}")


def exact_metrics(model, state):
    terminal = terminal_state(state.matrix)
    load = reduced_load(terminal)
    energy = float(LOAD_LEVELS @ np.diag(load).real)
    passive = float(LOAD_LEVELS @ np.linalg.eigvalsh(load)[::-1])
    coherence = terminal[1, 3] + math.sqrt(2) * terminal[2, 4]
    return {
        "global_energy": model.energy(state),
        "bare_total_energy": model.energy(state, 0.0),
        "bare_chain_energy": model.energy(state, 0.0) - energy,
        "load_energy": energy,
        "load_passive_energy": passive,
        "load_ergotropy": energy - passive,
        "exchange_energy": 2 * G * coherence.real,
        "c_real": coherence.real,
        "c_imag": coherence.imag,
        "c_abs": abs(coherence),
        "load_current": -2 * G * coherence.imag,
        "total_excitation": float(OCCUPATION @ np.diag(state.matrix).real),
    }


def check_state_fields(row, prefix, expected, context):
    for field, target in expected.items():
        reported = f"{prefix}_{field}"
        if reported in row:
            tolerance = TOL if field == "global_energy" else HALF_TOL
            close(number(row, reported), target, f"Exact replay {reported} for {context}", tolerance)
    if f"{prefix}_c_phase" not in row:
        return
    real, imag, magnitude = (number(row, f"{prefix}_c_{key}") for key in ("real", "imag", "abs"))
    close(magnitude, math.hypot(real, imag), f"Coherence amplitude for {context}/{prefix}")
    phase = row[f"{prefix}_c_phase"]
    if magnitude <= TOL:
        insist(not phase, f"Unresolved coherence has a phase for {context}/{prefix}")
    else:
        close(math.remainder(float(phase) - math.atan2(imag, real), 2 * math.pi), 0, f"Coherence phase for {context}/{prefix}")


def exact_ledger(model, row, state, context):
    tau = ticks(row, "tau")
    duration = ticks(row, "duration")
    waiting, before, after, cut, reconnect = dynamics_step(model, state, tau, duration - tau)
    accepted = flag(row, "accepted")
    committed = after if accepted else before
    exact_net = model.energy(state) - model.energy(after)
    checks = {
        "net_work": exact_net if accepted else 0.0,
        "cut_on": cut,
        "reconnect_on": reconnect,
        "direct_net": exact_net,
        "balance_residual": 0.0,
        "cumulative_balance_residual": 0.0,
    }
    for field, target in checks.items():
        if field in row:
            close(number(row, field), target, f"Exact {field} for {context}")
    for prefix, snapshot in (("start", state), ("reconnect", waiting), ("pre", before), ("post", committed)):
        if f"{prefix}_global_energy" in row:
            check_state_fields(row, prefix, exact_metrics(model, snapshot), context)
    return committed, exact_metrics(model, waiting)


def matrix_fingerprint(matrix):
    return hashlib.sha256(np.asarray(matrix, dtype="<c16", order="C").tobytes()).hexdigest()


def branch_key(row):
    return row["origin"], row["policy"]


def attempt_key(row):
    return (*branch_key(row), int(row["attempt"]))


def table_paths(root, name, staged):
    return sorted(root.glob(f"*/*/{name}.csv")) if staged else [root / f"{name}.csv"]


def table_rows(root, name, staged):
    for path in table_paths(root, name, staged):
        yield from read_rows(path)


def check_future_selected(model, row, recovered, context):
    elapsed = ticks(row, "elapsed_connected")
    insist(0 <= elapsed <= HORIZON and elapsed % GRID == 0 and int(row["candidate_count"]) == HORIZON // GRID + 1,
           f"Incorrect future-work diagnostic window for {context}")
    _, _, after, _, _ = dynamics_step(model, recovered, 0, elapsed)
    exact_net = model.energy(recovered) - model.energy(after)
    coarse, half = (number(row, name) for name in ("max_net", "max_net_half"))
    direct, direct_half = (number(row, name) for name in ("direct_max_net", "direct_max_net_half"))
    error = abs(coarse - half)
    for value in (coarse, direct):
        close(value, exact_net, f"Independent selected diagnostic work for {context}")
    close(direct_half, half, f"Direct half diagnostic work for {context}")
    close(number(row, "step_error"), error, f"Diagnostic half-step difference for {context}")
    insist(error <= number(row, "max_grid_step_error") <= HALF_TOL,
           f"Unresolved diagnostic convergence for {context}")
    for field in ("max_direct_residual", "max_balance_residual"):
        insist(0 <= number(row, field) <= TOL, f"Unresolved diagnostic {field} for {context}")
    accepted = coarse - error > TOL and direct > TOL
    insist(flag(row, "accepted") == accepted, f"Incorrect diagnostic acceptance for {context}")
    close(number(row, "diagnostic_work"), direct if accepted else 0, f"Credited diagnostic work for {context}")


def audit_history(data, sources, states, benchmark, rounds):
    model = ExactModel()
    attempts = read_unique(table_rows(data, "m25_history", benchmark), attempt_key)
    future = read_unique(table_rows(data, "m25_future", benchmark), attempt_key)
    branches = defaultdict(list)
    for key in sorted(attempts):
        branches[key[:2]].append(attempts[key])
    expected_origins = {"S0"} if benchmark else ORIGINS
    expected_count = rounds
    insist(branches.keys() == {(origin, policy) for origin in expected_origins for policy in POLICIES}, "Wrong history coverage")
    checked_future = set()
    reconnect_witnesses = {}
    for (origin, policy), rows in branches.items():
        exact_state = states[origin, "coarse"]
        origin_energy = model.energy(exact_state)
        origin_passive = float(model.eigensystems[G][0] @ exact_state.eigenvalues[::-1])
        origin_purity = float(np.vdot(exact_state.matrix, exact_state.matrix).real)
        history_hashes = {name: matrix_fingerprint(states[origin, name].matrix) for name in ("coarse", "half")}
        count = elapsed = 0
        credited = previous = 0.0
        insist(1 <= len(rows) <= expected_count + 1, f"Unexpected attempt count for {origin}/{policy}")
        for attempt, row in enumerate(rows, 1):
            context = (origin, policy, attempt)
            insist(int(row["attempt"]) == attempt, f"Missing or out-of-sequence attempt {context}")
            tau, connected, duration, window, end = (ticks(row, column) for column in (
                "tau", "elapsed_connected", "duration", "window", "elapsed_total"))
            insist(elapsed == ticks(row, "elapsed_start") and window == min(HORIZON, CAP-elapsed),
                   f"Incorrect epoch start or horizon for {context}")
            insist(0 <= tau <= 6250 and (tau == 0 or policy == "E") and connected >= 0 and connected % GRID == 0
                   and duration == tau + connected and 0 < duration <= window and end == elapsed + duration,
                   f"Incorrect continuous timing for {context}")
            insist(ticks(row, "absolute_time") == ticks(sources[origin], "source_time") + end, f"Incorrect absolute clock for {context}")
            if policy == "D":
                insist(duration == FIXED_DELAY and row["stop_reason"] == "fixed" and ticks(row, "decision_elapsed_total") == elapsed,
                       f"Incorrect M24 fixed delay for {context}")
            if policy in {"E", "F"}:
                insist(row["stop_reason"] == "retrospective" and row["decision_elapsed_total"] == "",
                       f"Retrospective control claims a causal decision for {context}")

            threshold = max(TOL, {"C25": 0.25, "C": 0.50}.get(policy, 0.0)*previous)
            close(number(row, "threshold"), threshold, f"Online threshold for {context}", 1e-16)
            close(number(row, "previous_accepted_net"), previous, f"Previous accepted event work for {context}", 1e-16)
            coarse, half = (number(row, field) for field in ("candidate_net", "candidate_net_half"))
            direct, direct_half = (number(row, field) for field in ("direct_net", "direct_net_half"))
            margin = coarse - abs(coarse - half)
            close(number(row, "resolution_margin"), margin, f"Coarse/half resolution margin for {context}")
            close(direct, coarse, f"Coarse work vs direct for {context}")
            close(direct_half, half, f"Half work vs direct for {context}")
            accepted = margin > TOL and direct > TOL and coarse >= threshold
            insist(flag(row, "accepted") == accepted and (accepted or attempt == len(rows)), f"Incorrect gate or continued rejection for {context}")
            expected_outcome = "extracted" if accepted else "threshold_at_horizon" if policy in {"C25", "C"} and coarse < threshold else "unresolved_candidate"
            insist(row["outcome"] == expected_outcome, f"Incorrect outcome for {context}")
            half_duration = ticks(row, "half_replay_duration")
            insist(tau <= half_duration <= window and (half_duration-tau) % GRID == 0, f"Nonlattice half replay for {context}")
            for field in ("max_grid_step_error", "half_state_max_error"):
                insist(0 <= number(row, field) <= HALF_TOL, f"Nonconvergence for {context}/{field}")
            for field in ("max_half_physicality_error", "accepted_energy_residual", "global_passive_unitary_drift",
                          "bare_chain_unitary_drift", "balance_residual", "waiting_energy_drift", "connected_energy_drift"):
                close(number(row, field), 0, f"Physics residual for {context}/{field}")
            for field in ("cut_linear_residual", "reconnect_linear_residual"):
                close(number(row, field), 0, f"Switch residual for {context}/{field}", 1e-15)

            value = direct if accepted else 0.0
            count += int(accepted)
            credited += value
            close(number(row, "net_work"), value, f"Credited operation for {context}")
            close(number(row, "cumulative_net"), credited, f"Cumulative work for {context}")
            close(number(row, "cumulative_rate"), credited / (end / 1000), f"Actual-time rate for {context}")
            insist(int(row["count"]) == count <= expected_count, f"Incorrect accepted count for {context}")
            close(number(row, "post_global_energy") + credited, origin_energy, f"Cumulative closed-system energy for {context}")
            for resolution, prior in history_hashes.items():
                insist(row[f"start_{resolution}_sha256"] == prior, f"State handoff hash differs for {context}/{resolution}")
                history_hashes[resolution] = row[f"post_{resolution}_sha256"]
                if not accepted:
                    insist(history_hashes[resolution] == row[f"pre_{resolution}_sha256"],
                           f"Rejected extraction modified state for {context}/{resolution}")
            for phase in ("pre", "post"):
                insist(0 <= number(row, f"{phase}_trace_error") <= TOL and 0 <= number(row, f"{phase}_hermiticity_error") <= TOL
                       and number(row, f"{phase}_minimum_eigenvalue") >= -TOL, f"Nonphysical reported density for {context}/{phase}")
                close(number(row, f"{phase}_load_energy")-number(row, f"{phase}_load_passive_energy"),
                      number(row, f"{phase}_load_ergotropy"), f"Load ergotropy identity for {context}/{phase}")
                close(number(row, f"{phase}_global_energy"), number(row, f"{phase}_bare_total_energy") + number(row, f"{phase}_exchange_energy"),
                      f"Connected energy decomposition for {context}/{phase}")
                close(number(row, f"{phase}_load_current"), -2*G*number(row, f"{phase}_c_imag"), f"Current coherence identity for {context}/{phase}")
                global_ergotropy = number(row, f"{phase}_global_ergotropy")
                close(number(row, f"{phase}_global_energy")-number(row, f"{phase}_global_passive_energy"), global_ergotropy,
                      f"Full ergotropy decomposition for {context}/{phase}")
                close(number(row, f"{phase}_global_passive_energy"), origin_passive, f"Unitary spectrum energy for {context}/{phase}")
                close(number(row, f"{phase}_global_purity"), origin_purity, f"Unitary density purity for {context}/{phase}")
                insist(-TOL <= number(row, f"{phase}_sector_ergotropy") <= global_ergotropy+TOL,
                       f"Sector restriction bound for {context}/{phase}")
            bare_work = number(row, "pre_load_ergotropy")
            close(coarse, bare_work-number(row, "interaction_jump")-number(row, "cut_on")-number(row, "reconnect_on"),
                  f"Switch-inclusive work decomposition for {context}")
            if accepted:
                close(number(row, "post_load_ergotropy"), 0, f"Local passivity after accepted extraction for {context}")
                close(number(row, "pre_total_excitation")-number(row, "post_total_excitation"), bare_work,
                      f"Excitation removed by local passivation for {context}")
                previous = value

            exact_state, reconnect_witnesses[context] = exact_ledger(model, row, exact_state, context)
            if accepted and count in DIAGNOSTIC_COUNTS:
                diagnostic = future[context]
                insist(int(diagnostic["count"]) == count and ticks(diagnostic, "elapsed_total") == end,
                       f"Future-work diagnostic references the wrong extraction for {context}")
                check_future_selected(model, diagnostic, exact_state, context)
                checked_future.add(context)
            elapsed = end
    insist(checked_future == future.keys(), "Unexpected or missing future-work records")
    return attempts, branches, future, reconnect_witnesses


def check_trace(rows, attempt, reconnect_witness):
    key = attempt_key(attempt)
    start, tau, connected, end, window = (ticks(attempt, label) for label in (
        "elapsed_start", "tau", "elapsed_connected", "elapsed_total", "window"))
    expected_connected = connected // GRID + 1
    expected_wait = len(range(0, tau, GRID))
    approved = flag(attempt, "accepted")
    expected_phases = ["wait"]*expected_wait + ["connected"]*expected_connected + ["post"]*int(approved)
    insist([row["phase"] for row in rows] == expected_phases, f"Trace omits states or inspects extra observations after stopping for {key}")
    insist(all(row["count"] == attempt["count"] for row in rows), f"Trace count mismatch for {key}")
    switches = number(attempt, "cut_on") + number(attempt, "reconnect_on")
    waiting = rows[:expected_wait]
    states = rows[expected_wait:expected_wait + expected_connected]
    for field in ("load_energy", "load_passive_energy", "load_ergotropy", "load_current", "c_real", "c_imag", "c_abs"):
        close(number(states[0], field), reconnect_witness[field], f"Independent reconnect {field} for {key}", HALF_TOL)
    for i, row in enumerate(waiting):
        insist(ticks(row, "elapsed_total") == start+i*GRID and row["index"] == ""
               and row["net_work_if_extracted"] == "" and not flag(row, "signal_skipped"), f"Invalid disconnected row for {key}/{i}")
        for field in ("load_energy", "load_passive_energy", "load_ergotropy"):
            close(number(row, field), number(states[0], field), f"Wait preserves {field} for {key}/{i}")
    for i, row in enumerate(states):
        insist(int(row["index"]) == i and ticks(row, "elapsed_total") == start+tau+i*GRID, f"Connected clock mismatch for {key}/{i}")
        close(number(row, "load_energy")-number(row, "load_passive_energy"), number(row, "load_ergotropy"),
              f"Separated load energy for {key}/{i}")
        current = number(row, "load_current")
        close(current, -2*G*number(row, "c_imag"), f"Current identity for {key}/{i}")
        close(current-number(row, "load_passive_energy_rate"), number(row, "load_ergotropy_rate"),
              f"Ergotropy derivative for {key}/{i}")
        close(number(row, "net_work_if_extracted"), number(row, "total_work")-switches,
              f"Connected hypothetical work for {key}/{i}")
    close(number(states[-1], "net_work_if_extracted"), number(attempt, "candidate_net"), f"Final predecision candidate for {key}")
    metadata = [("pre", states[-1])]
    if approved:
        metadata.append(("post", rows[-1]))
    for phase, snapshot in metadata:
        for field in ("load_energy", "load_passive_energy", "load_ergotropy", "load_current", "c_real", "c_imag", "c_abs"):
            close(number(snapshot, field), number(attempt, f"{phase}_{field}"), f"Trace joins ledger for {key}/{phase}/{field}")
    if approved:
        insist(ticks(rows[-1], "elapsed_total") == end and int(rows[-1]["index"]) == expected_connected-1,
               f"Post-extraction trace time for {key}")
    skipped = tuple(i for i, row in enumerate(states) if flag(row, "signal_skipped"))
    if key[1] in ONLINE:
        reported = (expected_connected-1, (ticks(attempt, "decision_elapsed_total")-start-tau)//GRID,
                    attempt["stop_reason"], skipped)
        expected = expected_online(states, (window-tau)//GRID+1, key[1], number(attempt, "threshold"))
        insist(reported == expected, f"Causal replay differs for {key}: {reported} != {expected}")
        insist(ticks(attempt, "decision_elapsed_total") == start+tau+expected[1]*GRID and int(attempt["skipped_peaks"]) == len(skipped),
               f"Decision time or skipped count for {key}")
    else:
        insist(not skipped and int(attempt["skipped_peaks"]) == 0, f"Non-online branch reports skipped signals for {key}")
    return len(rows)


def audit_traces(data, attempts, reconnect_witnesses, benchmark):
    found = set()
    total = 0
    for path in table_paths(data, "m25_trajectories", benchmark):
        with path.open(encoding="utf-8-sig", newline="") as file:
            for key, records in groupby(csv.DictReader(file), attempt_key):
                insist(key in attempts and key not in found, f"Unexpected, duplicate, or out-of-order trajectory key {key}")
                total += check_trace(list(records), attempts[key], reconnect_witnesses[key])
                found.add(key)
    insist(found == attempts.keys(), "A history row is missing the trajectory")
    return total


def audit_search(data, attempts, future, benchmark):
    groups = defaultdict(list)
    for row in table_rows(data, "m25_search", benchmark):
        groups[attempt_key(row)].append(row)
    insist(groups.keys() == {key for key in attempts if key[1] in {"E", "F"}}, "Retrospective search coverage differs from E/F")
    count = 0
    for key, rows in groups.items():
        count += len(rows)
        attempt = attempts[key]
        window = ticks(attempt, "window")
        pairs = read_unique(rows, lambda row: (row["stage"], ticks(row, "tau")))
        coarse = {tau: row for (stage, tau), row in pairs.items() if stage == "A"}
        fine = {tau: row for (stage, tau), row in pairs.items() if stage == "C"}
        insist(len(coarse) + len(fine) == len(rows), f"Unknown wait-refinement stage for {key}")
        expected_taus = {0} if key[1] == "F" else set(range(0, min(6000, window)+1, 250))
        insist(coarse.keys() == expected_taus, f"Wrong coarse candidate waits for {key}")
        if key[1] == "F":
            insist(not fine and not flag(coarse[0], "refinement_center"), f"F may only scan a connected branch for {key}")
        else:
            tau_list = sorted(coarse)
            values = [number(coarse[tau], "max_net") for tau in tau_list]
            local = sorted((-value, tau_list[i]) for i, value in enumerate(values)
                           if (i == 0 or values[i-1] < value) and (i == len(values)-1 or value >= values[i+1]))[:3]
            centers = {tau for _, tau in local}
            insist({tau for tau, row in coarse.items() if flag(row, "refinement_center")} == centers
                   and all(not flag(row, "refinement_center") for row in fine.values()), f"Wrong refinement margins for {key}")
            extends = any(tau > 6000 for tau in fine)
            if 6000 in centers and window > 6000:
                difference = values[-1]-values[-2]
                if difference > TOL+2*HALF_TOL and window >= 6025:
                    insist(extends, f"Resolved maximum at wait upper endpoint failed to extend for {key}")
                if difference <= TOL:
                    insist(not extends, f"Unresolved endpoint extended wait range for {key}")
            expected_fine = {tau for _, center in local for tau in range(max(0, center-250),
                min(window, 6250 if center == 6000 and extends else 6000, center+250)+1, 25)}
            insist(fine.keys() == expected_fine, f"Incorrect fine lattice for {key}")
        for (_, tau), row in pairs.items():
            time = ticks(row, "elapsed_connected")
            insist(time >= 0 and time%GRID == 0 and ticks(row, "elapsed_total") == tau+time
                   and 0 < tau+time <= window and int(row["candidate_count"]) == (window-tau)//GRID+1-int(tau==0),
                   f"Incorrect candidate time grid for {key}/{row['stage']}/{tau}")
        winner = min(rows, key=lambda row: (-number(row, "max_net"), ticks(row, "elapsed_total"), ticks(row, "tau")))
        insist([row for row in rows if flag(row, "selected")] == [winner], f"Wrong retrospective winner for {key}")
        insist(ticks(winner, "tau") == ticks(attempt, "tau") and ticks(winner, "elapsed_total") == ticks(attempt, "duration"),
               f"Retrospective winner is not the performed candidate for {key}")
        close(number(winner, "max_net"), number(attempt, "candidate_net"), f"Retrospective work for {key}")
        previous = (*key[:2], key[2]-1)
        if key[1] == "F" and previous in future and window == HORIZON:
            prior = future[previous]
            insist(ticks(prior, "elapsed_connected") == ticks(winner, "elapsed_connected"), f"F disagrees with matching prior diagnostic for {key}")
            close(number(winner, "max_net"), number(prior, "max_net"), f"Matching F diagnostic score for {key}")
    return count


def accepted_series(branches):
    return {key: [row for row in rows if flag(row, "accepted")] for key, rows in branches.items()}


def stage_rank(row):
    return (*branch_key(row), int(row["rounds_target"]))


def audit_stages(data, branch_histories, states, stage_root, benchmark, rounds):
    model = ExactModel()
    stages = (2,) if benchmark else tuple(target for target in STAGES if target <= rounds)
    runtime = read_unique(table_rows(data, "m25_stage_runtime", benchmark), stage_rank)
    insisting_keys = {(*key, target) for key in branch_histories for target in stages}
    insist(runtime.keys() == insisting_keys, "Staged runtime coverage differs from registered starts and count caps")
    series = accepted_series(branch_histories)
    for (origin, policy), history in branch_histories.items():
        prior_attempt = 0
        for target in stages:
            context = (origin, policy, target)
            attempts = len(history) if len(series[origin, policy]) < target else int(series[origin, policy][target-1]["attempt"])
            row = history[attempts-1]
            count, elapsed = int(row["count"]), ticks(row, "elapsed_total")
            work = number(row, "cumulative_net")
            previous = number(series[origin, policy][count-1], "net_work") if count else 0.0
            if count == target:
                ending = "count_cap"
            elif not flag(row, "accepted"):
                ending = row["outcome"]
            else:
                insist(CAP-elapsed < (FIXED_DELAY if policy == "D" else GRID), f"Insufficient rows for open branch {context}")
                ending = "time_cap"
            status = runtime[context]
            insist((int(status["count"]), ticks(status, "elapsed_total"), int(status["attempts_total"]),
                    int(status["attempts_in_stage"]), status["ending"]) == (count, elapsed, attempts, attempts-prior_attempt, ending),
                   f"Stage runtime bookkeeping differs for {context}")
            close(number(status, "cumulative_net"), work, f"Stage cumulative work for {context}")
            insist(number(status, "seconds") > 0, f"Invalid measured runtime for {context}")

            folder = (data if benchmark else stage_root / f"n{target}") / origin / policy
            local, = read_rows(folder / "m25_stage_runtime.csv")
            insist(local == status, f"Merged runtime row differs from staged output for {context}")
            history_file = folder / "m25_history.csv"
            local_history = read_rows(history_file) if history_file.is_file() else []
            insist(local_history == history[prior_attempt:attempts], f"Merged attempts differ from staged output for {context}")
            with np.load(folder / "checkpoint.npz", allow_pickle=False) as checkpoint:
                insist(set(checkpoint.files) == {"coarse", "half", "counters", "work", "ending"}, f"Incorrect checkpoint entries for {context}")
                insist(tuple(checkpoint["counters"]) == (elapsed, count, attempts) and checkpoint["ending"].item() == ending,
                       f"Checkpoint clock, counters or ending differ for {context}")
                actual_work, actual_previous = map(float, checkpoint["work"])
                close(actual_work, work, f"Checkpoint cumulative work for {context}")
                close(actual_previous, previous, f"Checkpoint previous accepted work for {context}")
                matrices = {resolution: checkpoint[resolution] for resolution in ("coarse", "half")}
                for resolution, matrix in matrices.items():
                    insist(matrix.shape == (DIM, DIM) and np.isfinite(matrix).all(), f"Invalid saved density for {context}/{resolution}")
                    insist(matrix_fingerprint(matrix) == row[f"post_{resolution}_sha256"], f"Checkpoint density fingerprint differs for {context}/{resolution}")
                    snapshot = State(matrix, number(row, "absolute_time"))
                    physical_state(snapshot, (context, resolution))
                    initial_energy = model.energy(states[origin, resolution])
                    close(model.energy(snapshot) + work, initial_energy, f"Checkpoint energy closure for {context}/{resolution}")
                diff = maxabs(matrices["coarse"]-matrices["half"])
                close(diff, number(row, "half_state_max_error"), f"Checkpoint observed integration difference for {context}")
            prior_attempt = attempts
    return runtime


def audit_comparisons(data, sources, branches, runtime, rounds):
    supplied = read_unique(read_rows(data / "m25_sources.csv"), lambda row: row["origin"])
    insist(supplied == sources, "M25 sources differ from the verified M24 references")
    series = accepted_series(branches)
    count_rows = read_unique(read_rows(data / "m25_count_comparison.csv"), lambda r: (*branch_key(r), int(r["target_count"])))
    expected_count = {(*key, count) for key in branches for count in range(1, rounds+1)}
    insist(count_rows.keys() == expected_count, "Same-count table coverage differs from the ledger")
    for (origin, policy, target), row in count_rows.items():
        caught = series[origin, policy]
        reached = len(caught) >= target
        insist(flag(row, "reached") == reached, f"Incorrect reached flag for {(origin, policy, target)}")
        for field in ("elapsed_total", "cumulative_net", "cumulative_rate"):
            if reached:
                close(number(row, field), number(caught[target-1], field), f"Same-count data for {(origin, policy, target)}/{field}")
            else:
                insist(row[field] == "", f"Unreached count has a value for {(origin, policy, target)}/{field}")

    time_rows = read_unique(read_rows(data / "m25_time_comparison.csv"), lambda r: (*branch_key(r), r["time_label"]))
    expected_times = {}
    for origin in ORIGINS:
        times = {f"t{clock}": clock*1000 for clock in FIXED_TIMES}
        for count in (stage for stage in STAGES if stage <= rounds):
            reached = [ticks(series[origin, policy][count-1], "elapsed_total") for policy in POLICIES
                       if len(series[origin, policy]) >= count]
            if reached:
                times[f"first_{count}"] = min(reached)
                if len(reached) == len(POLICIES):
                    times[f"all_{count}"] = max(reached)
        for policy in POLICIES:
            for label, clock in times.items():
                expected_times[origin, policy, label] = clock
    insist(time_rows.keys() == expected_times.keys(), "Same-time table coverage differs from registered deadlines")
    for (origin, policy, label), clock in expected_times.items():
        row = time_rows[origin, policy, label]
        completed = [event for event in series[origin, policy] if ticks(event, "elapsed_total") <= clock]
        work = math.fsum(number(event, "net_work") for event in completed)
        insist(ticks(row, "elapsed_total") == clock and int(row["count"]) == len(completed), f"Wrong actual-time placement for {(origin, policy, label)}")
        close(number(row, "cumulative_net"), work, f"Incorrect performed work for {(origin, policy, label)}")
        close(number(row, "cumulative_rate"), work/(clock/1000), f"Incorrect performed-work rate for {(origin, policy, label)}")

    endings = read_unique(read_rows(data / "m25_endpoints.csv"), branch_key)
    insist(endings.keys() == branches.keys(), "Wrong endpoint coverage")
    for key, row in endings.items():
        status = runtime[*key, rounds]
        insist((int(row["count"]), int(row["attempts"]), ticks(row, "elapsed_total"), row["ending"]) == (
            int(status["count"]), int(status["attempts_total"]), ticks(status, "elapsed_total"), status["ending"]),
            f"Wrong branch endpoint for {key}")
        close(number(row, "cumulative_net"), number(status, "cumulative_net"), f"Endpoint work for {key}")
        close(number(row, "cumulative_rate"), number(status, "cumulative_net")/number(status, "elapsed_total"), f"Endpoint rate for {key}")
        insist(ticks(row, "last_extraction_elapsed") == ticks(series[key][-1], "elapsed_total") if series[key]
               else row["last_extraction_elapsed"] == "", f"Last extraction clock for {key}")
    return len(count_rows), len(time_rows)


def audit_bench_estimates(data):
    rows = read_unique(read_rows(data / "m25_benchmark.csv"), branch_key)
    insist(rows.keys() == {("S0", policy) for policy in POLICIES}, "Wrong benchmark coverage")
    for key, row in rows.items():
        insist(int(row["rounds_target"]) == int(row["count"]) == 2, f"Incomplete two-extraction benchmark for {key}")
        duration = number(row, "seconds")
        insist(duration > 0, f"Invalid measured runtime for {key}")
        for n in STAGES:
            close(number(row, f"serial_estimate_{n}_per_origin_s"), duration*n/2, f"Benchmark runtime extrapolation {key}/{n}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("data", nargs="?", type=Path, default=ROOT / "results")
    parser.add_argument("--benchmark", action="store_true")
    parser.add_argument("--rounds", type=int, choices=STAGES, default=30)
    parser.add_argument("--stage-root", type=Path, default=ROOT / "stages")
    parser.add_argument("--m23", type=Path, default=M23)
    parser.add_argument("--m24", type=Path, default=M24)
    args = parser.parse_args()
    rounds = 2 if args.benchmark else args.rounds
    sources, states, historical = published_inputs(args.m23, args.m24)
    attempts, branches, future, reconnect_witnesses = audit_history(args.data, sources, states, args.benchmark, rounds)
    samples = audit_traces(args.data, attempts, reconnect_witnesses, args.benchmark)
    candidates = audit_search(args.data, attempts, future, args.benchmark)
    check_suffix_sentinels()
    check_m23_parity(branches, historical, min(8, rounds))
    runtime = audit_stages(args.data, branches, states, args.stage_root, args.benchmark, rounds)
    print(f"PASS: {len(branches)} branches, {len(attempts)} attempts, {samples} trajectory rows, "
          f"{candidates} retrospective candidates, {len(future)} future-work diagnostics, {len(runtime)} checkpoints and 4 suffix sentinels")
    replay_differences = sum(ticks(row, "half_replay_duration") != ticks(row, "duration") for row in attempts.values())
    print(f"Half-step replay changes the selected clock on {replay_differences} of {len(attempts)} attempts")
    if not args.benchmark:
        same_count, same_time = audit_comparisons(args.data, sources, branches, runtime, rounds)
        audit_bench_estimates(args.data)
        print(f"PASS: {same_count} same-count comparisons, {same_time} same-time comparisons and M23 parity for S0/E and S0/F")


if __name__ == "__main__":
    main()
