"""M25 online stopping and M23-matched retrospective selection."""

from dataclasses import dataclass
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
M23 = ROOT.parent / "Milestone_23"
M24 = ROOT.parent / "Milestone_24"
for folder in (M23, M24):
    sys.path.insert(0, str(folder))

import numpy as np

from m23_spectral import DT, FLOOR, G, GRID, local_diagnostics, partial
from m24_physics import ConnectedObservations, observe_local
from m24_rules import FORECAST, TURN, targets
from run_m23 import COARSE_TAUS

ORIGINS = ("S0", "A04", "B04", "C04")
POLICIES = ("A", "B", "C25", "C", "D", "E", "F")
RELATIVE = {"C25": 0.25, "C": 0.50}
ONLINE = ("A", "B", "C25", "C")
TOTAL_LIMIT = 540_000
FIXED = 16_340
DIAGNOSTIC_COUNTS = {1, 5, 10, 20, 30}


@dataclass(frozen=True)
class Stop:
    index: int
    decided: int | None
    reason: str
    skipped: tuple[int, ...] = ()


def online_stop(samples, count, policy, threshold):
    """Consume only through execution. Freeze the first forecast when issued."""
    if policy not in ONLINE or count < 2:
        raise ValueError("Online policy requires a positive-time observation grid")
    previous = None
    planned = None
    skipped = []
    for index, present in enumerate(samples):
        if planned is not None:
            if index == planned.index:
                return planned
        else:
            events = targets(index, previous, present, count - 1)
            if policy == "A" and FORECAST in events:
                planned = Stop(events[FORECAST], index, "forecast")
            elif policy != "A" and TURN in events:
                if policy == "B" or present["total_work"] >= threshold:
                    return Stop(index, index, "turn", tuple(skipped))
                skipped.append(index)
            if index == count - 1:
                return Stop(index, index, "horizon", tuple(skipped))
        previous = present
    raise ValueError("Observation stream ended before the selected extraction time")


def online_path(model, state, window, policy, threshold):
    count = window // GRID + 1
    projector = ConnectedObservations(model, model.connected.to_basis(state), DT[0], with_rate=False)
    observed = []

    def stream():
        for terminal, _ in projector.prefix(count):
            present = observe_local(terminal)
            observed.append(present)
            yield present

    decision = online_stop(stream(), count, policy, threshold)
    return decision, {name: np.asarray([sample[name] for sample in observed]) for name in observed[0]}


def waiting_state(model, density, tau, dt):
    return model.bases[0].evolve(density, tau, dt) if tau else density


def switch_input(density, waiting, tau):
    if not tau:
        return 0.0, 0.0
    c0, c1 = (float(local_diagnostics(partial(rho))["c_real"]) for rho in (density, waiting))
    return -2 * G * c0, 2 * G * c1


def connected_path(model, density, tau, index, dt=DT[0]):
    waiting = waiting_state(model, density, tau, dt)
    basis = model.connected.to_basis(waiting)
    terminals = model.terminal_grid(basis[None], dt, index + 1)[0]
    return observe_local(terminals)


@dataclass(frozen=True)
class Trial:
    stage: str
    tau: int
    index: int
    count: int
    work: float

    @property
    def elapsed(self):
        return self.tau + self.index * GRID


def candidates(model, initial, taus, window, stage):
    dt = DT[0]
    wait_basis = model.bases[0]
    cut_basis = wait_basis.to_basis(initial)
    c0 = float(local_diagnostics(partial(initial))["c_real"])
    trials = []
    for start in range(0, len(taus), 10):
        batch = taus[start:start + 10]
        counts = [(window - tau) // GRID + 1 for tau in batch]
        waiting = [wait_basis.from_basis(wait_basis.step_spectral(cut_basis, tau, dt)) if tau else initial
                   for tau in batch]
        bases = np.asarray([model.connected.to_basis(rho) for rho in waiting])
        paths = local_diagnostics(model.terminal_grid(bases, dt, max(counts)))
        for j, (tau, count) in enumerate(zip(batch, counts, strict=True)):
            switches = 2 * G * (paths["c_real"][j, 0] - c0) if tau else 0.0
            work = paths["total_work"][j, :count] - switches
            first = int(tau == 0)
            index = first + int(np.argmax(work[first:]))
            trials.append(Trial(stage, tau, index, count - first, float(work[index])))
    return trials


def half_at(model, half, trial):
    wait = waiting_state(model, half, trial.tau, DT[1])
    state = model.connected.evolve(wait, trial.index * GRID, DT[1])
    cut, connect = switch_input(half, wait, trial.tau)
    return float(local_diagnostics(partial(state))["total_work"]) - cut - connect


def retrospective(model, initial, window, policy):
    coarse = candidates(model, initial[0], (0,) if policy == "F" else tuple(
        tau for tau in COARSE_TAUS if tau <= window), window, "A")
    if policy == "F":
        return coarse[0], coarse, ()
    maxima = [trial for i, trial in enumerate(coarse)
              if (i == 0 or trial.work > coarse[i-1].work)
              and (i == len(coarse)-1 or trial.work >= coarse[i+1].work)]
    centers = sorted(maxima, key=lambda trial: (-trial.work, trial.tau))[:3]
    lattice = set()
    for trial in centers:
        bound = min(6000, window)
        if trial.tau == 6000:
            neighbor = coarse[-2]
            step_margin = (abs(trial.work - half_at(model, initial[1], trial))
                           + abs(neighbor.work - half_at(model, initial[1], neighbor)))
            if trial.work - neighbor.work > FLOOR + step_margin:
                bound = min(6250, window)
        lattice.update(range(max(0, trial.tau - 250), min(bound, trial.tau + 250) + 1, 25))
    refined = candidates(model, initial[0], sorted(lattice), window, "C")
    all_trials = coarse + refined
    winner = min(all_trials, key=lambda trial: (-trial.work, trial.elapsed, trial.tau))
    return winner, all_trials, tuple(trial.tau for trial in centers)
