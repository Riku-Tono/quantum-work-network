"""Merge completed stages and compute count-matched and time-matched results."""

import argparse
from bisect import bisect_right
import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ORIGINS = ("S0", "A04", "B04", "C04")
POLICIES = ("A", "B", "C25", "C", "D", "E", "F")
FIXED_TIMES = (25, 50, 100, 150, 250, 360, 500, 540)
FILES = ("m25_history", "m25_trajectories", "m25_future", "m25_search", "m25_stage_runtime")


def rows(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def write_rows(path, records):
    with path.open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)


def paths(stages, filename):
    for origin in ORIGINS:
        for policy in POLICIES:
            for stage in stages:
                path = stage / origin / policy / (filename + ".csv")
                if path.exists():
                    yield path


def merge(stages, destination, filename):
    headers = None
    with (destination / (filename + ".csv")).open("x", encoding="utf-8", newline="") as output:
        writer = csv.writer(output)
        for path in paths(stages, filename):
            with path.open(encoding="utf-8", newline="") as stream:
                reader = csv.reader(stream)
                current = next(reader)
                if headers is None:
                    headers = current
                    writer.writerow(headers)
                if current != headers:
                    raise ValueError(f"CSV fields differ in {path}")
                writer.writerows(reader)
    if headers is None:
        raise ValueError(f"No data for {filename}")


def compare(history, stage_runtime):
    accepted = {(origin, policy): [] for origin in ORIGINS for policy in POLICIES}
    for row in history:
        if row["accepted"] == "True":
            accepted[row["origin"], row["policy"]].append(row)
    last = {(row["origin"], row["policy"]): row for row in stage_runtime}
    max_count = max(int(row["rounds_target"]) for row in stage_runtime)
    count_results, time_results, end_results = [], [], []
    for origin in ORIGINS:
        cutoffs = [(f"t{t}", t) for t in FIXED_TIMES]
        for count in range(10, max_count + 1, 10):
            reached = [float(series[count-1]["elapsed_total"]) for (key, _), series in accepted.items()
                       if key == origin and len(series) >= count]
            if reached:
                cutoffs.append((f"first_{count}", min(reached)))
                if len(reached) == len(POLICIES):
                    cutoffs.append((f"all_{count}", max(reached)))
        for policy in POLICIES:
            start = {"origin": origin, "policy": policy}
            series = accepted[origin, policy]
            ending = last[origin, policy]
            for count in range(1, max_count + 1):
                reached = count <= len(series)
                result = series[count-1] if reached else {}
                count_results.append({**start, "target_count": count, "reached": reached,
                                      **{field: result.get(field, "") for field in (
                                          "elapsed_total", "cumulative_net", "cumulative_rate")}})
            times = [float(row["elapsed_total"]) for row in series]
            for label, cutoff in cutoffs:
                at = bisect_right(times, cutoff)
                work = float(series[at-1]["cumulative_net"]) if at else 0.0
                time_results.append({**start, "time_label": label, "elapsed_total": cutoff,
                                     "count": at, "cumulative_net": work, "cumulative_rate": work/cutoff})
            elapsed = float(ending["elapsed_total"])
            work = float(ending["cumulative_net"])
            end_results.append({**start, "count": ending["count"], "attempts": ending["attempts_total"],
                                "ending": ending["ending"], "elapsed_total": elapsed, "cumulative_net": work,
                                "cumulative_rate": work/elapsed if elapsed else "",
                                "last_extraction_elapsed": times[-1] if times else ""})
    return count_results, time_results, end_results


def collect(stages, destination, benchmark, sources):
    destination.mkdir(parents=True, exist_ok=True)
    for stage in stages:
        expected = [stage / origin / policy / "m25_stage_runtime.csv" for origin in ORIGINS for policy in POLICIES]
        if any(not path.is_file() for path in expected):
            raise ValueError(f"Incomplete calculation stage: {stage}")
    for filename in FILES:
        merge(stages, destination, filename)
    history = rows(destination / "m25_history.csv")
    runtime = rows(destination / "m25_stage_runtime.csv")
    for filename, comparison in zip(("m25_count_comparison", "m25_time_comparison", "m25_endpoints"),
                                    compare(history, runtime), strict=True):
        write_rows(destination / (filename + ".csv"), comparison)
    write_rows(destination / "m25_sources.csv", [row for row in rows(sources) if row["origin"] in ORIGINS])
    benchmark_rows = []
    for policy in POLICIES:
        row, = rows(benchmark / "S0" / policy / "m25_stage_runtime.csv")
        benchmark_rows.append({**row, **{f"serial_estimate_{n}_per_origin_s":
                                        float(row["seconds"]) * n / 2 for n in (10, 20, 30)}})
    write_rows(destination / "m25_benchmark.csv", benchmark_rows)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("destination", type=Path)
    parser.add_argument("stages", type=Path, nargs="+")
    parser.add_argument("--benchmark", type=Path, required=True)
    parser.add_argument("--sources", type=Path, default=ROOT.parent / "Milestone_24" / "results" / "m24_sources.csv")
    args = parser.parse_args()
    collect(args.stages, args.destination, args.benchmark, args.sources)
