"""Run staged repeated extraction experiments. Windows PowerShell and Python 3.14."""

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import hashlib
import os
from pathlib import Path
import time

os.environ.setdefault("OPENBLAS_NUM_THREADS", "2")

from m25_control import (
    DIAGNOSTIC_COUNTS, FIXED, M23, M24, ONLINE, ORIGINS, POLICIES, RELATIVE, ROOT, TOTAL_LIMIT,
    Stop, connected_path, online_path, online_stop, retrospective, switch_input, waiting_state,
)
from m21_observables import read_state, spectrum
from m23_spectral import DT, FLOOR, G, GRID, HALF_TOL, HORIZON, Dynamics, extraction, local_diagnostics, maxabs, partial
from run_m23 import Tables, account, csv_rows, ms
from m25_diagnostics import future_work, state_metrics

import numpy as np

MODEL = None
TRACE_FIELDS = ("load_energy", "load_passive_energy", "load_ergotropy", "load_current",
                "load_ergotropy_rate", "load_passive_energy_rate", "c_abs", "c_real", "c_imag", "total_work")


def fingerprint(rho):
    return hashlib.sha256(np.asarray(rho, dtype="<c16", order="C").tobytes()).hexdigest()


def source_pair(m23, source):
    pair = []
    for key in ("coarse", "half"):
        path = m23 / source[f"{key}_path"]
        if hashlib.sha256(path.read_bytes()).hexdigest().upper() != source[f"{key}_sha256"]:
            raise ValueError(f"Source hash mismatch: {path}")
        pair.append(read_state(path, float(source["source_time"])))
    return tuple(pair)


def state_path(folder, origin, policy):
    return folder / origin / policy / "checkpoint.npz"


def half_physicality(state):
    return max(abs(np.trace(state)-1), maxabs(state-state.conj().T), -float(spectrum(state)[0]))


def emit_trace(tables, meta, start, tau, stop, data, net, post):
    def emit(phase, i, elapsed, values, work):
        tables.add("m25_trajectories", {**meta, "phase": phase, "index": i, "elapsed_total": elapsed / 1000,
                                      **values, "net_work_if_extracted": work,
                                      "signal_skipped": phase == "connected" and i in stop.skipped})

    if tau:
        # Free-load time development preserves the three energy observables.
        frozen = {k: data[k][0] if k in TRACE_FIELDS[:3] else "" for k in TRACE_FIELDS}
        for t in range(0, tau, GRID):
            emit("wait", "", start+t, frozen, "")
    for i in range(stop.index + 1):
        emit("connected", i, start+tau+i*GRID, {k: data[k][i] for k in TRACE_FIELDS}, net[i])
    if post:
        emit("post", stop.index, start+tau+stop.index*GRID,
             {k: post.get(k, "") for k in TRACE_FIELDS}, "")


def evaluate_attempt(model, tables, source, policy, initial, attempt, accepted_count, start, cumulative, previous):
    window = min(HORIZON, TOTAL_LIMIT - start)
    threshold = max(FLOOR, RELATIVE.get(policy, 0.0)*previous)
    preliminary = {"origin": source["origin"], "policy": policy, "attempt": attempt}
    if policy in ONLINE:
        tau = 0
        stop, trace = online_path(model, initial[0], window, policy, threshold)
    elif policy == "D":
        tau = 0
        stop = Stop(FIXED // GRID, 0, "fixed")
        trace = connected_path(model, initial[0], tau, stop.index)
    else:
        winner, trials, centers = retrospective(model, initial, window, policy)
        tau = winner.tau
        stop = Stop(winner.index, None, "retrospective")
        trace = connected_path(model, initial[0], tau, stop.index)
        for trial in trials:
            tables.add("m25_search", {
                **preliminary, "stage": trial.stage, "tau": trial.tau / 1000,
                "elapsed_connected": trial.index * GRID / 1000, "elapsed_total": trial.elapsed / 1000,
                "candidate_count": trial.count, "max_net": trial.work, "refinement_center": trial.stage == "A" and trial.tau in centers,
                "selected": trial is winner,
            })

    duration = tau+stop.index*GRID
    if not 0 < duration <= window:
        raise ValueError(f"Invalid repeated-extraction interval {duration}")
    waiting = tuple(waiting_state(model, rho, tau, dt) for rho, dt in zip(initial, DT, strict=True))
    before = tuple(model.connected.evolve(rho, stop.index*GRID, dt)
                   for rho, dt in zip(waiting, DT, strict=True))
    cuts = tuple(switch_input(rho, wait, tau) for rho, wait in zip(initial, waiting, strict=True))
    coarse = trace["total_work"] - sum(cuts[0])
    if policy in ("E", "F") and abs(float(coarse[-1])-winner.work) > FLOOR:
        raise ValueError(f"Retrospective candidate mismatch: {preliminary}")
    half_trace = connected_path(model, initial[1], tau, (window-tau)//GRID, DT[1])
    half_net = half_trace["total_work"] - sum(cuts[1])
    work, work_half = float(coarse[-1]), float(half_net[stop.index])
    grid_error = maxabs(coarse - half_net[:len(coarse)])
    if grid_error > HALF_TOL:
        raise ValueError(f"Work convergence failed for {preliminary}: {grid_error:g}")
    if policy in ONLINE:
        half_samples = ({name: half_trace[name][i] for name in (
            "total_work", "load_ergotropy", "load_ergotropy_rate", "load_current")}
            for i in range(len(half_net)))
        half_stop = online_stop(half_samples, len(half_net), policy, threshold)
        half_replay = half_stop.index * GRID / 1000
    elif policy in ("E", "F"):
        first = int(tau == 0)
        half_replay = (tau+(first+int(np.argmax(half_net[first:])))*GRID) / 1000
    else:
        half_replay = duration / 1000

    accounts = tuple(account(model, start_rho, wait, state, candidate, tau, *cut)
                     for start_rho, wait, state, candidate, cut in zip(
                         initial, waiting, before, (work, work_half), cuts, strict=True))
    check, imaginary_after = accounts[0]
    check_half, imaginary_half = accounts[1]
    error = abs(work-work_half)
    resolution_margin = work-error
    accepted = resolution_margin > FLOOR and check["direct_net"] > FLOOR and work >= threshold
    reason = "extracted" if accepted else "threshold_at_horizon" if work < threshold and policy in RELATIVE else "unresolved_candidate"
    after = (imaginary_after, imaginary_half) if accepted else before
    net = check["direct_net"] if accepted else 0.0
    cumulative += net
    end = start+duration
    count = accepted_count + int(accepted)
    pre = state_metrics(model, before[0])
    post = state_metrics(model, after[0]) if accepted else pre
    half_error = max(half_physicality(before[1]), half_physicality(after[1]))
    if half_error > FLOOR:
        raise ValueError(f"Half-step physicality failed for {preliminary}: {half_error:g}")
    residual = post["global_energy"] - (check["start_global_energy"] - net)
    passive_drift = post["global_passive_energy"] - pre["global_passive_energy"]
    chain_drift = post["bare_chain_energy"] - pre["bare_chain_energy"]
    if max(abs(residual), abs(passive_drift), abs(chain_drift)) > FLOOR:
        raise ValueError(f"Energy closure or local-unitary invariant failed for {preliminary}")
    meta = {**preliminary, "count": count}
    tables.add("m25_history", {
        **meta, "accepted": accepted, "outcome": reason, "stop_reason": stop.reason,
        "window": window/1000, "tau": tau/1000, "elapsed_start": start/1000,
        "elapsed_connected": stop.index*GRID/1000, "duration": duration/1000, "elapsed_total": end/1000,
        "absolute_time": float(source["source_time"])+end/1000,
        "decision_elapsed_total": "" if stop.decided is None else (start+tau+stop.decided*GRID)/1000,
        "threshold": threshold, "previous_accepted_net": previous, "skipped_peaks": len(stop.skipped),
        "candidate_net": work, "candidate_net_half": work_half, "resolution_margin": resolution_margin,
        "net_work": net, "cumulative_net": cumulative, "cumulative_rate": cumulative/(end/1000),
        "half_replay_duration": half_replay, "max_grid_step_error": grid_error,
        "max_half_physicality_error": half_error, "half_state_max_error": maxabs(after[0]-after[1]),
        "cut_on": cuts[0][0], "reconnect_on": cuts[0][1],
        "cut_on_half": cuts[1][0], "reconnect_on_half": cuts[1][1],
        "interaction_jump": float(trace["interaction_jump"][-1]),
        "accepted_energy_residual": residual, "global_passive_unitary_drift": passive_drift,
        "bare_chain_unitary_drift": chain_drift, "direct_net_half": check_half["direct_net"],
        **check,
        **{f"pre_{field}": value for field,value in pre.items()},
        **{f"post_{field}": value for field,value in post.items()},
        **{f"{stage}_{label}_sha256": fingerprint(rho) for stage, pair in (
            ("start", initial), ("pre", before), ("post", after))
           for label, rho in zip(("coarse", "half"), pair, strict=True)},
    })
    emit_trace(tables, meta, start, tau, stop, trace, coarse, post if accepted else None)
    if accepted and count in DIAGNOSTIC_COUNTS:
        diagnostic = future_work(model, tuple(rho.copy() for rho in after))
        tables.add("m25_future", {**meta, "elapsed_total": end/1000, **diagnostic})
    return after, end, cumulative, count, net, accepted, reason


def run_branch(source, policy, destination, rounds, previous_stage, m23):
    global MODEL
    started = time.perf_counter()
    folder = destination / source["origin"] / policy
    folder.mkdir(parents=True, exist_ok=False)
    if MODEL is None:
        MODEL = Dynamics(HORIZON)
    initial = source_pair(m23, source)
    origin_energy = tuple(float(np.einsum("ij,ji->", density, MODEL.h[G]).real) for density in initial)
    elapsed = count = attempt = 0
    cumulative = previous = 0.0
    ending = "count_cap"
    if previous_stage is not None:
        with np.load(state_path(previous_stage, source["origin"], policy), allow_pickle=False) as saved:
            initial = (saved["coarse"], saved["half"])
            elapsed, count, attempt = map(int, saved["counters"])
            cumulative, previous = map(float, saved["work"])
            ending = str(saved["ending"].item())

    start_attempt = attempt
    tables = Tables(folder)
    try:
        if ending == "count_cap":
            while count < rounds:
                remaining = TOTAL_LIMIT-elapsed
                if remaining < (FIXED if policy == "D" else GRID):
                    ending = "time_cap"
                    break
                attempt += 1
                initial, elapsed, cumulative, count, net, accepted, reason = evaluate_attempt(
                    MODEL, tables, source, policy, initial, attempt, count, elapsed, cumulative, previous)
                actual_energy = float(np.einsum("ij,ji->", initial[0], MODEL.h[G]).real)
                if abs(actual_energy + cumulative - origin_energy[0]) > FLOOR:
                    raise ValueError(f"Cumulative energy closure failed: {source['origin']}/{policy}/{attempt}")
                if not accepted:
                    ending = reason
                    break
                previous = net
        np.savez(folder / "checkpoint.npz", coarse=initial[0], half=initial[1],
                 counters=(elapsed,count,attempt), work=(cumulative,previous), ending=ending)
        stats = {"origin": source["origin"], "policy": policy, "rounds_target": rounds, "attempts_in_stage": attempt-start_attempt,
                 "attempts_total": attempt, "count": count, "elapsed_total": elapsed/1000, "cumulative_net": cumulative,
                 "ending": ending, "seconds": time.perf_counter()-started}
        tables.add("m25_stage_runtime", stats)
    finally:
        tables.close()
    return stats


def execute(destination, rounds, previous, origins, workers, m23, source_table):
    if previous is not None and previous == destination:
        raise ValueError("Stage directory and previous directory must differ")
    by_origin = {source["origin"]: source for source in csv_rows(source_table)}
    if workers == 1:
        for origin in origins:
            for policy in POLICIES:
                print(run_branch(by_origin[origin], policy, destination, rounds, previous, m23), flush=True)
        return
    with ProcessPoolExecutor(max_workers=workers) as pool:
        tasks = [pool.submit(run_branch, by_origin[origin], policy, destination, rounds, previous, m23)
                 for policy in POLICIES for origin in origins]
        for task in as_completed(tasks):
            print(task.result(), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--rounds", type=int, choices=(2, 10, 20, 30), required=True)
    parser.add_argument("--previous", type=Path)
    parser.add_argument("--origins", choices=ORIGINS, nargs="+", default=ORIGINS)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--m23", type=Path, default=M23)
    parser.add_argument("--sources", type=Path, default=M24 / "results" / "m24_sources.csv")
    args = parser.parse_args()
    execute(args.destination, args.rounds, args.previous, args.origins, args.workers, args.m23, args.sources)
