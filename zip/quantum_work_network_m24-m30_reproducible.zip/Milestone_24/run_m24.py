"""Evaluate M24 load trajectories, precursors, and prefix-only extraction."""

import argparse
from pathlib import Path
import time

from m24_oracles import M23, ROOT, load_source
from m23_spectral import DT, FLOOR, G, GRID, HALF_TOL, HORIZON, Dynamics, maxabs, partial
from run_m23 import Tables, account, csv_rows, ms, selected_snapshots

import numpy as np

from m24_physics import ConnectedObservations, observe, observe_local, terminal_rate
from m24_rules import FORECAST, RULES, STEP, Decision, decide, targets

PATH_FIELDS = (
    "load_energy", "load_passive_energy", "load_ergotropy", "load_current", "load_energy_rate",
    "load_passive_energy_rate", "load_ergotropy_rate", "load_current_rate", "c_real", "c_imag",
    "interaction_jump", "net_work", "load_p0", "load_p1", "load_p2", "current_identity_error",
)
SIGNALS = (*RULES, "passive_rate_turn")
HIT_WINDOW = 0.10


def samples(records):
    for i in range(len(records["load_current"])):
        yield {field: records[field][i] for field in (
            "load_current", "load_ergotropy", "load_ergotropy_rate", "load_passive_energy_rate")}


def build_path(model, initial, tau, count):
    waiting = tuple(model.bases[0].evolve(rho, tau, dt) if tau else rho
                    for rho, dt in zip(initial, DT, strict=True))
    spectra = tuple(model.connected.to_basis(rho) for rho in waiting)
    online = ConnectedObservations(model, spectra[0], DT[0], with_rate=False)
    live = decide((observe_local(terminal) for terminal, _ in online.prefix(count)), count)
    curves = tuple(observe(*ConnectedObservations(model, spectral, dt).grid(count))
                   for spectral, dt in zip(spectra, DT, strict=True))
    replay, half_replay = (decide(samples(curve), count) for curve in curves)
    if live != replay:
        raise ValueError(f"Live and retrospective decision replay disagree at tau={tau}: {live} vs {replay}")
    cut = tuple(-2 * G * float(observe(partial(rho))["c_real"]) if tau else 0.0 for rho in initial)
    reconnect = tuple(2 * G * float(curve["c_real"][0]) if tau else 0.0 for curve in curves)
    for curve, wcut, wconnect in zip(curves, cut, reconnect, strict=True):
        curve["net_work"] = curve["total_work"] - wcut - wconnect
    return waiting, spectra, curves, live, half_replay, cut, reconnect


def signal_events(curve):
    events = {name: [] for name in SIGNALS}
    previous = None
    previous_forecast = False
    last = len(curve["net_work"]) - 1
    for i, present in enumerate(samples(curve)):
        now = targets(i, previous, present, last)
        if previous and previous["load_passive_energy_rate"] > 0 >= present["load_passive_energy_rate"]:
            now["passive_rate_turn"] = i
        for name, target in now.items():
            if name != FORECAST or not previous_forecast:
                events[name].append((i, target))
        previous_forecast = FORECAST in now
        previous = present
    return events


def emit_precursors(tables, meta, tau, curve, peak):
    def elapsed(i):
        return (tau + GRID * i) / 1000

    work = curve["net_work"]
    local = np.flatnonzero((work[1:-1] > work[:-2]) & (work[1:-1] >= work[2:]) & (work[1:-1] > FLOOR)) + 1
    time_window = ms(HIT_WINDOW) // GRID
    for name, events in signal_events(curve).items():
        nearest = min(events, key=lambda e: (abs(e[1] - peak), e[0])) if events else None
        n_global = sum(abs(target - peak) <= time_window for _, target in events)
        n_local = sum(bool(np.any(np.abs(local - target) <= time_window)) for _, target in events)
        tables.add("m24_precursors", {
            **meta, "signal": name, "peak_elapsed_total": elapsed(peak),
            "first_signal_elapsed_total": elapsed(events[0][0]) if events else "",
            "first_target_elapsed_total": elapsed(events[0][1]) if events else "",
            "signal_elapsed_total": elapsed(nearest[0]) if nearest else "",
            "target_elapsed_total": elapsed(nearest[1]) if nearest else "",
            "lead": (peak - nearest[0]) * STEP if nearest else "",
            "target_error": (nearest[1] - peak) * STEP if nearest else "",
            "event_count": len(events), "global_hits": n_global, "local_hits": n_local,
            "leading_global_hit": any(i < peak and abs(target - peak) <= time_window for i, target in events),
            "interior_local_peaks": len(local),
        })


def emit_physics(tables, model, meta, tau, initial, waiting, spectra, curves, peak):
    coarse, half = curves
    j = coarse["load_current"]
    passive_rate = coarse["load_passive_energy_rate"]
    growth = coarse["load_ergotropy_rate"]
    positive = (np.abs(j) > FLOOR) & (np.abs(growth) > FLOOR)
    integrated = np.r_[0, np.cumsum(STEP * (j[:-1] + j[1:]) / 2)]
    matrix = selected_snapshots(model, waiting, spectra, peak * GRID)[0]
    direct = observe(partial(matrix), terminal_rate(model, matrix))
    waiting_start, waiting_end = (observe(partial(x)) for x in (initial[0], waiting[0]))
    start_end_drift = max(abs(float(waiting_end[k] - waiting_start[k])) for k in (
        "load_energy", "load_passive_energy", "load_ergotropy"))
    max_half = max(maxabs(coarse[k] - half[k]) for k in (
        "load_energy", "load_passive_energy", "load_ergotropy", "net_work", "load_current",
        "load_ergotropy_rate", "load_passive_energy_rate"))
    identity = max(maxabs(curve["current_identity_error"]) for curve in curves)
    derivative_check = max(abs(float(direct[k] - coarse[k][peak])) for k in (
        "load_current", "load_energy_rate", "load_passive_energy_rate", "load_ergotropy_rate"))
    if max(start_end_drift, identity, derivative_check) > FLOOR or max_half > HALF_TOL:
        raise ValueError(f"Energy or step audit failed for {meta}: "
                         f"{start_end_drift=}, {identity=}, {derivative_check=}, {max_half=}")
    tables.add("m24_physics", {
        **meta, "samples": len(j), "max_current_identity_error": identity,
        "max_half_step_difference": max_half, "direct_peak_derivative_error": derivative_check,
        "max_wait_energy_drift": start_end_drift,
        "max_trapezoid_transport_error": maxabs(integrated - (coarse["load_energy"] - coarse["load_energy"][0])),
        "energy_span": np.ptp(coarse["load_energy"]), "passive_span": np.ptp(coarse["load_passive_energy"]),
        "ergotropy_span": np.ptp(coarse["load_ergotropy"]),
        "current_ergotropy_rate_r": float(np.corrcoef(j, growth)[0, 1]),
        "opposite_sign_fraction": float(np.mean(np.sign(j[positive]) != np.sign(growth[positive]))),
        "max_abs_net_minus_ergotropy": maxabs(coarse["net_work"] - coarse["load_ergotropy"]),
        "max_abs_interaction_jump": maxabs(coarse["interaction_jump"]),
        "current_at_peak": j[peak], "passive_rate_at_peak": passive_rate[peak],
        "ergotropy_rate_at_peak": growth[peak],
        "elapsed_peak": (tau + peak * GRID) / 1000,
        "elapsed_energy_peak": (tau + int(np.argmax(coarse["load_energy"])) * GRID) / 1000,
        "elapsed_ergotropy_peak": (tau + int(np.argmax(coarse["load_ergotropy"])) * GRID) / 1000,
        "peak_interior": 0 < peak < len(j) - 1,
    })


def evaluate_path(tables, model, source, initial, tau, chosen, wait_best, training):
    anchor = float(source["source_time"])
    tau_role = {0: "connected", 2000: "fixed_wait"}.get(tau, "oracle_wait")
    meta = {k: source[k] for k in ("origin", "split", "lineage")}
    meta.update(tau=tau / 1000, tau_role=tau_role)
    count = (HORIZON - tau) // GRID + 1
    waiting, spectra, curves, live, half_replay, cut, reconnect = build_path(model, initial, tau, count)
    coarse, half = curves
    work = coarse["net_work"]
    peak = int(np.argmax(work))
    match = wait_best["elapsed_connected"]
    if peak * GRID != ms(match) or abs(work[peak] - float(wait_best["net_work"])) > FLOOR:
        raise ValueError(f"M24 same-wait reproduction disagrees with M23 comparator at {meta}")

    for i in range(count):
        delta = (tau + i * GRID) / 1000
        tables.add("m24_trajectories", {
            **meta, "elapsed_connected": i * GRID / 1000, "elapsed_total": delta, "time": anchor + delta,
            **{name: coarse[name][i] for name in PATH_FIELDS}, "net_work_half": half["net_work"][i],
            "cut_on": cut[0], "reconnect_on": reconnect[0],
        })
    emit_physics(tables, model, meta, tau, initial, waiting, spectra, curves, peak)
    emit_precursors(tables, meta, tau, coarse, peak)

    choices = {**live, "same_wait_oracle": Decision(peak, peak, "retrospective")}
    is_variable_wait = tau == ms(chosen["tau"])
    if is_variable_wait:
        choices["variable_wait_oracle"] = choices["same_wait_oracle"]
    if tau in training:
        i = training[tau]
        choices["fixed_delay"] = Decision(0, i, "fixed")
    full_checks = {}
    for name, stop in choices.items():
        i = stop.extraction_index
        coarse_work, half_work = work[i], half["net_work"][i]
        if i not in full_checks:
            before = selected_snapshots(model, waiting, spectra, i * GRID)
            full_checks[i] = tuple(account(model, r, w, b, value, tau, wcut, wconn)[0]
                                   for r, w, b, value, wcut, wconn in zip(
                                       initial, waiting, before, (coarse_work, half_work), cut, reconnect, strict=True))
        direct, direct_half = full_checks[i]
        accepted = coarse_work - abs(coarse_work - half_work) > FLOOR and direct["direct_net"] > FLOOR
        earned = float(coarse_work) if accepted else 0.0
        elapsed = (tau + i * GRID) / 1000
        retrospective = stop.reason == "retrospective"
        tables.add("m24_policies", {
            **meta, "tau_role": "oracle_wait" if name == "variable_wait_oracle" else tau_role,
            "policy": name, "deployable": not retrospective and tau_role != "oracle_wait",
            "decision_elapsed_total": "" if retrospective else (tau + stop.observed_index * GRID) / 1000,
            "elapsed_connected": i * GRID / 1000, "elapsed_total": elapsed,
            "stop_reason": stop.reason,
            "observed_count": "" if retrospective else 0 if stop.reason == "fixed" else stop.observed_index + 1,
            "accepted": accepted, "net_work": earned, "candidate_net": coarse_work, "net_work_half": half_work,
            "same_wait_fraction": earned / work[peak], "variable_wait_fraction": earned / float(chosen["net_work"]),
            "same_wait_time_error": (i - peak) * STEP, "rate": earned / elapsed if elapsed else "",
            "direct_net": direct["direct_net"], "direct_net_half": direct_half["direct_net"],
            "direct_balance_residual": direct["balance_residual"],
            "half_replay_elapsed_total": (tau + half_replay[name].extraction_index * GRID) / 1000
            if name in half_replay else "",
        })
    return work / work[peak]


def evaluate(history, destination):
    source_rows = csv_rows(destination / "m24_sources.csv")
    if len(source_rows) != 12:
        raise ValueError("Complete m24_oracles.py before evaluating trajectories")
    search_rows = csv_rows(destination / "m24_wait_search.csv")
    winners = {row["origin"]: row for row in search_rows if row["selected"] == "True"}
    if len(winners) != len(source_rows):
        raise ValueError("The retrospective comparator is missing winners")
    waits = {(row["origin"], ms(row["tau"])): row for row in search_rows}
    tables = Tables(destination)
    model = Dynamics(HORIZON)
    reference_profiles = {0: [], 2000: []}
    fixed = {}
    try:
        for source in source_rows:
            started = time.perf_counter()
            origin = source["origin"]
            selected = winners[origin]
            initial = load_source(history, source)
            if source["split"] == "heldout" and not fixed:
                for tau, curves in reference_profiles.items():
                    profile = np.mean(curves, axis=0)
                    fixed[tau] = int(np.argmax(profile))
                    tables.add("m24_fixed_delay", {
                        "tau": tau / 1000, "training_origins": "S0 S1 S2",
                        "elapsed_connected": fixed[tau] * GRID / 1000,
                        "mean_same_wait_fraction": profile[fixed[tau]],
                    })
            for tau in dict.fromkeys((0, 2000, ms(selected["tau"]))):
                profile = evaluate_path(tables, model, source, initial, tau, selected, waits[origin, tau], fixed)
                if source["split"] == "reference" and tau in reference_profiles:
                    reference_profiles[tau].append(profile)
            tables.flush()
            print(f"{origin}: trajectories and policies complete ({time.perf_counter()-started:.1f}s)", flush=True)
    finally:
        tables.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("destination", type=Path, nargs="?", default=ROOT / "results")
    parser.add_argument("--m23", type=Path, default=M23)
    args = parser.parse_args()
    evaluate(args.m23, args.destination)
