"""Render the M24 trajectory, precursor, and held-out policy figures."""

import argparse
from collections import defaultdict
import csv
import math
from pathlib import Path
from statistics import median

import matplotlib

matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import PercentFormatter


ROOT = Path(__file__).resolve().parent
INK = "#14283D"
MUTED = "#486174"
GRID = "#DDE6EE"
BLUE = "#195983"
TEAL = "#00766D"
ORANGE = "#B55412"
PURPLE = "#734788"
GREY = "#596875"

POLICIES = {
    "fixed_delay": (GREY, "x", "Fixed delay"),
    "current_turn": (ORANGE, "^", "Current turn"),
    "ergotropy_turn": (BLUE, "s", "Ergotropy turn"),
    "ergotropy_forecast": (TEAL, "D", "Ergotropy forecast"),
    "same_wait_oracle": (PURPLE, "o", "Same-wait grid maximum"),
    "variable_wait_oracle": (INK, "*", "Variable-wait grid maximum"),
}
SPLITS = {"reference": (BLUE, "Reference"), "heldout": (ORANGE, "Held out")}


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def number(row, column):
    return float(row[column]) if row[column] else math.nan


def axis_style(axis, ylabel=None, *, zero=False, scientific=False):
    axis.set_axisbelow(True)
    axis.yaxis.grid(color=GRID, linewidth=0.8)
    axis.spines[["top", "right"]].set_visible(False)
    axis.spines[["bottom", "left"]].set_color(MUTED)
    axis.tick_params(labelcolor=INK, color=MUTED)
    if ylabel:
        axis.set_ylabel(ylabel)
    if zero:
        axis.axhline(0, color=MUTED, linewidth=0.8, zorder=1)
    if scientific:
        axis.ticklabel_format(axis="y", style="sci", scilimits=(-2, 2), useMathText=True, useOffset=False)


def heading(fig, title, caption):
    height = fig.get_figheight()
    fig.text(0.1, 1 - 0.25 / height, title, va="top", fontsize=19, fontweight="bold", color=INK)
    fig.text(0.1, 1 - 0.68 / height, caption, va="top", fontsize=10, color=MUTED)


def finish(fig, output, name):
    fig.savefig(output / name, dpi=220, facecolor="white")
    plt.close(fig)


def plot_trajectory(rows, policies, output):
    connected = defaultdict(list)
    for row in rows:
        if number(row, "tau") == 0:
            connected[row["split"], row["origin"]].append(row)
    examples = [(split, min(origin for label, origin in connected if label == split)) for split in SPLITS]
    fig, axes = plt.subplots(4, 2, figsize=(11.5, 10), sharex="col", layout=None)
    fig.subplots_adjust(left=0.1, right=0.964, top=0.817, bottom=0.075, hspace=0.35, wspace=0.28)
    heading(fig, "Energy and work under connected evolution",
            "First origin by ID in each split at zero disconnected wait. Time and energy are in model units.")
    for col, (split, origin) in enumerate(examples):
        path = sorted(connected[split, origin], key=lambda row: number(row, "elapsed_total"))
        time = [number(row, "elapsed_total") for row in path]
        for field, color, label, pattern in (
            ("load_energy", BLUE, r"Load $E_L$", "-"),
            ("load_passive_energy", ORANGE, r"Passive $E_{\mathrm{pass}}$", "--"),
        ):
            initial = number(path[0], field)
            axes[0, col].plot(time, [number(row, field) - initial for row in path], color=color,
                              linestyle=pattern, linewidth=1.65, label=label)
        for field, color, label, pattern in (
            ("load_current", BLUE, r"Exchange $J_E$", "-"),
            ("load_passive_energy_rate", ORANGE, r"Passive $\dot E_{\mathrm{pass}}$", "--"),
        ):
            axes[1, col].plot(time, [number(row, field) for row in path], color=color, linestyle=pattern,
                              linewidth=1.65, label=label)
        axes[2, col].plot(time, [number(row, "load_ergotropy_rate") for row in path], color=TEAL, linewidth=1.65)
        for field, color, label, pattern in (
            ("load_ergotropy", TEAL, r"Ergotropy $\mathcal{W}_L$", "-"),
            ("net_work", INK, r"Net work $W_{\mathrm{net}}$", "--"),
        ):
            axes[3, col].plot(time, [number(row, field) for row in path], color=color, linestyle=pattern,
                              linewidth=1.65, label=label)
        for row in policies:
            if row["origin"] != origin or number(row, "tau") != 0:
                continue
            if row["policy"] not in {"ergotropy_forecast", "same_wait_oracle"}:
                continue
            at = number(row, "elapsed_total")
            work = number(row, "net_work")
            if math.isfinite(at) and math.isfinite(work):
                color, marker, _ = POLICIES[row["policy"]]
                axes[3, col].axvline(at, color=color, linestyle=":", linewidth=1)
                axes[3, col].scatter(at, work, color="white", marker=marker, edgecolor=color, s=37, zorder=4)
        bounds = axes[0, col].get_position()
        fig.text(bounds.x0, bounds.y1 + 0.28 / fig.get_figheight(), f"{SPLITS[split][1]}  /  {origin}",
                 va="bottom", fontweight="bold", color=INK)
        axes[3, col].set_xlabel("Elapsed time")
        for index, ylabel in enumerate(("Energy change", "Energy per time", "Ergotropy per time", "Work")):
            axis_style(axes[index, col], ylabel, zero=True, scientific=True)
    for index in (0, 1):
        axes[index, 0].legend(loc="best", frameon=True, framealpha=0.95, edgecolor="white", fontsize=9)
    handles, labels = axes[3, 0].get_legend_handles_labels()
    for policy in ("ergotropy_forecast", "same_wait_oracle"):
        color, marker, label = POLICIES[policy]
        handles.append(Line2D([], [], color=color, marker=marker, markerfacecolor="white", linestyle=":"))
        labels.append(label)
    fig.legend(handles, labels, loc="upper left", bbox_to_anchor=(0.095, 1 - 0.99 / fig.get_figheight()),
               ncols=4, frameon=False)
    finish(fig, output, "m24_01_energy_current_work.png")


def plot_precursors(rows, output):
    by_signal = defaultdict(list)
    for row in rows:
        by_signal[row["signal"]].append(row)
    signals = list(by_signal)
    fig, axis = plt.subplots(figsize=(11, max(4.7, 2.7 + 0.45 * len(signals))))
    fig.subplots_adjust(left=0.30, right=0.967, top=1 - 1.42 / fig.get_figheight(), bottom=0.17)
    heading(fig, "Signal timing relative to maximum net work",
            "Each path uses the closest target in hindsight. Positive leads precede the net-work peak. Counts show coverage.")
    labels = []
    for index, (signal, group) in enumerate(by_signal.items()):
        leads = []
        for split, offset in (("reference", -0.12), ("heldout", 0.12)):
            x = [number(row, "lead") for row in group if row["split"] == split]
            x = [value for value in x if math.isfinite(value)]
            leads.extend(x)
            color, _ = SPLITS[split]
            axis.scatter(x, [index + offset] * len(x), color=color, alpha=0.49, s=29, linewidths=0, zorder=3)
            if x:
                axis.scatter([median(x)], [index + offset], color=color, marker="|", s=160, linewidths=2, zorder=4)
        labels.append(f"{signal.replace('_', ' ').capitalize()}  ({len(leads)}/{len(group)})")
    axis.set_yticks(range(len(signals)), labels)
    axis.set_ylim(len(signals) - 0.55, -0.55)
    axis.set_xlabel("Lead before maximum net work (model time)")
    axis_style(axis)
    axis.axvline(0, color=MUTED, linewidth=1.0, zorder=2)
    handles = [Line2D([], [], color=color, linestyle="none", marker="o", label=label)
               for color, label in SPLITS.values()]
    handles.append(Line2D([], [], color=MUTED, linestyle="none", marker="|", markersize=10, label="Split median"))
    fig.legend(handles=handles, loc="upper left", bbox_to_anchor=(0.095, 1 - 0.96 / fig.get_figheight()),
               ncols=3, frameon=False)
    finish(fig, output, "m24_02_precursor_leads.png")


def plot_policies(rows, output):
    heldout = defaultdict(list)
    for row in rows:
        if row["split"] == "heldout":
            heldout[row["origin"], row["policy"]].append(row)
    origins = sorted({origin for origin, _ in heldout})
    known = [policy for policy in POLICIES if any((origin, policy) in heldout for origin in origins)]
    fig, axes = plt.subplots(2, 2, figsize=(12.4, 7.3), sharex="col", sharey="row")
    fig.subplots_adjust(left=0.1, right=0.973, top=0.764, bottom=0.14, hspace=0.27, wspace=0.15)
    heading(fig, "Held-out extraction policies and the variable-wait benchmark",
            "The denominator is each origin's variable-wait grid maximum. Elapsed time includes disconnected waiting.")
    for col, (tau, title) in enumerate(((0, "Stay connected"), (2, "Fixed disconnected wait"))):
        for index, policy in enumerate(known):
            color, marker, _ = POLICIES[policy]
            offset = 0.15 * (index - (len(known) - 1) / 2)
            for slot, origin in enumerate(origins):
                candidates = heldout.get((origin, policy), [])
                if policy == "variable_wait_oracle":
                    records = candidates
                else:
                    records = [row for row in candidates if number(row, "tau") == tau]
                if records:
                    result = max(records, key=lambda row: number(row, "net_work"))
                    for level, field in enumerate(("variable_wait_fraction", "elapsed_total")):
                        value = number(result, field)
                        if math.isfinite(value):
                            axes[level, col].scatter(slot + offset, value, color=color, marker=marker,
                                                     s=42 if marker == "*" else 25, linewidths=1.05, zorder=3)
        axes[0, col].set_title(f"{title}  ($\\tau={tau}$)", loc="left", fontweight="bold", pad=9)
        axes[0, col].axhline(1, color=MUTED, linewidth=0.9, linestyle=":", zorder=1)
        axes[0, col].yaxis.set_major_formatter(PercentFormatter(xmax=1, decimals=0))
        axes[1, col].set_xticks(range(len(origins)), origins, rotation=30 if len(origins) > 6 else 0, ha="center")
        axes[1, col].set_xlim(-0.55, len(origins) - 0.45)
        axes[1, col].set_xlabel("Held-out origin")
        for level, label in enumerate(("Recovered fraction", "Elapsed time")):
            axis_style(axes[level, col], label if col == 0 else None)
    axes[0, 0].set_ylim(bottom=min(0, axes[0, 0].get_ylim()[0]))
    handles = [Line2D([], [], marker=marker, linestyle="none", color=color, label=label)
               for color, marker, label in (POLICIES[policy] for policy in known)]
    fig.legend(handles=handles, loc="upper left", bbox_to_anchor=(0.095, 1 - 0.98 / fig.get_figheight()),
               ncols=3, frameon=False)
    finish(fig, output, "m24_03_holdout_policies.png")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, help="Directory containing the M24 CSV results, defaulting to results")
    parser.add_argument("--output", type=Path, help="Figure directory, defaulting to figures in the milestone or --data")
    args = parser.parse_args()
    data = args.data or ROOT / "results"
    output = args.output or (args.data or ROOT) / "figures"
    output.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "text.color": INK,
                         "axes.labelcolor": INK, "axes.titlecolor": INK, "legend.labelcolor": INK})
    policies = read_csv(data / "m24_policies.csv")
    plot_trajectory(read_csv(data / "m24_trajectories.csv"), policies, output)
    plot_precursors(read_csv(data / "m24_precursors.csv"), output)
    plot_policies(policies, output)


if __name__ == "__main__":
    main()
