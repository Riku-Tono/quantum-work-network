"""Build the source manifest and retrospective variable-wait comparator."""

import argparse
import hashlib
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent
M23 = ROOT.parent / "Milestone_23"
sys.path.insert(0, str(M23))
os.environ.setdefault("OPENBLAS_NUM_THREADS", "4")

from m21_observables import read_state
from m23_spectral import HORIZON, Dynamics
from run_m23 import COARSE_TAUS, Tables, csv_rows, largest, ms, refine_trials, scan


def sources(history):
    for row in csv_rows(history / "m23_sources.csv"):
        yield {
            "origin": row["source"], "split": "reference", "lineage": "M23 single",
            "source_cycle": int(row["source_cycle"]), "source_time": float(row["source_time"]),
            "coarse_path": row["filename"], "coarse_sha256": row["sha256"],
            "half_path": row["filename"], "half_sha256": row["sha256"],
        }

    snapshots = {
        (row["scan"], int(row["cycle"]), row["resolution"]): row
        for row in csv_rows(history / "repeat" / "m23_state_manifest.csv")
        if row["phase"] == "after"
    }
    for row in csv_rows(history / "repeat" / "m23_repeated.csv"):
        cycle = int(row["cycle"])
        if cycle not in (4, 7, 8) or row["accepted"] != "True":
            continue
        lineage = row["strategy"]
        coarse = snapshots[row["scan"], cycle, "coarse"]
        half = snapshots[row["scan"], cycle, "half"]
        if coarse["time"] != row["time"] or half["time"] != row["time"]:
            raise ValueError(f"Source time mismatch for {lineage}{cycle:02d}")
        yield {
            "origin": f"{lineage}{cycle:02d}", "split": "heldout", "lineage": f"M23 repeat {lineage}",
            "source_cycle": cycle, "source_time": float(row["time"]),
            "coarse_path": f"repeat/{coarse['filename']}", "coarse_sha256": coarse["sha256"],
            "half_path": f"repeat/{half['filename']}", "half_sha256": half["sha256"],
        }


def load_source(history, source):
    densities = {}
    for resolution in ("coarse", "half"):
        path = history / source[f"{resolution}_path"]
        fingerprint = hashlib.sha256(path.read_bytes()).hexdigest().upper()
        if fingerprint != source[f"{resolution}_sha256"]:
            raise ValueError(f"Source SHA-256 mismatch: {path}")
        if path not in densities:
            densities[path] = read_state(path, float(source["source_time"]))
    return tuple(densities[history / source[f"{resolution}_path"]] for resolution in ("coarse", "half"))


def search(model, tables, source, initial):
    def run(tag, taus):
        return scan(model, tables, tag, source["origin"], int(source["source_cycle"]) + 1,
                    ms(source["source_time"]), initial, taus, False, scan_table=False)

    coarse = run("A", COARSE_TAUS)
    _, lattice = refine_trials(coarse)
    refined = run("C", lattice)
    best = largest(coarse + refined)
    return ([trial.data for trial in coarse + refined], best.data)


def write_oracles(history, destination):
    destination.mkdir(parents=True, exist_ok=True)
    manifest = list(sources(history))
    if len(manifest) != 12 or len({row["coarse_sha256"] for row in manifest}) != len(manifest):
        raise ValueError("Expected 12 distinct registered origin states")

    published_waits = csv_rows(history / "m23_wait_summary.csv")
    published_comparison = {(r["source"], r["strategy"]): r
                            for r in csv_rows(history / "m23_policy_comparison.csv")}
    repeated = {(r["strategy"], int(r["cycle"])): r
                for r in csv_rows(history / "repeat" / "m23_repeated.csv")}
    tables = Tables(destination)
    model = Dynamics(HORIZON)
    try:
        for source in manifest:
            start = time.perf_counter()
            origin = source["origin"]
            initial = load_source(history, source)
            tables.add("m24_sources", source)
            if source["split"] == "reference":
                candidates = [r for r in published_waits if r["source"] == origin]
                winner = min(candidates, key=lambda r: (-float(r["max_net"]),
                                                        float(r["best_elapsed_total"]), float(r["tau"])))
                check = published_comparison[origin, "C"]
                if any(float(winner[k]) != float(check[k]) for k in ("tau", "max_net", "best_elapsed_total")):
                    raise ValueError(f"M23 wait summary and policy table disagree for {origin}")
                provenance = "published_m23_single"
            else:
                candidates, winner = search(model, tables, source, initial)
                provenance = "recomputed_m23_grid"
                if origin.startswith("C"):
                    check = repeated["C", int(source["source_cycle"]) + 1]
                    if (float(winner["tau"]) != float(check["tau"])
                            or float(winner["best_elapsed_total"]) != float(check["elapsed_total"])
                            or abs(float(winner["max_net"]) - float(check["pre_candidate_net"])) > 1e-12):
                        raise ValueError(f"Recomputed comparator disagrees with M23 repeat for {origin}")
            for row in candidates:
                tables.add("m24_wait_search", {
                    "origin": origin, "split": source["split"], "provenance": provenance,
                    "stage": row["scan"], "tau": row["tau"], "candidate_count": row["candidate_count"],
                    "elapsed_connected": row["best_elapsed_connected"],
                    "elapsed_total": row["best_elapsed_total"], "net_work": row["max_net"],
                    "net_work_half": row["max_net_half"], "selected": row is winner,
                })
            tables.flush()
            print(f"{origin}: tau={float(winner['tau']):.3f}, "
                  f"peak={float(winner['max_net']):.8g} ({time.perf_counter() - start:.1f}s)", flush=True)
    finally:
        tables.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--m23", type=Path, default=M23)
    args = parser.parse_args()
    write_oracles(args.m23, args.destination)
