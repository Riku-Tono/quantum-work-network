"""Reduced-state energy, current and instantaneous rates for the M23 model."""

from operator import index
from typing import NamedTuple

import numpy as np

from m23_spectral import (
    DIM,
    DIM_LOCAL,
    EXCHANGE_LOWER,
    G,
    GRID,
    LOAD_DIM,
    LOAD_LEVELS,
    local_diagnostics,
    partial,
    passive_load,
    rk_steps,
)

_LOAD_HAMILTONIAN = np.diag(LOAD_LEVELS)
_TERMINAL_EXCHANGE = EXCHANGE_LOWER + EXCHANGE_LOWER.T


def terminal_rate(dynamics, rho, coupling=G):
    """Reference calculation of the physical derivative from a full density matrix."""
    hamiltonian = dynamics.h[coupling]
    return partial(-1j * (hamiltonian @ rho - rho @ hamiltonian))


def _trace_terminal_spin(terminal):
    return terminal[..., :LOAD_DIM, :LOAD_DIM] + terminal[..., LOAD_DIM:, LOAD_DIM:]


def _observe_load_rate(terminal, load_rate, observations):
    _, _, unitary = passive_load(terminal)
    rotated_rate = unitary @ load_rate @ unitary.conj().swapaxes(-1, -2)
    energy_rate = load_rate.diagonal(axis1=-2, axis2=-1).real @ LOAD_LEVELS
    passive_rate = rotated_rate.diagonal(axis1=-2, axis2=-1).real @ LOAD_LEVELS
    observations.update(
        load_energy_rate=energy_rate,
        load_passive_energy_rate=passive_rate,
        load_ergotropy_rate=energy_rate - passive_rate,
        current_identity_error=np.abs(energy_rate - observations["load_current"]),
    )
    return observations


def observe(terminal, terminal_rate=None):
    """Observe connected 6×6 densities and their optional Hamiltonian derivatives.

    Leading dimensions are arbitrary. The passive energy derivative uses the
    eigenprojectors of the instantaneous load density in decreasing eigenvalue
    order, with the M23 nondegeneracy tolerance.
    """
    observations = local_diagnostics(terminal)
    if terminal_rate is None:
        return observations

    exchange_rate = np.einsum("...ij,ji->...", terminal_rate, EXCHANGE_LOWER)
    observations["load_current_rate"] = -2 * G * exchange_rate.imag
    return _observe_load_rate(terminal, _trace_terminal_spin(terminal_rate), observations)


def observe_local(terminal):
    """Infer the load rates from the instantaneous connected terminal-load state."""
    load = _trace_terminal_spin(terminal)
    load_commutator = _LOAD_HAMILTONIAN @ load - load @ _LOAD_HAMILTONIAN
    exchange_commutator = _TERMINAL_EXCHANGE @ terminal - terminal @ _TERMINAL_EXCHANGE
    # A commutator with the chain Hamiltonian has zero partial trace over the chain.
    load_rate = -1j * (load_commutator + G * _trace_terminal_spin(exchange_commutator))
    return _observe_load_rate(terminal, load_rate, local_diagnostics(terminal))


class _Projection(NamedTuple):
    rows: np.ndarray
    columns: np.ndarray
    coefficients: np.ndarray
    advance: np.ndarray


class ConnectedObservations:
    """Project the connected-state RK4 evolution and its Hamiltonian derivative.

    ``spectra`` holds one 384×384 density or a batch in the M23 connected
    eigenbasis. ``point`` and ``prefix`` only project requested samples.
    ``grid`` is the offline, batched evaluator using M23's shared time kernels.
    The rate is the Liouville generator evaluated at each RK4 sample. Set
    ``with_rate=False`` to project only densities and return None for the rate.
    """

    def __init__(self, dynamics, spectra, dt, *, with_rate=True):
        self.dynamics = dynamics
        self.dt = dt
        spectra = np.asarray(spectra)
        self.single = spectra.ndim == 2
        if self.single:
            spectra = spectra[None, ...]
        if spectra.ndim != 3 or spectra.shape[-2:] != (DIM, DIM) or not len(spectra):
            raise ValueError(f"Expected connected-basis spectra with shape ({DIM},{DIM}) or (n,{DIM},{DIM})")
        self.batch_size = len(spectra)
        self.channels = 2 if with_rate else 1
        self.length = dynamics.horizon // GRID + 1
        self.projections = []
        connected = dynamics.connected
        step_count = rk_steps(GRID, dt)
        for left, right, pairs, weights in dynamics.groups:
            coefficients = spectra[:, left, right].T[:, :, None] * weights[:, None, :]
            if with_rate:
                generator = -1j * (connected.eigenvalues[left] - connected.eigenvalues[right])
                coefficients = np.stack((coefficients, coefficients * generator[:, None, None]), axis=2)
            rows, columns = np.asarray(pairs).T
            self.projections.append(_Projection(
                rows,
                columns,
                coefficients.reshape(len(left), -1),
                connected.logs[dt][left, right] * step_count,
            ))

    def _assemble(self, outputs):
        terminal_and_rate = np.empty(outputs[0].shape[:-1] + (DIM_LOCAL, DIM_LOCAL), dtype=np.complex128)
        for (rows, columns, _, _), output in zip(self.projections, outputs, strict=True):
            terminal_and_rate[..., rows, columns] = output
            terminal_and_rate[..., columns, rows] = output.conj()
        diagonal = np.arange(DIM_LOCAL)
        terminal_and_rate[..., diagonal, diagonal] = terminal_and_rate[..., diagonal, diagonal].real
        channels = np.moveaxis(terminal_and_rate, -3, 0)
        if self.single:
            channels = channels[:, 0]
        return channels[0], channels[1] if self.channels == 2 else None

    def _project(self, phases):
        return self._assemble([
            (phase @ projection.coefficients).reshape(self.batch_size, self.channels, -1)
            for projection, phase in zip(self.projections, phases, strict=True)
        ])

    def _check_length(self, length):
        length = index(length)
        if not 1 <= length <= self.length:
            raise ValueError(f"Grid length must be in [1, {self.length}]")
        return length

    def point(self, k):
        """Return (terminal, rate) at connected time ``k * GRID`` milliseconds."""
        k = index(k)
        if not 0 <= k < self.length:
            raise ValueError(f"Grid index must be in [0, {self.length - 1}]")
        return self._project([np.exp(k * projection.advance) for projection in self.projections])

    def prefix(self, length, stride=1):
        """Yield (terminal, rate) at indices ``range(0, length, stride)`` on demand."""
        length = self._check_length(length)
        stride = index(stride)
        if stride < 1:
            raise ValueError("Grid stride must be positive")
        phases = [np.ones_like(projection.advance) for projection in self.projections]
        increments = [np.exp(stride * projection.advance) for projection in self.projections]
        for k in range(0, length, stride):
            if k:
                for phase, increment in zip(phases, increments, strict=True):
                    phase *= increment
            yield self._project(phases)

    def grid(self, length):
        """Return terminal and rate arrays with axis order (batch, time, 6, 6)."""
        length = self._check_length(length)
        outputs = []
        for group, projection in enumerate(self.projections):
            kernel = self.dynamics.time_kernel(group, self.dt)[:length]
            output = kernel @ projection.coefficients
            outputs.append(output.reshape(length, self.batch_size, self.channels, -1).swapaxes(0, 1))
        return self._assemble(outputs)
