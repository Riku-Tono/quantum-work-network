# M24 再現手順

M23 の7サイト鎖・3準位負荷モデルを用い、負荷エネルギー、受動エネルギーと局所仕事の時間発展を調べる。既存の3起点と、M23 の反復枝 A/B/C の第4・7・8回抽出後の9起点を使う。

[報告書](MILESTONE_24_ERGOTROPY_TIMING_REPORT.md) · [起点とハッシュ](results/m24_sources.csv) · [軌道](results/m24_trajectories.csv) · [停止規則と対照](results/m24_policies.csv)

## 実行

PowerShell から `Milestone_24` をカレントディレクトリにする。Python 3.14 を使用する。隣の `Milestone_23` に正式展開済みの入力、CSV、公式ZIPが必要。

```powershell
py -3.14 -m pip install -r ../Milestone_23/requirements.txt
$env:OPENBLAS_NUM_THREADS = '4'
py -3.14 -B m24_oracles.py redo
py -3.14 -B run_m24.py redo
py -3.14 -B verify_m24.py redo
py -3.14 -B m24_plots.py --data redo --output redo/figures
```

`m24_oracles.py` は M23 の正式単回比較を読み、追加9起点の可変待機比較を再計算する。`run_m24.py` は各経路でオンライン規則を先に実行し、その後に全軌道を評価する。再計算先には新しいディレクトリ名を指定する。配布結果の監査は `py -3.14 -B verify_m24.py results`。

## データ

| ファイル | 内容 |
| --- | --- |
| `m24_sources.csv` | 起点、履歴、絶対モデル時刻、粗・半刻みの初期状態と SHA-256 |
| `m24_wait_search.csv` | M23 と同じ粗・精待機格子での正味仕事最大点。`selected=True` は起点ごとの可変待機最大 |
| `m24_trajectories.csv` | 再接続後 0.02 刻みのエネルギー、流入電流、変化率、切替・抽出込みの正味仕事 |
| `m24_physics.csv` | 経路ごとの電流恒等式、直接微分、粗半差、エネルギーの変動幅、最大点の診断 |
| `m24_precursors.csv` | 各信号の最初の検出と、窓内最大の近傍を指した検出、局所・窓内最大との一致数 |
| `m24_policies.csv` | 決定と実行の時刻、正味仕事、同じ待機と可変待機の最大点に対する達成率、直接エネルギー会計 |
| `m24_fixed_delay.csv` | 参照3起点で推定した、待機ごとの固定抽出遅延 |

`elapsed_connected` は接続区間の経過、`elapsed_total` は待機込みの起点からの経過、`time` は絶対モデル時刻。τ=0 は結合を維持する。`lead` は最大点の時刻から信号の検出時刻を引いた値で、正値が先行を表す。`target_error` は信号が指した抽出予定時刻から最大点の時刻を引いた値。`deployable=True` は待機が事前に固定され、抽出の決定にその起点の将来値を参照しない比較。観測量はシミュレーションで得た縮約状態から計算する。
