"""One-pass extraction decisions and corresponding causal signal events."""

from dataclasses import dataclass
import math

from m23_spectral import FLOOR, GRID

STEP = GRID / 1000
FORECAST_WINDOW = 0.10
CURRENT = "current_turn"
TURN = "ergotropy_turn"
FORECAST = "ergotropy_forecast"
RULES = (CURRENT, TURN, FORECAST)


@dataclass(frozen=True)
class Decision:
    observed_index: int
    extraction_index: int
    reason: str


def targets(index, previous, present, last):
    if previous is None:
        return {}
    events = {}
    if previous["load_current"] > 0 >= present["load_current"]:
        events[CURRENT] = index
    if present["load_ergotropy"] <= FLOOR:
        return events
    previous_rate = previous["load_ergotropy_rate"]
    rate = present["load_ergotropy_rate"]
    if previous_rate > 0 >= rate:
        events[TURN] = index
    if previous_rate > rate > 0:
        delay = STEP * rate / (previous_rate - rate)
        if delay <= FORECAST_WINDOW:
            proposed = index + max(1, math.floor(delay / STEP + 0.5))
            if proposed <= last:
                events[FORECAST] = proposed
    return events


def decide(samples, count):
    """Consume a prefix of an iterable, scheduling future extraction irrevocably."""
    decisions = {}
    previous = None
    last = count - 1
    for index, present in enumerate(samples):
        for rule, stop in targets(index, previous, present, last).items():
            if rule not in decisions:
                decisions[rule] = Decision(index, stop, "signal")
        if index == last:
            for rule in RULES:
                if rule not in decisions:
                    decisions[rule] = Decision(last, last, "horizon")
        if len(decisions) == len(RULES):
            return decisions
        previous = present
    raise ValueError("Observation stream ended before decisions were made")
