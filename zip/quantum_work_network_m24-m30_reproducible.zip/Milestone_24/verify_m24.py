"""Audit M24 CSVs against the published M23 archive and declared stopping rules."""

import argparse
from collections import defaultdict
import csv
import hashlib
import io
import math
from pathlib import Path, PurePosixPath
from statistics import correlation
import struct
import sys
from zipfile import ZipFile


ROOT = Path(__file__).resolve().parent
M23 = ROOT.parent / "Milestone_23"
HORIZON = 18_000
GRID = 20
TOL = 1e-12
HALF_TOL = 1e-10
COARSE_WAITS = set(range(0, 6001, 250))
REFERENCE = {"S0", "S1", "S2"}
HELDOUT = {f"{letter}{cycle:02d}" for letter in "ABC" for cycle in (4, 7, 8)}
SIGNAL_POLICIES = {"current_turn", "ergotropy_turn", "ergotropy_forecast"}


def insist(condition, message):
    if not condition:
        raise ValueError(message)


def read_rows(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def index(rows, key):
    indexed = {}
    for row in rows:
        value = key(row)
        insist(value not in indexed, f"Duplicate key {value}")
        indexed[value] = row
    return indexed


def number(row, name):
    value = float(row[name])
    insist(math.isfinite(value), f"Nonfinite {name} in {row}")
    return value


def ticks(row, name):
    value = number(row, name)
    clock = round(value * 1000)
    insist(abs(value - clock / 1000) <= TOL, f"Off-lattice {name} in {row}")
    return clock


def flag(row, name):
    value = row[name].casefold()
    insist(value in ("true", "false"), f"Invalid {name} flag in {row}")
    return value == "true"


def close(actual, expected, message, tolerance=TOL):
    insist(abs(actual - expected) <= tolerance, f"{message}: {actual!r} != {expected!r}")


class PublishedM23:
    def __init__(self, directory, archive):
        self.directory = directory
        self.archive = archive
        self.verified = {}

    def read(self, filename):
        relative = PurePosixPath(filename)
        insist(relative.parts and not relative.is_absolute() and ".." not in relative.parts
               and "\\" not in filename and ":" not in filename, f"Invalid archived path {filename}")
        if filename not in self.verified:
            contents = self.archive.read(f"Milestone_23/{relative.as_posix()}")
            insist(contents == (self.directory / relative).read_bytes(), f"Archive/file mismatch for {filename}")
            self.verified[filename] = contents
        return self.verified[filename]

    def rows(self, filename):
        stream = io.StringIO(self.read(filename).decode("utf-8-sig"), newline="")
        return list(csv.DictReader(stream))

    def state(self, filename, expected_sha, expected_time):
        data = self.read(filename)
        digest = hashlib.sha256(data).hexdigest().upper()
        insist(digest == expected_sha, f"State SHA-256 mismatch for {filename}")
        magic, dimension, time = struct.unpack_from("<8sQd", data)
        insist(magic == b"QWNRHO1\0" and dimension == 384 and len(data) == 24 + 384 * 384 * 16,
               f"Invalid density file {filename}")
        close(time, expected_time / 1000, f"State time mismatch for {filename}")


def check_sources(data, published):
    origins = index(read_rows(data / "m24_sources.csv"), lambda row: row["origin"])
    insist(origins.keys() == REFERENCE | HELDOUT, "Origin IDs differ from the 12 registered states")
    insist(len({row["coarse_sha256"] for row in origins.values()}) == len(origins), "Duplicate coarse origin state")
    reference = index(published.rows("m23_sources.csv"), lambda row: row["source"])
    repeated = index(published.rows("repeat/m23_repeated.csv"), lambda row: (row["strategy"], int(row["cycle"])))
    saved_after = index(
        (row for row in published.rows("repeat/m23_state_manifest.csv") if row["phase"] == "after"),
        lambda row: (row["scan"], int(row["cycle"]), row["resolution"]),
    )

    for origin, row in origins.items():
        cycle = int(row["source_cycle"])
        source_time = ticks(row, "source_time")
        if origin in REFERENCE:
            insist((row["split"], row["lineage"]) == ("reference", "M23 single"), f"Wrong split for {origin}")
            witness = reference[origin]
            insist(cycle == int(witness["source_cycle"]), f"Wrong source cycle for {origin}")
            insist(source_time == ticks(witness, "source_time"), f"Wrong source time for {origin}")
            paths = [(witness["filename"], witness["sha256"])] * 2
        else:
            lineage = origin[0]
            insist((row["split"], row["lineage"]) == ("heldout", f"M23 repeat {lineage}"), f"Wrong split for {origin}")
            insist(cycle == int(origin[1:]), f"Wrong source cycle for {origin}")
            witness = repeated[lineage, cycle]
            insist(flag(witness, "accepted") and source_time == ticks(witness, "time"), f"Wrong M23 repeat origin for {origin}")
            paths = []
            for resolution in ("coarse", "half"):
                saved = saved_after[witness["scan"], cycle, resolution]
                insist(ticks(saved, "time") == source_time and number(saved, "g") == 0.25,
                       f"Wrong M23 after-state metadata for {origin}/{resolution}")
                paths.append((f"repeat/{saved['filename']}", saved["sha256"]))
        for resolution, (filename, sha256) in zip(("coarse", "half"), paths, strict=True):
            insist((row[f"{resolution}_path"], row[f"{resolution}_sha256"]) == (filename, sha256),
                   f"Wrong origin path or hash for {origin}/{resolution}")
            published.state(filename, sha256, source_time)
    return origins, repeated


def candidate_rank(row):
    return -number(row, "net_work"), ticks(row, "elapsed_total"), ticks(row, "tau")


def refined_waits(coarse):
    local_peaks = []
    for tau in sorted(coarse):
        value = number(coarse[tau], "net_work")
        left = tau == 0 or number(coarse[tau - 250], "net_work") < value
        right = tau == 6000 or number(coarse[tau + 250], "net_work") <= value
        if left and right:
            local_peaks.append((-value, tau))
    extend = (
        number(coarse[6000], "net_work") - number(coarse[5750], "net_work")
        > TOL + sum(abs(number(coarse[tau], "net_work") - number(coarse[tau], "net_work_half"))
                    for tau in (5750, 6000))
    )
    fine = set()
    for _, center in sorted(local_peaks)[:3]:
        upper = 6250 if center == 6000 and extend else 6000
        fine.update(range(max(0, center - 250), min(upper, center + 250) + 1, 25))
    return fine


def check_waits(data, published, origins, repeated):
    groups = defaultdict(list)
    for row in read_rows(data / "m24_wait_search.csv"):
        groups[row["origin"]].append(row)
    insist(groups.keys() == origins.keys(), "Waiting-search coverage differs from origin manifest")
    archived = index(published.rows("m23_wait_summary.csv"),
                     lambda r: (r["source"], r["scan"], ticks(r, "tau")))
    published_c = index((r for r in published.rows("m23_policy_comparison.csv") if r["strategy"] == "C"),
                        lambda r: r["source"])

    winners = {}
    for origin, rows in groups.items():
        candidates = index(rows, lambda r: (r["stage"], ticks(r, "tau")))
        coarse = {tau: row for (stage, tau), row in candidates.items() if stage == "A"}
        insist(coarse.keys() == COARSE_WAITS, f"Incomplete coarse wait lattice for {origin}")
        fine = {tau for stage, tau in candidates if stage == "C"}
        insist(fine == refined_waits(coarse) and len(candidates) == len(coarse) + len(fine),
               f"Incorrect fine wait lattice for {origin}")
        for (stage, tau), row in candidates.items():
            provenance = "published_m23_single" if origin in REFERENCE else "recomputed_m23_grid"
            insist(row["split"] == origins[origin]["split"] and row["provenance"] == provenance,
                   f"Incorrect wait provenance for {origin}/{stage}/{tau}")
            elapsed = ticks(row, "elapsed_connected")
            insist(elapsed % GRID == 0 and 0 <= elapsed <= HORIZON - tau
                   and ticks(row, "elapsed_total") == tau + elapsed
                   and int(row["candidate_count"]) == (HORIZON - tau) // GRID + 1,
                   f"Invalid candidate clock metadata for {origin}/{stage}/{tau}")
            close(number(row, "net_work"), number(row, "net_work_half"),
                  f"Wait-summary coarse/half agreement for {origin}/{stage}/{tau}", HALF_TOL)
            if origin in REFERENCE:
                archive_row = archived[origin, stage, tau]
                for current, original in (("candidate_count", "candidate_count"),
                                          ("elapsed_connected", "best_elapsed_connected"),
                                          ("elapsed_total", "best_elapsed_total"),
                                          ("net_work", "max_net"), ("net_work_half", "max_net_half")):
                    insist(number(row, current) == number(archive_row, original),
                           f"Published M23 candidate differs for {origin}/{stage}/{tau}/{current}")

        winner = min(rows, key=candidate_rank)
        selected = [row for row in rows if flag(row, "selected")]
        insist(selected == [winner], f"Wrong retrospective comparator winner for {origin}")
        if origin in REFERENCE:
            reference = published_c[origin]
            insist(candidate_rank(winner) == (-number(reference, "max_net"),
                                              ticks(reference, "best_elapsed_total"), ticks(reference, "tau")),
                   f"Published strategy C winner differs for {origin}")
        elif origin.startswith("C"):
            reference = repeated["C", int(origins[origin]["source_cycle"]) + 1]
            insist(ticks(winner, "tau") == ticks(reference, "tau")
                   and ticks(winner, "elapsed_total") == ticks(reference, "elapsed_total"),
                   f"M23 continuation winner clock differs for {origin}")
            close(number(winner, "net_work"), number(reference, "pre_candidate_net"),
                  f"M23 continuation winner work differs for {origin}")
        winners[origin] = winner
    return groups, winners


def check_trajectories(data, origins, waits, winners):
    paths = defaultdict(list)
    for row in read_rows(data / "m24_trajectories.csv"):
        paths[row["origin"], ticks(row, "tau")].append(row)
    expected = {(origin, tau) for origin, peak in winners.items() for tau in (0, 2000, ticks(peak, "tau"))}
    insist(paths.keys() == expected, "Trajectory coverage differs from fixed and selected variable waits")
    peaks = {}
    for key, rows in paths.items():
        origin, tau = key
        rows.sort(key=lambda row: ticks(row, "elapsed_connected"))
        insist(len(rows) == (HORIZON - tau) // GRID + 1, f"Incomplete grid for {key}")
        source = origins[origin]
        time0 = ticks(source, "source_time")
        role = {0: "connected", 2000: "fixed_wait"}.get(tau, "oracle_wait")
        cut_on, reconnect_on = (number(rows[0], field) for field in ("cut_on", "reconnect_on"))
        if tau == 0:
            insist(cut_on == reconnect_on == 0, f"Unexpected switch for {key}")
        else:
            close(reconnect_on, 0.5 * number(rows[0], "c_real"), f"Reconnect work for {key}", 1e-15)
        for step, row in enumerate(rows):
            elapsed = step * GRID
            insist((row["split"], row["lineage"], row["tau_role"]) == (source["split"], source["lineage"], role),
                   f"Trajectory provenance differs for {key}/{elapsed}")
            insist((ticks(row, "elapsed_connected"), ticks(row, "elapsed_total"), ticks(row, "time"))
                   == (elapsed, tau + elapsed, time0 + tau + elapsed), f"Invalid trajectory clock for {key}/{elapsed}")
            load, passive, erg = (number(row, field) for field in ("load_energy", "load_passive_energy", "load_ergotropy"))
            current, e_rate, p_rate, erg_rate = (number(row, field) for field in
                ("load_current", "load_energy_rate", "load_passive_energy_rate", "load_ergotropy_rate"))
            close(erg, load - passive, f"Ergotropy energy identity for {key}/{elapsed}")
            close(current, -0.5 * number(row, "c_imag"), f"Current coherence identity for {key}/{elapsed}")
            close(current, e_rate, f"Current energy identity for {key}/{elapsed}")
            close(erg_rate, current - p_rate, f"Ergotropy rate identity for {key}/{elapsed}")
            for field, switch in (("cut_on", cut_on), ("reconnect_on", reconnect_on)):
                insist(number(row, field) == switch, f"Changing switch term for {key}/{elapsed}/{field}")
            net = number(row, "net_work")
            close(net, erg - number(row, "interaction_jump") - cut_on - reconnect_on,
                  f"Net work accounting for {key}/{elapsed}")
            close(net, number(row, "net_work_half"), f"Trajectory coarse/half agreement for {key}/{elapsed}", HALF_TOL)
        peak = min(rows, key=candidate_rank)
        ranked = min((row for row in waits[origin] if ticks(row, "tau") == tau), key=candidate_rank)
        insist(ticks(peak, "elapsed_total") == ticks(ranked, "elapsed_total"), f"Retrospective peak time differs for {key}")
        for field in ("net_work", "net_work_half"):
            close(number(peak, field), number(ranked, field), f"Retrospective peak value differs for {key}/{field}")
        peaks[key] = peak
    return paths, peaks


def signal_events(rows):
    """Recover physical trigger times from consecutive observations."""
    events = {name: [] for name in sorted(SIGNAL_POLICIES | {"passive_rate_turn"})}
    forecast_previous = False
    for step, (left, right) in enumerate(zip(rows, rows[1:]), 1):
        if number(left, "load_current") > 0 and number(right, "load_current") <= 0:
            events["current_turn"].append((step, step))
        if number(left, "load_passive_energy_rate") > 0 >= number(right, "load_passive_energy_rate"):
            events["passive_rate_turn"].append((step, step))
        if number(right, "load_ergotropy") <= TOL:
            forecast_previous = False
            continue
        old_slope = number(left, "load_ergotropy_rate")
        new_slope = number(right, "load_ergotropy_rate")
        if old_slope > 0 >= new_slope:
            events["ergotropy_turn"].append((step, step))
        forecast_now = False
        if old_slope > new_slope > 0:
            intervals = new_slope / (old_slope - new_slope)
            stop = step + max(1, math.floor(intervals + 0.5))
            if intervals <= 5 and stop < len(rows):
                forecast_now = True
                if not forecast_previous:
                    events["ergotropy_forecast"].append((step, stop))
        forecast_previous = forecast_now
    return events


def check_training(data, paths, peaks):
    training = index(read_rows(data / "m24_fixed_delay.csv"), lambda r: ticks(r, "tau"))
    insist(training.keys() == {0, 2000}, "Wrong fixed-delay wait coverage")
    fitted = {}
    for tau, row in training.items():
        insist(set(row["training_origins"].split()) == REFERENCE, f"Fixed-delay training leakage at wait {tau}")
        ordered = sorted(REFERENCE)
        windows = [paths[origin, tau] for origin in ordered]
        divisors = [number(peaks[origin, tau], "net_work") for origin in ordered]
        values = [sum(number(record, "net_work") / best for record, best in zip(records, divisors, strict=True))
                  / len(REFERENCE) for records in zip(*windows, strict=True)]
        winner = max(range(len(values)), key=values.__getitem__)
        insist(ticks(row, "elapsed_connected") == winner * GRID, f"Incorrect learned fixed delay for {tau}")
        close(number(row, "mean_same_wait_fraction"), values[winner], f"Fixed-delay train score for {tau}")
        fitted[tau] = winner
    return fitted


def check_policies(data, origins, paths, peaks, winners, events):
    trained = check_training(data, paths, peaks)
    policies = index(read_rows(data / "m24_policies.csv"), lambda r: (r["origin"], ticks(r, "tau"), r["policy"]))
    expected = {}
    for (origin, tau), rows in paths.items():
        best = ticks(peaks[origin, tau], "elapsed_connected") // GRID
        expected[origin, tau, "same_wait_oracle"] = (None, best, "retrospective")
        if tau == ticks(winners[origin], "tau"):
            expected[origin, tau, "variable_wait_oracle"] = (None, best, "retrospective")
        if origin in HELDOUT and tau in trained:
            expected[origin, tau, "fixed_delay"] = (0, trained[tau], "fixed")
        for policy in SIGNAL_POLICIES:
            sequence = events[origin, tau][policy]
            expected[origin, tau, policy] = (*sequence[0], "signal") if sequence else (len(rows)-1, len(rows)-1, "horizon")
    insist(policies.keys() == expected.keys(), "Incorrect policy coverage or retrospective wait counted as a live fixed control")

    for key, row in policies.items():
        origin, tau, name = key
        source = origins[origin]
        seen, step, reason = expected[key]
        tau_role = "oracle_wait" if name == "variable_wait_oracle" else paths[origin, tau][0]["tau_role"]
        insist((row["split"], row["lineage"], row["tau_role"], row["stop_reason"])
               == (source["split"], source["lineage"], tau_role, reason), f"Incorrect policy metadata for {key}")
        insist(flag(row, "deployable") == (seen is not None and tau_role != "oracle_wait"), f"Oracle use credited as live for {key}")
        elapsed = tau + step * GRID
        insist((ticks(row, "elapsed_connected"), ticks(row, "elapsed_total")) == (step * GRID, elapsed),
               f"Incorrect extraction time for {key}")
        if seen is None:
            insist(row["decision_elapsed_total"] == row["observed_count"] == "", f"Retrospective decision claims observation timing for {key}")
        else:
            insist(ticks(row, "decision_elapsed_total") == tau + seen * GRID and
                   int(row["observed_count"]) == (0 if reason == "fixed" else seen + 1), f"Wrong causal prefix for {key}")
        if name in SIGNAL_POLICIES:
            half_elapsed = ticks(row, "half_replay_elapsed_total")
            insist(half_elapsed == elapsed, f"Half-step replay changes the extraction time for {key}")
        else:
            insist(not row["half_replay_elapsed_total"], f"Unexpected half-step rule replay for {key}")

        source_row = paths[origin, tau][step]
        coarse, half = (number(source_row, field) for field in ("net_work", "net_work_half"))
        direct = number(row, "direct_net")
        close(number(row, "candidate_net"), coarse, f"Policy candidate score for {key}")
        close(number(row, "net_work_half"), half, f"Policy half score for {key}")
        close(direct, coarse, f"Direct accounting score for {key}")
        close(number(row, "direct_net_half"), half, f"Direct half accounting score for {key}")
        close(number(row, "direct_balance_residual"), 0, f"Accounting balance for {key}")
        accepted = coarse - abs(coarse - half) > TOL and direct > TOL
        insist(flag(row, "accepted") == accepted, f"Incorrect policy convergence gate for {key}")
        earned = coarse if accepted else 0.0
        same_peak = peaks[origin, tau]
        scores = {
            "net_work": earned,
            "same_wait_fraction": earned / number(same_peak, "net_work"),
            "variable_wait_fraction": earned / number(winners[origin], "net_work"),
            "same_wait_time_error": (elapsed - ticks(same_peak, "elapsed_total")) / 1000,
        }
        if elapsed:
            scores["rate"] = earned / (elapsed / 1000)
        else:
            insist(not row["rate"], f"Zero-duration policy has a rate for {key}")
        for field, score in scores.items():
            close(number(row, field), score, f"Policy {field} score for {key}")
    return len(policies)


def check_precursors(data, paths, peaks, events):
    records = index(read_rows(data / "m24_precursors.csv"), lambda r: (r["origin"], ticks(r, "tau"), r["signal"]))
    insist(records.keys() == {(*key, name) for key in paths for name in events[key]}, "Incorrect precursor coverage")
    for path_key, path in paths.items():
        _, tau = path_key
        work = [number(row, "net_work") for row in path]
        local = [k for k in range(1, len(path)-1) if work[k] > max(TOL, work[k-1]) and work[k] >= work[k+1]]
        peak = ticks(peaks[path_key], "elapsed_connected") // GRID
        times = range(tau, tau + len(path)*GRID, GRID)
        for name, values in events[path_key].items():
            key = (*path_key, name)
            row = records[key]
            insist(all(row[k] == path[0][k] for k in ("split", "lineage", "tau_role")), f"Wrong precursor provenance for {key}")
            insist(ticks(row, "peak_elapsed_total") == times[peak], f"Wrong retrospective precursor reference for {key}")
            insist(int(row["event_count"]) == len(values) and int(row["interior_local_peaks"]) == len(local),
                   f"Wrong precursor counts for {key}")
            near_global = [(i, j) for i, j in values if abs(j - peak) <= 5]
            near_local = [(i, j) for i, j in values if any(abs(j-k) <= 5 for k in local)]
            insist(int(row["global_hits"]) == len(near_global) and int(row["local_hits"]) == len(near_local)
                   and flag(row, "leading_global_hit") == any(i < peak for i, _ in near_global), f"Wrong precursor hits for {key}")
            columns = ("first_signal_elapsed_total", "first_target_elapsed_total", "signal_elapsed_total", "target_elapsed_total")
            if values:
                nearest = min(values, key=lambda item: (abs(item[1] - peak), item[0]))
                insist(tuple(ticks(row, field) for field in columns) == tuple(times[i] for i in (*values[0], *nearest)),
                       f"Wrong first or closest precursor for {key}")
                insist(ticks(row, "lead") == (peak - nearest[0]) * GRID and
                       ticks(row, "target_error") == (nearest[1] - peak) * GRID, f"Wrong precursor lead or error for {key}")
            else:
                insist(all(not row[field] for field in (*columns, "lead", "target_error")), f"Absent precursor has timing for {key}")
    return len(records)


def check_physics(data, paths, peaks):
    records = index(read_rows(data / "m24_physics.csv"), lambda r: (r["origin"], ticks(r, "tau")))
    insist(records.keys() == paths.keys(), "Incorrect physics-summary coverage")
    for key, path in paths.items():
        row, peak = records[key], peaks[key]
        insist(all(row[k] == path[0][k] for k in ("split", "lineage", "tau_role")), f"Wrong physics provenance for {key}")
        insist(int(row["samples"]) == len(path), f"Physics sample count for {key}")
        for field, tolerance in (("max_current_identity_error", TOL), ("max_wait_energy_drift", TOL),
                                 ("direct_peak_derivative_error", TOL), ("max_half_step_difference", HALF_TOL)):
            insist(0 <= number(row, field) <= tolerance, f"Numerical audit exceeds tolerance for {key}/{field}")
        for column, physical in (("current_at_peak", "load_current"), ("passive_rate_at_peak", "load_passive_energy_rate"),
                                 ("ergotropy_rate_at_peak", "load_ergotropy_rate"), ("elapsed_peak", "elapsed_total")):
            close(number(row, column), number(peak, physical), f"Peak summary for {key}/{column}")
        for column, physical in (("energy_span", "load_energy"), ("passive_span", "load_passive_energy"),
                                 ("ergotropy_span", "load_ergotropy")):
            values = [number(sample, physical) for sample in path]
            close(number(row, column), max(values) - min(values), f"Energy span for {key}/{column}")
        for column, physical in (("elapsed_energy_peak", "load_energy"), ("elapsed_ergotropy_peak", "load_ergotropy")):
            winner = max(path, key=lambda sample: number(sample, physical))
            insist(ticks(row, column) == ticks(winner, "elapsed_total"), f"Energy peak time for {key}/{column}")
        insist(flag(row, "peak_interior") == (peak is not path[0] and peak is not path[-1]), f"Wrong peak classification for {key}")
        current = [number(sample, "load_current") for sample in path]
        slope = [number(sample, "load_ergotropy_rate") for sample in path]
        resolved = [(a, b) for a, b in zip(current, slope, strict=True) if abs(a) > TOL and abs(b) > TOL]
        close(number(row, "current_ergotropy_rate_r"), correlation(current, slope), f"Current-growth correlation for {key}")
        close(number(row, "opposite_sign_fraction"), sum(a * b < 0 for a, b in resolved) / len(resolved),
              f"Current-growth opposite signs for {key}")
        close(number(row, "max_abs_net_minus_ergotropy"),
              max(abs(number(sample, "net_work") - number(sample, "load_ergotropy")) for sample in path),
              f"Net versus load ergotropy residual for {key}", 1e-15)
        close(number(row, "max_abs_interaction_jump"), max(abs(number(sample, "interaction_jump")) for sample in path),
              f"Extraction interaction maximum for {key}", 1e-15)
        integrated = error = 0.0
        energy0 = number(path[0], "load_energy")
        for step, (left, right) in enumerate(zip(current, current[1:]), 1):
            integrated += (GRID / 2000) * (left + right)
            error = max(error, abs(integrated - (number(path[step], "load_energy") - energy0)))
        close(number(row, "max_trapezoid_transport_error"), error, f"Trapezoidal transport residual for {key}")


def check_prefix_consumption(m23):
    # Verify the production streamer stops reading as soon as all decisions are recorded.
    sys.path.insert(0, str(m23))
    from m24_rules import decide

    def observations():
        for current, slope in zip((2, 1.5, -1, -1, -1), (3, 2.6, 1, 0.25, -0.25), strict=True):
            yield {"load_current": current, "load_ergotropy_rate": slope, "load_ergotropy": 1}
        raise ValueError("Decision streamer read beyond the prefix in the sentinel test")

    decisions = decide(observations(), 9)
    expected = {"current_turn": (2, 2), "ergotropy_forecast": (2, 3), "ergotropy_turn": (4, 4)}
    insist(decisions.keys() == expected.keys(), "Decision streamer returned an unexpected policy set")
    for name, clock in expected.items():
        choice = decisions[name]
        insist((choice.observed_index, choice.extraction_index) == clock and choice.reason == "signal",
               f"Sentinel trigger or precommitted extraction changed for {name}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("data", nargs="?", type=Path, default=ROOT / "results")
    parser.add_argument("--m23", type=Path, default=M23)
    parser.add_argument("--oracles-only", action="store_true")
    args = parser.parse_args()
    archive_path = args.m23 / "M23_all_results.zip"
    with archive_path.open("rb") as stream:
        observed = hashlib.file_digest(stream, "sha256").hexdigest()
    expected = (args.m23 / "M23_all_results.sha256").read_text(encoding="utf-8-sig").split()[0]
    insist(observed.casefold() == expected.casefold(), "Published M23 ZIP SHA-256 mismatch")
    with ZipFile(archive_path) as archive:
        published = PublishedM23(args.m23, archive)
        origins, repeated = check_sources(args.data, published)
        groups, winners = check_waits(args.data, published, origins, repeated)
    print(f"PASS: {len(origins)} verified origin states, {sum(map(len, groups.values()))} waiting candidates")
    if not args.oracles_only:
        paths, peaks = check_trajectories(args.data, origins, groups, winners)
        events = {key: signal_events(path) for key, path in paths.items()}
        policy_count = check_policies(args.data, origins, paths, peaks, winners, events)
        precursor_count = check_precursors(args.data, paths, peaks, events)
        check_physics(args.data, paths, peaks)
        check_prefix_consumption(args.m23)
        print(f"PASS: {len(paths)} trajectories ({sum(map(len, paths.values()))} samples), "
              f"{policy_count} policy outcomes, {precursor_count} precursor rows, prefix sentinel")


if __name__ == "__main__":
    main()
