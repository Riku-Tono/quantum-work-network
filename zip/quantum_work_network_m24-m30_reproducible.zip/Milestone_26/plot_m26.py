"""Render the eight M26 time-budget figures from its official CSV outputs."""

import argparse
from collections import defaultdict
from dataclasses import dataclass
import math
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / "Milestone_25"))

from plot_m25 import (  # noqa: E402
    BLUE, INK, MUTED, PURPLE, TEAL, ORIGINS, accepted, csv_rows, grouped, number,
    page_title, panel_title, plt, style_axis,
)
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator


PRIMARY = "S0"
POLICIES = {
    "A": (TEAL, "D", "-", "Forecast"),
    "B": (BLUE, "o", "--", "Ergotropy turn"),
    "C25": ("#93641B", "^", "-.", "Prior-work floor 25%"),
    "E": (PURPLE, "s", "-", "M23 variable-wait grid maximum"),
}
BRANCH_KEYS = [(origin, policy) for origin in ORIGINS for policy in POLICIES]
PAIRS = (("E", "A"), ("A", "B"))


@dataclass(frozen=True)
class Timeline:
    elapsed: list[float]
    work: list[float]
    count: list[int]
    end: float

    @classmethod
    def from_ledger(cls, rows, end):
        actions = accepted(rows)
        return cls(
            [0.0, *(number(row, "elapsed_total") for row in actions)],
            [0.0, *(number(row, "cumulative_net") for row in actions)],
            [0, *(int(row["count"]) for row in actions)],
            end,
        )


def policy_legend(*, filled=False):
    return [Line2D([], [], color=color, marker=marker, markerfacecolor=color if filled else "white", linestyle=pattern,
                   linewidth=1.45, label=f"{policy}  {label}")
            for policy, (color, marker, pattern, label) in POLICIES.items()]


def elapsed_grid(title, caption, handles, *, legend_cols=4, integer=False, scientific=True, ylabel=None):
    fig, axes = plt.subplots(2, 2, figsize=(12.5, 8.15), sharex=True)
    fig.subplots_adjust(left=0.105, right=0.967, top=0.77, bottom=0.107, wspace=0.25, hspace=0.44)
    page_title(fig, title, caption, handles, columns=legend_cols)
    for index, (origin, axis) in enumerate(zip(ORIGINS, axes.flat, strict=True)):
        panel_title(fig, axis, origin)
        style_axis(axis, xlabel="Total elapsed model time" if index >= 2 else None,
                   ylabel=ylabel if index % 2 == 0 else None, scientific=scientific)
        if integer:
            axis.yaxis.set_major_locator(MaxNLocator(integer=True, nbins=6))
    return fig, dict(zip(ORIGINS, axes.flat, strict=True))


def set_elapsed_limits(axes, ticks, *, include_zero=True):
    axis = next(iter(axes.values()))
    axis.set_xlim(0 if include_zero else ticks[0], ticks[-1])
    axis.set_xticks([0, *ticks] if include_zero else ticks)


def finish(fig, output, name):
    fig.savefig(output / f"m26_{name}.png", dpi=205, facecolor="white")
    plt.close(fig)


def fractions(start, end, work, segments):
    elapsed = [start + (end - start) * i / segments for i in range(segments + 1)]
    return elapsed, [work / time if time > 0 else 0.0 for time in elapsed]


def rate_profile(timeline):
    elapsed, rate = [0.0], [0.0]
    end = timeline.end
    for i, (left, work) in enumerate(zip(timeline.elapsed, timeline.work, strict=True)):
        right = timeline.elapsed[i + 1] if i + 1 < len(timeline.elapsed) else end
        elapsed.append(left)
        rate.append(work / left if left > 0 else 0.0)
        if right > left:
            points, values = fractions(left, right, work, 12)
            elapsed.extend(points[1:])
            rate.extend(values[1:])
    return elapsed, rate


def stair_profile(timeline, field):
    elapsed = timeline.elapsed.copy()
    values = getattr(timeline, field).copy()
    if timeline.end > elapsed[-1]:
        elapsed.append(timeline.end)
        values.append(values[-1])
    return elapsed, values


def time_trace(axis, policy, timeline, horizon, field):
    color, marker, pattern, _ = POLICIES[policy]
    is_rate = field == "rate"
    elapsed, values = rate_profile(timeline) if is_rate else stair_profile(timeline, field)
    axis.plot(elapsed, values, color=color, linewidth=1.45, linestyle=pattern,
              drawstyle="default" if is_rate else "steps-post")
    axis.scatter(elapsed[-1], values[-1], color=color, marker=marker, s=25, linewidths=0.85, zorder=4, clip_on=False)
    if timeline.end < horizon:
        tail = (fractions(timeline.end, horizon, timeline.work[-1], 80) if is_rate
                else ([elapsed[-1], horizon], [values[-1], values[-1]]))
        axis.plot(*tail, color=color, linewidth=1.2, linestyle=":", alpha=0.55)


def plot_time_profiles(timelines, ticks, output):
    plots = (
        ("01_work_over_time", "Credited net work over elapsed time", "Cumulative net work", "work"),
        ("02_rate_over_time", "Cumulative work per time over elapsed time", "Cumulative work per time", "rate"),
        ("03_count_over_time", "Accepted extractions over elapsed time", "Accepted extractions", "count"),
    )
    for name, title, ylabel, field in plots:
        tail = ("Afterward the rate declines as elapsed time increases." if field == "rate"
                else "Dotted tails carry the credited value forward after the branch ends.")
        caption = f"Markers show each branch's last observation. {tail}"
        fig, axes = elapsed_grid(title, caption, policy_legend(), ylabel=ylabel,
                                 scientific=field != "count", integer=field == "count")
        for origin, policy in BRANCH_KEYS:
            time_trace(axes[origin], policy, timelines[origin, policy], ticks[-1], field)
        for axis in axes.values():
            axis.set_ylim(bottom=0)
        set_elapsed_limits(axes, ticks)
        finish(fig, output, name)


def plot_actions(history, ticks, output):
    fig, axes = plt.subplots(2, 1, figsize=(11.9, 7.45), sharex=True)
    fig.subplots_adjust(left=0.115, right=0.964, top=0.77, bottom=0.11, hspace=0.33)
    page_title(fig, "Work and timing of each accepted extraction at S0",
               "Each point uses its extraction time. Dotted lines mark the tiny-work and short-interval cutoffs.",
               policy_legend())
    for policy, (color, marker, _, _) in POLICIES.items():
        rows = accepted(history[PRIMARY, policy])
        x = [number(row, "elapsed_total") for row in rows]
        for axis, field in zip(axes, ("net_work", "duration"), strict=True):
            y = [number(row, field) for row in rows]
            axis.scatter(x, y, color=color, marker=marker, s=18, linewidths=0, alpha=0.68, clip_on=False)
    for axis in axes:
        axis.set_yscale("log")
    axes[0].axhline(1e-8, color=MUTED, linestyle=":", linewidth=1.0, zorder=1)
    axes[1].axhline(0.10, color=MUTED, linestyle=":", linewidth=1.0, zorder=1)
    style_axis(axes[0], ylabel="Net work (log scale)")
    style_axis(axes[1], xlabel="Total elapsed model time", ylabel="Extraction interval (log scale)")
    set_elapsed_limits({PRIMARY: axes[1]}, ticks)
    finish(fig, output, "04_action_work_intervals")


def plot_interval_rates(groups, timelines, ticks, output):
    handles = policy_legend()
    handles.append(Line2D([], [], color=MUTED, linewidth=1.4, linestyle=":", label="Interval extends past branch end"))
    fig, axes = elapsed_grid("Net work per time within each fixed budget interval",
                             "Each segment shows work credited during that interval divided by its full duration.",
                             handles, ylabel="Interval work per time")
    for origin, policy in BRANCH_KEYS:
        color, marker, pattern, _ = POLICIES[policy]
        end = timelines[origin, policy].end
        axis = axes[origin]
        for row in groups[origin, policy]:
            start, stop, rate = (number(row, key) for key in ("interval_start", "elapsed_total", "interval_rate"))
            if not math.isfinite(rate) or not start < stop:
                continue
            after_end = stop > end
            opacity = 0.5 if after_end else 0.91
            axis.plot((start, stop), (rate, rate), color=color, linestyle=":" if after_end else pattern,
                      linewidth=1.6, alpha=opacity)
            axis.scatter((start + stop) / 2, rate, facecolor="white" if after_end else color,
                         edgecolor=color, marker=marker, s=20, linewidths=0.9, alpha=opacity, zorder=3)
    for axis in axes.values():
        axis.set_ylim(bottom=0)
    set_elapsed_limits(axes, ticks)
    finish(fig, output, "05_interval_rate")


def plot_capacity(groups, ticks, output):
    handles = policy_legend(filled=True) + [
        Line2D([], [], color=MUTED, marker="o", markerfacecolor="white", linestyle="none", label="Cut wait"),
        Line2D([], [], color=MUTED, marker="x", linestyle=":", label="Post-stop free evolution"),
    ]
    fig, axes = elapsed_grid("Future single-extraction capacity at common times",
                             "A fresh connected window of 18.00 starts from each marked state. Cut waits include reconnection input.",
                             handles, legend_cols=3, ylabel="Diagnostic maximum work")
    for origin, policy in BRANCH_KEYS:
        color, marker, pattern, _ = POLICIES[policy]
        rows = groups.get((origin, policy), [])
        axis = axes[origin]
        previous = None
        for row in rows:
            x = number(row, "elapsed_total")
            y = number(row, "diagnostic_work")
            passive = row["continuation"].casefold() == "true"
            waiting = row["phase"] == "wait"
            if previous is not None and passive == previous[2]:
                axis.plot((previous[0], x), (previous[1], y), color=color,
                          linestyle=":" if passive else pattern, linewidth=1.45, alpha=0.55 if passive else 1)
            previous = x, y, passive
            if passive:
                axis.scatter(x, y, marker="x", color=color, s=34, linewidths=1.2, zorder=4)
            else:
                axis.scatter(x, y, marker=marker, facecolor="white" if waiting else color,
                             edgecolor=color, s=25, linewidths=1.1, zorder=4)
    for axis in axes.values():
        axis.set_ylim(bottom=0)
    set_elapsed_limits(axes, ticks, include_zero=False)
    padding = (ticks[-1] - ticks[0]) * 0.018
    axes[PRIMARY].set_xlim(ticks[0] - padding, ticks[-1] + padding)
    finish(fig, output, "06_future_capacity")


def plot_capped(history, timelines, ticks, output):
    handles = policy_legend()
    handles.append(Line2D([], [], marker="o", color=MUTED, linewidth=1.45, linestyle="--",
                          markerfacecolor="white", label="M25 cap and credited plateau"))
    fig, axes = elapsed_grid("M25 capped work and M26 work over the same elapsed time",
                             "The traces share the archived prefix. Dashed plateaus begin where the M25 branches stopped.",
                             handles, ylabel="Cumulative net work")
    for origin, policy in BRANCH_KEYS:
        color, _, _, _ = POLICIES[policy]
        axis = axes[origin]
        time_trace(axis, policy, timelines[origin, policy], ticks[-1], "work")
        inherited = [row for row in history[origin, policy] if row["record_source"] == "m25_archive"]
        if inherited and int(inherited[-1]["count"]) == 30:
            cap = number(inherited[-1], "elapsed_total")
            work = number(inherited[-1], "cumulative_net")
            axis.plot((cap, ticks[-1]), (work, work), color=color, linewidth=1.4, linestyle="--", alpha=0.58)
            axis.scatter(cap, work, color="white", edgecolor=color, marker="o", s=28, linewidths=1.1, zorder=5)
    for axis in axes.values():
        axis.set_ylim(bottom=0)
    set_elapsed_limits(axes, ticks)
    finish(fig, output, "07_m25_vs_m26")


def pair_series(rows):
    groups = defaultdict(list)
    for row in rows:
        key = row["origin"], row["left"], row["right"]
        groups[key].append((number(row, "elapsed_total"), number(row, "gap")))
    return {key: sorted(values) for key, values in groups.items()}


def oriented_pair(groups, origin, left, right):
    if (origin, left, right) in groups:
        return groups[origin, left, right]
    return [(elapsed, -work) for elapsed, work in groups.get((origin, right, left), [])]


def plot_pair_gaps(gaps, events, ticks, output):
    fig, axes = plt.subplots(len(ORIGINS), 2, figsize=(12.3, 10.25), sharex=True, squeeze=False)
    fig.subplots_adjust(left=0.109, right=0.968, top=0.807, bottom=0.09, hspace=0.48, wspace=0.29)
    handles = [Line2D([], [], linestyle="none", color=INK, marker="o", markerfacecolor="white", label="Change of leader")]
    page_title(fig, "Cumulative-work gaps and lead changes",
               "Positive gaps favor the first policy. Labels give the last E–A lead-change time in each panel.",
               handles)
    for col, (left, right) in enumerate(PAIRS):
        title = f"{left} minus {right}"
        panel_title(fig, axes[0, col], title)
        for index, origin in enumerate(ORIGINS):
            axis = axes[index, col]
            series = oriented_pair(gaps, origin, left, right)
            if series:
                if series[0][0] > 0:
                    series = [(0.0, 0.0), *series]
                if series[-1][0] < ticks[-1]:
                    series = [*series, (ticks[-1], series[-1][1])]
                axis.step(*zip(*series, strict=True), where="post", color=POLICIES[left][0], linewidth=1.45)
            crossovers = oriented_pair(events, origin, left, right)
            if crossovers:
                axis.scatter(*zip(*crossovers, strict=True), marker="o", facecolor="white", edgecolor=INK,
                             s=27 if col == 0 else 11, linewidth=1.05 if col == 0 else 0.64, zorder=4)
                if col == 0:
                    elapsed, work = crossovers[-1]
                    align_right = elapsed > ticks[-1] * 0.15
                    label = f"{elapsed:.3f}".rstrip("0").rstrip(".")
                    axis.annotate(label, (elapsed, work), xytext=(-7 if align_right else 7, 11),
                                  textcoords="offset points", ha="right" if align_right else "left",
                                  color=INK, fontsize=8.5, zorder=5)
            axis.axhline(0, color=MUTED, linewidth=0.9, zorder=1)
            style_axis(axis, xlabel="Total elapsed model time" if index == len(ORIGINS) - 1 else None,
                       ylabel=origin if col == 0 else None, scientific=True)
    set_elapsed_limits({PRIMARY: axes[0, 0]}, ticks)
    finish(fig, output, "08_gaps_and_crossovers")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, help="Directory containing the M26 CSVs, defaulting to results")
    parser.add_argument("--output", type=Path, help="Figure directory, defaulting to figures in the milestone or --data")
    args = parser.parse_args()
    data = args.data or ROOT / "results"
    output = args.output or (args.data or ROOT) / "figures"
    output.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "text.color": INK,
                         "axes.labelcolor": INK, "legend.labelcolor": INK})

    history = grouped(csv_rows(data / "m26_history.csv"), "attempt")
    endpoints = {(row["origin"], row["policy"]): number(row, "elapsed_observed")
                 for row in csv_rows(data / "m26_endpoints.csv")}
    timelines = {key: Timeline.from_ledger(history[key], endpoints[key]) for key in BRANCH_KEYS}
    time_groups = grouped(csv_rows(data / "m26_time_comparison.csv"), "elapsed_total")
    ticks = sorted({number(row, "elapsed_total") for rows in time_groups.values() for row in rows
                    if number(row, "elapsed_total") > 0})

    plot_time_profiles(timelines, ticks, output)
    plot_actions(history, ticks, output)
    plot_interval_rates(time_groups, timelines, ticks, output)
    capacity = grouped((row for row in csv_rows(data / "m26_future.csv") if row["diagnostic_kind"] == "common"),
                       "elapsed_total")
    plot_capacity(capacity, ticks, output)
    plot_capped(history, timelines, ticks, output)
    plot_pair_gaps(pair_series(csv_rows(data / "m26_gap.csv")), pair_series(csv_rows(data / "m26_crossovers.csv")),
                   ticks, output)


if __name__ == "__main__":
    main()
