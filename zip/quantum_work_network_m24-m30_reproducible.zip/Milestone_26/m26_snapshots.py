"""Reconstruct M26 cutoff states and assess cloned-state work opportunities."""

from dataclasses import dataclass
from operator import index

import numpy as np

from m21_observables import expectation, spectrum
from m23_spectral import DT, FLOOR, G, HALF_TOL, HORIZON, local_diagnostics, partial, rk_steps
from m25_diagnostics import future_work_many, state_metrics


@dataclass(frozen=True)
class Snapshot:
    """Density pair at a branch-relative model time, with the actual coupling."""

    pair: tuple[np.ndarray, np.ndarray]
    coupling: float
    tick: int
    phase: str
    continuation: bool = False


def _ticks(value):
    milliseconds = index(value)
    if milliseconds < 0:
        raise ValueError("Snapshot times must be nonnegative")
    for dt in DT:
        rk_steps(milliseconds, dt)
    return milliseconds


def _evolve_pair(model, pair, coupling, milliseconds):
    if coupling not in (0.0, G):
        raise ValueError(f"Unsupported snapshot coupling {coupling:g}")
    if milliseconds == 0:
        return pair
    return tuple(model.bases[coupling].evolve(rho, milliseconds, dt)
                 for rho, dt in zip(pair, DT, strict=True))


def snapshot_at(model, start_pair, after_pair, start, tau, duration, tick):
    """Replay part of an actual operation using the inherited dual RK4 lattice.

    Times are integer model milliseconds. Instantaneous switches are evaluated
    on their right side. At the operation end, ``after_pair`` is the actual
    committed pair following the extraction decision, including a rejection.
    """
    start, tau, duration, tick = map(_ticks, (start, tau, duration, tick))
    elapsed = tick - start
    if duration <= 0 or tau > duration or not 0 <= elapsed <= duration:
        raise ValueError("The snapshot tick must fall inside a positive-length operation")
    if elapsed == duration:
        return Snapshot(after_pair, G, tick, "operation_end")
    if elapsed < tau:
        waiting = _evolve_pair(model, start_pair, 0.0, elapsed)
        return Snapshot(waiting, 0.0, tick, "wait")
    waiting = _evolve_pair(model, start_pair, 0.0, tau)
    connected = _evolve_pair(model, waiting, G, elapsed - tau)
    return Snapshot(connected, G, tick, "connected")


def continue_passively(model, snapshot, tick):
    """Evolve beyond a terminal stop with its last coupling and no control."""
    tick = _ticks(tick)
    elapsed = tick - _ticks(snapshot.tick)
    if elapsed < 0:
        raise ValueError("Passive continuation cannot precede the source snapshot")
    if elapsed == 0:
        return snapshot
    pair = _evolve_pair(model, snapshot.pair, snapshot.coupling, elapsed)
    return Snapshot(pair, snapshot.coupling, tick, "passive", continuation=True)


def snapshot_metrics(model, snapshot, *, half=False):
    """Measure the snapshot relative to its actual Hamiltonian and coupling."""
    rho = snapshot.pair[int(half)]
    metrics = state_metrics(model, rho)
    coupling = snapshot.coupling
    metrics.update(coupling=coupling, hypothetical_connected_current=metrics["load_current"],
                   hypothetical_connected_exchange_energy=metrics["exchange_energy"])
    if coupling == G:
        return metrics
    if coupling != 0:
        raise ValueError(f"Unsupported snapshot coupling {coupling:g}")
    hamiltonian, block_levels, levels = model.obs.hamiltonian(0.0)
    energy = expectation(rho, hamiltonian)
    passive_energy = float(levels @ spectrum(rho)[::-1])
    sector_passive_energy = sum(float(e @ spectrum(rho[indices])[::-1])
                                for indices, e in zip(model.obs.sectors, block_levels, strict=True))
    ergotropy = energy - passive_energy
    sector_ergotropy = energy - sector_passive_energy
    split_error = abs(energy - (metrics["bare_chain_energy"] + metrics["load_energy"]))
    if split_error > FLOOR or not -FLOOR <= sector_ergotropy <= ergotropy + FLOOR:
        raise ValueError("Disconnected-state energy decomposition or sector bound failed")
    metrics.update(global_energy=energy, global_passive_energy=passive_energy, global_ergotropy=ergotropy,
                   sector_passive_energy=sector_passive_energy, sector_ergotropy=sector_ergotropy,
                   exchange_energy=0.0, energy_split_error=split_error, load_current=0.0)
    return metrics


def _reconnect_inputs(model, pair, coupling):
    if coupling == G:
        return (0.0, 0.0), (0.0, 0.0)
    if coupling != 0:
        raise ValueError(f"Unsupported snapshot coupling {coupling:g}")
    linear = tuple(2 * G * float(local_diagnostics(partial(rho))["c_real"]) for rho in pair)
    direct = tuple(expectation(rho, model.h[G]) - expectation(rho, model.h[0]) for rho in pair)
    if max(abs(a - b) for a, b in zip(linear, direct, strict=True)) > 1e-15:
        raise ValueError("Instantaneous reconnect-work accounting failed")
    return linear, direct


def _account_future(model, snapshot, connected):
    (reconnect, reconnect_half), (direct_reconnect, direct_reconnect_half) = _reconnect_inputs(
        model, snapshot.pair, snapshot.coupling)
    net = connected["max_net"] - reconnect
    net_half = connected["max_net_half"] - reconnect_half
    direct = connected["direct_max_net"] - direct_reconnect
    direct_half = connected["direct_max_net_half"] - direct_reconnect_half
    step_error = abs(net - net_half)
    switch_error = abs(reconnect - reconnect_half)
    grid_error_bound = connected["max_grid_step_error"] + switch_error
    direct_error = max(abs(net - direct), abs(net_half - direct_half))
    if grid_error_bound > HALF_TOL or direct_error > FLOOR:
        raise ValueError("Cloned-state net work failed convergence or direct accounting")
    accepted = net - step_error > FLOOR and direct > FLOOR
    return {
        **connected,
        "source_coupling": snapshot.coupling,
        "reconnect_on": reconnect,
        "reconnect_on_half": reconnect_half,
        "direct_reconnect_input": direct_reconnect,
        "direct_reconnect_input_half": direct_reconnect_half,
        "connected_max_net": connected["max_net"],
        "connected_max_net_half": connected["max_net_half"],
        "connected_direct_max_net": connected["direct_max_net"],
        "connected_diagnostic_work": connected["diagnostic_work"],
        "max_net": net,
        "max_net_half": net_half,
        "direct_max_net": direct,
        "direct_max_net_half": direct_half,
        "step_error": step_error,
        "max_net_grid_step_error_bound": grid_error_bound,
        "max_direct_residual": direct_error,
        "accepted": accepted,
        "diagnostic_work": direct if accepted else 0.0,
    }


def snapshot_future_work_many(model, snapshots, *, horizon=HORIZON):
    """Audit independent snapshots, connecting a disconnected clone at time zero.

    Reconnection work is a signed, candidate-independent input. The connected
    maximum therefore stays at the M25-selected time after this adjustment.
    The inherited ``max_grid_step_error`` describes the connected-only curve,
    and ``max_net_grid_step_error_bound`` includes reconnect-cost uncertainty.
    """
    snapshots = list(snapshots)
    results = []
    for first in range(0, len(snapshots), 10):
        batch = snapshots[first:first + 10]
        clones = (tuple(rho.copy() for rho in snapshot.pair) for snapshot in batch)
        connected = future_work_many(model, clones, horizon=horizon)
        results.extend(_account_future(model, snapshot, result)
                       for snapshot, result in zip(batch, connected, strict=True))
    return results


def snapshot_future_work(model, snapshot, *, horizon=HORIZON):
    """Audit one independent snapshot with the common connected diagnostic."""
    return snapshot_future_work_many(model, (snapshot,), horizon=horizon)[0]
