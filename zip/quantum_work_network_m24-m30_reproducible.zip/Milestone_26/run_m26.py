"""Continue audited M25 branches to a common time, saving physical staged checkpoints."""

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent
M25 = ROOT.parent / "Milestone_25"
sys.path.insert(0, str(M25))
os.environ.setdefault("OPENBLAS_NUM_THREADS", "2")

from m25_control import M23, ORIGINS, TOTAL_LIMIT, waiting_state
from run_m25 import evaluate_attempt, fingerprint, source_pair
from m21_observables import expectation
from m23_spectral import DT, FLOOR, G, GRID, HALF_TOL, HORIZON, Dynamics, extraction, maxabs
from run_m23 import Tables, csv_rows, ms
from m26_snapshots import Snapshot, continue_passively, snapshot_at, snapshot_future_work, snapshot_metrics

import numpy as np

POLICIES = ("A", "B", "C25", "E")
STAGES = (150_000, 300_000, TOTAL_LIMIT)
COMMON = (50_000, 100_000, 150_000, 200_000, 300_000, 360_000, 450_000, TOTAL_LIMIT)
COUNT_DIAGNOSTICS = (40, 50, 75, 100, 150, 200)
INHERITED = 30
MODEL = None


@dataclass
class Anchor:
    pair: tuple
    tick: int
    count: int
    attempt: int
    cumulative: float
    previous: float
    ending: str = "active"


class AttemptTables:
    """Retain one attempt until its execution falls inside the current stage."""

    def __init__(self):
        self.rows = {}

    def add(self, name, row):
        self.rows.setdefault(name, []).append(row)

    def commit(self, tables):
        for name, rows in self.rows.items():
            for row in rows:
                if name == "m25_history":
                    row = {**row, "record_source": "m26"}
                tables.add(name.replace("m25_", "m26_"), row)


def model():
    global MODEL
    if MODEL is None:
        MODEL = Dynamics(HORIZON)
    return MODEL


def read_published(m25):
    directory = m25 / "results"
    sources = {r["origin"]: r for r in csv_rows(directory / "m25_sources.csv")}
    histories = {(o, p): [] for o in ORIGINS for p in POLICIES}
    for row in csv_rows(directory / "m25_history.csv"):
        key = row["origin"], row["policy"]
        if key in histories:
            histories[key].append(row)
    for history in histories.values():
        if [int(r["count"]) for r in history] != list(range(1, INHERITED+1)) or any(
                r["accepted"] != "True" for r in history):
            raise ValueError("M26 requires 30 published accepted M25 extractions for each selected branch")
    return sources, histories


def archived_anchor(m25, key, last):
    origin, policy = key
    filename = m25 / "stages" / "n30" / origin / policy / "checkpoint.npz"
    with np.load(filename, allow_pickle=False) as checkpoint:
        pair = (checkpoint["coarse"], checkpoint["half"])
        tick, count, attempt = map(int, checkpoint["counters"])
        cumulative, previous = map(float, checkpoint["work"])
        ending = str(checkpoint["ending"].item())
    if (tick, count, attempt, cumulative, previous, ending) != (
            ms(last["elapsed_total"]), INHERITED, INHERITED, float(last["cumulative_net"]),
            float(last["net_work"]), "count_cap"):
        raise ValueError(f"M25 checkpoint counters differ from its ledger: {key}")
    for rho, label in zip(pair, ("coarse", "half"), strict=True):
        if fingerprint(rho) != last[f"post_{label}_sha256"]:
            raise ValueError(f"M25 checkpoint fingerprint changed: {key}/{label}")
    return Anchor(pair, tick, count, attempt, cumulative, previous)


def from_m25(dynamics, anchor, row, authoritative):
    if ms(row["elapsed_start"]) != anchor.tick or int(row["attempt"]) != anchor.attempt+1:
        raise ValueError("Invalid M25 inherited clock or attempt")
    tau = ms(row["tau"])
    connected = ms(row["elapsed_connected"])
    after = tuple(extraction(dynamics.connected.evolve(waiting_state(dynamics, rho, tau, dt), connected, dt))
                  for rho, dt in zip(anchor.pair, DT, strict=True))
    if int(row["count"]) == INHERITED:
        if max(maxabs(actual-official) for actual, official in zip(after, authoritative.pair, strict=True)) > FLOOR:
            raise ValueError("Replay of M25 prefix differs from the certified n30 densities")
        return authoritative
    return Anchor(after, ms(row["elapsed_total"]), int(row["count"]), int(row["attempt"]),
                  float(row["cumulative_net"]), float(row["net_work"]))


def from_m26(dynamics, source, policy, anchor):
    buffer = AttemptTables()
    after, end, cumulative, count, net, accepted, reason = evaluate_attempt(
        dynamics, buffer, source, policy, anchor.pair, anchor.attempt+1, anchor.count,
        anchor.tick, anchor.cumulative, anchor.previous)
    candidate, = buffer.rows["m25_history"]
    ending = "active" if accepted else ("numeric_floor" if reason == "unresolved_candidate" else reason)
    return Anchor(after, end, count, anchor.attempt+1, cumulative, net if accepted else anchor.previous, ending), candidate, buffer


def known_at(row, anchor_tick, tick):
    if row["stop_reason"] == "retrospective":
        decision_tick = anchor_tick
    elif row["decision_elapsed_total"]:
        decision_tick = ms(row["decision_elapsed_total"])
    else:
        raise ValueError("Chronology is missing an online decision time")
    return (decision_tick, ms(row["elapsed_total"])) if decision_tick <= tick else (-1, -1)


def checkpoint_path(stage, origin, policy):
    return stage / origin / policy / "checkpoint.npz"


def load_checkpoint(path):
    with np.load(path, allow_pickle=False) as state:
        tick, count, attempt = map(int, state["counters"])
        cumulative, previous = map(float, state["work"])
        anchor = Anchor((state["coarse"], state["half"]), tick, count, attempt, cumulative, previous,
                        str(state["ending"].item()))
        snapshot = Snapshot((state["snapshot_coarse"], state["snapshot_half"]),
                            float(state["snapshot_coupling"].item()), int(state["cutoff"].item()),
                            str(state["snapshot_phase"].item()), bool(state["snapshot_continuation"].item()))
        known = (int(state["known_decision_tick"].item()), int(state["known_execution_tick"].item()))
    return anchor, snapshot, known


def save_checkpoint(path, anchor, snapshot, known):
    np.savez(path, coarse=anchor.pair[0], half=anchor.pair[1], counters=(anchor.tick,anchor.count,anchor.attempt),
             work=(anchor.cumulative,anchor.previous), ending=anchor.ending,
             snapshot_coarse=snapshot.pair[0], snapshot_half=snapshot.pair[1], cutoff=snapshot.tick,
             snapshot_coupling=snapshot.coupling, snapshot_phase=snapshot.phase, snapshot_continuation=snapshot.continuation,
             known_decision_tick=known[0], known_execution_tick=known[1])


def same_snapshot(actual, saved, actual_known, saved_known):
    if (actual.tick, actual.coupling, actual.phase, actual.continuation, actual_known) != (
            saved.tick, saved.coupling, saved.phase, saved.continuation, saved_known):
        raise ValueError(f"Chronology did not survive stage restart at {saved.tick}")
    error = max(maxabs(r-s) for r, s in zip(actual.pair, saved.pair, strict=True))
    if error > FLOOR:
        raise ValueError(f"State did not survive stage restart at {saved.tick}: {error:g}")
    return error


def diagnostic(tables, dynamics, meta, snapshot, anchor, kind):
    states = snapshot_metrics(dynamics, snapshot)
    prediction = snapshot_future_work(dynamics, snapshot)
    tables.add("m26_future", {
        **meta, "diagnostic_kind": kind, "elapsed_total": snapshot.tick/1000,
        "count": anchor.count, "cumulative_net": anchor.cumulative, "coupling": snapshot.coupling,
        "phase": snapshot.phase, "continuation": snapshot.continuation,
        "coarse_sha256": fingerprint(snapshot.pair[0]), "half_sha256": fingerprint(snapshot.pair[1]),
        **states, **prediction,
    })


def run_branch(source, policy, history, destination, cutoff, previous_stage, m25, m23):
    start_wall = time.perf_counter()
    origin = source["origin"]
    key = origin, policy
    meta = {"origin": origin, "policy": policy}
    folder = destination / origin / policy
    folder.mkdir(parents=True, exist_ok=False)
    dynamics = model()
    initial = source_pair(m23, source)
    initial_energy = expectation(initial[0], dynamics.h[G])
    official = archived_anchor(m25, key, history[-1])
    anchor = Anchor(initial, 0, 0, 0, 0.0, 0.0)
    saved = None
    restart_error = 0.0
    lower = 0
    if previous_stage:
        anchor, saved, saved_known = load_checkpoint(checkpoint_path(previous_stage, *key))
        lower = saved.tick
        if lower >= cutoff:
            raise ValueError("M26 stages must progress forward")

    common = [tick for tick in COMMON if lower < tick <= cutoff]
    inherited_count = anchor.count
    known = (-1, -1)
    boundary = None
    tables = Tables(folder)
    try:
        while anchor.ending == "active" and anchor.tick < cutoff:
            if TOTAL_LIMIT-anchor.tick < GRID:
                anchor.ending = "time_cap_no_grid"
                break
            if anchor.count < INHERITED:
                row = history[anchor.count]
                next_anchor = from_m25(dynamics, anchor, row, official)
                buffer = None
            else:
                next_anchor, row, buffer = from_m26(dynamics, source, policy, anchor)
            tau, duration = ms(row["tau"]), ms(row["duration"])

            def at(tick):
                return snapshot_at(dynamics, anchor.pair, next_anchor.pair, anchor.tick, tau, duration, tick)

            if saved is not None:
                rebuilt = Snapshot(anchor.pair, G, anchor.tick, "operation_end") if saved.tick == anchor.tick else at(saved.tick)
                replanned = (-1, -1) if saved.tick == anchor.tick else known_at(row, anchor.tick, saved.tick)
                restart_error = same_snapshot(rebuilt, saved, replanned, saved_known)
                saved = None

            for tick in common:
                if anchor.tick < tick <= min(cutoff, next_anchor.tick):
                    diagnostic(tables, dynamics, meta, at(tick), next_anchor if tick == next_anchor.tick else anchor, "common")

            if next_anchor.tick > cutoff:
                boundary = at(cutoff)
                known = known_at(row, anchor.tick, cutoff)
                break
            if buffer is not None:
                buffer.commit(tables)
            if abs(expectation(next_anchor.pair[0], dynamics.h[G])+next_anchor.cumulative-initial_energy) > FLOOR:
                raise ValueError(f"M26 cumulative energy closure failed: {key}/{next_anchor.attempt}")
            if next_anchor.count > anchor.count and next_anchor.count in COUNT_DIAGNOSTICS:
                diagnostic(tables, dynamics, meta, at(next_anchor.tick), next_anchor, "accepted_count")
            if next_anchor.ending != "active":
                diagnostic(tables, dynamics, meta, at(next_anchor.tick), next_anchor, "stop")
            anchor = next_anchor

        if boundary is None:
            if anchor.tick == TOTAL_LIMIT and anchor.ending == "active":
                anchor.ending = "time_cap"
            state = Snapshot(anchor.pair, G, anchor.tick, "operation_end")
            if saved is not None:
                restart_error = same_snapshot(continue_passively(dynamics, state, saved.tick), saved, known, saved_known)
            for tick in common:
                if tick > anchor.tick:
                    diagnostic(tables, dynamics, meta, continue_passively(dynamics, state, tick), anchor, "common")
            boundary = state if anchor.tick == cutoff else continue_passively(dynamics, state, cutoff)

        save_checkpoint(folder / "checkpoint.npz", anchor, boundary, known)
        stats = {**meta, "cutoff": cutoff/1000, "anchor_elapsed": anchor.tick/1000,
                 "count": anchor.count, "attempt": anchor.attempt, "count_in_stage": anchor.count-inherited_count,
                 "cumulative_net": anchor.cumulative, "previous_net": anchor.previous, "ending": anchor.ending,
                 "coupling": boundary.coupling, "phase": boundary.phase, "continuation": boundary.continuation,
                 "known_decision_tick": known[0], "known_execution_tick": known[1],
                 "anchor_coarse_sha256": fingerprint(anchor.pair[0]), "anchor_half_sha256": fingerprint(anchor.pair[1]),
                 "snapshot_coarse_sha256": fingerprint(boundary.pair[0]), "snapshot_half_sha256": fingerprint(boundary.pair[1]),
                 "restart_max_difference": restart_error, "seconds": time.perf_counter()-start_wall}
        tables.add("m26_checkpoints", stats)
    finally:
        tables.close()
    return stats


def benchmark(destination, m25, sources, histories):
    destination.mkdir(parents=True, exist_ok=False)
    tables = Tables(destination)
    try:
        for policy in POLICIES:
            started = time.perf_counter()
            key = "S0", policy
            first = anchor = archived_anchor(m25, key, histories[key][-1])
            for _ in range(3):
                anchor, _, _ = from_m26(model(), sources["S0"], policy, anchor)
                if anchor.ending != "active":
                    break
            calls = anchor.attempt-first.attempt
            duration = anchor.tick-first.tick
            seconds = time.perf_counter()-started
            estimated_calls = (TOTAL_LIMIT-first.tick)*calls/duration
            row = {"origin": "S0", "policy": policy, "inherited_count": INHERITED,
                   "start_elapsed": first.tick/1000, "end_elapsed": anchor.tick/1000,
                   "attempts": calls, "accepted": anchor.count-first.count, "ending": anchor.ending,
                   "seconds": seconds, "linear_estimated_total_count": INHERITED+estimated_calls,
                   "linear_estimated_serial_seconds_per_origin": seconds*estimated_calls/calls}
            tables.add("m26_benchmark", row)
            print(row, flush=True)
    finally:
        tables.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--benchmark", action="store_true")
    parser.add_argument("--cutoff", type=int, choices=tuple(t//1000 for t in STAGES))
    parser.add_argument("--previous", type=Path)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--m25", type=Path, default=M25)
    parser.add_argument("--m23", type=Path, default=M23)
    args = parser.parse_args()
    sources, histories = read_published(args.m25)
    if args.benchmark:
        benchmark(args.destination, args.m25, sources, histories)
        return
    if args.cutoff is None:
        parser.error("--cutoff is required outside benchmark mode")
    if (args.cutoff == 150) != (args.previous is None):
        parser.error("A previous stage is required for the 300 and 540 cutoffs only")
    if args.previous and args.previous.resolve() == args.destination.resolve():
        parser.error("The new stage needs a different directory")
    policy_order = ("E", "A", "B", "C25") if args.cutoff*1000 == TOTAL_LIMIT else POLICIES
    tasks = [(sources[o], p, histories[o,p], args.destination, args.cutoff*1000, args.previous, args.m25, args.m23)
             for p in policy_order for o in ORIGINS]
    if args.workers == 1:
        for task in tasks:
            print(run_branch(*task), flush=True)
        return
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(run_branch, *task) for task in tasks]
        for result in as_completed(futures):
            print(result.result(), flush=True)


if __name__ == "__main__":
    main()
