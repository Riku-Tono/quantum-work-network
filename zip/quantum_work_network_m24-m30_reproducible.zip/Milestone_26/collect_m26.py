"""Merge the inherited ledger with committed continuations and compare paid work."""

import argparse
from bisect import bisect_right
import csv
from itertools import combinations
from pathlib import Path
from statistics import median

ROOT = Path(__file__).resolve().parent
M25 = ROOT.parent / "Milestone_25"
ORIGINS = ("S0", "A04", "B04", "C04")
POLICIES = ("A", "B", "C25", "E")
COMMON = (50, 100, 150, 200, 300, 360, 450, 540)
FLOOR = 1e-12
TINY_WORK = 1e-8
SHORT_INTERVAL = 0.10
INHERITED = 30


def rows(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def ticks(number):
    return round(float(number)*1000)


def write(path, records):
    with path.open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)


def stage_paths(stages, filename):
    for origin in ORIGINS:
        for policy in POLICIES:
            for stage in stages:
                path = stage / origin / policy / (filename + ".csv")
                if path.exists():
                    yield path


def merge(stages, destination, filename):
    paths = list(stage_paths(stages, filename))
    if not paths:
        return
    header = None
    with (destination / (filename+".csv")).open("x", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        for path in paths:
            with path.open(encoding="utf-8", newline="") as source:
                reader = csv.DictReader(source)
                fields = [field for field in reader.fieldnames
                          if field != "any_local_unitary_full_work_upper_bound"]
                if header is None:
                    header = fields
                    writer.writerow(header)
                if fields != header:
                    raise ValueError(f"Fields differ: {path}")
                writer.writerows([row[field] for field in fields] for row in reader)


class Ledger:
    def __init__(self, history):
        self.actions = [r for r in history if r["accepted"] == "True"]
        self.times = [ticks(r["elapsed_total"]) for r in self.actions]
        self.net = [0.0]
        self.half = [0.0]
        self.bound = [0.0]
        for count, r in enumerate(self.actions, 1):
            if int(r["count"]) != count or (count > 1 and self.times[count-1] <= self.times[count-2]):
                raise ValueError("Non-monotone extraction times or discontinuous counts")
            self.net.append(float(r["cumulative_net"]))
            self.half.append(self.half[-1]+float(r["direct_net_half"]))
            self.bound.append(self.bound[-1]+abs(float(r["candidate_net"])-float(r["candidate_net_half"])))

    def at(self, tick):
        return bisect_right(self.times, tick)


def compare(histories, final_checkpoints, cutoff):
    ledgers = {key: Ledger(history) for key, history in histories.items()}
    times, counts, endpoints, gaps, crossovers, actions = [], [], [], [], [], []
    for (origin, policy), ledger in ledgers.items():
        meta = {"origin": origin, "policy": policy}
        stage = final_checkpoints[origin, policy]
        last = len(ledger.actions)
        if int(stage["count"]) != last or float(stage["cumulative_net"]) != ledger.net[last]:
            raise ValueError(f"Stage checkpoint and final ledger differ: {meta}")
        observed = cutoff if stage["ending"] == "active" else ticks(stage["anchor_elapsed"])
        endpoints.append({**meta, "count": last, "attempts": stage["attempt"],
                          "elapsed_observed": observed/1000, "common_limit": cutoff/1000,
                          "last_extraction_elapsed": ledger.times[-1]/1000, "cumulative_net": ledger.net[last],
                          "cumulative_rate": ledger.net[last]/(cutoff/1000), "cumulative_net_half_aligned": ledger.half[last],
                          "cumulative_step_error_bound": ledger.bound[last], "ending": stage["ending"]})
        for r in ledger.actions:
            counts.append({**meta, **{key: r[key] for key in (
                "count", "elapsed_total", "cumulative_net", "cumulative_rate", "post_load_energy",
                "post_load_passive_energy", "post_load_ergotropy", "post_bare_chain_energy",
                "post_c_abs", "post_c_phase", "record_source")}})
        prior = 0
        for time in COMMON:
            tick = time*1000
            if tick > cutoff:
                break
            before, now = ledger.at(prior), ledger.at(tick)
            old_count = min(INHERITED, now)
            interval_net = ledger.net[now]-ledger.net[before]
            interval = ledger.actions[before:now]
            times.append({**meta, "elapsed_total": time, "interval_start": prior/1000,
                          "count": now, "cumulative_net": ledger.net[now], "cumulative_rate": ledger.net[now]/time,
                          "interval_count": now-before, "interval_net": interval_net,
                          "interval_rate": interval_net/((tick-prior)/1000),
                          "active_interval_span": max(0, min(tick, observed)-prior)/1000,
                          "cumulative_net_half_aligned": ledger.half[now], "cumulative_step_error_bound": ledger.bound[now],
                          "m25_count": old_count, "m25_cumulative_net": ledger.net[old_count],
                          "m25_cumulative_rate": ledger.net[old_count]/time})
            actions.append({**meta, "interval_start": prior/1000, "interval_end": time,
                            "count": now-before,
                            "tiny_work_count": sum(float(r["net_work"]) <= TINY_WORK for r in interval),
                            "short_interval_count": sum(float(r["duration"]) <= SHORT_INTERVAL for r in interval),
                            "minimum_interval": min((float(r["duration"]) for r in interval), default=""),
                            "median_interval": median(float(r["duration"]) for r in interval) if interval else "",
                            "median_work": median(float(r["net_work"]) for r in interval) if interval else ""})
            prior = tick

    for origin in ORIGINS:
        for left, right in combinations(POLICIES, 2):
            ledger_left, ledger_right = ledgers[origin, left], ledgers[origin, right]
            grid = {0, cutoff, *(t*1000 for t in COMMON if t*1000 <= cutoff), *ledger_left.times, *ledger_right.times}
            previous = None
            for tick in sorted(grid):
                nl, nr = ledger_left.at(tick), ledger_right.at(tick)
                gap = ledger_left.net[nl]-ledger_right.net[nr]
                bound = FLOOR+ledger_left.bound[nl]+ledger_right.bound[nr]
                leader = left if gap > bound else right if gap < -bound else ""
                point = {"origin": origin, "left": left, "right": right, "elapsed_total": tick/1000,
                         "gap": gap, "resolution_bound": bound, "left_count": nl, "right_count": nr}
                gaps.append({**point, "leader": leader})
                if leader:
                    if previous is not None and leader != previous:
                        crossovers.append({**point, "leading_before": previous, "leading_after": leader})
                    previous = leader
    return (times, counts, endpoints, gaps, crossovers, actions)


def compare_ab_states(stages):
    import numpy as np

    def distance(difference):
        return float(np.abs(np.linalg.eigvalsh((difference + difference.conj().T) / 2)).sum() / 2)

    def load_part(difference):
        return np.trace(difference.reshape(128, 3, 128, 3), axis1=0, axis2=2)

    records = []
    for stage in stages:
        for origin in ORIGINS:
            path_a = stage / origin / "A" / "checkpoint.npz"
            path_b = stage / origin / "B" / "checkpoint.npz"
            with np.load(path_a, allow_pickle=False) as a, np.load(path_b, allow_pickle=False) as b:
                if int(a["cutoff"].item()) != int(b["cutoff"].item()):
                    raise ValueError(f"Different A/B state clocks for {stage}/{origin}")
                ac, ah = a["snapshot_coarse"], a["snapshot_half"]
                bc, bh = b["snapshot_coarse"], b["snapshot_half"]
                records.append({"origin": origin, "elapsed_total": int(a["cutoff"].item())/1000,
                                "global_trace_distance": distance(ac-bc),
                                "load_trace_distance": distance(load_part(ac-bc)),
                                "global_step_distance_bound": distance(ac-ah)+distance(bc-bh),
                                "load_step_distance_bound": distance(load_part(ac-ah))+distance(load_part(bc-bh))})
    return records


def collect(destination, stages, benchmark, m25):
    destination.mkdir(parents=True, exist_ok=False)
    histories = {(origin, policy): [] for origin in ORIGINS for policy in POLICIES}
    for row in rows(m25 / "results" / "m25_history.csv"):
        key = row["origin"], row["policy"]
        if key in histories:
            histories[key].append({**row, "record_source": "m25_archive"})
    for history in histories.values():
        if len(history) != INHERITED or any(row["accepted"] != "True" for row in history):
            raise ValueError("M25 prefix must have 30 accepted rows for each branch")

    checkpoints = []
    for stage in stages:
        checkpoint = [r for p in stage_paths((stage,), "m26_checkpoints") for r in rows(p)]
        if len(checkpoint) != len(histories):
            raise ValueError(f"M26 stage incomplete: {stage}")
        checkpoints.extend(checkpoint)
        for path in stage_paths((stage,), "m26_history"):
            for row in rows(path):
                histories[row["origin"],row["policy"]].append(row)
    cutoff = max(ticks(r["cutoff"]) for r in checkpoints)
    final = {(r["origin"],r["policy"]): r for r in checkpoints if ticks(r["cutoff"]) == cutoff}
    for key, history in histories.items():
        histories[key] = [row for row in history if ticks(row["elapsed_total"]) <= cutoff]
    write(destination / "m26_history.csv", [row for history in histories.values() for row in history])
    write(destination / "m26_checkpoints.csv", checkpoints)
    write(destination / "m26_benchmark.csv", rows(benchmark / "m26_benchmark.csv"))
    write(destination / "m26_sources.csv", rows(m25 / "results" / "m25_sources.csv"))
    write(destination / "m26_ab_state.csv", compare_ab_states(stages))
    for filename in ("m26_trajectories", "m26_search", "m26_future"):
        merge(stages, destination, filename)
    comparisons = compare(histories, final, cutoff)
    for name, data in zip(("m26_time_comparison", "m26_count_comparison", "m26_endpoints",
                           "m26_gap", "m26_crossovers", "m26_action_summary"), comparisons, strict=True):
        write(destination / (name+".csv"), data)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("destination", type=Path)
    parser.add_argument("stages", type=Path, nargs="+")
    parser.add_argument("--benchmark", type=Path, default=ROOT / "stages" / "benchmark")
    parser.add_argument("--m25", type=Path, default=M25)
    args = parser.parse_args()
    collect(args.destination, args.stages, args.benchmark, args.m25)
