"""Independently verify M26 continuation against the official M25 state and work ledger."""

import argparse
from bisect import bisect_right
from collections import defaultdict
import csv
from dataclasses import dataclass
from functools import lru_cache
from itertools import combinations, groupby
import math
import os
from pathlib import Path
from statistics import median
import sys

ROOT = Path(__file__).resolve().parent
M25 = ROOT.parent / "Milestone_25"
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
sys.path.insert(0, str(M25))

from verify_m25 import (
    CAP, DIM, G, GRID, HALF_TOL, HORIZON, LOAD_LEVELS, M23, ORIGINS, POLICIES, TOL, ExactModel, State,
    attempt_key, branch_key, check_state_fields, check_suffix_sentinels, check_trace, close, exact_metrics,
    file_hash, flag, insist, matrix_fingerprint, maxabs, np, number, physical_state, read_rows,
    read_unique, reduced_load, state_file, terminal_state, ticks,
)

STAGE_TIMES = (150_000, 300_000, 540_000)
COMMON_TIMES = (50_000, 100_000, 150_000, 200_000, 300_000, 360_000, 450_000, 540_000)
DIAGNOSTIC_COUNTS = {40, 50, 75, 100, 150, 200}
CONTINUED = {"A", "B", "C25", "E"}
M26_BRANCHES = {(origin, policy) for origin in ORIGINS for policy in CONTINUED}


@dataclass(frozen=True)
class InheritedBranch:
    source: dict
    endpoint: dict
    history: tuple
    checkpoint: Path
    checkpoint_sha256: str
    coarse_sha256: str
    half_sha256: str
    elapsed: int
    count: int
    attempts: int
    cumulative: float
    previous: float
    ending: str

    def states(self):
        insist(file_hash(self.checkpoint) == self.checkpoint_sha256, f"M25 checkpoint changed during audit: {self.checkpoint}")
        with np.load(self.checkpoint, allow_pickle=False) as saved:
            clock = (ticks(self.source, "source_time") + self.elapsed) / 1000
            return State(saved["coarse"], clock, self.coarse_sha256), State(saved["half"], clock, self.half_sha256)


@dataclass(frozen=True)
class IndependentSnapshot:
    state: State
    coupling: float
    phase: str
    continuation: bool = False


class ExactContinuation(ExactModel):
    """Independent exact replay with reuse of frequently repeated unitary intervals."""

    @lru_cache(maxsize=64)
    def propagator(self, coupling, elapsed):
        spectrum, vectors = self.eigensystems[coupling]
        return (vectors*np.exp(-1j*spectrum*elapsed))@vectors.T

    def evolve(self, state, g, elapsed):
        if elapsed == 0:
            return state
        transform = self.propagator(g, elapsed)
        return State(transform@state.matrix@transform.conj().T, state.time+elapsed)


def dynamics_step(model, start, tau, connected):
    waited = model.evolve(start, 0.0, tau/1000)
    before = model.evolve(waited, G, connected/1000)
    cut = -G*model.exchange_expectation(start) if tau else 0.0
    reconnect = G*model.exchange_expectation(waited) if tau else 0.0
    load = reduced_load(terminal_state(before.matrix))
    values, vectors = np.linalg.eigh(load)
    insist(float(np.min(np.diff(values))) > TOL, "Degenerate load spectrum in independent replay")
    pivots = [max(range(3), key=lambda i: (abs(column[i]), i)) for column in vectors.T]
    phases = vectors[pivots, range(3)]
    passive = (vectors*(phases.conj()/np.abs(phases))).conj().T[::-1]
    blocks = before.matrix.reshape(DIM//3, 3, DIM//3, 3).transpose(0, 2, 1, 3)
    rotated = (passive@blocks@passive.conj().T).transpose(0, 2, 1, 3).reshape(DIM, DIM)
    return waited, before, State(rotated, before.time), cut, reconnect


def exact_ledger(model, row, state, context):
    waited, before, after, cut, reconnect = dynamics_step(model, state, ticks(row, "tau"), ticks(row, "elapsed_connected"))
    exact = model.energy(state)-model.energy(after)
    approved = flag(row, "accepted")
    committed = after if approved else before
    for field, expected in (("net_work", exact if approved else 0), ("direct_net", exact), ("cut_on", cut), ("reconnect_on", reconnect)):
        close(number(row, field), expected, f"Independent full Hamiltonian {field} for {context}")
    check_state_fields(row, "pre", exact_metrics(model, before), context)
    check_state_fields(row, "post", exact_metrics(model, committed), context)
    return committed, exact_metrics(model, waited)


def official_m25(m25):
    """Match each archived stage file to source identity and the full M25 ledger."""
    data = m25 / "results"
    sources = read_unique(read_rows(data / "m25_sources.csv"), lambda row: row["origin"])
    insist(sources.keys() == ORIGINS, "Incorrect M25 source list")
    endpoints = read_unique(read_rows(data / "m25_endpoints.csv"), branch_key)
    expected = {(origin, policy) for origin in ORIGINS for policy in POLICIES}
    insist(endpoints.keys() == expected, "M25 branch endpoints differ from the registered origins and policies")
    histories = defaultdict(list)
    for row in read_rows(data / "m25_history.csv"):
        histories[branch_key(row)].append(row)
    insist(histories.keys() == expected, "M25 history coverage differs from its endpoints")

    result = {}
    model = ExactModel()
    for key, endpoint in endpoints.items():
        origin, policy = key
        history = tuple(sorted(histories[key], key=lambda row: int(row["attempt"])))
        accepted = [row for row in history if flag(row, "accepted")]
        insist([int(row["attempt"]) for row in history] == list(range(1, len(history)+1)), f"M25 ordering for {key}")
        last = history[-1]
        elapsed, count, attempts = ticks(endpoint, "elapsed_total"), int(endpoint["count"]), int(endpoint["attempts"])
        insist((elapsed, count, attempts) == (ticks(last, "elapsed_total"), len(accepted), len(history)), f"M25 endpoint counters for {key}")
        cumulative = number(endpoint, "cumulative_net")
        previous = number(accepted[-1], "net_work") if accepted else 0.0
        close(cumulative, math.fsum(number(row, "net_work") for row in accepted), f"M25 inherited work for {key}")
        close(number(endpoint, "cumulative_rate"), cumulative / (elapsed / 1000), f"M25 inherited rate for {key}")
        ending = endpoint["ending"]
        insist((ending == "count_cap" and count == 30) or (ending != "count_cap" and not flag(last, "accepted")),
               f"M25 inherited stopping classification for {key}")

        folder = m25 / "stages" / "n30" / origin / policy
        status, = read_rows(folder / "m25_stage_runtime.csv")
        insist(int(status["rounds_target"]) == 30 and branch_key(status) == key
               and (ticks(status, "elapsed_total"), int(status["count"]), int(status["attempts_total"]), status["ending"])
               == (elapsed, count, attempts, ending), f"M25 n30 status differs for {key}")
        close(number(status, "cumulative_net"), cumulative, f"M25 n30 work for {key}")
        checkpoint = folder / "checkpoint.npz"
        hashes = []
        with np.load(checkpoint, allow_pickle=False) as saved:
            insist(set(saved.files) == {"coarse", "half", "counters", "work", "ending"}, f"M25 checkpoint entries for {key}")
            insist(tuple(saved["counters"]) == (elapsed, count, attempts) and str(saved["ending"].item()) == ending,
                   f"M25 checkpoint clock and ending for {key}")
            close(float(saved["work"][0]), cumulative, f"M25 checkpoint cumulative work for {key}")
            close(float(saved["work"][1]), previous, f"M25 checkpoint previous accepted work for {key}")
            absolute_time = (ticks(sources[origin], "source_time") + elapsed) / 1000
            matrices = []
            for resolution in ("coarse", "half"):
                matrix = saved[resolution]
                insist(matrix.shape == (DIM, DIM) and np.isfinite(matrix).all(), f"Invalid M25 {resolution} density for {key}")
                fingerprint = matrix_fingerprint(matrix)
                insist(fingerprint == last[f"post_{resolution}_sha256"], f"M25 checkpoint state fingerprint for {key}/{resolution}")
                hashes.append(fingerprint)
                matrices.append(matrix)
                state = State(matrix, absolute_time, fingerprint)
                physical_state(state, (key, resolution, "M25 n30"))
                close(model.energy(state), number(last, "post_global_energy"), f"M25 state energy for {key}/{resolution}")
            close(maxabs(matrices[0]-matrices[1]), number(last, "half_state_max_error"), f"M25 checkpoint half-step error for {key}")
        result[key] = InheritedBranch(sources[origin], endpoint, history, checkpoint, file_hash(checkpoint),
                                      *hashes, elapsed, count, attempts, cumulative, previous, ending)
    return result


def continued_ledgers(data, published, cutoff):
    groups = defaultdict(list)
    for row in read_rows(data / "m26_history.csv"):
        groups[branch_key(row)].append(row)
    insist(groups.keys() == M26_BRANCHES, "M26 history has the wrong branch coverage")
    additions = {}
    for key, rows in groups.items():
        inherited = published[key]
        insist(inherited.ending == "count_cap" and inherited.count == 30, f"M26 attempts to restart a terminated M25 branch {key}")
        archives = [row for row in rows if row["record_source"] == "m25_archive"]
        archived_fields = [{field: value for field, value in row.items() if field != "record_source"} for row in archives]
        expected_prefix = [row for row in inherited.history if ticks(row, "elapsed_total") <= cutoff]
        insist(archived_fields == expected_prefix and rows[:len(archives)] == archives,
               f"Official M25 prefix was edited or reordered for {key}")
        extensions = rows[len(archives):]
        insist(all(row["record_source"] == "m26" and ticks(row, "elapsed_total") <= cutoff for row in extensions),
               f"Invalid or unexecuted M26 action for {key}")
        insist(cutoff < CAP or extensions, f"Missing M26 continuation for {key}")
        additions[key] = extensions
    return groups, additions


def within_operation(model, anchor, after, start, tau, end, tick):
    if tick == end:
        return IndependentSnapshot(after, G, "operation_end")
    if tick < start+tau:
        return IndependentSnapshot(model.evolve(anchor, 0.0, (tick-start)/1000), 0.0, "wait")
    restarted = model.evolve(anchor, 0.0, tau/1000)
    state = model.evolve(restarted, G, (tick-start-tau)/1000)
    return IndependentSnapshot(state, G, "connected")


def capture_times(model, states, needed, anchor, after, start, tau, end):
    for tick in needed.difference(states):
        if start < tick <= end:
            states[tick] = within_operation(model, anchor, after, start, tau, end, tick)


def legacy_snapshots(model, inherited, times, m23):
    source = inherited.source
    state = state_file(m23, source["coarse_path"], source["coarse_sha256"], ticks(source, "source_time"))
    saved = {0: IndependentSnapshot(state, G, "operation_end")} if 0 in times else {}
    for row in inherited.history:
        if saved.keys() == times:
            break
        start, tau, connected, end = (ticks(row, field) for field in ("elapsed_start", "tau", "elapsed_connected", "elapsed_total"))
        _, _, after, _, _ = dynamics_step(model, state, tau, connected)
        capture_times(model, saved, times, state, after, start, tau, end)
        state = after
    insist(saved.keys() == times, f"Unable to reconstruct archived M25 snapshots for {branch_key(inherited.endpoint)}")
    return saved


def audit_extensions(additions, published, model, needed, m23, cutoff):
    expected_trace_start = {}
    computed_states = {}
    for key, rows in additions.items():
        origin, policy = key
        inherited = published[key]
        clock, count, previous, cumulative = inherited.elapsed, inherited.count, inherited.previous, inherited.cumulative
        start_state, _ = inherited.states()
        expected_hashes = {"coarse": inherited.coarse_sha256, "half": inherited.half_sha256}
        budget = model.energy(start_state) + cumulative
        exact_state = start_state
        required = needed[key]
        computed = legacy_snapshots(model, inherited, {t for t in required if t < inherited.elapsed}, m23)
        if clock in required:
            computed[clock] = IndependentSnapshot(exact_state, G, "operation_end")
        for attempt, row in enumerate(rows, inherited.attempts+1):
            context = (*key, attempt)
            insist(attempt_key(row) == context and ticks(row, "elapsed_start") == clock, f"Discontinuous continuation date/count for {context}")
            tau, s, duration, end, window = (ticks(row, field) for field in (
                "tau", "elapsed_connected", "duration", "elapsed_total", "window"))
            insist(0 <= tau <= 6250 and (tau == 0 or policy == "E") and s >= 0 and s % GRID == 0,
                   f"Invalid waiting or observation lattice for {context}")
            insist(window == min(HORIZON, CAP-clock) and 0 < duration == tau+s <= window and end == clock+duration,
                   f"Intermediate stage changed the epoch window or duration for {context}")
            insist(ticks(row, "absolute_time") == ticks(inherited.source, "source_time")+end,
                   f"Invalid full-model clock for {context}")
            if policy == "E":
                insist(row["decision_elapsed_total"] == "" and row["stop_reason"] == "retrospective",
                       f"Retrospective decision represented as online for {context}")
            else:
                decision = ticks(row, "decision_elapsed_total")
                insist(clock < decision <= end, f"Online decision lies outside the observable prefix for {context}")

            threshold = max(TOL, 0.25*previous if policy == "C25" else 0.0)
            close(number(row, "threshold"), threshold, f"Inherited relative threshold for {context}", 1e-16)
            close(number(row, "previous_accepted_net"), previous, f"Previous accepted work for {context}", 1e-16)
            coarse, half = (number(row, field) for field in ("candidate_net", "candidate_net_half"))
            direct, direct_half = (number(row, field) for field in ("direct_net", "direct_net_half"))
            margin = coarse - abs(coarse - half)
            accepted = margin > TOL and direct > TOL and coarse >= threshold
            reason = "extracted" if accepted else "threshold_at_horizon" if policy == "C25" and coarse < threshold else "unresolved_candidate"
            insist(flag(row, "accepted") == accepted and row["outcome"] == reason and (accepted or row is rows[-1]),
                   f"Extraction rejection or stopping accounting for {context}")
            close(number(row, "resolution_margin"), margin, f"Coarse/half margin for {context}")
            close(direct, coarse, f"Coarse candidate versus direct energy for {context}")
            close(direct_half, half, f"Half candidate versus direct energy for {context}")
            replay = ticks(row, "half_replay_duration")
            insist(0 < replay <= window and replay >= tau and (replay-tau) % GRID == 0, f"Half replay falls off the epoch lattice for {context}")
            insist(abs(coarse-half) <= number(row, "max_grid_step_error") + TOL and number(row, "max_grid_step_error") <= HALF_TOL,
                   f"Unresolved coarse/half selected or prefix work for {context}")
            for field in ("max_half_physicality_error", "accepted_energy_residual", "global_passive_unitary_drift",
                          "bare_chain_unitary_drift", "balance_residual", "waiting_energy_drift", "connected_energy_drift"):
                close(number(row, field), 0.0, f"Ledger physical closure for {context}/{field}")

            net = direct if accepted else 0.0
            count += int(accepted)
            cumulative += net
            close(number(row, "net_work"), net, f"Net work actually credited for {context}")
            close(number(row, "cumulative_net"), cumulative, f"Cumulative work from inherited epoch for {context}")
            close(number(row, "cumulative_rate"), cumulative / (end / 1000), f"Actual elapsed-time rate for {context}")
            close(number(row, "post_global_energy")+cumulative, budget, f"Energy closure from shared start for {context}")
            insist(int(row["count"]) == count, f"Accepted extraction count for {context}")
            for resolution, prior in expected_hashes.items():
                insist(row[f"start_{resolution}_sha256"] == prior, f"State handoff hash for {context}/{resolution}")
                expected_hashes[resolution] = row[f"post_{resolution}_sha256"]
                if not accepted:
                    insist(expected_hashes[resolution] == row[f"pre_{resolution}_sha256"], f"Rejected extraction changed density for {context}/{resolution}")

            exact_state, witness = exact_ledger(model, row, exact_state, context)
            expected_trace_start[context] = witness
            capture_times(model, computed, required, start_state, exact_state, clock, tau, end)
            if accepted:
                previous = net
            clock = end
            start_state = exact_state
        for remaining in required.difference(computed):
            insist(remaining > clock, f"Missing independent replay state for {key}/{remaining}")
            state = model.evolve(exact_state, G, (remaining-clock)/1000)
            passive = cutoff == CAP or bool(rows and not flag(rows[-1], "accepted"))
            insist(passive or key[1] != "E", "An active retrospective branch lacks a known pending action")
            computed[remaining] = IndependentSnapshot(state, G, "passive" if passive else "connected", passive)
        computed_states[key] = computed
    return expected_trace_start, computed_states


def audit_traces(data, additions, reconnect_witnesses):
    attempts = {attempt_key(row): row for rows in additions.values() for row in rows}
    seen = set()
    samples = 0
    with (data / "m26_trajectories.csv").open(encoding="utf-8-sig", newline="") as stream:
        for key, rows in groupby(csv.DictReader(stream), attempt_key):
            insist(key in attempts and key not in seen, f"Unexpected or repeated M26 trajectory {key}")
            samples += check_trace(list(rows), attempts[key], reconnect_witnesses[key])
            seen.add(key)
    insist(seen == attempts.keys(), "At least one M26 committed candidate lacks its trajectory")
    return samples


def accepted_to(rows, cutoff, start=-1):
    return [row for row in rows if start < ticks(row, "elapsed_total") <= cutoff and flag(row, "accepted")]


def work_for(rows):
    return math.fsum(number(row, "net_work") for row in rows)


def precision(rows):
    half = math.fsum(number(row, "direct_net_half") for row in rows)
    bound = math.fsum(abs(number(row, "candidate_net")-number(row, "candidate_net_half")) for row in rows)
    return half, bound


def audit_time_comparison(data, history, published, ceiling, endpoints):
    rows = read_unique(read_rows(data / "m26_time_comparison.csv"), lambda row: (*branch_key(row), ticks(row, "elapsed_total")))
    by_branch = defaultdict(list)
    for key in rows:
        by_branch[key[:2]].append(key[2])
    insist(by_branch.keys() == M26_BRANCHES, "Common-time comparison does not cover all continued branches")
    common = set(by_branch["S0", "A"])
    insist(common == {t for t in COMMON_TIMES if t <= ceiling}, "Common-time table differs from the registered deadlines")
    for key, deadlines in by_branch.items():
        insist(set(deadlines) == common, f"Different common-time grid for {key}")
        previous = 0
        for cutoff in sorted(deadlines):
            summary = rows[*key, cutoff]
            start = ticks(summary, "interval_start")
            insist(start == previous, f"Unexpected interval start for {key}/{cutoff}")
            whole = accepted_to(history[key], cutoff)
            prior = accepted_to(published[key].history, cutoff)
            interval = accepted_to(history[key], cutoff, start)
            for field, expected in (("count", len(whole)), ("interval_count", len(interval)), ("m25_count", len(prior))):
                insist(int(summary[field]) == expected, f"{field} includes unexecuted work at {key}/{cutoff}")
            for prefix, events, width in (("cumulative", whole, cutoff), ("interval", interval, cutoff-start),
                                          ("m25_cumulative", prior, cutoff)):
                net = work_for(events)
                close(number(summary, prefix + "_net"), net, f"Common-time {prefix} work for {key}/{cutoff}")
                close(number(summary, prefix + "_rate"), net / (width / 1000), f"Common-time {prefix} rate for {key}/{cutoff}")
            aligned_half, bound = precision(whole)
            insist(abs(aligned_half-work_for(whole)) <= bound+TOL, f"Common-time aligned half-step work exceeds resolution for {key}/{cutoff}")
            close(number(summary, "cumulative_net_half_aligned"), aligned_half, f"Common-time aligned half-step work for {key}/{cutoff}")
            close(number(summary, "cumulative_step_error_bound"), bound, f"Common-time precision bound for {key}/{cutoff}", 1e-16)
            observed = ticks(endpoints[key], "elapsed_observed")
            insist(ticks(summary, "active_interval_span") == max(0, min(cutoff, observed)-start),
                   f"Active observation span differs for {key}/{cutoff}")
            previous = cutoff
    return len(rows)


def audit_search(data, additions):
    attempts = {attempt_key(row): row for key, rows in additions.items() if key[1] == "E" for row in rows}
    groups = defaultdict(list)
    path = data / "m26_search.csv"
    for row in read_rows(path) if path.is_file() else []:
        groups[attempt_key(row)].append(row)
    insist(groups.keys() == attempts.keys(), "Unexpected or missing M26 retrospective search epoch")
    for key, rows in groups.items():
        attempt = attempts[key]
        window = ticks(attempt, "window")
        pairs = read_unique(rows, lambda row: (row["stage"], ticks(row, "tau")))
        coarse = {tau: row for (stage, tau), row in pairs.items() if stage == "A"}
        fine = {tau: row for (stage, tau), row in pairs.items() if stage == "C"}
        insist(len(coarse)+len(fine) == len(rows) and coarse.keys() == set(range(0, min(6000, window)+1, 250)),
               f"Incorrectly clipped or sampled coarse wait lattice for {key}")
        waits = sorted(coarse)
        values = [number(coarse[tau], "max_net") for tau in waits]
        peaks = sorted((-value, waits[i]) for i, value in enumerate(values)
                       if (i == 0 or value > values[i-1]) and (i == len(values)-1 or value >= values[i+1]))[:3]
        centers = {tau for _, tau in peaks}
        insist(centers == {tau for tau, row in coarse.items() if flag(row, "refinement_center")}
               and all(not flag(row, "refinement_center") for row in fine.values()), f"Incorrect refinement centers for {key}")
        extended = any(tau > 6000 for tau in fine)
        if 6000 in centers and window >= 6025:
            difference = values[-1]-values[-2]
            if difference > TOL+2*HALF_TOL:
                insist(extended, f"Missing resolved endpoint extension for {key}")
            if difference <= TOL:
                insist(not extended, f"Endpoint extension is numerically unresolved for {key}")
        expected_fine = {tau for center in centers for tau in range(max(0, center-250),
            min(window, 6250 if extended and center == 6000 else 6000, center+250)+1, 25)}
        insist(fine.keys() == expected_fine, f"Incorrect fine wait grid for {key}")
        for (_, tau), row in pairs.items():
            connected = ticks(row, "elapsed_connected")
            insist(connected >= 0 and connected % GRID == 0 and 0 < tau+connected <= window
                   and ticks(row, "elapsed_total") == tau+connected
                   and int(row["candidate_count"]) == (window-tau)//GRID+1-int(tau == 0),
                   f"Incorrect retrospective time grid for {key}/{tau}")
        winner = min(rows, key=lambda row: (-number(row, "max_net"), ticks(row, "elapsed_total"), ticks(row, "tau")))
        insist([row for row in rows if flag(row, "selected")] == [winner], f"Wrong retrospective winner for {key}")
        insist((ticks(winner, "tau"), ticks(winner, "elapsed_total")) == (ticks(attempt, "tau"), ticks(attempt, "duration")),
               f"Wrong retrospective candidate executed for {key}")
        close(number(winner, "max_net"), number(attempt, "candidate_net"), f"Selected retrospective work for {key}")
    return sum(map(len, groups.values()))


def at_boundary(history, cutoff):
    finished = [row for row in history if ticks(row, "elapsed_total") <= cutoff]
    next_row = history[len(finished)] if len(finished) < len(history) else None
    anchor = finished[-1] if finished else None
    return anchor, next_row, finished


def cutoff_ending(anchor, pending, cutoff):
    if anchor is not None and not flag(anchor, "accepted"):
        return "numeric_floor" if anchor["outcome"] == "unresolved_candidate" else anchor["outcome"]
    if cutoff < CAP:
        return "active"
    insist(pending is None and anchor is not None, "The final cutoff has an unexecuted candidate or no anchor")
    elapsed = ticks(anchor, "elapsed_total")
    if elapsed == CAP:
        return "time_cap"
    insist(0 < CAP-elapsed < GRID, "An unfinished final positive-time grid was silently discarded")
    return "time_cap_no_grid"


@lru_cache(maxsize=1)
def terminal_projection(model):
    energies, vectors = model.eigensystems[G]
    left, right = np.triu_indices(6)
    weights = np.array([vectors[a::6].T@vectors[b::6] for a, b in zip(left, right, strict=True)])
    return energies, vectors, left, right, weights.reshape(len(left), DIM*DIM).T.copy()


def terminal_prefix(model, start, delays):
    """Project exact full-H evolution to the 6×6 terminal without taking future samples."""
    energies, vectors, left, right, weights = terminal_projection(model)
    spectral = vectors.T@start.matrix@vectors
    coefficients = spectral.reshape(-1, 1)*weights
    for first in range(0, len(delays), 16):
        selected = delays[first:first+16]
        phase = np.exp(-1j*(np.array(selected)[:, None]/1000)*energies)
        products = phase[:, :, None]*phase[:, None, :].conj()
        projected = products.reshape(len(selected), DIM*DIM)@coefficients
        for delay, values in zip(selected, projected, strict=True):
            terminal = np.empty((6, 6), dtype=np.complex128)
            terminal[left, right] = values
            terminal[right, left] = values.conj()
            diag = np.arange(6)
            terminal[diag, diag] = terminal[diag, diag].real
            yield delay, terminal


def prefix_pending(model, start, epoch, cutoff, policy, previous):
    """Find any pending forecast using only exact observations through an interim cutoff."""
    threshold = max(TOL, 0.25*previous if policy == "C25" else 0.0)
    load_h = np.diag(LOAD_LEVELS)
    local_h = np.kron(np.eye(2), load_h)+G*model.exchange
    old_rate = None
    delays = range(0, cutoff-epoch+1, GRID)
    for delay, terminal in terminal_prefix(model, start, delays):
        load = reduced_load(terminal)
        values, vectors = np.linalg.eigh(load)
        erg = float(LOAD_LEVELS @ (np.diag(load).real-values[::-1]))
        reduced_rate = reduced_load(-1j*(local_h@terminal-terminal@local_h))
        rates = np.diag(vectors.conj().T@reduced_rate@vectors).real
        rate = float(LOAD_LEVELS @ (np.diag(reduced_rate).real-rates[::-1]))
        if erg > TOL and old_rate is not None:
            if policy == "A" and old_rate > rate > 0:
                intervals = rate/(old_rate-rate)
                execution = epoch+delay+GRID*max(1, math.floor(intervals+0.5))
                if intervals <= 5 and execution <= min(epoch+HORIZON, CAP):
                    insist(execution > cutoff, "Interim prefix forecast implies a missing committed action")
                    return epoch+delay, execution
            elif policy != "A" and old_rate > 0 >= rate:
                pivots = [max(range(3), key=lambda i: (abs(column[i]), i)) for column in vectors.T]
                phases = vectors[pivots, range(3)]
                passive = (vectors*(phases.conj()/abs(phases))).conj().T[::-1]
                unitary = np.kron(np.eye(2), passive)
                change = unitary@terminal@unitary.conj().T-terminal
                work = erg-G*float(np.einsum("ij,ji->", model.exchange, change).real)
                insist(work < threshold, "Interim prefix contains a resolved turn missing from the ledger")
        old_rate = rate
    insist(cutoff-epoch < min(HORIZON, CAP-epoch)//GRID*GRID, "Interim history omitted the horizon action")
    return -1, -1


def check_one_cutoff(model, key, row, history, independent, stage_root, previous_count):
    cutoff = ticks(row, "cutoff")
    anchor, pending, finished = at_boundary(history, cutoff)
    expected = independent[cutoff]
    elapsed = ticks(anchor, "elapsed_total") if anchor else 0
    attempt = int(anchor["attempt"]) if anchor else 0
    accepted = [operation for operation in finished if flag(operation, "accepted")]
    count = len(accepted)
    cumulative = work_for(accepted)
    previous = number(accepted[-1], "net_work") if count else 0.0
    ending = cutoff_ending(anchor, pending, cutoff)
    phase = expected.phase
    known = (-1, -1)
    if pending is not None and elapsed < cutoff and phase in {"wait", "connected"}:
        planned = number(pending, "elapsed_start") if key[1] == "E" else number(pending, "decision_elapsed_total")
        decision_tick = round(planned*1000)
        if decision_tick <= cutoff:
            known = decision_tick, ticks(pending, "elapsed_total")
    elif pending is None and phase == "connected" and cutoff < CAP:
        known = None
    insist((ticks(row, "anchor_elapsed"), int(row["count"]), int(row["attempt"]), int(row["count_in_stage"]), row["ending"])
           == (elapsed, count, attempt, count-previous_count, ending), f"Wrong stage counters or termination for {key}/{cutoff}")
    insist((number(row, "coupling"), row["phase"], flag(row, "continuation"))
           == (expected.coupling, phase, expected.continuation), f"Wrong physical phase at boundary {key}/{cutoff}")
    close(number(row, "cumulative_net"), cumulative, f"Only executed work at boundary {key}/{cutoff}")
    close(number(row, "previous_net"), previous, f"Previous successful operation at boundary {key}/{cutoff}")
    insist(0 <= number(row, "restart_max_difference") <= TOL and number(row, "seconds") > 0,
           f"Unresolved restart or runtime at {key}/{cutoff}")

    folder = stage_root / f"t{cutoff//1000}" / key[0] / key[1]
    local, = read_rows(folder / "m26_checkpoints.csv")
    insist(local == row, f"Merged M26 checkpoint row differs from stage file for {key}/{cutoff}")
    physical_error = 0.0
    with np.load(folder / "checkpoint.npz", allow_pickle=False) as data:
        keys = {"coarse", "half", "counters", "work", "ending", "cutoff", "snapshot_coarse", "snapshot_half",
                "snapshot_coupling", "snapshot_phase", "snapshot_continuation", "known_decision_tick", "known_execution_tick"}
        insist(set(data.files) == keys, f"Wrong checkpoint format for {key}/{cutoff}")
        insist(tuple(data["counters"]) == (elapsed, count, attempt) and data["ending"].item() == ending
               and int(data["cutoff"]) == cutoff, f"NPZ state anchor metadata for {key}/{cutoff}")
        close(float(data["work"][0]), cumulative, f"NPZ cumulative work for {key}/{cutoff}")
        close(float(data["work"][1]), previous, f"NPZ previous work for {key}/{cutoff}")
        if known is None:
            known = prefix_pending(model, State(data["coarse"], independent[elapsed].state.time), elapsed, cutoff, key[1], previous)
        insist((int(row["known_decision_tick"]), int(row["known_execution_tick"])) == known,
               f"A pending decision was forgotten or exposed too early for {key}/{cutoff}")
        insist((float(data["snapshot_coupling"]), data["snapshot_phase"].item(), bool(data["snapshot_continuation"]),
                int(data["known_decision_tick"]), int(data["known_execution_tick"]))
               == (expected.coupling, phase, expected.continuation, *known), f"NPZ boundary phase or decision for {key}/{cutoff}")
        for resolution in ("coarse", "half"):
            matrix, actual = data[resolution], data[f"snapshot_{resolution}"]
            insist(matrix.shape == (DIM, DIM) and actual.shape == (DIM, DIM)
                   and np.isfinite(matrix).all() and np.isfinite(actual).all(), f"Malformed checkpoint density for {key}/{cutoff}/{resolution}")
            anchor_hash, snapshot_hash = matrix_fingerprint(matrix), matrix_fingerprint(actual)
            insist(anchor_hash == row[f"anchor_{resolution}_sha256"] and snapshot_hash == row[f"snapshot_{resolution}_sha256"],
                   f"Checkpoint fingerprints for {key}/{cutoff}/{resolution}")
            if anchor is not None:
                insist(anchor_hash == anchor[f"post_{resolution}_sha256"], f"Checkpoint did not retain actual epoch anchor for {key}/{cutoff}/{resolution}")
            start = State(matrix, independent[elapsed].state.time)
            actual = State(actual, expected.state.time)
            physical_state(start, (key, cutoff, resolution, "anchor"))
            physical_state(actual, (key, cutoff, resolution, "boundary"))
            if phase == "operation_end":
                independently_expected = start
            elif phase == "passive":
                independently_expected = model.evolve(start, G, (cutoff-elapsed)/1000)
            elif pending is None:
                independently_expected = model.evolve(start, G, (cutoff-elapsed)/1000)
            else:
                independently_expected = within_operation(model, start, start, elapsed, ticks(pending, "tau"),
                                                           ticks(pending, "elapsed_total"), cutoff).state
            difference = maxabs(actual.matrix-independently_expected.matrix)
            insist(difference <= HALF_TOL, f"Independent cutoff propagation differs for {key}/{cutoff}/{resolution}: {difference:g}")
            physical_error = max(physical_error, difference)
        close(model.energy(State(data["snapshot_coarse"], expected.state.time), expected.coupling),
              model.energy(expected.state, expected.coupling), f"Independent cutoff Hamiltonian energy at {key}/{cutoff}")
    return count, physical_error


def check_future(model, key, records, history, independent, staged_rows, cutoff):
    keyed = read_unique(records, lambda row: (row["diagnostic_kind"], ticks(row, "elapsed_total")))
    expected = {("common", tick) for tick in COMMON_TIMES if tick <= cutoff}
    for row in history:
        elapsed = ticks(row, "elapsed_total")
        if flag(row, "accepted") and int(row["count"]) in DIAGNOSTIC_COUNTS:
            expected.add(("accepted_count", elapsed))
        if not flag(row, "accepted"):
            expected.add(("stop", elapsed))
    insist(keyed.keys() == expected, f"Missing or extra diagnostic states for {key}")
    for (kind, elapsed), row in keyed.items():
        snapshot = independent[elapsed]
        g = snapshot.coupling
        state = snapshot.state
        accepted = accepted_to(history, elapsed)
        insist((int(row["count"]), number(row, "coupling"), row["phase"], flag(row, "continuation"))
               == (len(accepted), g, snapshot.phase, snapshot.continuation), f"Wrong diagnostic state or clock for {key}/{kind}/{elapsed}")
        close(number(row, "cumulative_net"), work_for(accepted), f"Diagnostic ledger must stop at its date for {key}/{kind}/{elapsed}")
        if kind == "common" and elapsed in staged_rows:
            for resolution in ("coarse", "half"):
                insist(row[f"{resolution}_sha256"] == staged_rows[elapsed][f"snapshot_{resolution}_sha256"],
                       f"Diagnostic clone identity differs from boundary checkpoint for {key}/{elapsed}/{resolution}")
        anchor, _, _ = at_boundary(history, elapsed)
        if snapshot.phase == "operation_end" and anchor is not None:
            for resolution in ("coarse", "half"):
                insist(row[f"{resolution}_sha256"] == anchor[f"post_{resolution}_sha256"],
                       f"Diagnostic used something other than the committed post-state for {key}/{elapsed}/{resolution}")

        metrics = exact_metrics(model, state)
        for field in ("load_energy", "load_passive_energy", "load_ergotropy", "c_abs", "c_real", "c_imag"):
            close(number(row, field), metrics[field], f"Independent snapshot {field} for {key}/{elapsed}", HALF_TOL)
        close(number(row, "load_current"), metrics["load_current"] if g == G else 0, f"Actual exchange current for {key}/{elapsed}", HALF_TOL)
        close(number(row, "hypothetical_connected_current"), metrics["load_current"], f"Hypothetical connected current for {key}/{elapsed}", HALF_TOL)
        close(number(row, "global_energy"), model.energy(state, g), f"Actual Hamiltonian energy for {key}/{elapsed}")
        close(number(row, "exchange_energy"), metrics["exchange_energy"] if g == G else 0, f"Actual interaction energy for {key}/{elapsed}")

        wait = ticks(row, "elapsed_connected")
        insist(0 <= wait <= HORIZON and wait % GRID == 0 and int(row["candidate_count"]) == HORIZON//GRID+1
               and number(row, "source_coupling") == g, f"Incorrect diagnostic candidate grid for {key}/{elapsed}")
        _, _, after, _, _ = dynamics_step(model, state, 0, wait)
        full_net = model.energy(state, g)-model.energy(after, G)
        connect_input = model.energy(state, G)-model.energy(state, g)
        close(number(row, "reconnect_on"), connect_input, f"Required diagnostic reconnect work for {key}/{elapsed}")
        close(number(row, "max_net"), number(row, "connected_max_net")-number(row, "reconnect_on"), f"Candidate reconnect debit for {key}/{elapsed}")
        close(number(row, "max_net_half"), number(row, "connected_max_net_half")-number(row, "reconnect_on_half"), f"Half candidate reconnect debit for {key}/{elapsed}")
        close(number(row, "direct_max_net"), full_net, f"Independent full-H selected diagnostic for {key}/{elapsed}")
        close(number(row, "max_net"), full_net, f"Diagnostic local observables versus full Hamiltonian for {key}/{elapsed}")
        difference = abs(number(row, "max_net")-number(row, "max_net_half"))
        close(number(row, "step_error"), difference, f"Diagnostic precision margin for {key}/{elapsed}")
        insist(number(row, "max_net_grid_step_error_bound") <= HALF_TOL and number(row, "max_direct_residual") <= TOL
               and number(row, "max_balance_residual") <= TOL, f"Unresolved diagnostic accounting for {key}/{elapsed}")
        usable = number(row, "max_net")-difference > TOL and number(row, "direct_max_net") > TOL
        insist(flag(row, "accepted") == usable, f"Incorrect diagnostic acceptance for {key}/{elapsed}")
        close(number(row, "diagnostic_work"), number(row, "direct_max_net") if usable else 0.0,
              f"Credited diagnostic work for {key}/{elapsed}")
    return len(records)


def audit_endpoints(data, histories, checkpoints, cutoff):
    rows = read_unique(read_rows(data / "m26_endpoints.csv"), branch_key)
    insist(rows.keys() == M26_BRANCHES, "M26 endpoint branch set differs from ledger")
    for key, row in rows.items():
        accepted = accepted_to(histories[key], cutoff)
        net = work_for(accepted)
        half, bound = precision(accepted)
        insist(abs(half-net) <= bound+TOL, f"Long-run aligned half-step work exceeds resolution for {key}")
        last = checkpoints[*key, cutoff]
        observed = cutoff if last["ending"] == "active" else ticks(last, "anchor_elapsed")
        insist((int(row["count"]), int(row["attempts"]), row["ending"], ticks(row, "elapsed_observed"), ticks(row, "common_limit"),
                ticks(row, "last_extraction_elapsed")) == (len(accepted), len(histories[key]), last["ending"], observed, cutoff,
                ticks(accepted[-1], "elapsed_total")), f"Endpoint does not distinguish completed work and active observation for {key}")
        close(number(row, "cumulative_net"), net, f"Endpoint cumulative accepted work for {key}")
        close(number(row, "cumulative_rate"), net / (cutoff/1000), f"Common-cut endpoint rate for {key}")
        close(number(row, "cumulative_net_half_aligned"), half, f"Endpoint aligned half-step credited work for {key}")
        close(number(row, "cumulative_step_error_bound"), bound, f"Endpoint cumulative resolution bound for {key}", 1e-16)
    return rows


def audit_count_interval(data, histories, cutoff):
    accepted = {key: accepted_to(rows, cutoff) for key, rows in histories.items()}
    counts = read_unique(read_rows(data / "m26_count_comparison.csv"), lambda row: (*branch_key(row), int(row["count"])))
    fields = ("count", "elapsed_total", "cumulative_net", "cumulative_rate", "post_load_energy", "post_load_passive_energy",
              "post_load_ergotropy", "post_bare_chain_energy", "post_c_abs", "post_c_phase", "record_source")
    expected = {(*key, int(row["count"])): row for key, rows in accepted.items() for row in rows}
    insist(counts.keys() == expected.keys(), "Same-count comparisons include missing or unaccepted entries")
    for key, row in counts.items():
        insist(all(row[field] == expected[key][field] for field in fields), f"Count comparison does not use committed data for {key}")
    intervals = read_unique(read_rows(data / "m26_action_summary.csv"), lambda row: (*branch_key(row), ticks(row, "interval_end")))
    times = [tick for tick in COMMON_TIMES if tick <= cutoff]
    insist(intervals.keys() == {(*key, tick) for key in M26_BRANCHES for tick in times}, "Action summaries miss a common interval")
    for key, values in accepted.items():
        prior = 0
        for now in times:
            row = intervals[*key, now]
            epoch = accepted_to(values, now, prior)
            duration = [number(event, "duration") for event in epoch]
            work = [number(event, "net_work") for event in epoch]
            insist((ticks(row, "interval_start"), int(row["count"]), int(row["short_interval_count"]), int(row["tiny_work_count"]))
                   == (prior, len(epoch), sum(value <= 0.10 for value in duration), sum(value <= 1e-8 for value in work)),
                   f"Action interval totals differ for {key}/{now}")
            for field, measured, statistic in (("minimum_interval", duration, min), ("median_interval", duration, median), ("median_work", work, median)):
                if measured:
                    close(number(row, field), statistic(measured), f"Action interval {field} for {key}/{now}")
                else:
                    insist(row[field] == "", f"A nonexistent action has a statistic for {key}/{now}/{field}")
            prior = now
    return len(counts), len(intervals)


def gap_key(row):
    return row["origin"], row["left"], row["right"], ticks(row, "elapsed_total")


def audit_crossovers(data, histories, cutoff):
    gaps = read_unique(read_rows(data / "m26_gap.csv"), gap_key)
    switches = read_unique(read_rows(data / "m26_crossovers.csv"), gap_key)
    expected_gaps = set()
    expected_switches = set()
    for origin in sorted(ORIGINS):
        for left, right in combinations(("A", "B", "C25", "E"), 2):
            series = []
            for policy in (left, right):
                accepted = accepted_to(histories[origin, policy], cutoff)
                times = [ticks(row, "elapsed_total") for row in accepted]
                work = [0.0]
                errors = [0.0]
                for row in accepted:
                    work.append(work[-1]+number(row, "net_work"))
                    errors.append(errors[-1]+abs(number(row, "candidate_net")-number(row, "candidate_net_half")))
                series.append((times, work, errors))
            last_resolved = ""
            grid = {0, cutoff, *(time for time in COMMON_TIMES if time <= cutoff), *series[0][0], *series[1][0]}
            for tick in sorted(grid):
                key = origin, left, right, tick
                nl, nr = (bisect_right(points, tick) for points, _, _ in series)
                gap = series[0][1][nl]-series[1][1][nr]
                bound = TOL+series[0][2][nl]+series[1][2][nr]
                leader = left if gap > bound else right if gap < -bound else ""
                row = gaps[key]
                expected_gaps.add(key)
                insist((int(row["left_count"]), int(row["right_count"]), row["leader"]) == (nl, nr, leader),
                       f"Resolved gap uses unexecuted events or incorrect bound at {key}")
                close(number(row, "gap"), gap, f"Cumulative gap for {key}")
                close(number(row, "resolution_bound"), bound, f"Pair resolution bound for {key}", 1e-16)
                if leader:
                    if last_resolved and leader != last_resolved:
                        expected_switches.add(key)
                        event = switches[key]
                        insist((event["leading_before"], event["leading_after"]) == (last_resolved, leader)
                               and all(event[field] == row[field] for field in ("gap", "resolution_bound", "left_count", "right_count")),
                               f"Incorrect resolved crossover at {key}")
                    last_resolved = leader
    insist(gaps.keys() == expected_gaps and switches.keys() == expected_switches, "Unexpected or missing pair-gap or crossover event")
    return len(gaps), len(switches)


def audit_benchmark(data, stage_root, published):
    original = read_rows(stage_root / "benchmark" / "m26_benchmark.csv")
    copied = read_rows(data / "m26_benchmark.csv")
    insist(original == copied, "M26 merged benchmark differs from the stage output")
    branches = read_unique(copied, branch_key)
    insist(branches.keys() == {("S0", policy) for policy in CONTINUED}, "M26 benchmark is missing a continued policy")
    for key, row in branches.items():
        inherited = published[key]
        start, end = ticks(row, "start_elapsed"), ticks(row, "end_elapsed")
        measured = number(row, "seconds")
        attempts = int(row["attempts"])
        insist(start == inherited.elapsed and end > start and measured > 0 and int(row["inherited_count"]) == 30,
               f"Benchmark did not start from the inherited state for {key}")
        insist(1 <= attempts <= 3 and int(row["accepted"]) <= attempts, f"Invalid benchmark action counts for {key}")
        calls = (CAP-start)*attempts/(end-start)
        close(number(row, "linear_estimated_total_count"), inherited.count+calls, f"Estimated total extraction count for {key}")
        close(number(row, "linear_estimated_serial_seconds_per_origin"), measured*calls/attempts, f"Estimated runtime for {key}")


def audit_prefix_sentinels():
    check_suffix_sentinels()
    from run_m26 import known_at

    class UnobservedFuture(dict):
        def __getitem__(self, key):
            if key == "elapsed_total":
                raise ValueError("A saved cutoff read an unobserved forecast target")
            return super().__getitem__(key)

    withheld = UnobservedFuture(stop_reason="forecast", decision_elapsed_total="150.02")
    insist(known_at(withheld, 147_000, 150_000) == (-1, -1), "Future decision leaked into the cutoff")
    plan = {"stop_reason": "forecast", "decision_elapsed_total": "149.98", "elapsed_total": "150.06"}
    insist(known_at(plan, 147_000, 150_000) == (149_980, 150_060), "An observed forecast was not retained")


def audit_ab_distance(data, stage_root, stage_times):
    path = data / "m26_ab_state.csv"
    if not path.exists() and max(stage_times) < CAP:
        return 0
    rows = read_unique(read_rows(path), lambda row: (row["origin"], ticks(row, "elapsed_total")))
    insist(rows.keys() == {(origin, tick) for origin in ORIGINS for tick in stage_times}, "Mismatched A/B physical comparison times")

    def norm(matrix):
        return float(np.linalg.svd(matrix, compute_uv=False).sum()/2)

    def load(matrix):
        return reduced_load(terminal_state(matrix))

    for (origin, tick), row in rows.items():
        parent = stage_root / f"t{tick//1000}" / origin
        pairs = []
        for policy in ("A", "B"):
            with np.load(parent / policy / "checkpoint.npz", allow_pickle=False) as state:
                insist(int(state["cutoff"]) == tick, f"A/B checkpoint clock differs for {origin}/{policy}/{tick}")
                pairs.append((state["snapshot_coarse"], state["snapshot_half"]))
        difference = pairs[0][0]-pairs[1][0]
        own_errors = [coarse-half for coarse, half in pairs]
        global_distance, reduced_distance = norm(difference), norm(load(difference))
        global_bound = sum(norm(error) for error in own_errors)
        reduced_bound = sum(norm(load(error)) for error in own_errors)
        half_difference = pairs[0][1]-pairs[1][1]
        insist(reduced_distance <= global_distance + TOL, f"Partial trace increased A/B trace distance for {origin}/{tick}")
        insist(abs(global_distance-norm(half_difference)) <= global_bound+TOL
               and abs(reduced_distance-norm(load(half_difference))) <= reduced_bound+TOL,
               f"A/B trace distance exceeds the aligned half-step bound for {origin}/{tick}")
        for field, expected in (("global_trace_distance", global_distance), ("load_trace_distance", reduced_distance),
                                ("global_step_distance_bound", global_bound), ("load_step_distance_bound", reduced_bound)):
            close(number(row, field), expected, f"Independent singular-value trace distance for {origin}/{tick}/{field}")
    return len(rows)


def audit_aligned_half(model, additions, published, endpoints, cutoff):
    """Replay S0 with exact propagation from the archived half-step state at the shared clocks."""
    checked = 0
    max_error = 0.0
    for policy in sorted(CONTINUED):
        key = "S0", policy
        inherited = published[key]
        if inherited.elapsed > cutoff:
            continue
        _, state = inherited.states()
        work, _ = precision(inherited.history)
        for row in additions[key]:
            _, before, after, _, _ = dynamics_step(model, state, ticks(row, "tau"), ticks(row, "elapsed_connected"))
            direct = model.energy(state)-model.energy(after)
            error = abs(direct-number(row, "direct_net_half"))
            close(direct, number(row, "direct_net_half"), f"Independent aligned half-step extraction for {attempt_key(row)}")
            max_error = max(max_error, error)
            if flag(row, "accepted"):
                work += direct
                state = after
            else:
                state = before
            checked += 1
        close(work, number(endpoints[key], "cumulative_net_half_aligned"), f"Independent S0 accumulated aligned half-step work for {policy}")
    return checked, max_error


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("data", nargs="?", default=ROOT / "results", type=Path)
    parser.add_argument("--cutoff", type=int, default=540, choices=tuple(t//1000 for t in STAGE_TIMES))
    parser.add_argument("--stage-root", type=Path, default=ROOT / "stages")
    parser.add_argument("--m25", type=Path, default=M25)
    parser.add_argument("--m23", type=Path, default=M23)
    args = parser.parse_args()
    cutoff = args.cutoff*1000
    published = official_m25(args.m25)
    registered = read_unique(read_rows(args.data / "m26_sources.csv"), lambda row: row["origin"])
    insist(registered == {origin: published[origin, "A"].source for origin in ORIGINS}, "M26 changed the M25 source manifest")
    histories, additions = continued_ledgers(args.data, published, cutoff)
    checkpoints = read_unique(read_rows(args.data / "m26_checkpoints.csv"), lambda row: (*branch_key(row), ticks(row, "cutoff")))
    stage_times = [tick for tick in STAGE_TIMES if tick <= cutoff]
    insist(checkpoints.keys() == {(*key, tick) for key in M26_BRANCHES for tick in stage_times}, "M26 is missing a staged boundary checkpoint")
    future = defaultdict(list)
    for item in read_rows(args.data / "m26_future.csv"):
        future[branch_key(item)].append(item)
    insist(future.keys() == M26_BRANCHES, "M26 future diagnostics do not cover all branches")
    endpoints = audit_endpoints(args.data, histories, checkpoints, cutoff)
    time_rows = audit_time_comparison(args.data, histories, published, cutoff, endpoints)
    counts, intervals = audit_count_interval(args.data, histories, cutoff)
    gap_rows, crossover_rows = audit_crossovers(args.data, histories, cutoff)
    audit_benchmark(args.data, args.stage_root, published)
    audit_prefix_sentinels()
    distances = audit_ab_distance(args.data, args.stage_root, stage_times)

    witnesses = {}
    boundary_error = 0.0
    future_count = 0
    truth = ExactContinuation()
    for key in sorted(histories):
        staged = {t: checkpoints[*key, t] for t in stage_times}
        needed = {ticks(row, "elapsed_total") for row in future[key]} | set(stage_times)
        needed.update(ticks(row, "anchor_elapsed") for row in staged.values())
        reconnect, independent = audit_extensions({key: additions[key]}, published, truth, {key: needed}, args.m23, cutoff)
        witnesses.update(reconnect)
        last_count = 0
        boundary_history = [*published[key].history, *additions[key]]
        for tick, row in staged.items():
            last_count, error = check_one_cutoff(truth, key, row, boundary_history, independent[key], args.stage_root, last_count)
            boundary_error = max(boundary_error, error)
        future_count += check_future(truth, key, future[key], histories[key], independent[key], staged, cutoff)
    samples = audit_traces(args.data, additions, witnesses)
    search_count = audit_search(args.data, additions)
    half_count, half_error = audit_aligned_half(truth, additions, published, endpoints, cutoff)
    extensions = [row for rows in additions.values() for row in rows]
    changed = sum(ticks(row, "duration") != ticks(row, "half_replay_duration") for row in extensions)
    print(f"PASS: {len(histories)} branches inherited from M25, {len(extensions)} extension attempts, {samples} trajectory rows, "
          f"{search_count} retrospective candidates and {future_count} independently checked diagnostic states")
    print(f"PASS: {len(checkpoints)} boundary checkpoints, maximum independent snapshot difference {boundary_error:.6g}, "
          f"6 causal suffix/forecast sentinels, {changed}/{len(extensions)} changed half-step replay times")
    print(f"PASS: {counts} count entries, {time_rows} common-time and {intervals} interval entries, "
          f"{gap_rows} resolution-aware pair points and {crossover_rows} crossovers")
    print(f"PASS: {distances} A/B trace-distance records and {half_count} S0 aligned half-step attempts "
          f"replayed independently; maximum half-step direct work difference {half_error:.6g}")


if __name__ == "__main__":
    main()
