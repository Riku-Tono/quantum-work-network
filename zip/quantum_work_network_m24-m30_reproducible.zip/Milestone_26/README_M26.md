# M26 再現手順

M25のA・B・C25・Eを4起点で経過540まで追跡する。条件と比較の定義は [正式計算の条件](PROTOCOL_M26.md)、結果は [報告書](MILESTONE_26_UNCAPPED_LONG_HORIZON_REPORT.md) を参照。

## 実行

Windows PowerShellで `Milestone_26` をカレントディレクトリにする。Python 3.14、NumPy 2.5.5、Matplotlib 3.10.9を使用した。隣の `Milestone_23`・`Milestone_24`・`Milestone_25` の正式成果物が必要。再計算先には新しいディレクトリ名を指定する。

```powershell
py -3.14 -m pip install -r ../Milestone_23/requirements.txt
$env:OPENBLAS_NUM_THREADS = '2'
py -3.14 -B run_m26.py redo/benchmark --benchmark
py -3.14 -B run_m26.py redo/t150 --cutoff 150 --workers 4
py -3.14 -B run_m26.py redo/t300 --cutoff 300 --previous redo/t150 --workers 4
py -3.14 -B run_m26.py redo/t540 --cutoff 540 --previous redo/t300 --workers 4
py -3.14 -B collect_m26.py redo/results redo/t150 redo/t300 redo/t540 --benchmark redo/benchmark
py -3.14 -B verify_m26.py redo/results --stage-root redo
py -3.14 -B plot_m26.py --data redo/results --output redo/figures
```

配布済み結果の独立監査は `py -3.14 -B verify_m26.py`。メモリに余裕がない場合は `--workers 1` を指定する。150・300の `checkpoint.npz` は直前の確定状態と境界時刻の状態を両方保存する。`--previous` に完成済みの段階フォルダーを指定すると、その書き出し時点から再開できる。途中の試行は期限540を基準とした元の窓で再評価し、境界時刻の状態および確定済み予定が保存値と一致することを検査する。

## データ

| ファイル | 内容 |
| --- | --- |
| `m26_history.csv` | 全試行の候補と採否、決定時刻、抽出前後の状態量・ハッシュ、正味仕事、会計。`record_source=m25_archive` は正式な採択1〜30回、`m26` は延長 |
| `m26_trajectories.csv` | 延長で実行した試行の接続・待機・抽出後のデータ。1〜30回の記録は [M25の軌道](../Milestone_25/results/m25_trajectories.csv) |
| `m26_time_comparison.csv` | 共通時刻での実行済み仕事・回数、前区間の仕事と率、M25の30回上限ありの対照 |
| `m26_count_comparison.csv` | 同じ採択回数での累積結果と抽出直後状態量 |
| `m26_future.csv` | 共通時刻、代表採択回数直後、早期終了時の複製状態による18.00窓の仕事診断 |
| `m26_endpoints.csv` | 枝別の終端理由、最後の実行時刻、共通540での累積値 |
| `m26_gap.csv`・`m26_crossovers.csv` | 左方式−右方式の右連続の累積仕事差と、数値分解能を超えた先行方式の交代 |
| `m26_action_summary.csv` | 共通区間ごとの採択数、仕事と間隔の中央値、極小仕事と短間隔の件数 |
| `m26_ab_state.csv` | 保存境界でのAとBの全状態・負荷状態のトレース距離と、両方式の粗半差の和 |
| `m26_checkpoints.csv` | 150・300・540の境界状態と最後の確定状態のハッシュ、確定予定、再開時の照合残差 |
| `m26_search.csv` | 延長Eの粗精待機・抽出探索と各回の採択候補 |
| `m26_benchmark.csv`・`m26_sources.csv` | 短縮実測と線形外挿、起点とM25由来の入力情報 |

時間は起点からのモデル経過。`duration` は当該試行の待機込み経過、`elapsed_observed` は制御が実際に進んだ終端。`known_*_tick` はモデル時間の1000分の1を単位とする整数で、未確定は−1。`cumulative_net_half_aligned` は粗刻みの実行時刻で半刻み状態を引き継いだ値。`half_replay_duration` はその半刻み開始状態から当該回の選択を再評価した時刻で、Eは粗で選んだ待機を固定する。`continuation=True` は早期終了後または最終格子の端数に対する無操作発展の診断。

## 図

1. [累積正味仕事](figures/m26_01_work_over_time.png)
2. [累積時間率](figures/m26_02_rate_over_time.png)
3. [累積抽出回数](figures/m26_03_count_over_time.png)
4. [各回の正味仕事と間隔](figures/m26_04_action_work_intervals.png)
5. [区間ごとの仕事回収率](figures/m26_05_interval_rate.png)
6. [共通時刻での将来回収余地](figures/m26_06_future_capacity.png)
7. [M25の30回上限ありとの比較](figures/m26_07_m25_vs_m26.png)
8. [累積仕事差とリード交代](figures/m26_08_gaps_and_crossovers.png)
