"""Run the M24–M30 primary reproduction sequence in a separate workspace."""

import argparse
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys


PACKAGE = Path(__file__).resolve().parent
MILESTONES = tuple(range(24, 31))
WORKSPACE_MARKER = ".qwn-m24-m30-workspace"


def primary_steps(workers):
    worker = f"--workers {workers}"
    return {
        24: (
            "m24_oracles.py results",
            "run_m24.py results",
            "m24_plots.py --data results --output figures",
        ),
        25: (
            "run_m25.py stages/benchmark --rounds 2 --origins S0 --workers 1",
            f"run_m25.py stages/n10 --rounds 10 {worker}",
            f"run_m25.py stages/n20 --rounds 20 --previous stages/n10 {worker}",
            f"run_m25.py stages/n30 --rounds 30 --previous stages/n20 {worker}",
            "collect_m25.py results stages/n10 stages/n20 stages/n30 --benchmark stages/benchmark",
            "plot_m25.py --data results --output figures",
        ),
        26: (
            f"run_m26.py stages/benchmark --benchmark {worker}",
            f"run_m26.py stages/t150 --cutoff 150 {worker}",
            f"run_m26.py stages/t300 --cutoff 300 --previous stages/t150 {worker}",
            f"run_m26.py stages/t540 --cutoff 540 --previous stages/t300 {worker}",
            "collect_m26.py results stages/t150 stages/t300 stages/t540 --benchmark stages/benchmark",
            "plot_m26.py --data results --output figures",
        ),
        27: (
            f"run_m27.py stages --cutoffs 150 300 540 {worker}",
            f"verify_m27.py stages {worker} --output results/audit.json",
            "collect_m27.py --runs stages --output results",
            "compare_m27_checkpoints.py --stages stages --output results/m27_step_states.csv",
            f"diagnose_m27.py --stages stages --output results {worker}",
            "plot_m27.py --data results --output figures",
        ),
        28: (
            f"run_m28.py main --stages stages {worker}",
            "run_m28.py anchors --stages stages --anchors anchors",
            f"run_m28.py matched --stages stages --anchors anchors --groups F2-R {worker}",
            "reuse_m28_f1_history.py --stages stages --anchors anchors",
            f"run_m28.py matched --stages stages --anchors anchors --groups F1 {worker}",
            f"run_m28_oracle.py --stages stages --anchors anchors {worker}",
            f"run_m28_ablations.py --stages stages --anchors anchors {worker}",
            "analyze_m28_robustness.py --stages stages --output results --exploration exploration",
            f"verify_m28.py stages --sensitivity {worker} --output results/audit_primary.json",
            f"verify_m28.py stages --matched-only --anchors anchors --policies R0 R1 R3 R6 RH RP {worker} --output results/audit_matched.json",
            f"verify_m28.py stages --matched-only --anchors anchors --policies E {worker} --output results/audit_oracle.json",
            "collect_m28.py --stages stages --output results",
            "plot_m28.py --data results --output figures",
        ),
        29: (
            "prepare_unseen_m29.py --output .",
            f"run_m29.py --stages stages --reuse {worker}",
            "analyze_m29.py --stages stages --output results",
            "collect_m29.py --stages stages --output results",
            "plot_m29.py --data results --output figures",
        ),
        30: (
            f"run_m30.py --output . --no-reuse {worker}",
            "analyze_m30.py --root .",
            "plot_m30.py --data results --output figures",
            "m30_u05.py --stages stages --exact exact_online --output u05",
            "m30_causal_context.py --stages stages --output results",
            "m30_provenance.py --root . --output results",
        ),
    }


def audit_steps(workers):
    worker = f"--workers {workers}"
    return {
        24: ("verify_m24.py results",),
        25: (
            "verify_m25.py stages/benchmark --benchmark",
            "verify_m25.py results --stage-root stages",
        ),
        26: ("verify_m26.py results --stage-root stages",),
        27: ("verify_m27_diagnostics.py --stages stages --data results",),
        28: (
            f"verify_m28.py stages --matched-only --anchors anchors --groups F2-R --precisions coarse --policies Xphase Xamp Xcurrent Xinput {worker} --output results/audit_ablations.json",
        ),
        29: (
            f"verify_m29.py stages --groups F2-R {worker} --output results/audit_f2r.json",
            f"verify_m29.py stages --groups F1 {worker} --output results/audit_f1.json",
            f"verify_m29.py stages --groups unseen --policies RP P1 P2 P3 P4 R3 RH {worker} --output results/audit_unseen.json",
            "verify_m29.py --control m29_control.py --output results/audit_gate_inputs.json",
            "verify_m29.py --unseen unseen --output results/audit_unseen_preparations.json",
            "verify_m29.py --whole results --whole-stage-root stages --output results/audit_whole.json",
            "verify_m29.py --comparison-tables results --output results/audit_tables.json",
        ),
        30: (
            "run_m30.py --output . --one-shot --mode rk4 --origins U05 --precisions coarse --policies RP P3 P1 P3+IA --workers 1",
            f"verify_m30.py --stages stages --online exact_online --one-shot one_shot {worker} --cache audit_cache --output results/audit_independent.json",
            "verify_m30_u05.py --root .",
            "verify_m30_tables.py --root .",
        ),
    }


def invoke(directory, arguments, plan):
    argv = [sys.executable, "-B", *map(str, arguments)]
    print(f"[{directory}] {subprocess.list2cmdline(argv)}", flush=True)
    if not plan:
        environment = {**os.environ, "OPENBLAS_NUM_THREADS": "1"}
        subprocess.run(argv, cwd=directory, env=environment, check=True)


def initialize(workspace):
    if (workspace / WORKSPACE_MARKER).is_file():
        return
    if workspace.exists():
        raise ValueError(f"Choose a new directory for the reproduction workspace: {workspace}")
    workspace.mkdir(parents=True)
    for stage in (23, *MILESTONES):
        name = f"Milestone_{stage}"
        ignored = ("__pycache__", "stages", "one_shot", "audit_cache", "exact_online")
        if stage >= 24:
            ignored += ("results", "figures", "benchmark", "benchmark_uninterrupted", "exploration")
        if stage == 28:
            ignored += ("anchors",)
        if stage == 29:
            ignored += ("anchors", "unseen")
        if stage == 30:
            ignored += ("u05",)
        shutil.copytree(PACKAGE / name, workspace / name, ignore=shutil.ignore_patterns(*ignored))
    (workspace / WORKSPACE_MARKER).write_text("M24–M30 reproduction workspace\n", encoding="utf-8")


def formal(workspace, first, last, workers, audit, plan):
    if not plan:
        if first != 24 and not (workspace / WORKSPACE_MARKER).is_file():
            raise ValueError("Start at M24 in a new workspace. Select a later stage in a prepared workspace.")
        invoke(PACKAGE, ("verify_bundle_m23_inputs.py",), False)
        initialize(workspace)
    primary, independent = primary_steps(workers), audit_steps(workers)
    for stage in range(first, last + 1):
        directory = workspace / f"Milestone_{stage}"
        commands = primary[stage]
        if audit:
            archive = workspace / "Milestone_23" / "M23_all_results.zip"
            upstream_audit_ready = archive.is_file() or (plan and (PACKAGE / "Milestone_23" / archive.name).is_file())
            if stage in (24, 25) and not upstream_audit_ready:
                print(f"M{stage} original ZIP audit requires {archive}. The compact input check still runs.", flush=True)
            else:
                commands += independent[stage]
        for command in commands:
            invoke(directory, shlex.split(command), plan)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("quick", "formal"))
    parser.add_argument("--workspace", type=Path, required=True, help="Output directory outside the extracted package")
    parser.add_argument("--from-stage", type=int, choices=MILESTONES, default=24)
    parser.add_argument("--through-stage", type=int, choices=MILESTONES, default=30)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--audit", action="store_true", help="Run additional independent checks after each formal stage")
    parser.add_argument("--plan", action="store_true", help="Print commands without running or writing anything")
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    if workspace.is_relative_to(PACKAGE) or PACKAGE.is_relative_to(workspace):
        parser.error("Choose a separate output directory outside the extracted package")
    if args.from_stage > args.through_stage or args.workers < 1:
        parser.error("Use increasing stage numbers and one or more workers")
    if args.mode == "quick":
        invoke(PACKAGE, ("verify_bundle_m23_inputs.py",), args.plan)
        invoke(PACKAGE, ("Milestone_30/m30_u05.py", "--local-only", "--output", workspace), args.plan)
    else:
        formal(workspace, args.from_stage, args.through_stage, args.workers, args.audit, args.plan)


if __name__ == "__main__":
    main()
