# Milestone 4 reproduction package

This package contains the Rust source, locked dependencies, Milestone 4 report,
and the stored CSV outputs for the Milestone 4 coherent-input experiments.

## Requirements

- Rust toolchain with Cargo
- Dependencies already cached when using `--offline`

## Verify and run

From this directory:

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo build --release --offline

cargo run --release --offline --bin first_experiment
cargo run --release --offline --bin coherent_input_sanity
cargo run --release --offline --bin coherent_same_time_match
cargo run --release --offline --bin coherent_robustness
```

Each run writes its CSV files to the current directory. The previously stored
reference outputs are under `results/`; keep them unchanged for comparison.

The main result statement and its scope limits are in
`MILESTONE_4_RESULT.md`. `README.md` documents the model conventions and the
first Milestone 4 run.

## Package boundary

This is the Milestone 4 code boundary. The later Milestone 5a
time-dependent-RK4 module and binary are intentionally not included.
