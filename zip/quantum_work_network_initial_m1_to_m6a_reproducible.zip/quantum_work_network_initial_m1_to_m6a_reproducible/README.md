# Quantum Work Network: initial milestones M1 to M6a

This parent package reconstructs the initial Quantum Work Network line from the
surviving source snapshots, numerical outputs, and the supplied report folder.
Original files were copied; the source locations were not modified.

## Included stages

- `MILESTONE_1`: static operators, partial trace, and ergotropy foundations
- `MILESTONE_2`: Liouvillian and dense time propagation
- `MILESTONE_2_1`: full-model ignored integration smoke test
- `MILESTONE_3`: diagnostics and signed power accounting
- `MILESTONE_3_1`: corrected clean Milestone 3 snapshot
- `MILESTONE_4`: first coherent-input A/B experiments and stored CSV results
- `MILESTONE_5A`: time-dependent RK4 implementation and sanity result
- `MILESTONE_5B`: coherent-drive sanity result
- `MILESTONE_5C`: coherent-drive energy-matched comparison
- `MILESTONE_6A`: explicit ideal load-work extraction
- `reports_original`: the 18 files supplied in the original report folder

## Basic verification

For each milestone folder containing `Cargo.toml`, run from that folder:

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo build --release --offline
```

Some stages contain a dense 576 x 576 integration smoke test marked `ignored`.
Run it explicitly only when needed, following the stage README. Milestones 1,
2, and 3.1 did not originally include `Cargo.lock`. Validation in this copied
package generated lock files so future runs use the versions that passed here.

The earliest snapshots predate the current `rustfmt` output and can report
format-only differences under `cargo fmt -- --check`. Their original formatting
is preserved; successful release tests and builds are the execution verdict.

## Result reproduction

Stages M4 through M6a contain their own `REPRODUCE.md`, source, reports, and
stored reference results. Preserve `results/` before rerunning binaries so new
outputs can be compared against the stored copies.

The supplied report folder alone was not reproducible because it contained no
Rust source or CSV data. This reconstructed package supplies those missing
artifacts from the matching saved Codex workspaces.
