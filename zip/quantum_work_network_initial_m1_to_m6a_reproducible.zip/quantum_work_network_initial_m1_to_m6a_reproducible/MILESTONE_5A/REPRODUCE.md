# Milestone 5a reproduction

Run from this folder:

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo build --release --offline
cargo run --release --offline --bin time_dependent_sanity
```

Milestone 5a implements and verifies the fixed-maximum-step RK4 propagator for
the time-dependent Lindblad equation. The stored sanity metrics are under
`results/`. The implementation result and limits are documented in
`MILESTONE_5A_IMPLEMENTATION_REPORT.md`.

Runtime fields and the last digits of floating-point diagnostics can vary by
platform. The dense 576 x 576 smoke test is intentionally ignored unless run
explicitly in release mode.
