# Milestone 5c reproduction package

This folder contains the Milestone 5c Rust source, locked dependencies,
reports, and the five stored result CSV files.

## Requirements

- Rust toolchain with Cargo
- Dependencies already cached when using `--offline`

## Verify the code

Run these commands from this folder:

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo build --release --offline
```

The package was checked with 60 passed, 0 failed, and one intentionally
ignored dense 576 x 576 smoke test.

## Reproduce Milestone 5c

```text
cargo run --release --offline --bin coherent_drive_match
```

The run writes these files to the current folder:

- `coherent_drive_match_grid.csv`
- `coherent_drive_match_roots.csv`
- `coherent_drive_match_comparison.csv`
- `coherent_drive_match_timeseries.csv`
- `coherent_drive_match_convergence.csv`

The previously stored reference copies are under `results/`. Keep those files
unchanged and compare newly generated files against them.

The result, success conditions, fairness boundary, and unconfirmed claims are
documented in `MILESTONE_5C_REPORT.md`.
