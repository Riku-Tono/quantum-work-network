# Coherent-input robustness check

## Scope

- J = 1, g = 0.25
- p_A = 0.1
- t_eval = 3.0, 5.0, 7.9, 10.0
- gamma_phi = 0.1, 0.2, 0.5, 1.0
- 16 matched conditions plus the same 16 equal-input conditions with p_B=p_A
- No Lindblad injection, continuous drive, Hamiltonian/model change, or large parameter search

## Matching method

For this source-free initial-state family, load energy was numerically verified to be linear in p. The maximum relative residual of `E(p=0.1) = 0.1 E(p=1)` across the tested B conditions was 1.5269204294532284e-14.

Therefore each candidate was obtained from `p_B = E_A / E_B(p=1)`, constrained to [0,1], and then rerun at that p_B. Every final matched run independently passed the required relative load-energy error below 1e-4.

## Final matched aggregation

- MATCH: 16
- A ergotropy greater than B: 16
- Reversed, B greater than A: 0
- NO_MATCH: 0
- Minimum A/B ergotropy ratio: 1.2292105822463972
- Median A/B ergotropy ratio: 3.2179083178375452
- Maximum A/B ergotropy ratio: 49.318165801320376
- Maximum relative load-energy matching error: 1.1803395829689295e-14
- Matched physical-check failures: 0
- Equal-input physical-check failures: 0

## Matched A/B ergotropy ratio

| t_eval \ gamma_phi | 0.1 | 0.2 | 0.5 | 1.0 |
|---:|---:|---:|---:|---:|
| 3.0 | 1.2292 | 1.5239 | 3.0488 | 11.8229 |
| 5.0 | 1.3630 | 1.8628 | 4.6516 | 18.7885 |
| 7.9 | 1.6139 | 2.5803 | 9.0586 | 48.2088 |
| 10.0 | 1.9448 | 3.3870 | 11.4116 | 49.3182 |

## Matched p_B

| t_eval \ gamma_phi | 0.1 | 0.2 | 0.5 | 1.0 |
|---:|---:|---:|---:|---:|
| 3.0 | 0.122749 | 0.148955 | 0.250376 | 0.506581 |
| 5.0 | 0.114481 | 0.129186 | 0.177563 | 0.282313 |
| 7.9 | 0.145248 | 0.192941 | 0.318084 | 0.474159 |
| 10.0 | 0.114476 | 0.129264 | 0.174299 | 0.241335 |

Because p_A=0.1, these p_B values are also the initial-energy ratios multiplied by 0.1. The matched comparisons do not use equal initial input. The equal-input rows are included separately in the results CSV under `comparison_type=EQUAL_INPUT`.

For both matched and equal-input comparisons, A ergotropy exceeded B in all 16 conditions. This is a finite 4x4 robustness check, not a general statement over untested times or dephasing rates.

## Verification

- `cargo fmt --all -- --check`: passed
- `cargo test --release --offline`: 39 passed, 0 failed, 1 explicitly ignored dense smoke test
- Results CSV contains 32 rows: 16 MATCHED and 16 EQUAL_INPUT
