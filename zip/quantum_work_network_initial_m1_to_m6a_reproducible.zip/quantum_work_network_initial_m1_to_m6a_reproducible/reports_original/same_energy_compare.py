from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "outputs" / "coherent_input_timeseries.csv"
OUTPUT_DIR = ROOT / "outputs"
OUTPUT_CSV = OUTPUT_DIR / "coherent_input_same_energy.csv"
OUTPUT_JSON = ROOT / "work" / "same_energy_analysis.json"

CONDITIONS = ("A_no_noise", "B_dephasing")
TARGETS = np.arange(0.01, 0.101, 0.01)
H_LOAD = np.diag([0.0, 1.0, 2.0]).astype(complex)
TOLERANCE = 1.0e-9


def first_rising_branch(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.sort_values("time").reset_index(drop=True)
    energies = frame["load_energy"].to_numpy(float)
    end = 0
    for index in range(1, len(energies)):
        if energies[index] > energies[index - 1]:
            end = index
        else:
            break
    return frame.iloc[: end + 1].copy()


def density_matrix(row: pd.Series) -> np.ndarray:
    rho = np.diag(
        [
            float(row["load_level_population_0"]),
            float(row["load_level_population_1"]),
            float(row["load_level_population_2"]),
        ]
    ).astype(complex)
    for i, j in ((0, 1), (0, 2), (1, 2)):
        value = complex(float(row[f"load_rho_re_{i}_{j}"]), float(row[f"load_rho_im_{i}_{j}"]))
        rho[i, j] = value
        rho[j, i] = value.conjugate()
    return rho


def ergotropy(rho: np.ndarray) -> tuple[float, float]:
    rho_h = 0.5 * (rho + rho.conjugate().T)
    trace = float(np.trace(rho_h).real)
    rho_n = rho_h / trace
    eigenvalues = np.linalg.eigvalsh(rho_h).real
    if eigenvalues.min() < -TOLERANCE:
        raise ValueError(f"interpolated density matrix is not positive: {eigenvalues.min():.3e}")
    eigenvalues = np.clip(eigenvalues, 0.0, None)
    eigenvalues /= eigenvalues.sum()
    eigenvalues = np.sort(eigenvalues)[::-1]
    energy = float(np.trace(rho_n @ H_LOAD).real)
    passive_energy = float(eigenvalues @ np.array([0.0, 1.0, 2.0]))
    work = energy - passive_energy
    if abs(work) <= 10.0 * TOLERANCE:
        work = 0.0
    if work < 0.0:
        raise ValueError(f"negative ergotropy beyond tolerance: {work:.3e}")
    return energy, work


def interpolate_at_energy(branch: pd.DataFrame, target: float) -> dict[str, float | np.ndarray]:
    energies = branch["load_energy"].to_numpy(float)
    upper = int(np.searchsorted(energies, target, side="left"))
    if upper == 0 or upper >= len(branch):
        raise ValueError(f"target {target} is outside the strict interpolation range")
    lower = upper - 1
    e0, e1 = energies[lower], energies[upper]
    alpha = (target - e0) / (e1 - e0)
    row0, row1 = branch.iloc[lower], branch.iloc[upper]
    rho = (1.0 - alpha) * density_matrix(row0) + alpha * density_matrix(row1)
    time = (1.0 - alpha) * float(row0["time"]) + alpha * float(row1["time"])
    actual_energy, work = ergotropy(rho)
    delta_rho = np.diag(np.diag(rho))
    _, diagonal_work = ergotropy(delta_rho)
    coherence_work = work - diagonal_work
    coherence_l1 = float(np.abs(rho - delta_rho).sum())
    return {
        "time": time,
        "rho": rho,
        "work": work,
        "diagonal_work": diagonal_work,
        "coherence_work": coherence_work,
        "coherence_l1": coherence_l1,
        "actual_energy": actual_energy,
        "target_error": actual_energy - target,
        "lower_time": float(row0["time"]),
        "upper_time": float(row1["time"]),
        "alpha": alpha,
    }


source = pd.read_csv(SOURCE)
branches = {
    condition: first_rising_branch(source[source["condition"] == condition])
    for condition in CONDITIONS
}

rows: list[dict[str, float]] = []
for target in TARGETS:
    a = interpolate_at_energy(branches["A_no_noise"], float(target))
    b = interpolate_at_energy(branches["B_dephasing"], float(target))
    a_work = float(a["work"])
    b_work = float(b["work"])
    rows.append(
        {
            "target_load_energy": float(target),
            "A_time": float(a["time"]),
            "B_time": float(b["time"]),
            "A_load_ergotropy": a_work,
            "B_load_ergotropy": b_work,
            "ergotropy_difference_A_minus_B": a_work - b_work,
            "ergotropy_ratio_A_over_B": a_work / b_work if b_work != 0.0 else float("inf"),
            "A_load_coherence_l1": float(a["coherence_l1"]),
            "B_load_coherence_l1": float(b["coherence_l1"]),
            "A_diagonal_ergotropy": float(a["diagonal_work"]),
            "B_diagonal_ergotropy": float(b["diagonal_work"]),
            "A_coherence_ergotropy": float(a["coherence_work"]),
            "B_coherence_ergotropy": float(b["coherence_work"]),
            "A_actual_load_energy": float(a["actual_energy"]),
            "B_actual_load_energy": float(b["actual_energy"]),
            "A_energy_error": float(a["target_error"]),
            "B_energy_error": float(b["target_error"]),
            "actual_energy_difference_A_minus_B": float(a["actual_energy"]) - float(b["actual_energy"]),
            "A_lower_time": float(a["lower_time"]),
            "A_upper_time": float(a["upper_time"]),
            "A_interpolation_fraction": float(a["alpha"]),
            "B_lower_time": float(b["lower_time"]),
            "B_upper_time": float(b["upper_time"]),
            "B_interpolation_fraction": float(b["alpha"]),
        }
    )

fieldnames = list(rows[0])
with OUTPUT_CSV.open("w", newline="", encoding="utf-8") as handle:
    writer = csv.DictWriter(handle, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(rows)

analysis = {
    "source": str(SOURCE),
    "branches": {
        condition: {
            "samples": len(branch),
            "start_time": float(branch.iloc[0]["time"]),
            "end_time": float(branch.iloc[-1]["time"]),
            "start_energy": float(branch.iloc[0]["load_energy"]),
            "end_energy": float(branch.iloc[-1]["load_energy"]),
        }
        for condition, branch in branches.items()
    },
    "rows": rows,
    "checks": {
        "max_abs_A_energy_error": max(abs(row["A_energy_error"]) for row in rows),
        "max_abs_B_energy_error": max(abs(row["B_energy_error"]) for row in rows),
        "max_abs_actual_energy_difference": max(abs(row["actual_energy_difference_A_minus_B"]) for row in rows),
        "minimum_interpolated_eigenvalue": min(
            float(np.linalg.eigvalsh(interpolate_at_energy(branches[c], float(target))["rho"]).min())
            for c in CONDITIONS
            for target in TARGETS
        ),
    },
}
OUTPUT_JSON.write_text(json.dumps(analysis, indent=2), encoding="utf-8")
print(json.dumps(analysis, indent=2))
