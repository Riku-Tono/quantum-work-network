# Milestone 5b reproduction

Run from this folder:

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo build --release --offline
cargo run --release --offline --bin coherent_drive_sanity
```

The run writes `coherent_drive_timeseries.csv`, `coherent_drive_summary.csv`,
`coherent_drive_convergence.csv`, and `MILESTONE_5B_REPORT.md`. The three stored
reference CSV files are under `results/`; preserve them before rerunning for
comparison.

Milestone 5b is the coherent-drive sanity stage, not the energy-matched search
performed in Milestone 5c. Runtime and final floating-point digits can vary by
platform.
