# Milestone 6a reproduction package

This folder contains the Milestone 6a Rust source, locked dependencies,
reports, and the three stored result CSV files.

## Requirements

- Rust toolchain with Cargo
- Dependencies already cached when using `--offline`

## Verify the code

Run these commands from this folder:

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo build --release --offline
```

The package was checked with 68 passed, 0 failed, and one intentionally
ignored dense 576 x 576 smoke test.

## Reproduce Milestone 6a

```text
cargo run --release --offline --bin explicit_load_extraction
```

The run writes these files to the current folder:

- `explicit_load_extraction_results.csv`
- `explicit_load_extraction_checks.csv`
- `explicit_load_extraction_mapping.csv`
- `MILESTONE_6A_REPORT.md`

The previously stored reference CSV files are under `results/`. Keep those
files unchanged and compare newly generated files against them.

Milestone 6a deterministically reconstructs the confirmed Milestone 5c states;
it does not perform a new parameter search or matching experiment. The result,
checks, idealizations, and unconfirmed claims are documented in
`MILESTONE_6A_REPORT.md`.
