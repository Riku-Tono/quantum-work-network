# Precommit: phase-noise W-peak prediction

This record was generated before the eta=0.75 full trajectory.

## Fixed existing points

| eta | W peak | time |
|---:|---:|---:|
| 0.00 | 2.2435519997068172e-02 | 7.71 |
| 1.50 | 3.8080717406769921e-03 | 7.70 |
| 3.00 | 6.9917463344182883e-04 | 7.67 |


## Fixed candidate

`W_peak(eta) = A exp(-k eta)`

- ln A = -3.8102006568779934e+00
- A = 2.2143735218442824e-02
- k = 1.1561667172666619e+00
- reference-only R squared in log space = 9.9982909466329251e-01

The 3-point fit quality is not used for the verdict.

## Fixed new condition and prediction

- selected eta = 0.75
- gamma_site = eta/7 = 1.0714285714285714e-01
- predicted W peak = **9.3038620128203936e-03**
- reason: eta=0.75 is the first proposed candidate, exactly midway between 0 and 1.5, and has a larger predicted W signal than eta=2.25. Only eta=0.75 will be run.

All other settings remain N=7, Omega=0.2, vacuum initial state, dt=0.0025, save interval=0.01, t_final=10, fixed-step RK4, the same ergotropy definition, and global saved-grid W peak extraction.

## Fixed verdict thresholds

- Case A: relative error <= 0.10
- Case C: 0.10 < relative error <= 0.20
- Case B: relative error > 0.20
- Case D: configuration, numerical, or peak-resolution failure

No alternative model or second new eta will be run automatically.
