#!/usr/bin/env python3
"""Verify the fixed N=7 W-peak noise-dependence experiment."""
from __future__ import annotations

import argparse
import csv
import hashlib
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REFERENCE = ROOT / "data" / "reference"
RESULTS = ROOT / "reference-results"

REFERENCE_FILES = {
    0.0: (REFERENCE / "eta_0_noise_free_timeseries.csv", "f430feaccea0ff20070b4332c343c1854c4197873dfe2a165ee7d0881c0952a3"),
    1.5: (REFERENCE / "eta_1_5_timeseries.csv", "aa582f956aa8942bc886c537d02bbd6eadd2c75984cce10190079a81d917f3f5"),
    3.0: (REFERENCE / "eta_3_0_timeseries.csv", "7753116415567415330e3186ffa3008c78394b880eb7ff0ac1f909d897f5eb73"),
}
PRECOMMIT_HASH = "391f38595331986a8bb450522c5fbbfd106a5d4d0fc5488b05d2d0f9385a05ab"
EXPECTED = {"A": 2.2143735218442824e-02, "k": 1.1561667172666619, "predicted": 9.3038620128203936e-03}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def peak(path: Path) -> tuple[float, float, list[dict[str, str]]]:
    table = [row for row in rows(path) if int(float(row.get("chain_length", "7"))) == 7]
    if len(table) != 1001:
        raise ValueError(f"{path}: expected 1001 rows, found {len(table)}")
    index = max(range(len(table)), key=lambda i: float(table[i]["load_ergotropy"]))
    return float(table[index]["load_ergotropy"]), float(table[index]["time"]), table


def fit(points: list[tuple[float, float]]) -> tuple[float, float]:
    xs = [x for x, _ in points]
    ys = [math.log(y) for _, y in points]
    xbar, ybar = sum(xs) / len(xs), sum(ys) / len(ys)
    slope = sum((x - xbar) * (y - ybar) for x, y in zip(xs, ys)) / sum((x - xbar) ** 2 for x in xs)
    return math.exp(ybar - slope * xbar), -slope


def check_reference() -> tuple[float, float, float]:
    points = []
    for eta, (path, expected_hash) in REFERENCE_FILES.items():
        if digest(path) != expected_hash:
            raise ValueError(f"{path}: SHA-256 mismatch")
        value, time, _ = peak(path)
        points.append((eta, value))
        print(f"reference eta={eta:g}: W_peak={value:.16e} at t={time:.2f} [hash PASS]")
    a_value, k_value = fit(points)
    predicted = a_value * math.exp(-k_value * 0.75)
    for label, actual, expected in (("A", a_value, EXPECTED["A"]), ("k", k_value, EXPECTED["k"]), ("prediction", predicted, EXPECTED["predicted"])):
        if not math.isclose(actual, expected, rel_tol=0.0, abs_tol=2e-17):
            raise ValueError(f"fixed fit {label} mismatch: {actual:.18e} != {expected:.18e}")
    if digest(RESULTS / "PRECOMMIT.md") != PRECOMMIT_HASH:
        raise ValueError("PRECOMMIT.md SHA-256 mismatch")
    print("three-point fit and precommit hash: PASS")
    return a_value, k_value, predicted


def check_eta_075(timeseries: Path, summary_path: Path, label: str) -> None:
    value, time, table = peak(timeseries)
    predicted = EXPECTED["predicted"]
    error = abs(value - predicted) / predicted
    idx = max(range(len(table)), key=lambda i: float(table[i]["load_ergotropy"]))
    if idx in (0, len(table) - 1) or sum(float(r["load_ergotropy"]) == value for r in table) != 1:
        raise ValueError(f"{label}: peak is not a unique interior saved-grid maximum")
    if not (float(table[idx - 1]["load_ergotropy"]) < value and float(table[idx + 1]["load_ergotropy"]) < value):
        raise ValueError(f"{label}: peak neighbors do not decrease")
    gamma = 0.75 / 7.0
    if not all(int(float(r["chain_length"])) == 7 and math.isclose(float(r["total_gamma"]), 0.75, abs_tol=1e-15) and math.isclose(float(r["gamma_site"]), gamma, abs_tol=1e-15) for r in table):
        raise ValueError(f"{label}: N or gamma configuration mismatch")
    if not all(r["state_finite"].lower() == "true" and r["solver_finite"].lower() == "true" for r in table):
        raise ValueError(f"{label}: non-finite state or solver")
    summary = rows(summary_path)[0]
    if summary["solver_failure_count"] != "0" or summary["checks_passed"].lower() != "true":
        raise ValueError(f"{label}: summary numerical checks failed")
    if not math.isclose(value, float(summary["W_max"]), abs_tol=1e-16):
        raise ValueError(f"{label}: W peak differs from summary")
    verdict = "phase_noise_W_peak_exponential_candidate_retained" if error <= 0.10 else "not retained"
    print(f"{label}: W_peak={value:.16e} at t={time:.2f}; relative_error={error:.6%}; verdict={verdict}")


def main() -> None:
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--reference", action="store_true", help="validate supplied reference results")
    group.add_argument("--generated", action="store_true", help="validate a newly generated eta=0.75 run in the repository root")
    args = parser.parse_args()
    check_reference()
    if args.reference:
        check_eta_075(RESULTS / "eta_0_75" / "phase_noise_eta_0_75_timeseries.csv", RESULTS / "eta_0_75" / "phase_noise_eta_0_75_summary.csv", "shipped eta=0.75")
    else:
        check_eta_075(ROOT / "phase_noise_eta_0_75_timeseries.csv", ROOT / "phase_noise_eta_0_75_summary.csv", "generated eta=0.75")


if __name__ == "__main__":
    main()
