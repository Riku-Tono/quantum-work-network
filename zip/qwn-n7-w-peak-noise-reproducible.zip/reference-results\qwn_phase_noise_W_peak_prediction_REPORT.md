# ミニミニ実験: 総位相雑音に対するWピークの事前予測検証

## 最終判定

**`phase_noise_W_peak_exponential_candidate_retained`**

Case A。既存3点だけで固定した指数候補は、独立な追加1点eta=0.75と10%以内で整合した。

## 事前固定

- model: W_peak(eta) = A exp(-k eta)
- A = 2.2143735218442824e-02
- k = 1.1561667172666619e+00
- new eta = 0.75
- predicted W peak = 9.3038620128203936e-03
- Case A threshold: relative error <= 0.10
- PRECOMMIT SHA-256 = 391f38595331986a8bb450522c5fbbfd106a5d4d0fc5488b05d2d0f9385a05ab

3点fitのR squaredは支持判定に使用していない。追加点を見た後の再fitも行っていない。

## 新規軌道

- N=7, Omega=0.2, vacuum
- total gamma=0.75, gamma_site=1.0714285714285714e-01
- dt=0.0025, save interval=0.01, t_final=10
- 4000 fixed-step RK4 steps, 1001 saved points
- elapsed=2447.060 s
- numerical status=completed_with_fallback_diagnostic

既存eta=0, 1.5, 3.0軌道は再計算していない。

## Wピーク抽出

- observed W peak = 9.1509856038800939e-03
- peak time = 7.71
- previous = 9.1509499786677061e-3 at t=7.70
- next = 9.1505756037855608e-3 at t=7.72
- boundary peak = false
- equal peak count = 1
- saved time resolution = 0.01; half-grid time uncertainty = 0.005
- max neighbor W drop scale = 4.1000009453305564e-07 (4.4803927388893738e-05 of peak)

global saved-grid maximumは内部点で一意であり、両隣より高い。neighbor drop scaleは10%判定閾値より十分小さい。dt半減は今回の事前計画に含まれず、連続時間の厳密なpeakや積分誤差全体を保証する量ではない。

## 予測検証

- predicted = 9.3038620128203936e-03
- observed = 9.1509856038800939e-03
- absolute error = 1.5287640894029973e-04
- relative error = 1.6431500029734043e-02 = 1.643150%

relative errorは10%以下なのでCase Aである。

## 解釈限界

この結果は、同じ有限模型・N=7・Omega=0.2・eta=0.75・t<=10の追加1点が固定済み指数予測と整合したことだけを示す。普遍則、指数法則の確立、coherence因果、量子チャネル、散逸機構は主張しない。2点目の追加etaや別モデルは実行していない。

## Checks

14/14 PASS。詳細は `final_checks.csv` と `final_sha256_manifest.csv`。
