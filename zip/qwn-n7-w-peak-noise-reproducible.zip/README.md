# N=7 W-peak versus total phase noise

This package reproduces one narrow, precommitted result for the finite quantum work-network model:
an exponential *candidate*, fitted only to the stored `eta = 0, 1.5, 3.0` reference points, is tested
at the independently computed `eta = 0.75` point.

It is not evidence for a universal exponential law, a mechanism, a quantum advantage, or a result for
other chain lengths, drives, noise kernels, time steps, or time windows.

## Fixed model and run

| Item | Value |
| --- | --- |
| Chain length | `N = 7` |
| Drive strength | `Omega = 0.2` |
| Total phase noise | `eta = TOTAL_GAMMA` |
| New test point | `eta = 0.75`, uniformly `eta / 7` on the seven chain sites |
| Time step | `dt = 0.0025` |
| End time / saved points | `t = 10`, 1001 points at `0.01` spacing |
| Integrator | fixed-step RK4 |
| Load dimension | 3 |

## Result being reproduced

The reference fit, fixed before the new trajectory, is

```text
W_peak(eta) = A exp(-k eta)
A = 2.2143735218442824e-02
k = 1.1561667172666619
```

For `eta = 0.75`, it predicts `9.3038620128203936e-03`. The stored new trajectory gives
`9.1509856038800939e-03` at `t = 7.71`, a relative error of `1.643150%`, below the precommitted
10% threshold. The recorded verdict is:

```text
phase_noise_W_peak_exponential_candidate_retained
```

## Contents

- `data/reference/`: the three immutable reference trajectories at `eta = 0, 1.5, 3.0`.
- `reference-results/`: precommit, fitted candidate, the original eta=0.75 output, and checks.
- `src/` plus `Cargo.toml` / `Cargo.lock`: exact Rust model and trajectory binary.
- `scripts/verify.py`: validates the reference data, hashes, precommitted prediction, and either the
  shipped or newly generated eta=0.75 result.

## Quick verification (no long computation)

Requirements: Python 3.10+; no third-party Python packages.

```bash
python scripts/verify.py --reference
```

This checks all four supplied time series, reconstructs the three-point log-space fit, checks the
precommitted eta=0.75 prediction, and confirms the stored verdict.

## Full eta=0.75 reproduction

Requirements: Rust stable with Cargo. The lockfile pins the Rust dependency versions. Online Cargo
access is normally needed on a fresh machine to download them once.

```bash
cargo run --release --bin phase_noise_peak_prediction -- --benchmark-steps 16
cargo run --release --bin phase_noise_peak_prediction
python scripts/verify.py --generated
```

The full trajectory has 4000 RK4 steps and originally took about 2447 seconds on the reference
machine. It writes these generated files in the repository root (they are gitignored):

```text
phase_noise_eta_0_75_timeseries.csv
phase_noise_eta_0_75_summary.csv
phase_noise_eta_0_75_performance.csv
```

`--generated` verifies their physical configuration, numerical checks, W peak, and the precommitted
prediction threshold. Floating-point output can vary in the final digits across platforms; the
decision threshold, saved-grid peak conditions, and numerical-quality checks are the reproducibility
criteria.

## Integrity

The original result files and their SHA-256 values are in
`reference-results/final_sha256_manifest.csv`. The three reference trajectories retain their original
file hashes in `scripts/verify.py`; their source paths are intentionally not needed to rerun this
package.

## License note

`Cargo.toml` declares MIT for the Rust package. Confirm the intended copyright holder and add a
repository-level `LICENSE` before publishing this package publicly.
