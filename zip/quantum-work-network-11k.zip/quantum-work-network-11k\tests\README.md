# Tests

This reduced package has no separate Rust test target. The Milestone 11k binary
performs 13 analysis checks and writes their results to
`results/equal_input_post_peak_decay_checks.csv`.
