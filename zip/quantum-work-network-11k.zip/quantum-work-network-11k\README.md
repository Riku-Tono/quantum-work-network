# Milestone 11k reproduction package

This package reproduces the saved-trajectory analysis performed in Milestone 11k.
It does not recompute the underlying N=3 or N=7 quantum trajectories.

## Run

From this directory:

```bash
cargo run --release --offline --bin equal_input_post_peak_decay_analysis
```

If the Rust dependencies are not already cached, omit `--offline`:

```bash
cargo run --release --bin equal_input_post_peak_decay_analysis
```

The program reads the six files in `inputs/` and writes the reproduced CSVs to
`results/`. It also writes `results/MILESTONE_11K_GENERATED_REPORT.md`.

The submitted report in `reports/MILESTONE_11K_POST_PEAK_DECAY_REPORT.md`
contains final verification notes added after the analysis run, so the program
does not overwrite it.

Expected terminal verdict:

```text
late_tail_structure_remains
tail_classification=tail_residual_concentrated_late
new_time_evolution=false
```

## Contents

- `src/bin/`: the Milestone 11k analysis program
- `inputs/`: six fixed inputs from the preceding milestones
- `results/`: reproduced CSV outputs and the automatically generated report
- `reports/`: the finalized Milestone 11k report

