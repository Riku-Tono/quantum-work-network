# Milestone 11k: 等入力Wピーク後の減衰率・尾部残差解析

## 1. 範囲

11j正式成果物とN=3/N=7等入力保存時系列のみを使用。新規RK4・軌道再計算なし。主区間t=7.70～10.00、補助区間7.70～9.00と9.00～10.00。11j境界t_b=7.75295。

## 2. 瞬間減衰率

k_Q=-d ln(Q)/dtを中央差分、端点のみ片側差分で計算。floor=1e-10。N7実測W、11jモデルW、N3 Wと、N7のE/P/coherenceをCSV化した。

## 3. 低自由度モデル

Model A単一指数、Model B連続二段階指数（switch 8.5/9.0/9.5のみ）、Model C指数×線形だけを評価。AIC-like/BIC-likeは記述的比較で物理過程の証明ではない。

## 4. 主結果

BIC-like最良=model_B_two_stage_exponential、normalized RMSE=0.00809806、BIC-like=-4836.732603。Model A nRMSE=0.01014188、Model B nRMSE=0.00809806（switch=8.50, lambda1=0.15000, lambda2=0.20000）、Model C nRMSE=0.00913268。

## 5. 11j残差の尾部

post-peak absolute area=4.075384e-4、9～10 absolute fraction=0.596160、符号変化=1、最大正=1.839769e-4 at 7.70、最大負=-2.826439e-4 at 9.50。分類: **tail_residual_concentrated_late**。

## 6. E/W/passive/coherence

各量をt=7.70値で規格化し、対数減衰率とともに保存した。これは同時変化の記述であり、coherenceがW減衰を引き起こしたとは主張しない。t=8～10のDelta E/W/passive/usableと11j残差も同一表に保存した。usable fraction上昇を独立性能向上とは扱わない。

## 7. Checks

13/13 PASS。入力SHA-256とreleaseテスト記録は提出固定時に追記する。

## 8. 判定

**late_tail_structure_remains**

## 9. 解釈限界

減衰fitは形状診断であり、境界反射、群速度、二つの物理過程、因果機構を証明しない。

## 10. 次段階

終盤構造が残る場合、11iのsite-resolved診断を同一N=7 matched軌道1本に限定して検討できる。ただし自動実行しない。
