# Milestone 10c reproduction

Run from this folder:

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo build --release --offline
cargo run --release --offline --bin fixed_total_gamma_1_5_with_xgamma
```

Required 10a and 10b artifacts are included, and the saved 9c validation input
is under `inputs/milestone_10a`. Runtime and fallback diagnostic fields can be
machine-dependent. Preserve stored outputs before rerunning. See
`MILESTONE_10C_REPORT.md`.
