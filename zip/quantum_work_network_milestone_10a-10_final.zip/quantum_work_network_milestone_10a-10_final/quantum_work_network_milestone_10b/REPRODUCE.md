# Milestone 10b reproduction

Run from this folder:

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo build --release --offline
cargo run --release --offline --bin fixed_total_gamma_3_comparison
```

The required Milestone 10a comparison file is included in this folder, and
earlier official artifacts are under `inputs/milestone_10a`. Runtime fields are
machine-dependent. Preserve the stored outputs before rerunning for comparison.
See `MILESTONE_10B_REPORT.md`.
