# Milestone 10 final reproduction

Run from this folder:

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo build --release --offline
cargo run --release --offline --bin milestone_10_closure
```

The closure performs no new time evolution. It reads the included official
10a, 10b, and 10c artifacts and writes the final comparison, ranking structure,
fixed-total summary, closure checks, and `MILESTONE_10_FINAL_REPORT.md`.
Preserve the stored outputs before rerunning for comparison.
