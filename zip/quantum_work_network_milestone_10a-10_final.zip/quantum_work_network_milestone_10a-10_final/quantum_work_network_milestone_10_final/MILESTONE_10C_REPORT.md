# Milestone 10c: fixed total gamma 1.5 with XGamma

## 1. 目的

TOTAL_GAMMA=1.5をXGamma付きでN=3・5・7について再計算した。

## 2. 10a・10bとの関係

10aのfixed-total欠損を正式値で埋め、10bのTOTAL_GAMMA=3.0と同じ診断で比較可能にした。既定の1.5を計算したもので、新しいgamma点は追加していない。

## 3. 物理条件

9c・10bと同じJ=1.0, g=0.25, omega=1.0, Omega=0.2, tau=3.2, dt=0.0025, t_final=10、vacuum初期状態を使用した。drive siteは0、load coupling siteはN-1、load dimensionは3である。全chain siteに位相雑音を入れ、loadへ直接雑音を入れていない。

## 4. gamma配分

| N | gamma_site | TOTAL_GAMMA |
|---:|---:|---:|
| 3 | 0.5 | 1.5 |
| 5 | 0.3 | 1.5 |
| 7 | 1.5/7 | 1.5 |

## 5. XGamma

10bと同じ `x_gamma(t)=sum_ab Gamma[a,b]|rho[a,b](t)|^2` と、その保存時刻間の台形積分を用いた。XGammaはdephasing-kernel-weighted coherence exposureという診断量であり、仕事損失、散逸エネルギー、dephasing power、熱、entropy production、効率ではない。

## 6. unit testと回帰

`cargo test --release --offline` は104 passed、0 failed、1 ignored。XGammaの6 unit testとruntime mirrorはすべてPASSした。ignoredは既存dense 576x576 smoke testである。

## 7. N=7既存9c軌道との一致

1001時刻でtime、load_energy、load_ergotropy、usable_fraction、load_coherence_l1、drive_power、dephasing_powerを許容値1e-12で比較した。`N=7 trajectory comparison all checks=true`。詳細は `fixed_total_gamma_1_5_trajectory_comparison.csv` に保存した。

## 8. 数値品質

| N | trace max | Hermiticity max | worst selected min eigenvalue | primary success/failure | fallback success/attempt | solver failure | ledger max |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 3 | 1.332e-15 | 0.000e0 | -7.053e-19 | 1001/0 | 0/0 | 0 | 5.147e-7 |
| 5 | 1.776e-15 | 0.000e0 | -7.053e-18 | 1001/0 | 0/0 | 0 | 5.654e-7 |
| 7 | 3.997e-15 | 0.000e0 | -5.278e-18 | 999/2 | 2/2 | 0 | 5.892e-7 |

## 9. t=10結果

| N | E | W | usable fraction | XGamma |
|---:|---:|---:|---:|---:|
| 3 | 1.25968749e-2 | 2.36524768e-3 | 1.87764641e-1 | 5.45902406e-2 |
| 5 | 8.79576200e-3 | 2.59454478e-3 | 2.94976692e-1 | 5.91251258e-2 |
| 7 | 7.15497051e-3 | 2.61691906e-3 | 3.65748407e-1 | 6.01834458e-2 |

## 10. 最大値

| N | W_max | t_at_W_max | E_at_W_max | usable_fraction_at_W_max |
|---:|---:|---:|---:|---:|
| 3 | 3.03020059e-3 | 5.63 | 7.59724549e-3 | 3.98855164e-1 |
| 5 | 3.48762041e-3 | 6.62 | 7.37090703e-3 | 4.73160277e-1 |
| 7 | 3.80807174e-3 | 7.70 | 7.36411209e-3 | 5.17112137e-1 |

## 11. 時間全体

| N | W_time_area | E_time_area | XGamma |
|---:|---:|---:|---:|
| 3 | 1.73613227e-2 | 5.55191009e-2 | 5.45902406e-2 |
| 5 | 1.55154662e-2 | 3.73787423e-2 | 5.91251258e-2 |
| 7 | 1.35220953e-2 | 2.74533401e-2 | 6.01834458e-2 |

## 12. N横断順位（TOTAL_GAMMA=1.5）

- W_max: N=7 (3.808072e-3) > N=5 (3.487620e-3) > N=3 (3.030201e-3)
- W_at_t10: N=7 (2.616919e-3) > N=5 (2.594545e-3) > N=3 (2.365248e-3)
- W_time_area: N=3 (1.736132e-2) > N=5 (1.551547e-2) > N=7 (1.352210e-2)
- usable fraction: N=7 (3.657484e-1) > N=5 (2.949767e-1) > N=3 (1.877646e-1)
- ergotropy arrival（早い順）: N=3 (1.950000e0) > N=5 (2.860000e0) > N=7 (3.790000e0)
- XGamma: N=7 (6.018345e-2) > N=5 (5.912513e-2) > N=3 (5.459024e-2)

## 13. TOTAL_GAMMA=1.5と3.0の比較

絶対差は `|value_3.0-value_1.5|`、比は安全に非ゼロの場合の `value_3.0/value_1.5` である。

| N | metric | ratio 3/1.5 | absolute difference |
|---:|---|---:|---:|
| 3 | W_max | 1.80333042e-1 | 2.48375530e-3 |
| 3 | W_at_t10 | 1.67564642e-1 | 1.96891580e-3 |
| 3 | W_time_area | 1.83215243e-1 | 1.41804637e-2 |
| 3 | E_at_t10 | 5.38011916e-1 | 5.81960609e-3 |
| 3 | E_time_area | 4.85921137e-1 | 2.85411963e-2 |
| 3 | usable_fraction_at_t10 | 3.11451544e-1 | 1.29285053e-1 |
| 3 | ergotropy_arrival_time | 1.09230769e0 | 1.80000000e-1 |
| 3 | XGamma | 8.52221673e-1 | 8.06725440e-3 |
| 5 | W_max | 1.80179392e-1 | 2.85922308e-3 |
| 5 | W_at_t10 | 1.79023425e-1 | 2.13006049e-3 |
| 5 | W_time_area | 1.91983071e-1 | 1.25367593e-2 |
| 5 | E_at_t10 | 5.88600435e-1 | 3.61857266e-3 |
| 5 | E_time_area | 4.80815422e-1 | 1.94064666e-2 |
| 5 | usable_fraction_at_t10 | 3.04151024e-1 | 2.05259229e-1 |
| 5 | ergotropy_arrival_time | 1.08741259e0 | 2.50000000e-1 |
| 5 | XGamma | 9.19070381e-1 | 4.78497393e-3 |
| 7 | W_max | 1.83603325e-1 | 3.10889711e-3 |
| 7 | W_at_t10 | 2.01551173e-1 | 2.08947596e-3 |
| 7 | W_time_area | 1.96505890e-1 | 1.08649240e-2 |
| 7 | E_at_t10 | 5.57309226e-1 | 3.16743943e-3 |
| 7 | E_time_area | 4.27834648e-1 | 1.57078500e-2 |
| 7 | usable_fraction_at_t10 | 3.61650522e-1 | 2.33475304e-1 |
| 7 | ergotropy_arrival_time | 1.08179420e0 | 3.10000000e-1 |
| 7 | XGamma | 9.68940904e-1 | 1.86924345e-3 |

この2点だけから関数形、一般単調性、普遍倍率は決めない。

## 14. 最大値・最終値・時間面積の順位一致

| metric | TOTAL_GAMMA=1.5 | TOTAL_GAMMA=3.0 | same ranking |
|---|---|---|---|
| W_max | N=7 (3.808072e-3) > N=5 (3.487620e-3) > N=3 (3.030201e-3) | N=7 (6.991746e-4) > N=5 (6.283973e-4) > N=3 (5.464453e-4) | true |
| W_at_t10 | N=7 (2.616919e-3) > N=5 (2.594545e-3) > N=3 (2.365248e-3) | N=7 (5.274431e-4) > N=5 (4.644843e-4) > N=3 (3.963319e-4) | true |
| W_time_area | N=3 (1.736132e-2) > N=5 (1.551547e-2) > N=7 (1.352210e-2) | N=3 (3.180859e-3) > N=5 (2.978707e-3) > N=7 (2.657171e-3) | true |
| usable_fraction | N=7 (3.657484e-1) > N=5 (2.949767e-1) > N=3 (1.877646e-1) | N=7 (1.322731e-1) > N=5 (8.971746e-2) > N=3 (5.847959e-2) | true |

## 15. XGammaとWの関係

各Nについて、1.5から3.0へのXGamma、W_max、W_at_t10、W_time_areaの変化は第13節の有限条件比較に示した。同時に変わった量の記述であり、XGammaがWを変化させたという因果は示していない。

## 16. 直接確認できたこと

この模型・初期条件・N=3・5・7・TOTAL_GAMMA=1.5と3.0・t<=10の6条件について、同じXGamma定義と数値診断で比較表を作成できた。1.5のN=7物理軌道は9c正本と比較した。

## 17. 確認できていないこと

中間gamma、全面gamma sweep、XGamma一致探索、dt半減、t>10、N>7、等入力費用比較、因果機構、scaling law、実機性能は確認していない。

## 18. 主張してはいけないこと

XGammaを仕事損失や散逸エネルギーと呼ぶこと、2つのgamma点から関数形を決めること、gamma倍増の普遍倍率、XGamma単独因果、N単独因果、N>7への外挿、量子優位は主張しない。

## 19. 実行と最終判定

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo run --release --offline --bin fixed_total_gamma_1_5_with_xgamma
```

| N | construction s | propagation s | diagnostics s | total s |
|---:|---:|---:|---:|---:|
| 3 | 0.001 | 0.789 | 0.205 | 1.001 |
| 5 | 0.034 | 33.595 | 7.281 | 40.919 |
| 7 | 2.449 | 1999.805 | 426.571 | 2429.124 |

最終判定: **completed_with_fallback_diagnostic**

## 20. 次段階

TOTAL_GAMMA=1.5と3.0のXGamma付き比較を確認後、
中間gamma点が必要か判断する。
