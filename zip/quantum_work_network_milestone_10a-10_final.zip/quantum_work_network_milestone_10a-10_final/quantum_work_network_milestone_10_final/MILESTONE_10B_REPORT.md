# Milestone 10b: fixed total gamma 3 comparison

## 1. 目的

TOTAL_GAMMA=3.0をN=3・5・7の3条件だけで新規計算し、XGammaを初導入した。

## 2. 変更していない物理模型

Hamiltonian、drive、3準位load、vacuum初期状態、dt=0.0025、t_final=10、固定刻みRK4、既存DiagonalDephasingKernelはMilestone 9cと同じである。kernelはdense Lindblad dephasing項の厳密な成分表示であり、新しい物理近似ではない。

## 3. gamma配分

| N | gamma_site | total gamma |
|---:|---:|---:|
| 3 | 1.0 | 3.0 |
| 5 | 0.6 | 3.0 |
| 7 | 3/7 | 3.0 |

全chain siteへ均等配分し、loadへ直接雑音を入れていない。

## 4. XGamma定義

`d rho[a,b]/dt|dephasing = -Gamma[a,b] rho[a,b]` に対し、`x_gamma(t)=sum_ab Gamma[a,b]|rho[a,b](t)|^2`、`XGamma(T)=integral_0^T x_gamma(t)dt` と定義した。保存時刻0.01間隔の台形積分を使った。

XGammaはdephasing-kernel-weighted coherence exposureという診断量であり、失われたergotropy、散逸エネルギー、dephasing power、累積仕事損失、制御費用、熱、entropy productionではない。因果量や効率として解釈しない。

## 5. unit test

対角状態、単一Hermitian非対角成分、gamma=0、非負性、次元不一致、gamma線形スケーリングの6要件をunit testとruntime mirrorで確認した。`cargo test --release --offline` は101 passed、0 failed、1 ignored。ignoredは既存dense 576x576 smoke testで、設定を変更していない。

## 6. 数値品質

| N | trace max | Hermiticity max | worst selected min eigenvalue | primary success/failure | fallback success/attempt | solver failure | ledger max |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 3 | 1.554e-15 | 0.000e0 | -9.565e-19 | 1001/0 | 0/0 | 0 | 4.191e-7 |
| 5 | 2.887e-15 | 0.000e0 | -4.628e-18 | 1001/0 | 0/0 | 0 | 4.936e-7 |
| 7 | 2.665e-15 | 0.000e0 | -5.171e-18 | 1001/0 | 0/0 | 0 | 5.326e-7 |

state finitenessとsolver finitenessは分離した。rhoをHermitian化し、SymmetricEigenをprimary、不合格時だけComplex Schurをfallbackとして用いた。fallbackは診断層だけで、時間発展を変更していない。

## 7. t=10結果

| N | E | W | usable fraction | XGamma |
|---:|---:|---:|---:|---:|
| 3 | 6.77726878e-3 | 3.96331881e-4 | 5.84795873e-2 | 4.65229861e-2 |
| 5 | 5.17718935e-3 | 4.64484293e-4 | 8.97174628e-2 | 5.43401518e-2 |
| 7 | 3.98753108e-3 | 5.27443106e-4 | 1.32273102e-1 | 5.83142023e-2 |

## 8. 最大値

| N | W_max | t_at_W_max | E_at_W_max | usable_fraction_at_W_max |
|---:|---:|---:|---:|---:|
| 3 | 5.46445292e-4 | 5.39 | 2.98688642e-3 | 1.82948133e-1 |
| 5 | 6.28397326e-4 | 6.55 | 2.89668377e-3 | 2.16936806e-1 |
| 7 | 6.99174633e-4 | 7.67 | 2.78049015e-3 | 2.51457331e-1 |

## 9. 時間全体

| N | W_time_area | E_time_area | XGamma |
|---:|---:|---:|---:|
| 3 | 3.18085897e-3 | 2.69779046e-2 | 4.65229861e-2 |
| 5 | 2.97870684e-3 | 1.79722758e-2 | 5.43401518e-2 |
| 7 | 2.65717138e-3 | 1.17454901e-2 | 5.83142023e-2 |

W_time_areaとE_time_areaは状態量の時間積分であり、累積仕事、累積流入エネルギー、実際に抽出された仕事、効率ではない。

## 10. N横断比較（TOTAL_GAMMA=3.0のみ）

- W_max: N=7 (6.991746e-4) > N=5 (6.283973e-4) > N=3 (5.464453e-4)
- W_at_t10: N=7 (5.274431e-4) > N=5 (4.644843e-4) > N=3 (3.963319e-4)
- W_time_area: N=3 (3.180859e-3) > N=5 (2.978707e-3) > N=7 (2.657171e-3)
- usable fraction: N=7 (1.322731e-1) > N=5 (8.971746e-2) > N=3 (5.847959e-2)
- ergotropy arrival（早い順）: N=3 (2.130000e0) > N=5 (3.110000e0) > N=7 (4.100000e0)
- XGamma: N=7 (5.831420e-2) > N=5 (5.434015e-2) > N=3 (4.652299e-2)

## 11. 3つのtotal gamma点

0.0、1.5、3.0について正式に利用可能な値だけを`fixed_total_gamma_three_point_comparison.csv`へ並べた。0.0と1.5は再計算していない。10aで欠損だった値はnot_availableのままで、XGammaも0.0・1.5ではnot_availableとした。3点を曲線として扱わず、補間、単調性一般化、交差点・臨界値推定、指数・べきfitを行っていない。

## 12. XGammaとWの関係

今回の3つのNについてXGamma、W_max、W_at_t10、W_time_areaを記述的に並べた。N自体も同時に変わる有限3条件なので、XGammaがW低下の原因とは言えない。相関係数や統計的有意性は主張しない。

## 13. 直接確認できたこと

TOTAL_GAMMA=3.0のN=3・5・7各1軌道、1001保存点、XGamma、load指標、robust positivity会計を直接確認した。

## 14. 確認できていないこと

中間gamma、gamma sweep、XGamma一致条件、dt半減、t>10、N>7、等入力費用比較、因果機構、scaling law、実機性能は確認していない。

## 15. 主張してはいけないこと

XGammaを失われた仕事・散逸エネルギーと呼ばない。3点から単調性や関数形を一般化しない。fixed-per-siteとfixed-totalを混同しない。Nだけ、雑音だけ、XGammaだけの単独因果を断定しない。量子優位を主張せず、N>7へ外挿しない。

## 16. 実行記録と最終判定

実行コマンド:

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo run --release --offline --bin fixed_total_gamma_3_comparison
```

各Nの実行時間:

| N | construction s | propagation s | diagnostics s | total s |
|---:|---:|---:|---:|---:|
| 3 | 0.000 | 0.543 | 0.136 | 0.680 |
| 5 | 0.035 | 33.466 | 7.221 | 40.728 |
| 7 | 2.886 | 2632.258 | 562.701 | 3198.125 |

最終判定: **completed_fixed_total_gamma_3_comparison**

## 17. 次段階

TOTAL_GAMMA=0, 1.5, 3.0の結果とXGammaを確認した後、
追加gamma点が必要か判断する。
