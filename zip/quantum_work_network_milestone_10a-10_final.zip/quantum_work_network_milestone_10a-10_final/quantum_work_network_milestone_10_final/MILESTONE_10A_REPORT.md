# Milestone 10a: 既存結果の横断比較

## 1. 目的

新しい物理計算を行わず、既存結果だけでN=3・5・7の最大値、最終値、時間面積、到達時刻、usable fractionを比較した。Hamiltonian、Liouvillian、RK4、密度行列の時間発展は実行していない。

## 2. 使用した既存成果物

- N=3・5 noise-free / fixed-per-site: `chain_length_reachability_summary.csv`, `chain_length_reachability_arrivals.csv`
- N=7 noise-free: `n7_noise_free_summary.csv`
- N=7 fixed-per-site: `n7_all_site_noisy_summary.csv`
- fixed-totalの正式正本: `MILESTONE_9C_VALIDATION.md`, `n7_fixed_total_validation_summary.csv`, `fixed_total_noise_final_comparison.csv`

`MILESTONE_9C_REPORT.md`と`MILESTONE_9C_DIAGNOSTIC.md`は最終値の出典に使用していない。9cの正式判定は `completed_comparison_with_fallback_diagnostic` である。

## 3. 比較条件

- noise-free: gamma_site=0、total gamma=0。
- fixed-per-site: 各site gamma=0.5。total gammaはN=3で1.5、N=5で2.5、N=7で3.5となり、Nとともに増える。
- fixed-total: N=3・5・7すべてtotal gamma=1.5。gamma_siteは1.5/N。

fixed-per-siteとfixed-totalは、N=5・7では同じ総雑音条件ではない。

## 4. 主比較表

| N | noise condition | gamma_site | total_gamma | W_max | t_at_W_max | W_at_t10 | W_time_area | ergotropy arrival | usable fraction | status |
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---|
| 3 | noise_free | 0.000000e0 | 0.000000e0 | 5.542406e-2 | 9.480000e0 | 5.279827e-2 | 1.951140e-1 | 1.800000e0 | 9.696516e-1 | available |
| 3 | fixed_per_site_gamma_0_5 | 5.000000e-1 | 1.500000e0 | 3.030201e-3 | 5.630000e0 | 2.365248e-3 | 1.736132e-2 | 1.950000e0 | 1.877646e-1 | available |
| 3 | fixed_total_gamma_1_5 | 5.000000e-1 | 1.500000e0 | 3.030201e-3 | not_available | not_available | not_available | not_available | not_available | not_available |
| 5 | noise_free | 0.000000e0 | 0.000000e0 | 2.197446e-2 | 6.630000e0 | 2.108587e-2 | 9.249064e-2 | 2.660000e0 | 9.516221e-1 | available |
| 5 | fixed_per_site_gamma_0_5 | 5.000000e-1 | 2.500000e0 | 1.096818e-3 | 6.580000e0 | 8.051814e-4 | 5.093679e-3 | 3.020000e0 | 1.318061e-1 | available |
| 5 | fixed_total_gamma_1_5 | 3.000000e-1 | 1.500000e0 | 3.487620e-3 | not_available | not_available | not_available | not_available | not_available | not_available |
| 7 | noise_free | 0.000000e0 | 0.000000e0 | 2.243552e-2 | 7.710000e0 | 1.308501e-2 | 7.311278e-2 | 3.550000e0 | 9.372587e-1 | available |
| 7 | fixed_per_site_gamma_0_5 | 5.000000e-1 | 3.500000e0 | 4.043748e-4 | 7.650000e0 | 3.115741e-4 | 1.568021e-3 | 4.220000e0 | 9.430049e-2 | available |
| 7 | fixed_total_gamma_1_5 | 2.142857e-1 | 1.500000e0 | 3.808072e-3 | 7.700000e0 | 2.616919e-3 | 1.352210e-2 | 3.790000e0 | 3.657484e-1 | available |

`W_time_area`はergotropyという状態量の0〜10の時間面積である。累積抽出仕事、loadへの累積流入エネルギー、実際に回収された総仕事、装置効率ではない。

到達時刻は、利用した成果物すべてで `ergotropy >= 1e-5` が5保存点連続する持続閾値定義であることを列名・arrival行から確認した。fixed-total N=3・5は正式正本に到達時刻がないため、他の途中成果物から埋めなかった。

## 5. 指標ごとの順位

各順位は利用可能な値だけで作った。同値判定は `abs(a-b) <= 1e-12 + 1e-9 max(abs(a),abs(b))` とし、その範囲では同順位にする。完全な行別順位は `milestone_10a_metric_rankings.csv` に保存した。

### W_max

- noise_free, N横断: 1位 N=3 noise_free (5.542406e-2) / 2位 N=7 noise_free (2.243552e-2) / 3位 N=5 noise_free (2.197446e-2)
- fixed_per_site_gamma_0_5, N横断: 1位 N=3 fixed_per_site_gamma_0_5 (3.030201e-3) / 2位 N=5 fixed_per_site_gamma_0_5 (1.096818e-3) / 3位 N=7 fixed_per_site_gamma_0_5 (4.043748e-4)
- fixed_total_gamma_1_5, N横断: 1位 N=7 fixed_total_gamma_1_5 (3.808072e-3) / 2位 N=5 fixed_total_gamma_1_5 (3.487620e-3) / 3位 N=3 fixed_total_gamma_1_5 (3.030201e-3)
- N=3, 雑音条件横断: 1位 N=3 noise_free (5.542406e-2) / 2位 N=3 fixed_per_site_gamma_0_5 (3.030201e-3) / 2位 N=3 fixed_total_gamma_1_5 (3.030201e-3)
- N=5, 雑音条件横断: 1位 N=5 noise_free (2.197446e-2) / 2位 N=5 fixed_total_gamma_1_5 (3.487620e-3) / 3位 N=5 fixed_per_site_gamma_0_5 (1.096818e-3)
- N=7, 雑音条件横断: 1位 N=7 noise_free (2.243552e-2) / 2位 N=7 fixed_total_gamma_1_5 (3.808072e-3) / 3位 N=7 fixed_per_site_gamma_0_5 (4.043748e-4)

### W_at_t10

- noise_free, N横断: 1位 N=3 noise_free (5.279827e-2) / 2位 N=5 noise_free (2.108587e-2) / 3位 N=7 noise_free (1.308501e-2)
- fixed_per_site_gamma_0_5, N横断: 1位 N=3 fixed_per_site_gamma_0_5 (2.365248e-3) / 2位 N=5 fixed_per_site_gamma_0_5 (8.051814e-4) / 3位 N=7 fixed_per_site_gamma_0_5 (3.115741e-4)
- fixed_total_gamma_1_5, N横断: 1位 N=7 fixed_total_gamma_1_5 (2.616919e-3) / 判定は利用可能値だけ（不足あり）
- N=3, 雑音条件横断: 1位 N=3 noise_free (5.279827e-2) / 2位 N=3 fixed_per_site_gamma_0_5 (2.365248e-3) / 判定は利用可能値だけ（不足あり）
- N=5, 雑音条件横断: 1位 N=5 noise_free (2.108587e-2) / 2位 N=5 fixed_per_site_gamma_0_5 (8.051814e-4) / 判定は利用可能値だけ（不足あり）
- N=7, 雑音条件横断: 1位 N=7 noise_free (1.308501e-2) / 2位 N=7 fixed_total_gamma_1_5 (2.616919e-3) / 3位 N=7 fixed_per_site_gamma_0_5 (3.115741e-4)

### W_time_area

- noise_free, N横断: 1位 N=3 noise_free (1.951140e-1) / 2位 N=5 noise_free (9.249064e-2) / 3位 N=7 noise_free (7.311278e-2)
- fixed_per_site_gamma_0_5, N横断: 1位 N=3 fixed_per_site_gamma_0_5 (1.736132e-2) / 2位 N=5 fixed_per_site_gamma_0_5 (5.093679e-3) / 3位 N=7 fixed_per_site_gamma_0_5 (1.568021e-3)
- fixed_total_gamma_1_5, N横断: 1位 N=7 fixed_total_gamma_1_5 (1.352210e-2) / 判定は利用可能値だけ（不足あり）
- N=3, 雑音条件横断: 1位 N=3 noise_free (1.951140e-1) / 2位 N=3 fixed_per_site_gamma_0_5 (1.736132e-2) / 判定は利用可能値だけ（不足あり）
- N=5, 雑音条件横断: 1位 N=5 noise_free (9.249064e-2) / 2位 N=5 fixed_per_site_gamma_0_5 (5.093679e-3) / 判定は利用可能値だけ（不足あり）
- N=7, 雑音条件横断: 1位 N=7 noise_free (7.311278e-2) / 2位 N=7 fixed_total_gamma_1_5 (1.352210e-2) / 3位 N=7 fixed_per_site_gamma_0_5 (1.568021e-3)

### ergotropy_arrival_time

- noise_free, N横断: 1位 N=3 noise_free (1.800000e0) / 2位 N=5 noise_free (2.660000e0) / 3位 N=7 noise_free (3.550000e0)
- fixed_per_site_gamma_0_5, N横断: 1位 N=3 fixed_per_site_gamma_0_5 (1.950000e0) / 2位 N=5 fixed_per_site_gamma_0_5 (3.020000e0) / 3位 N=7 fixed_per_site_gamma_0_5 (4.220000e0)
- fixed_total_gamma_1_5, N横断: 1位 N=7 fixed_total_gamma_1_5 (3.790000e0) / 判定は利用可能値だけ（不足あり）
- N=3, 雑音条件横断: 1位 N=3 noise_free (1.800000e0) / 2位 N=3 fixed_per_site_gamma_0_5 (1.950000e0) / 判定は利用可能値だけ（不足あり）
- N=5, 雑音条件横断: 1位 N=5 noise_free (2.660000e0) / 2位 N=5 fixed_per_site_gamma_0_5 (3.020000e0) / 判定は利用可能値だけ（不足あり）
- N=7, 雑音条件横断: 1位 N=7 noise_free (3.550000e0) / 2位 N=7 fixed_total_gamma_1_5 (3.790000e0) / 3位 N=7 fixed_per_site_gamma_0_5 (4.220000e0)

### usable_fraction_at_t10

- noise_free, N横断: 1位 N=3 noise_free (9.696516e-1) / 2位 N=5 noise_free (9.516221e-1) / 3位 N=7 noise_free (9.372587e-1)
- fixed_per_site_gamma_0_5, N横断: 1位 N=3 fixed_per_site_gamma_0_5 (1.877646e-1) / 2位 N=5 fixed_per_site_gamma_0_5 (1.318061e-1) / 3位 N=7 fixed_per_site_gamma_0_5 (9.430049e-2)
- fixed_total_gamma_1_5, N横断: 1位 N=7 fixed_total_gamma_1_5 (3.657484e-1) / 判定は利用可能値だけ（不足あり）
- N=3, 雑音条件横断: 1位 N=3 noise_free (9.696516e-1) / 2位 N=3 fixed_per_site_gamma_0_5 (1.877646e-1) / 判定は利用可能値だけ（不足あり）
- N=5, 雑音条件横断: 1位 N=5 noise_free (9.516221e-1) / 2位 N=5 fixed_per_site_gamma_0_5 (1.318061e-1) / 判定は利用可能値だけ（不足あり）
- N=7, 雑音条件横断: 1位 N=7 noise_free (9.372587e-1) / 2位 N=7 fixed_total_gamma_1_5 (3.657484e-1) / 3位 N=7 fixed_per_site_gamma_0_5 (9.430049e-2)

## 6. 最大値と時間全体の結果が一致するか

判定はscopeごとに行う。3値が揃わないscopeは判定不能とした。

| scope | W_max vs W_time_area | W_max vs W_at_t10 | W_at_t10 vs usable_fraction |
|---|---|---|---|
| same noise: noise_free | do_not_agree | do_not_agree | agree |
| same noise: fixed_per_site_gamma_0_5 | agree | agree | agree |
| same noise: fixed_total_gamma_1_5 | indeterminate_due_to_missing_or_definition_difference | indeterminate_due_to_missing_or_definition_difference | indeterminate_due_to_missing_or_definition_difference |
| same N: 3 | indeterminate_due_to_missing_or_definition_difference | indeterminate_due_to_missing_or_definition_difference | indeterminate_due_to_missing_or_definition_difference |
| same N: 5 | indeterminate_due_to_missing_or_definition_difference | indeterminate_due_to_missing_or_definition_difference | indeterminate_due_to_missing_or_definition_difference |
| same N: 7 | agree | agree | agree |

## 7. 直接確認できたこと

- 9条件を明示的に列挙できた。
- noise-freeとfixed-per-siteは5指標すべてをN=3・5・7で比較できた。
- fixed-totalのN=7は5指標すべて正式正本から取得できた。
- fixed-totalのN=3・5は正式正本からW_maxだけ取得できた。その他を推測・補間・再計算しなかった。
- fixed-per-siteの総雑音はNとともに増え、fixed-totalでは1.5で一定である。

## 8. 確認できていないこと

新しい物理軌道、total gamma=3.0、XGamma、gamma sweep、N>7、等入力費用比較、因果機構、scaling lawは確認していない。

## 9. 主張してはいけないこと

- 3つの雑音条件を同一横軸上の連続スイープとして扱わない。
- fixed-per-siteとfixed-totalを同じ総雑音条件として扱わない。
- 有限3点から単調性、指数則、べき則を主張しない。
- W_time_areaを累積仕事と呼ばない。
- 到達時刻の定義が違う値を直接順位付けしない。
- 距離または雑音だけの単独因果を断定しない。

## 10. チェックと実行記録

必須チェックは 16/16 PASS。詳細は `milestone_10a_checks.csv`。

実行した検証コマンド:

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo run --release --offline --bin milestone_10a_existing_results_comparison
```

既存のignored testの設定は変更していない。Milestone 10a binは解析専用で、新しい時間発展を呼ばない。

## 11. 最終判定

**completed_with_explicit_missing_values**

不足はfixed-total N=3・5のW_max以外の指標である。欠損を明示したため、比較処理そのものは完了した。

## 12. 次段階

Milestone 10b:
TOTAL_GAMMA=3.0をN=3,5,7で各1条件計算し、
dephasing-kernel-weighted coherence exposure XGammaを同時記録する

Milestone 10bは実行していない。
