# Milestone 10a reproduction

Run from this folder:

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo build --release --offline
cargo run --release --offline --bin milestone_10a_existing_results_comparison
```

Milestone 10a performs no new time evolution. It reads the official earlier
artifacts under `inputs/milestone_10a` and produces the comparison, rankings,
checks, and report in this folder. Preserve the existing files before rerunning
if you want to compare them byte-for-byte. See `MILESTONE_10A_REPORT.md`.
