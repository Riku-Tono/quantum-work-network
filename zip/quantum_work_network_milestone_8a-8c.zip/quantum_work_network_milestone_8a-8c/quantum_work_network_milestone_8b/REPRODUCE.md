# Milestone 8b reproduction

Verify from this folder:

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo build --release --offline
```

Run Milestone 8b:

```text
cargo run --release --offline --bin n7_feasibility_probe
```

This is a construction, one-step, and short-time feasibility benchmark, not
the N=7 full run. Runtime estimates are machine-dependent. The six stored
reference CSV files are under `results/`. See `MILESTONE_8B_REPORT.md`.

The shared library is the saved Milestone 8c-compatible version. The dedicated
Milestone 8b binary is byte-for-byte identical to the distributed original.
