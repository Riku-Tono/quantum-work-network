# Milestone 8a reproduction

Verify from this folder:

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo build --release --offline
```

Run Milestone 8a:

```text
cargo run --release --offline --bin chain_length_reachability
```

The nine stored reference CSV files are under `results/`. See
`MILESTONE_8A_REPORT.md` for the numerical conditions, checks, and limits.

The shared library is the saved Milestone 8c-compatible version. The dedicated
Milestone 8a binary is byte-for-byte identical to the original saved binary.
