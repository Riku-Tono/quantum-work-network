# Milestone 8c reproduction

Verify from this folder:

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo build --release --offline
```

Run Milestone 8c:

```text
cargo run --release --offline --bin dephasing_kernel_benchmark
```

The run validates exact dephasing-kernel equivalence and benchmarks it.
Benchmark timings are machine-dependent. The seven stored reference CSV files
are under `results/`. See `MILESTONE_8C_REPORT.md`.

The dephasing-kernel module, library registration, and dedicated binary match
the distributed Milestone 8c files byte-for-byte.
