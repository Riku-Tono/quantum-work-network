# Milestone 15A: End-Point Extraction Accounting after Coupling Control

## Verdict

`state_improvement_preserved_after_extraction`

Mandatory numerical failures: `0`.

C2のgross extracted workはC0より `1.882685627546e-4` 大きく、抽出前の
Wcoh差と `9.107e-18` の精度で一致した。したがって、状態量として保持された
追加Wcohは、今回の理想局所抽出会計でもそのまま保持された。

## Fixed comparison at t=8.50

| quantity | C0 | C2 | C2-C0 |
|---|---:|---:|---:|
| Wcoh before | 3.062677468487e-3 | 3.250946031241e-3 | 1.882685627546e-4 |
| load energy before | 6.601877630500e-3 | 6.533284638378e-3 | -6.859299212134e-5 |
| W_load_gross | 3.062677468487e-3 | 3.250946031241e-3 | 1.882685627546e-4 |
| W_operation_out_total | 3.062677468536e-3 | 3.250946031265e-3 | 1.882685627292e-4 |
| interaction jump | -4.957529045397e-14 | -2.416320556056e-14 | 2.541208489341e-14 |
| load ergotropy after | 0.000000000000e0 | 0.000000000000e0 | 0.000000000000e0 |

## Accounting

The state, M14 switch, and extraction ledgers are separate. Gross load extraction reproduces the pre-extraction Wcoh difference with residual `9.107e-18` (ratio `1.000000000000`). Total-Hamiltonian operation work differs from gross load work by the interaction-energy jump. The extraction operation is ideal and instantaneous; no implementation cost or net-benefit claim is included.

M14 Plan B C2 switching work on the system is reused as `8.8624029002963674e-16`; it is not combined with either extraction-work column.

The interaction-jump difference is only `2.541208489341e-14`, so the
bare-load and total-Hamiltonian comparisons have the same positive conclusion.
Case C is therefore not triggered.

All `40/40` numerical and provenance checks pass, including trace,
Hermiticity, positivity, release solver completion, post-extraction zero
ergotropy, M13A endpoint reuse, M14 state SHA, and switching-accounting reuse.

## Scope stop

Only C0 and C2 were propagated from 7.70 to 8.50 and extracted once. No additional Milestone is started.
