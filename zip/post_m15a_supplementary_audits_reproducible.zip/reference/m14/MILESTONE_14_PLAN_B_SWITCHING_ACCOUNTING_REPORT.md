# Milestone 14 Plan B — Formal Switching-Work Accounting

## Formal result

Plan B completed successfully. Exactly one baseline prefix was propagated from t=0 to t=7.70. Full density matrices were saved at t=7.50 and t=7.70, and the ideal same-state switch g=0.25 to g=0.125 was evaluated at both times.

- New baseline prefix: 1 through t=7.70.
- New post-switch branches: 0.
- New coupling values, sweeps, ramps, extraction, optimization, fine-dt, and t>8.50: 0.
- Existing M13A C0/C1/C2 post-switch state trajectories were reused unchanged.

## Switching-work results

The fixed convention is `W_switch_on_system=Tr[rho(H_after-H_before)]` and `W_switch_out=-W_switch_on_system`.

| protocol | switch time | Tr(rho V_CL) | W_switch_on_system | W_switch_out |
|---|---:|---:|---:|---:|
| C1 | 7.50 | -1.3584658388632867e-14 | 1.6980822985791084e-15 | -1.6980822985791084e-15 |
| C2 | 7.70 | -7.0899223202370955e-15 | 8.8624029002963674e-16 | -8.8624029002963674e-16 |

Both ideal-quench energy jumps are below the fixed 1e-12 numerical audit tolerance. The exact stored floating-point values are retained, but the appropriate description is **numerically zero at this tolerance**. This does not mean that a real controller is free: the model has no actuator Hamiltonian, finite ramp, bandwidth, or device-cost ledger.

The linear formula, interaction-energy jump, and total-Hamiltonian jump identities all pass with maximum absolute residual 1.582e-17. The density matrix is unchanged exactly across each evaluated switch.

## Relative switching scales

All four denominators are applicable for both protocols. The ratios are available in `m14_plan_b_scale_diagnostics.csv`; they are scale diagnostics, not efficiencies. For C1, abs(W_switch)/abs(delta_Wcoh_endpoint) is 9.026e-12; for C2 it is 4.707e-12.

## Reused M13A state tradeoff

- C1: endpoint Wcoh relative difference +6.142%, Wcoh-area difference +1.467%, endpoint load-energy retention 97.159%.
- C2: endpoint Wcoh relative difference +6.147%, Wcoh-area difference +2.103%, endpoint load-energy retention 98.961%.

Under the frozen state thresholds, both protocols are `Wcoh_improves_with_load_energy_tradeoff`: Wcoh endpoint and area each improve by at least 1%, while endpoint load-energy retention is below 99%.

## Formal composite classification

- C1: **`Wcoh_improves_with_load_energy_tradeoff + switching_accounting_available`**.
- C2: **`Wcoh_improves_with_load_energy_tradeoff + switching_accounting_available`**.

The ideal-quench work scale status for both is `numerically_zero_within_1e-12_audit_tolerance`. This is kept separate from the state classification and is not converted into a profit, net protected Wcoh, or control-efficiency claim.

## State reproduction and numerical quality

M13A B0 load energy, passive energy, Wcoh, Cl1, MI, and current reproduce at both switch times with maximum absolute difference 3.839e-13. The MI comparison is the largest difference and remains below the fixed 1e-12 tolerance.

All 22/22 numerical and audit checks are PASS. Maximum trace error is 6.661e-16, maximum Hermiticity error 0.000e+00, minimum raw eigenvalue -7.408e-20, and population-sum error 2.220e-16. Drive Hamiltonian and drive power are exactly zero at both switches. W_pop is zero and `E_load=Wcoh+passive` passes.

## Full-state artifacts

The two 384x384 states are stored as row-major little-endian complex-f64 binaries with `QWNRHO1` metadata. Each file is 2,359,320 bytes and has an individual SHA-256 recorded in `m14_plan_b_state_files.csv`.

## Runtime and immutability

Observed total runtime was 2177.4 s (36.29 min): construction 5.2 s, 3080-step prefix 2169.8 s, and two-state diagnostics/write 2.4 s.

All 15/15 source/formal input hashes are unchanged. No M13A artifact was rewritten.

## Interpretation limits and stop

This result closes the instantaneous Hamiltonian-jump ledger for the two M13A coupling-down protocols. It does not show that weak coupling is optimal, that 6% work was extracted, that protection is free, that an experimental controller has zero cost, or that a positive net benefit exists. Wcoh, load energy, switching work, and interaction energy remain separate ledgers.

The authorized Plan B endpoint has been reached. No R2 full post-switch energy-ledger propagation, ramp, sweep, switch-back, extraction, or optimization was started.
