# Milestone 13A — Formal Short-Horizon Counterfactual Branch Experiment

## 実行結果

固定したN=7 serial条件で、同一の全体系状態からbranch開始後のgenerator項だけを変更する正式比較を完了した。結果は記述的な反実仮想比較に限定する。

- branch開始: 7.50、7.70
- branch終了: 8.50
- 条件: B0、B1、B3、B4（B2は未実行）
- 保存間隔: 0.01
- 正式保存行: 728
- 実測runtime: 3390.2秒（56.50分）
- t=10延長、抽出・回収操作、追加Milestone: 未実行

## 正式classification

### t_branch=7.50

- B1: `dephasing_counterfactual_mixed`
- B3: `weaker_coupling_weakens_Wcoh_decline`
- B4: `zero_coupling_boundary_control_pass`

### t_branch=7.70

- B1: `future_dephasing_change_has_small_effect`
- B3: `weaker_coupling_weakens_Wcoh_decline`
- B4: `zero_coupling_boundary_control_pass`

開始時刻間でclassificationが異なる場合は平均化せず、その差を正式結果として扱った。

## 主要Wcoh差分

- start=7.50, B1: 最大絶対delta_Wcoh=-3.7240053774637537e-05 at t=8.5000000000000000e+00; 終端相対差=-1.2159312940333504e-02; area相対差=-2.5343780437242021e-03
- start=7.50, B3: 最大絶対delta_Wcoh=1.8812288440751054e-04 at t=8.5000000000000000e+00; 終端相対差=6.1424321151409798e-02; area相対差=1.4670925175957812e-02
- start=7.70, B1: 最大絶対delta_Wcoh=-2.9230525289355731e-05 at t=8.5000000000000000e+00; 終端相対差=-9.5441082484599149e-03; area相対差=-2.4745096999829615e-03
- start=7.70, B3: 最大絶対delta_Wcoh=1.8826856275459521e-04 at t=8.5000000000000000e+00; 終端相対差=6.1471886834895455e-02; area相対差=2.1027954259932112e-02

## 数値品質

- row_count: PASS（728）
- B0_vs_M12C_max_abs_difference: PASS（0.0000000000000000e+00）
- branch_start_observable_match: PASS（0.0000000000000000e+00）
- state_clone_exact_runtime_assertion: PASS（0）
- B4_max_invariant_drift: PASS（1.9984014443252818e-15）
- max_trace_error: PASS（1.7763568394002505e-15）
- max_hermiticity_error: PASS（0.0000000000000000e+00）
- minimum_raw_eigenvalue: PASS（-7.1936523544087704e-19）
- fallback_used: PASS（false）
- drive_after_branch: PASS（0.0000000000000000e+00）
- population_sum_error: PASS（1.3322676295501878e-15）

## 解釈範囲

観測内容は「同一状態から、その時点以降のgeneratorを変更したbranchで、baselineとの差がこのように現れた」という記述に限定する。time-areaは状態量の時間積分である。

## 保存点数について

固定窓と0.01間隔から、7.50開始は各101点、7.70開始は各81点で、合計728点となる。1001点はt=0から10までのM12C全時系列に対応し、今回の正式窓には適用していない。
