# Milestone 12A: Load Population Passivity Margin Audit

## 結論

**Classification: `passive_at_all_saved_times_near_boundary`**

M12Aの正式軌道の全保存時刻で、loadのエネルギー基底populationはpassive orderingを満たした。最小passivity marginは `0.0000000000000000e+00`（最初の時刻 `t=0.0000000000000000e+00`、同率 2 点）であり、保存済み `W_pop=0` と整合した。したがって、M12Aの全保存点において、対角load状態はpassiveであり、population ergotropyは数値許容差内で0だった。

最小marginは `epsilon_pop=9.9999999999999998e-13` より大きくない。これは違反ではなく、保存点にpassivity境界上の点があるため、positive-margin分類ではなくnear-boundary分類となる。

## 目的と範囲

保存済みM12A時系列だけを用い、各保存時刻の `p0 >= p1 >= p2`、保存済み `W_pop`、および `W=W_pop+W_coh` を独立に照合した。新しい時間発展、再伝播、再matching、補間、smoothing、fittingは行っていない。

## 正式入力と同一性

- 入力: `C:\Users\yauki\Documents\Codex\2026-07-18\milestone-12a-local-ergotropy-decomposition-after\outputs\matched_n7_local_ergotropy_decomposition_timeseries.csv`
- 保存点数: 1001
- SHA-256（今回）: `5AE060355A3657A440C930DEB08348DC78620A1E948E8648D7C30C53F74EA702`
- 既知の正式SHA-256: `5AE060355A3657A440C930DEB08348DC78620A1E948E8648D7C30C53F74EA702`
- 同一性確認: **PASS**

既知hashは、同じ正式M12A CSVを後続のM12B/M12Cがimmutable inputとして監査した値である。

## 列名対応

| 意味 | 正式CSV列 |
|---|---|
| `time` | `time` |
| `p0` | `load_population_0` |
| `p1` | `load_population_1` |
| `p2` | `load_population_2` |
| `W_pop` | `load_diagonal_ergotropy` |
| `W_coh` | `load_coherence_ergotropy` |
| `W` | `load_ergotropy` |

ここで `W_pop=load_diagonal_ergotropy`、`W_coh=load_coherence_ergotropy`、`W=load_ergotropy` である。

## 数学的判定

- `m01=p0-p1`
- `m12=p1-p2`
- `minimum_passivity_margin=min(m01,m12)`
- strict violation: `m01<0` または `m12<0`
- tolerance-aware violation: `m01<-epsilon_pop` または `m12<-epsilon_pop`
- near-boundary: `|m01|<=epsilon_pop` または `|m12|<=epsilon_pop`

`H_L=diag(0,1,2)` とした。対角状態の直接再計算は、実エネルギー `p1+2*p2` から、populationを降順に並べて低いエネルギーへ割り当てたpassive energyを引いた。この再計算は保存済み `W_pop` 列を使わない。

## 数値許容差

結果を見る前に、既存M12A checksのpopulation sum、ergotropy decomposition、M11M common-trajectory reproductionに使われた `1e-12` を採用した。

- `epsilon_pop = 9.9999999999999998e-13`
- `epsilon_W_pop = 9.9999999999999998e-13`
- `epsilon_decomposition = 9.9999999999999998e-13`
- `epsilon_normalization = 9.9999999999999998e-13`

## 最小マージンと順序監査

| 項目 | 最小値 | 最初の時刻 | 同率点数 |
|---|---:|---:|---:|
| `p0-p1` | 9.8667255783438390e-01 | 8.1500000000000004e+00 | 1 |
| `p1-p2` | 0.0000000000000000e+00 | 0.0000000000000000e+00 | 2 |
| `min(p0-p1,p1-p2)` | 0.0000000000000000e+00 | 0.0000000000000000e+00 | 2 |

- `p0<p1` 点数: 0
- `p1<p2` 点数: 0
- strict order violation点数: 0
- tolerance-aware violation点数: 0
- near-boundary点数: 150

## `W_pop`との独立照合

- 保存済み `W_pop` strictly nonzero点数: 0
- 保存済み `W_pop` numerically nonzero beyond tolerance点数: 0
- 保存済み `W_pop` numerically zero within tolerance点数: 1001
- `max |W_pop_saved| = 0.0000000000000000e+00`
- `max |W_pop_recomputed| = 0.0000000000000000e+00`
- `max |W_pop_saved-W_pop_recomputed| = 0.0000000000000000e+00`

population順序、保存済み `W_pop`、populationだけからの直接再計算は相互に整合した。

## 分解恒等式と数値品質

- `max |W-(W_pop+W_coh)| = 0.0000000000000000e+00`
- `max |p0+p1+p2-1| = 1.3322676295501878e-15`
- 非有限値点数: 0
- checks: **13/13 PASS**

## 明示的な非主張事項

この監査は解析的定理の証明ではない。次は主張しない。

- 保存点間を含む連続時間全体で必ずpassiveであること
- このモデルで原理的に常に `W_pop=0` であること
- 他の `N, Omega, gamma`、drive、初期状態への一般化
- 励起数保存性だけからpopulation順序が保証されること
- 抽出可能仕事が一般に本質的にcoherence由来だという機構
- `W_pop` と `W_coh` が独立した保存エネルギーであること
- 量子優位、普遍法則、または一般的な熱力学的結論
