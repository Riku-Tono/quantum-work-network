# C0 vs C2 Bare-Load Single-Shot Extraction-Time Difference Scan

## 結論

**Classification: `C2_advantage_persistent_on_saved_window`**  
**Secondary: `difference_monotonic_non_decreasing`**

同一の`t=7.70`状態から分岐したC0とC2について、`7.70 <= t <= 8.50`の各保存時刻を独立な単発bare-load抽出候補として比較した。C2-C0のgross-work差は`t=7.7100000000000000e+00`から許容差を超えて正となり、最大差`1.8826856275459521e-04`は`t=8.5000000000000000e+00`に観測された。`t=8.50`の差はM15Aを残差`-9.1072982488782372e-18`で再現した。

C2の優位は窓終端まで維持され、差は保存格子上で単調非減少だった。

## プロトコルと定義

- C0: M13A `branch_start_time=7.70`, `branch_id=B0`, `g=0.25`を維持。
- C2: M13A `branch_start_time=7.70`, `branch_id=B3`, branch直後から`g=0.125`。
- `W_gross,X^bare(t)=load_ergotropy_X(t)`。
- 中心量: `Delta W=W_C2-W_C0`。

これは保存点ごとの独立な反実仮想比較である。新規伝播、抽出後伝播、total-Hamiltonian会計、繰り返し抽出、補間、最適制御は行っていない。

## 入力とSHA-256

- `branch_csv`: `C:\Users\yauki\Documents\Codex\2026-07-18\milestone-12a-local-ergotropy-decomposition-after\outputs\milestone_13a_formal_short_branch\m13a_formal_branch_timeseries.csv`; SHA-256 `F6857C05DE2E21F9494A4835B08F4551182D98B70C78D378CBBD09A08F774FDF`; **PASS**
- `m13_report`: `C:\Users\yauki\Documents\Codex\2026-07-18\milestone-12a-local-ergotropy-decomposition-after\outputs\milestone_13a_formal_short_branch\MILESTONE_13A_FORMAL_SHORT_HORIZON_COUNTERFACTUAL_BRANCH_REPORT.md`; SHA-256 `1C635BE418BCBFDDFD4D823E735B7795AFC91401BC7152E1CDAF3D3D9DEB48F0`; **PASS**
- `m13_area`: `C:\Users\yauki\Documents\Codex\2026-07-18\milestone-12a-local-ergotropy-decomposition-after\outputs\milestone_13a_formal_short_branch\m13a_formal_time_area_comparison.csv`; SHA-256 `325CFD235DA5E154D14AF7313D596BF9E68670244A1746D3311300260472CDD0`; **PASS**
- `m14_report`: `C:\Users\yauki\Documents\Codex\2026-07-18\milestone-13b-temporal-response-decomposition-of\outputs\milestone_14_plan_b\MILESTONE_14_PLAN_B_SWITCHING_ACCOUNTING_REPORT.md`; SHA-256 `3D18141F244DCB38547A58312E53BD45083AF7D4F68F9F2C82032796E5733EDB`; **PASS**
- `m15_report`: `C:\Users\yauki\Documents\Codex\2026-07-18\milestone-13b-temporal-response-decomposition-of\outputs\milestone_15a\MILESTONE_15A_ENDPOINT_EXTRACTION_ACCOUNTING.md`; SHA-256 `EB0F54975C6C2C745CAB7899BDD266A75996ADBDC2D38F81DBF871E4B2314294`; **PASS**
- `m15_gross`: `C:\Users\yauki\Documents\Codex\2026-07-18\milestone-13b-temporal-response-decomposition-of\outputs\milestone_15a\gross_work.csv`; SHA-256 `DD84E7A1B7851E3948EAD0837F81A4E23A7B2DAA1E5106B37891808C77026C20`; **PASS**
- `m15_comparison`: `C:\Users\yauki\Documents\Codex\2026-07-18\milestone-13b-temporal-response-decomposition-of\outputs\milestone_15a\endpoint_extraction_comparison.csv`; SHA-256 `DE5CCFA4EC49A57C73F11836C44884AD4E8517C1AB7DEAF9EFCCB3B002828B3A`; **PASS**
- `m12_scan_report`: `C:\Users\yauki\Documents\Codex\2026-07-19\milestone-12a-load-population-passivity-margin\outputs\MILESTONE_12A_BARE_LOAD_EXTRACTION_TIME_SCAN.md`; SHA-256 `AA7FE83807B413674BDF19368C20151DBEF27E2FEDA2BCC852CD21A12FF002F6`; **PASS**

正式入力CSVはM13A branch時系列である。M13A/M14/M15Aおよび直前M12A scanレポートは参照同一性を確認した。許容差は既存監査と同じ`9.9999999999999998e-13`。

## 時間窓と保存格子

- range: `7.7000000000000002e+00` to `8.5000000000000000e+00`
- saved points: `81` each
- interval: `9.9999999999997868e-03`、80 intervals
- C0/C2 grid: one-to-one match within `1e-12`; maximum time difference `1.7763568394002505e-15`
- raw f64 time-rendering mismatches: `10` of `81` rows
- duplicate times: `0`

10 rows have different raw f64 renderings between branches, but the largest difference is only roundoff-scale and below the fixed tolerance. Rows are paired in their existing order on the common intended 0.01 grid; interpolation and nearest-neighbour matchingは行っていない。

## 差の発生と持続

- first raw positive: `7.7100000000000000e+00` (`Delta W=1.8828509004524541e-08`)
- first tolerance-positive: `7.7100000000000000e+00`
- persistent positive, 3 intervals: `7.7100000000000000e+00`
- persistent positive, 5 intervals formal rule: `7.7100000000000000e+00`
- persistent positive, 7 intervals: `7.7100000000000000e+00`

「5 intervals」は開始点と5個先のendpointまでの6保存点が連続して`Delta W>1e-12`であることと固定した。0.01格子なので0.05時間に対応する。

## 最大差

- maximum absolute difference: `1.8826856275459521e-04` at `t=8.5000000000000000e+00`, ties `1`
- C0 gross: `3.0626774684866464e-03`
- C2 gross: `3.2509460312412416e-03`
- relative vs C0: `6.1471886834895455e-02`
- symmetric relative difference: `5.9638831096820839e-02`
- Delta E_load: `-6.8592992121342677e-05`
- Delta E_passive: `-2.5686155487593789e-04`
- maximum relative difference: `6.1471886834895455e-02` at `t=8.5000000000000000e+00`, ties `1`

最大絶対差と最大相対差は同じendpointで観測された。

## 単調性・符号監査

- monotonic non-decreasing within tolerance: `True`
- strict decrease intervals: `0`
- tolerance-aware decrease intervals: `0`
- near-flat intervals: `0`
- signed increase/decrease intervals: `80/0`
- largest single-step increase: `3.7747316550206488e-06`, interval `8.4900000000000002e+00 -> 8.5000000000000000e+00`
- largest single-step decrease: `not observed`
- first local maximum/minimum: `not observed` / `not observed`
- endpoint is global maximum of Delta W: `True`
- positive/near-zero/negative points: `80/1/0`
- category transition count (near-zero to positive included): `1`
- first/last positive: `7.7100000000000000e+00` / `8.5000000000000000e+00`
- negative difference beyond tolerance: `not observed`

## Time-area comparison

- A_C0: `2.6137853251616125e-03`
- A_C2: `2.6687478834243926e-03`
- A_DeltaW: `5.4962558262780269e-05`
- relative area difference: `2.1027954259932112e-02`
- M13A reported value: `2.1027954259932112e-02`
- reproduction residual: `0.0000000000000000e+00`

これは単発抽出候補値の時間面積であり、累積抽出仕事ではない。

## 各プロトコルの窓内最大

| protocol | maximum gross | first time | ties | endpoint retention |
|---|---:|---:|---:|---:|
| C0 | 3.3852501212993710e-03 | 7.7000000000000002e+00 | 1 | 9.0471231334336066e-01 |
| C2 | 3.3852501212993710e-03 | 7.7000000000000002e+00 | 1 | 9.6032668628734030e-01 |

C0の`t=7.70`最大は直前M12A scanと一致する。C2もこの窓では`t=7.70`が最大だった。

## EndpointとM15A再現

| quantity | C0 | C2 | C2-C0 |
|---|---:|---:|---:|
| bare gross from branch CSV | 3.0626774684866464e-03 | 3.2509460312412416e-03 | 1.8826856275459521e-04 |
| M15A bare gross | 3.0626774684866503e-03 | 3.2509460312412546e-03 | 1.8826856275460432e-04 |
| residual | -3.9031278209478160e-18 | -1.3010426069826053e-17 | -9.1072982488782372e-18 |

- endpoint relative difference: `6.1471886834895455e-02`
- endpoint Delta E_load: `-6.8592992121342677e-05`
- endpoint Delta E_passive: `-2.5686155487593789e-04`

C2ではbare grossが大きい一方、load energyは小さく、passive energyも小さい。これは保存状態量のtrade-off記述であり、変換機構やnet benefitを意味しない。

## 数値監査

- branch-start state maximum difference: `0.0000000000000000e+00`（currentはcouplingを含むgenerator-dependent observableなのでsame-state検査から除外）
- Delta W at t=7.70: `0.0000000000000000e+00`
- max C0/C2 decomposition residual: `0.0000000000000000e+00`
- nonfinite count: `0`
- M15A maximum reproduction residual: `1.3010426069826053e-17`
- checks: **20/20 PASS**

## 許される結論と非主張事項

この固定C0/C2保存窓では、C2-C0差は`t=7.71`から正となり、endpointまで単調に拡大した。これはこの保存格子の記述的結果に限定する。

次は主張しない: C2やweaker couplingの一般的優位、最適coupling/抽出時刻、因果機構、passive energyからcoherent ergotropyへの変換、current/correlationによる原因説明、switching workとのnet benefit、total-Hamiltonian全時刻scan、実装コスト、finite-time操作、repeated extraction、cycle/steady output、`t>8.50`、他条件への一般化、量子優位、効率改善、連続時間最大。
