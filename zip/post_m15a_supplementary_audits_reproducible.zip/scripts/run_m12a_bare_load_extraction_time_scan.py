#!/usr/bin/env python3
"""Saved-grid bare-load single-shot extraction-time scan for formal M12A."""

from __future__ import annotations

import argparse
import csv
import hashlib
import math
from pathlib import Path


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
FORMAL_CSV = (
    PACKAGE_ROOT
    / "reference"
    / "m12a"
    / "matched_n7_local_ergotropy_decomposition_timeseries.csv"
)
PASSIVITY_REFERENCE = PACKAGE_ROOT / "reference" / "expected" / "passivity"
PASSIVITY_REPORT = PASSIVITY_REFERENCE / "MILESTONE_12A_PASSIVITY_MARGIN_AUDIT.md"
PASSIVITY_SUMMARY = PASSIVITY_REFERENCE / "m12a_passivity_margin_summary.csv"

EXPECTED_FORMAL_SHA256 = "5AE060355A3657A440C930DEB08348DC78620A1E948E8648D7C30C53F74EA702"
EXPECTED_PASSIVITY_REPORT_SHA256 = "D7ACF8F59249D230D5A55CDEE5436F13BB13AB4DC25B4502687B6190A14790B5"
TOL = 1.0e-12

COLUMNS = {
    "time": "time",
    "W": "load_ergotropy",
    "W_coh": "load_coherence_ergotropy",
    "W_pop": "load_diagonal_ergotropy",
    "E_load": "load_energy",
    "E_passive": "load_passive_energy",
}
KEY_TIMES = [7.50, 7.70, 8.50, 9.68, 10.00]
POST_PEAK_TIMES = {8.50, 9.68, 10.00}
WINDOWS = [(0.00, 7.50), (7.50, 7.70), (7.70, 8.50), (8.50, 9.68), (9.68, 10.00)]
DEADLINES = [7.50, 7.70, 8.50, 9.68, 10.00]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def fmt(value: float | None) -> str:
    return "" if value is None else f"{value:.16e}"


def flag(value: bool) -> str:
    return str(value).lower()


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        raise ValueError(f"refusing to write empty CSV: {path}")
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def select_time(rows: list[dict[str, float]], target: float) -> dict[str, float]:
    matches = [row for row in rows if abs(row["time"] - target) <= TOL]
    if len(matches) != 1:
        raise ValueError(f"expected exactly one saved point at t={target}, found {len(matches)}")
    return matches[0]


def maximum(rows: list[dict[str, float]]) -> tuple[float, list[dict[str, float]]]:
    value = max(row["gross"] for row in rows)
    return value, [row for row in rows if row["gross"] == value]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=FORMAL_CSV)
    parser.add_argument("--passivity-report", type=Path, default=PASSIVITY_REPORT)
    parser.add_argument("--passivity-summary", type=Path, default=PASSIVITY_SUMMARY)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()

    input_path = args.input.resolve()
    report_path = args.passivity_report.resolve()
    summary_path = args.passivity_summary.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    input_hash = sha256(input_path)
    report_hash = sha256(report_path)
    input_identity = input_hash == EXPECTED_FORMAL_SHA256
    report_identity = report_hash == EXPECTED_PASSIVITY_REPORT_SHA256

    with summary_path.open(newline="", encoding="utf-8") as handle:
        audit_rows = list(csv.DictReader(handle))
    audit = audit_rows[0] if len(audit_rows) == 1 else {}
    audit_consistent = (
        audit.get("input_sha256") == EXPECTED_FORMAL_SHA256
        and audit.get("saved_point_count") == "1001"
        and audit.get("strict_violation_count") == "0"
        and audit.get("tolerance_violation_count") == "0"
        and float(audit.get("max_abs_W_pop", "nan")) <= TOL
        and float(audit.get("max_abs_saved_vs_recomputed_W_pop", "nan")) <= TOL
        and float(audit.get("max_abs_decomposition_residual", "nan")) <= TOL
        and audit.get("nonfinite_count") == "0"
        and audit.get("classification") == "passive_at_all_saved_times_near_boundary"
    )

    with input_path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        headers = reader.fieldnames or []
        missing = [column for column in COLUMNS.values() if column not in headers]
        if missing:
            raise ValueError(f"missing required columns: {missing}")
        source_rows = list(reader)

    rows: list[dict[str, float]] = []
    nonfinite_count = 0
    for source in source_rows:
        values = {name: float(source[column]) for name, column in COLUMNS.items()}
        if not all(math.isfinite(value) for value in values.values()):
            nonfinite_count += 1
            continue
        energy = values["E_load"]
        gross = values["W"]
        usable = None if abs(energy) <= TOL else gross / energy
        rows.append(
            {
                **values,
                "gross": gross,
                "usable": usable,
                "gross_minus_W": gross - values["W"],
                "gross_minus_Wcoh": gross - values["W_coh"],
                "decomposition": values["W"] - (values["W_pop"] + values["W_coh"]),
            }
        )

    if not rows:
        raise ValueError("no finite saved points")

    times = [row["time"] for row in rows]
    duplicate_time_count = len(times) - len(set(times))
    monotonic = all(later > earlier for earlier, later in zip(times, times[1:]))
    time_range_valid = abs(times[0]) <= TOL and abs(times[-1] - 10.0) <= TOL
    key_grid_valid = all(sum(abs(row["time"] - target) <= TOL for row in rows) == 1 for target in KEY_TIMES)

    peak_value, peak_rows = maximum(rows)
    peak_first = peak_rows[0]
    peak_last = peak_rows[-1]
    peak_tied = len(peak_rows) > 1

    timeseries: list[dict[str, object]] = []
    for row in rows:
        difference = row["gross"] - peak_value
        relative_shortfall = None if abs(peak_value) <= TOL else (peak_value - row["gross"]) / peak_value
        timeseries.append(
            {
                "time": fmt(row["time"]),
                "W_load_gross_bare": fmt(row["gross"]),
                "load_ergotropy": fmt(row["W"]),
                "load_coherence_ergotropy": fmt(row["W_coh"]),
                "load_diagonal_ergotropy": fmt(row["W_pop"]),
                "load_energy": fmt(row["E_load"]),
                "load_passive_energy": fmt(row["E_passive"]),
                "usable_fraction": fmt(row["usable"]),
                "difference_from_global_peak": fmt(difference),
                "relative_shortfall_from_global_peak": fmt(relative_shortfall),
                "gross_minus_W": fmt(row["gross_minus_W"]),
                "gross_minus_Wcoh": fmt(row["gross_minus_Wcoh"]),
                "decomposition_residual": fmt(row["decomposition"]),
                "is_global_peak": flag(row["gross"] == peak_value),
            }
        )
    write_csv(output_dir / "m12a_bare_load_extraction_time_scan.csv", timeseries)

    key_rows: list[dict[str, object]] = []
    for target in KEY_TIMES:
        row = select_time(rows, target)
        retention = None if abs(peak_value) <= TOL else row["gross"] / peak_value
        loss = None if retention is None else 1.0 - retention
        label = "global_peak" if row["gross"] == peak_value else f"t_{target:.2f}"
        key_rows.append(
            {
                "time": fmt(row["time"]),
                "label": label,
                "W_load_gross_bare": fmt(row["gross"]),
                "load_ergotropy": fmt(row["W"]),
                "load_coherence_ergotropy": fmt(row["W_coh"]),
                "load_diagonal_ergotropy": fmt(row["W_pop"]),
                "load_energy": fmt(row["E_load"]),
                "load_passive_energy": fmt(row["E_passive"]),
                "usable_fraction": fmt(row["usable"]),
                "difference_from_global_peak": fmt(row["gross"] - peak_value),
                "relative_shortfall_from_global_peak": fmt(loss),
                "retention_from_peak": fmt(retention),
                "loss_from_peak": fmt(loss),
                "post_peak_change_required": flag(target in POST_PEAK_TIMES),
            }
        )
    write_csv(output_dir / "m12a_bare_load_extraction_key_times.csv", key_rows)

    window_rows: list[dict[str, object]] = []
    for start, end in WINDOWS:
        candidates = [row for row in rows if row["time"] >= start - TOL and row["time"] <= end + TOL]
        best, ties = maximum(candidates)
        window_rows.append(
            {
                "window_start": fmt(start),
                "window_end": fmt(end),
                "maximum_gross_work": fmt(best),
                "time_of_maximum": fmt(ties[0]["time"]),
                "last_time_of_maximum": fmt(ties[-1]["time"]),
                "tie_count": len(ties),
                "difference_from_global_peak": fmt(best - peak_value),
                "retention_vs_global_peak": fmt(None if abs(peak_value) <= TOL else best / peak_value),
                "inclusive_boundaries": "true",
            }
        )
    write_csv(output_dir / "m12a_bare_load_extraction_window_summary.csv", window_rows)

    deadline_rows: list[dict[str, object]] = []
    for deadline in DEADLINES:
        candidates = [row for row in rows if row["time"] <= deadline + TOL]
        best, ties = maximum(candidates)
        deadline_rows.append(
            {
                "deadline": fmt(deadline),
                "best_extraction_time": fmt(ties[0]["time"]),
                "last_best_extraction_time": fmt(ties[-1]["time"]),
                "tie_count": len(ties),
                "best_gross_work": fmt(best),
                "difference_from_global_peak": fmt(best - peak_value),
                "retention_vs_global_peak": fmt(None if abs(peak_value) <= TOL else best / peak_value),
            }
        )
    write_csv(output_dir / "m12a_bare_load_extraction_deadline_summary.csv", deadline_rows)

    max_gross_w = max(abs(row["gross_minus_W"]) for row in rows)
    max_gross_wcoh = max(abs(row["gross_minus_Wcoh"]) for row in rows)
    max_w_pop = max(abs(row["W_pop"]) for row in rows)
    max_decomposition = max(abs(row["decomposition"]) for row in rows)
    max_residual = max(max_gross_w, max_gross_wcoh, max_w_pop, max_decomposition)
    completion_ok = (
        input_identity
        and report_identity
        and audit_consistent
        and len(source_rows) == 1001
        and len(rows) == 1001
        and nonfinite_count == 0
        and duplicate_time_count == 0
        and monotonic
        and time_range_valid
        and key_grid_valid
        and max_residual <= TOL
    )
    if not completion_ok:
        classification = "bare_load_extraction_time_scan_inconclusive_due_to_invalid_input"
    elif peak_tied:
        classification = "bare_load_extraction_time_scan_completed_with_tied_peak"
    else:
        classification = "bare_load_extraction_time_scan_completed"

    checks_spec = [
        ("formal_M12A_csv_SHA256", input_identity, input_hash, EXPECTED_FORMAL_SHA256, "matches passivity audit input"),
        ("passivity_audit_report_SHA256", report_identity, report_hash, EXPECTED_PASSIVITY_REPORT_SHA256, "unchanged referenced audit report"),
        ("passivity_audit_summary_consistent", audit_consistent, audit.get("classification", "missing"), "passive_at_all_saved_times_near_boundary", "zero violations/residuals and 1001 points"),
        ("required_columns_present", not missing, len(COLUMNS) - len(missing), len(COLUMNS), ";".join(missing) or "all mapped"),
        ("expected_saved_point_count", len(source_rows) == 1001 and len(rows) == 1001, len(rows), 1001, "all rows processed"),
        ("nonfinite_count", nonfinite_count == 0, nonfinite_count, 0, "required source values"),
        ("duplicate_time_count", duplicate_time_count == 0, duplicate_time_count, 0, "exact saved times"),
        ("time_strictly_increasing", monotonic, monotonic, True, "adjacent saved times"),
        ("time_range_0_to_10", time_range_valid, f"{fmt(times[0])}..{fmt(times[-1])}", "0..10 within 1e-12", "saved range"),
        ("required_key_times_on_grid", key_grid_valid, key_grid_valid, True, "7.50,7.70,8.50,9.68,10.00 each once"),
        ("gross_equals_W", max_gross_w <= TOL, fmt(max_gross_w), fmt(TOL), "max absolute residual"),
        ("gross_equals_Wcoh", max_gross_wcoh <= TOL, fmt(max_gross_wcoh), fmt(TOL), "passivity-audited equality"),
        ("W_pop_zero", max_w_pop <= TOL, fmt(max_w_pop), fmt(TOL), "max |W_pop|"),
        ("ergotropy_decomposition", max_decomposition <= TOL, fmt(max_decomposition), fmt(TOL), "max |W-(W_pop+Wcoh)|"),
        ("global_peak_computed", len(peak_rows) >= 1, fmt(peak_value), "finite maximum", "saved-grid maximum"),
        ("classification_conclusive", not classification.endswith("invalid_input"), classification, "completed classification", "all prerequisites"),
    ]
    checks = [
        {
            "check_name": name,
            "status": "PASS" if passed else "FAIL",
            "passed": flag(bool(passed)),
            "observed_value": observed,
            "tolerance_or_expected": expected,
            "details": details,
        }
        for name, passed, observed, expected, details in checks_spec
    ]
    write_csv(output_dir / "m12a_bare_load_extraction_time_scan_checks.csv", checks)

    def key(target: float) -> dict[str, float]:
        return select_time(rows, target)

    def ratio(target: float) -> float:
        return key(target)["gross"] / peak_value

    column_table = "\n".join(f"| `{meaning}` | `{source}` |" for meaning, source in COLUMNS.items())
    key_table_lines = []
    for target in KEY_TIMES:
        row = key(target)
        retention = row["gross"] / peak_value
        key_table_lines.append(
            f"| {target:.2f} | {fmt(row['gross'])} | {fmt(row['W_coh'])} | {fmt(row['W_pop'])} | "
            f"{fmt(row['E_load'])} | {fmt(row['E_passive'])} | {fmt(row['usable'])} | "
            f"{fmt(row['gross'] - peak_value)} | {fmt(1.0-retention)} |"
        )
    window_table = "\n".join(
        f"| {row['window_start']}..{row['window_end']} | {row['maximum_gross_work']} | {row['time_of_maximum']} | {row['tie_count']} | {row['retention_vs_global_peak']} |"
        for row in window_rows
    )
    deadline_table = "\n".join(
        f"| {row['deadline']} | {row['best_extraction_time']} | {row['best_gross_work']} | {row['difference_from_global_peak']} | {row['retention_vs_global_peak']} |"
        for row in deadline_rows
    )
    checks_passed = sum(row["status"] == "PASS" for row in checks)
    report = f"""# Milestone 12A: Bare-Load Single-Shot Extraction-Time Scan

## 結論

**Classification: `{classification}`**

固定したM12A軌道について、各保存時刻を独立な単発理想抽出時刻として評価した。bare-load gross extracted workは各時刻のload ergotropyに等しく、M12Aの全保存格子上では `W_pop=0` のため `W=W_coh` と一致した。保存格子上の最大値は `t={fmt(peak_first['time'])}` の `{fmt(peak_value)}` であった。

これは保存時系列に基づく単発抽出候補の比較である。抽出後軌道は伝播していない。

## 目的と物理的定義

各保存時刻を互いに独立な反実仮想として、理想局所抽出のbare-load gross workを

`W_load_gross_bare(t) = W(rho_L(t)) = load_ergotropy(t)`

と定義した。照合残差は `gross-Wcoh` と `W-(W_pop+Wcoh)` である。新しい時間発展、再matching、補間、smoothing、fitting、抽出後状態の連続伝播は行っていない。

## 入力とSHA-256

- 正式M12A CSV: `{input_path}`
- 正式CSV SHA-256: `{input_hash}`（既知値との一致 **{'PASS' if input_identity else 'FAIL'}**）
- passivity audit report: `{report_path}`
- audit report SHA-256: `{report_hash}`（監査実行時成果物との一致 **{'PASS' if report_identity else 'FAIL'}**）
- passivity audit classification: `{audit.get('classification', 'missing')}`
- 許容差: `{fmt(TOL)}`

参照監査の1001点、strict違反0、tolerance-aware違反0、`W_pop=0`、分解残差0、非有限値0をsummary CSVからも照合した。

## 列名対応

| 意味 | 正式CSV列 |
|---|---|
{column_table}

## Global peak

- maximum bare-load gross work: `{fmt(peak_value)}`
- first time: `{fmt(peak_first['time'])}`
- last time: `{fmt(peak_last['time'])}`
- tie count: `{len(peak_rows)}`
- `W_coh` at maximum: `{fmt(peak_first['W_coh'])}`
- load energy at maximum: `{fmt(peak_first['E_load'])}`
- load passive energy at maximum: `{fmt(peak_first['E_passive'])}`
- usable fraction at maximum: `{fmt(peak_first['usable'])}`

## 主要時刻比較

`difference_from_global_peak = W(t)-W_max`、相対取り逃し率は `(W_max-W(t))/W_max` とした。

| t | gross | Wcoh | Wpop | Eload | Epassive | usable fraction | difference | relative shortfall |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
{chr(10).join(key_table_lines)}

`usable_fraction=W/E_load` は、その時刻のload energyに占める局所ergotropyの記述的割合にすぎない。独立した利得、効率、装置性能ではない。`|E_load|<=1e-12` では未定義とした。

## ピーク後retention/loss

| t | Delta W | retention | loss |
|---:|---:|---:|---:|
| 8.50 | {fmt(key(8.50)['gross']-peak_value)} | {fmt(ratio(8.50))} | {fmt(1.0-ratio(8.50))} |
| 9.68 | {fmt(key(9.68)['gross']-peak_value)} | {fmt(ratio(9.68))} | {fmt(1.0-ratio(9.68))} |
| 10.00 | {fmt(key(10.00)['gross']-peak_value)} | {fmt(ratio(10.00))} | {fmt(1.0-ratio(10.00))} |

これらは単発抽出候補の比較であり、途中で抽出してから運転を継続した結果ではない。

## 時刻窓別最大値

| window | maximum gross | first maximum time | ties | retention vs global peak |
|---|---:|---:|---:|---:|
{window_table}

全windowは両端を含むため、隣接windowの境界保存点は重複する。

## 期限付き最大値

| deadline | best time | best gross | difference | retention |
|---:|---:|---:|---:|---:|
{deadline_table}

これは「deadlineまでに抽出する」という制約下の単発候補比較である。

## 数値監査

- saved points: {len(rows)}
- time range: `{fmt(times[0])}` to `{fmt(times[-1])}`
- duplicate time count: {duplicate_time_count}
- strictly increasing time: {monotonic}
- nonfinite count: {nonfinite_count}
- `max |gross-W| = {fmt(max_gross_w)}`
- `max |gross-Wcoh| = {fmt(max_gross_wcoh)}`
- `max |W_pop| = {fmt(max_w_pop)}`
- `max |W-(W_pop+Wcoh)| = {fmt(max_decomposition)}`
- checks: **{checks_passed}/{len(checks)} PASS**

## Bare-load会計とtotal-Hamiltonian会計

正式結果は `W_load_gross_bare` のみである。total-Hamiltonian抽出仕事には抽出前後のinteraction energy差が必要であり、この保存時系列CSVだけでは全時刻評価できない。M15Aの `t=8.50` total-Hamiltonian結果を他時刻へ外挿していない。

## 許される結論

固定M12A保存格子上では、最大単発bare-load gross workは上記の保存時刻で得られた。`t=8.50` の候補はglobal peakの `{fmt(ratio(8.50))}` を保持し、`t=10.00` は `{fmt(ratio(10.00))}` を保持していた。

## 非主張事項

次は主張しない。

- 実際に複数時刻で抽出したこと、抽出後軌道、繰り返し抽出、累積仕事
- steady-state output、cycle operation、最適制御、最適運転方策
- extraction device/unitaryの実装コスト、finite-time extraction、controller cost
- switching workを含むnet benefit、total-Hamiltonian gross workの全時刻スキャン
- 効率改善、量子優位、他の `N, Omega, gamma` への一般化
- 保存点間を補間した連続時間最大、または保存格子上の最大が連続時間の厳密な最大であること
"""
    (output_dir / "MILESTONE_12A_BARE_LOAD_EXTRACTION_TIME_SCAN.md").write_text(
        report, encoding="utf-8", newline="\n"
    )

    print(f"global_peak_time={fmt(peak_first['time'])}")
    print(f"global_peak_gross_work={fmt(peak_value)}")
    for target in [7.70, 8.50, 9.68, 10.00]:
        print(f"t={target:.2f} gross={fmt(key(target)['gross'])}")
    print(f"t=8.50 retention={fmt(ratio(8.50))}")
    print(f"t=10.00 retention={fmt(ratio(10.00))}")
    print(f"maximum_numerical_residual={fmt(max_residual)}")
    print(f"checks={checks_passed}/{len(checks)} PASS")
    print(f"classification={classification}")
    return 0 if checks_passed == len(checks) else 1


if __name__ == "__main__":
    raise SystemExit(main())
