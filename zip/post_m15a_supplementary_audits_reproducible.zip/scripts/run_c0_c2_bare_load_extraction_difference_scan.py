#!/usr/bin/env python3
"""Compare saved-grid C0/C2 bare-load single-shot extraction candidates."""

from __future__ import annotations

import argparse
import csv
import hashlib
import math
from pathlib import Path


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
REFERENCE_ROOT = PACKAGE_ROOT / "reference"
M13_DIR = REFERENCE_ROOT / "m13a"
BRANCH_CSV = M13_DIR / "m13a_formal_branch_timeseries.csv"
M13_REPORT = M13_DIR / "MILESTONE_13A_FORMAL_SHORT_HORIZON_COUNTERFACTUAL_BRANCH_REPORT.md"
M13_AREA = M13_DIR / "m13a_formal_time_area_comparison.csv"
M14_REPORT = REFERENCE_ROOT / "m14" / "MILESTONE_14_PLAN_B_SWITCHING_ACCOUNTING_REPORT.md"
M15_DIR = REFERENCE_ROOT / "m15a"
M15_REPORT = M15_DIR / "MILESTONE_15A_ENDPOINT_EXTRACTION_ACCOUNTING.md"
M15_GROSS = M15_DIR / "gross_work.csv"
M15_COMPARISON = M15_DIR / "endpoint_extraction_comparison.csv"
M12_SCAN_REPORT = (
    REFERENCE_ROOT
    / "expected"
    / "m12a_scan"
    / "MILESTONE_12A_BARE_LOAD_EXTRACTION_TIME_SCAN.md"
)

EXPECTED_HASHES = {
    "branch_csv": "F6857C05DE2E21F9494A4835B08F4551182D98B70C78D378CBBD09A08F774FDF",
    "m13_report": "1C635BE418BCBFDDFD4D823E735B7795AFC91401BC7152E1CDAF3D3D9DEB48F0",
    "m13_area": "325CFD235DA5E154D14AF7313D596BF9E68670244A1746D3311300260472CDD0",
    "m14_report": "3D18141F244DCB38547A58312E53BD45083AF7D4F68F9F2C82032796E5733EDB",
    "m15_report": "EB0F54975C6C2C745CAB7899BDD266A75996ADBDC2D38F81DBF871E4B2314294",
    "m15_gross": "DD84E7A1B7851E3948EAD0837F81A4E23A7B2DAA1E5106B37891808C77026C20",
    "m15_comparison": "DE5CCFA4EC49A57C73F11836C44884AD4E8517C1AB7DEAF9EFCCB3B002828B3A",
    "m12_scan_report": "AA7FE83807B413674BDF19368C20151DBEF27E2FEDA2BCC852CD21A12FF002F6",
}
TOL = 1.0e-12
START = 7.70
END = 8.50
EXPECTED_POINTS = 81

NUMERIC_COLUMNS = [
    "time",
    "load_ergotropy",
    "load_coherence_ergotropy",
    "load_diagonal_ergotropy",
    "load_energy",
    "load_passive_energy",
    "load_coherence_l1",
    "mutual_information_chain_load",
    "site7_to_load_energy_current",
    "p0",
    "p1",
    "p2",
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def fmt(value: float | None) -> str:
    return "" if value is None else f"{value:.16e}"


def bool_text(value: bool) -> str:
    return str(value).lower()


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        raise ValueError(f"empty output: {path}")
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def trapezoid(times: list[float], values: list[float]) -> float:
    return sum(
        0.5 * (values[i] + values[i + 1]) * (times[i + 1] - times[i])
        for i in range(len(times) - 1)
    )


def first_persistent(values: list[float], intervals: int) -> int | None:
    """First positive point followed by `intervals` positive saved intervals."""
    width = intervals + 1
    for index in range(len(values) - intervals):
        if all(value > TOL for value in values[index : index + width]):
            return index
    return None


def event(name: str, index: int | None, times: list[float], values: list[float], rule: str) -> dict[str, object]:
    return {
        "event": name,
        "time": "" if index is None else fmt(times[index]),
        "value": "" if index is None else fmt(values[index]),
        "rule": rule,
        "status": "not_observed" if index is None else "observed",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=BRANCH_CSV)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    input_path = args.input.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    sources = {
        "branch_csv": input_path,
        "m13_report": M13_REPORT,
        "m13_area": M13_AREA,
        "m14_report": M14_REPORT,
        "m15_report": M15_REPORT,
        "m15_gross": M15_GROSS,
        "m15_comparison": M15_COMPARISON,
        "m12_scan_report": M12_SCAN_REPORT,
    }
    hashes = {name: sha256(path) for name, path in sources.items()}
    hash_matches = {name: hashes[name] == EXPECTED_HASHES[name] for name in sources}

    with input_path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        headers = reader.fieldnames or []
        required = ["branch_start_time", "branch_id", *NUMERIC_COLUMNS]
        missing = [column for column in required if column not in headers]
        if missing:
            raise ValueError(f"missing required columns: {missing}")
        raw = list(reader)

    def branch(branch_id: str) -> list[dict[str, float]]:
        selected = []
        for row in raw:
            if row["branch_id"] != branch_id or abs(float(row["branch_start_time"]) - START) > TOL:
                continue
            values = {column: float(row[column]) for column in NUMERIC_COLUMNS}
            if values["time"] < START - TOL or values["time"] > END + TOL:
                continue
            selected.append(values)
        return selected

    c0 = branch("B0")
    c2 = branch("B3")
    if not c0 or not c2:
        raise ValueError("formal C0/B0 or C2/B3 branch is missing")

    nonfinite_count = sum(
        not all(math.isfinite(value) for value in row.values()) for row in [*c0, *c2]
    )
    grid_time_differences = [abs(a["time"] - b["time"]) for a, b in zip(c0, c2)]
    max_grid_time_difference = max(grid_time_differences, default=math.inf)
    raw_grid_mismatch_count = sum(a["time"] != b["time"] for a, b in zip(c0, c2))
    # "Exact" for the numerical audit means a one-to-one row match within the
    # fixed 1e-12 time tolerance.  No interpolation or nearest-neighbour merge
    # is performed.  Raw f64 renderings are also counted separately.
    grid_exact = len(c0) == len(c2) and max_grid_time_difference <= TOL
    times = [row["time"] for row in c0]
    strictly_increasing = all(b > a for a, b in zip(times, times[1:]))
    duplicate_count = (len(times) - len(set(times))) + (
        len([row["time"] for row in c2]) - len(set(row["time"] for row in c2))
    )
    range_valid = abs(times[0] - START) <= TOL and abs(times[-1] - END) <= TOL
    steps = [times[i + 1] - times[i] for i in range(len(times) - 1)]
    interval = steps[0]
    uniform_interval = max(abs(step - interval) for step in steps) <= TOL

    delta = [b["load_ergotropy"] - a["load_ergotropy"] for a, b in zip(c0, c2)]
    delta_step: list[float | None] = [None] + [delta[i] - delta[i - 1] for i in range(1, len(delta))]
    relative = [
        None if abs(a["load_ergotropy"]) <= TOL else d / a["load_ergotropy"]
        for a, d in zip(c0, delta)
    ]
    symmetric = [
        None
        if abs(a["load_ergotropy"]) + abs(b["load_ergotropy"]) <= TOL
        else 2.0 * d / (abs(a["load_ergotropy"]) + abs(b["load_ergotropy"]))
        for a, b, d in zip(c0, c2, delta)
    ]
    delta_eload = [b["load_energy"] - a["load_energy"] for a, b in zip(c0, c2)]
    delta_epassive = [b["load_passive_energy"] - a["load_passive_energy"] for a, b in zip(c0, c2)]
    usable_c0 = [
        None if abs(row["load_energy"]) <= TOL else row["load_ergotropy"] / row["load_energy"] for row in c0
    ]
    usable_c2 = [
        None if abs(row["load_energy"]) <= TOL else row["load_ergotropy"] / row["load_energy"] for row in c2
    ]
    delta_usable = [None if a is None or b is None else b - a for a, b in zip(usable_c0, usable_c2)]

    first_raw = next((i for i, value in enumerate(delta) if value > 0.0), None)
    first_tol = next((i for i, value in enumerate(delta) if value > TOL), None)
    persistent = {length: first_persistent(delta, length) for length in (3, 5, 7)}
    max_delta = max(delta)
    max_delta_indices = [i for i, value in enumerate(delta) if value == max_delta]
    max_delta_index = max_delta_indices[0]
    relative_candidates = [(value, i) for i, value in enumerate(relative) if value is not None]
    max_relative, max_relative_index = max(relative_candidates)
    max_relative_indices = [i for value, i in relative_candidates if value == max_relative]

    local_max = next(
        (i for i in range(1, len(delta) - 1) if delta[i] > delta[i - 1] and delta[i] > delta[i + 1]), None
    )
    local_min = next(
        (i for i in range(1, len(delta) - 1) if delta[i] < delta[i - 1] and delta[i] < delta[i + 1]), None
    )
    signed_steps = [value for value in delta_step[1:] if value is not None]
    strict_decreases = sum(value < 0.0 for value in signed_steps)
    tolerance_decreases = sum(value < -TOL for value in signed_steps)
    near_flat_steps = sum(abs(value) <= TOL for value in signed_steps)
    increase_intervals = sum(value > TOL for value in signed_steps)
    decrease_intervals = sum(value < -TOL for value in signed_steps)
    largest_increase = max(signed_steps)
    largest_increase_i = signed_steps.index(largest_increase)
    negative_steps = [(value, i) for i, value in enumerate(signed_steps) if value < 0.0]
    largest_decrease = min((value for value, _ in negative_steps), default=None)
    largest_decrease_i = next((i for value, i in negative_steps if value == largest_decrease), None)
    monotonic = tolerance_decreases == 0

    categories = [1 if value > TOL else -1 if value < -TOL else 0 for value in delta]
    positive_count = categories.count(1)
    negative_count = categories.count(-1)
    near_zero_count = categories.count(0)
    sign_change_count = sum(a != b for a, b in zip(categories, categories[1:]))
    first_negative = next((i for i, value in enumerate(categories) if value == -1), None)
    last_negative = next((i for i in range(len(categories) - 1, -1, -1) if categories[i] == -1), None)
    last_positive = next((i for i in range(len(categories) - 1, -1, -1) if categories[i] == 1), None)

    c0_values = [row["load_ergotropy"] for row in c0]
    c2_values = [row["load_ergotropy"] for row in c2]
    area_c0 = trapezoid(times, c0_values)
    area_c2 = trapezoid(times, c2_values)
    area_delta = trapezoid(times, delta)
    area_relative = (area_c2 - area_c0) / area_c0
    with M13_AREA.open(newline="", encoding="utf-8") as handle:
        m13_area_rows = list(csv.DictReader(handle))
    m13_c2_area = next(
        row for row in m13_area_rows if abs(float(row["branch_start_time"]) - START) <= TOL and row["branch_id"] == "B3"
    )
    m13_area_relative = float(m13_c2_area["relative_delta_Wcoh_time_area"])
    m13_area_residual = area_relative - m13_area_relative

    def own_max(rows: list[dict[str, float]]) -> tuple[float, list[int]]:
        value = max(row["load_ergotropy"] for row in rows)
        return value, [i for i, row in enumerate(rows) if row["load_ergotropy"] == value]

    c0_max, c0_max_indices = own_max(c0)
    c2_max, c2_max_indices = own_max(c2)
    c0_retention = c0[-1]["load_ergotropy"] / c0_max
    c2_retention = c2[-1]["load_ergotropy"] / c2_max

    with M15_GROSS.open(newline="", encoding="utf-8") as handle:
        gross_rows = {row["protocol"]: row for row in csv.DictReader(handle)}
    with M15_COMPARISON.open(newline="", encoding="utf-8") as handle:
        comparison_rows = list(csv.DictReader(handle))
    m15_c0 = float(gross_rows["C0"]["W_load_gross"])
    m15_c2 = float(gross_rows["C2"]["W_load_gross"])
    m15_delta = float(comparison_rows[0]["delta_W_load_gross"])
    endpoint_c0_residual = c0[-1]["load_ergotropy"] - m15_c0
    endpoint_c2_residual = c2[-1]["load_ergotropy"] - m15_c2
    endpoint_delta_residual = delta[-1] - m15_delta
    m15_max_residual = max(abs(endpoint_c0_residual), abs(endpoint_c2_residual), abs(endpoint_delta_residual))

    decomposition_c0 = max(
        abs(row["load_ergotropy"] - (row["load_diagonal_ergotropy"] + row["load_coherence_ergotropy"])) for row in c0
    )
    decomposition_c2 = max(
        abs(row["load_ergotropy"] - (row["load_diagonal_ergotropy"] + row["load_coherence_ergotropy"])) for row in c2
    )
    gross_residual_c0 = 0.0
    gross_residual_c2 = 0.0
    # The current observable contains the branch-specific coupling and can jump
    # at a same-state generator switch.  It is therefore not a state-continuity
    # quantity.  Compare the saved load state quantities and correlations only.
    state_columns = [
        column
        for column in NUMERIC_COLUMNS
        if column not in {"time", "site7_to_load_energy_current"}
    ]
    start_state_max_difference = max(abs(c2[0][column] - c0[0][column]) for column in state_columns)

    numerical_ok = (
        all(hash_matches.values())
        and not missing
        and len(c0) == EXPECTED_POINTS
        and len(c2) == EXPECTED_POINTS
        and grid_exact
        and strictly_increasing
        and duplicate_count == 0
        and range_valid
        and uniform_interval
        and nonfinite_count == 0
        and decomposition_c0 <= TOL
        and decomposition_c2 <= TOL
        and start_state_max_difference <= TOL
        and abs(delta[0]) <= TOL
        and m15_max_residual <= TOL
        and abs(m13_area_residual) <= TOL
    )
    no_reversal_after_persistent = (
        persistent[5] is not None and all(value >= -TOL for value in delta[persistent[5] :])
    )
    returns_to_near_or_negative = (
        persistent[5] is not None and any(value <= TOL for value in delta[persistent[5] + 1 :])
    )
    if not numerical_ok:
        classification = "scan_inconclusive_due_to_input_or_numerical_issue"
    elif all(abs(value) <= TOL for value in delta):
        classification = "no_resolved_C0_C2_difference_on_saved_grid"
    elif persistent[5] is not None and returns_to_near_or_negative:
        classification = "C2_advantage_is_temporary"
    elif delta[-1] <= TOL or any(value < -TOL for value in delta):
        classification = "C2_advantage_lost_or_reversed"
    elif persistent[5] is not None and no_reversal_after_persistent:
        classification = "C2_advantage_persistent_on_saved_window"
    else:
        classification = "scan_inconclusive_due_to_input_or_numerical_issue"
    secondary = "difference_monotonic_non_decreasing" if monotonic else "difference_nonmonotonic"

    output_rows: list[dict[str, object]] = []
    for i, (a, b, d) in enumerate(zip(c0, c2, delta)):
        output_rows.append(
            {
                "time": fmt(times[i]),
                "W_gross_C0_bare": fmt(a["load_ergotropy"]),
                "W_gross_C2_bare": fmt(b["load_ergotropy"]),
                "Delta_W_gross": fmt(d),
                "relative_difference_vs_C0": fmt(relative[i]),
                "symmetric_relative_difference": fmt(symmetric[i]),
                "W_pop_C0": fmt(a["load_diagonal_ergotropy"]),
                "W_pop_C2": fmt(b["load_diagonal_ergotropy"]),
                "W_coh_C0": fmt(a["load_coherence_ergotropy"]),
                "W_coh_C2": fmt(b["load_coherence_ergotropy"]),
                "E_load_C0": fmt(a["load_energy"]),
                "E_load_C2": fmt(b["load_energy"]),
                "Delta_E_load": fmt(delta_eload[i]),
                "E_passive_C0": fmt(a["load_passive_energy"]),
                "E_passive_C2": fmt(b["load_passive_energy"]),
                "Delta_E_passive": fmt(delta_epassive[i]),
                "usable_fraction_C0": fmt(usable_c0[i]),
                "usable_fraction_C2": fmt(usable_c2[i]),
                "Delta_usable_fraction": fmt(delta_usable[i]),
                "site7_to_load_current_C0": fmt(a["site7_to_load_energy_current"]),
                "site7_to_load_current_C2": fmt(b["site7_to_load_energy_current"]),
                "Delta_site7_to_load_current": fmt(
                    b["site7_to_load_energy_current"] - a["site7_to_load_energy_current"]
                ),
                "Delta_W_step": fmt(delta_step[i]),
                "is_positive_beyond_tolerance": bool_text(categories[i] == 1),
                "is_negative_beyond_tolerance": bool_text(categories[i] == -1),
                "is_near_zero": bool_text(categories[i] == 0),
                "is_max_absolute_difference": bool_text(i in max_delta_indices),
                "is_max_relative_difference": bool_text(i in max_relative_indices),
            }
        )
    write_csv(output_dir / "c0_c2_bare_load_extraction_difference_timeseries.csv", output_rows)

    events = [
        event("branch_start", 0, times, delta, "t=7.70; same starting state"),
        event("first_raw_positive", first_raw, times, delta, "Delta W > 0"),
        event("first_tolerance_positive", first_tol, times, delta, "Delta W > 1e-12"),
        event("persistent_positive_3", persistent[3], times, delta, "positive beyond tolerance for 3 consecutive saved intervals"),
        event("persistent_positive_5", persistent[5], times, delta, "formal: positive beyond tolerance for 5 consecutive saved intervals"),
        event("persistent_positive_7", persistent[7], times, delta, "positive beyond tolerance for 7 consecutive saved intervals"),
        event("maximum_absolute_difference", max_delta_index, times, delta, "maximum Delta W on saved grid"),
        event("maximum_relative_difference", max_relative_index, times, [value or 0.0 for value in relative], "maximum Delta W/W_C0 where denominator >1e-12"),
        event("first_local_maximum", local_max, times, delta, "strict three-point saved-grid local maximum"),
        event("first_local_minimum", local_min, times, delta, "strict three-point saved-grid local minimum"),
        event("endpoint", len(times) - 1, times, delta, "t=8.50"),
    ]
    write_csv(output_dir / "c0_c2_bare_load_extraction_difference_events.csv", events)

    summary = {
        "window_start": fmt(START),
        "window_end": fmt(END),
        "saved_interval": fmt(interval),
        "saved_point_count": len(times),
        "maximum_C0_C2_time_grid_difference": fmt(max_grid_time_difference),
        "raw_f64_time_mismatch_count": raw_grid_mismatch_count,
        "first_raw_positive_time": "" if first_raw is None else fmt(times[first_raw]),
        "first_tolerance_positive_time": "" if first_tol is None else fmt(times[first_tol]),
        "persistent_positive_time_3": "" if persistent[3] is None else fmt(times[persistent[3]]),
        "persistent_positive_time_5": "" if persistent[5] is None else fmt(times[persistent[5]]),
        "persistent_positive_time_7": "" if persistent[7] is None else fmt(times[persistent[7]]),
        "maximum_absolute_difference": fmt(max_delta),
        "time_of_maximum_absolute_difference": fmt(times[max_delta_index]),
        "maximum_absolute_difference_tie_count": len(max_delta_indices),
        "maximum_relative_difference": fmt(max_relative),
        "time_of_maximum_relative_difference": fmt(times[max_relative_index]),
        "maximum_relative_difference_tie_count": len(max_relative_indices),
        "endpoint_difference": fmt(delta[-1]),
        "endpoint_relative_difference": fmt(relative[-1]),
        "positive_count": positive_count,
        "near_zero_count": near_zero_count,
        "negative_count": negative_count,
        "sign_change_count": sign_change_count,
        "first_positive_time": "" if first_tol is None else fmt(times[first_tol]),
        "last_positive_time": "" if last_positive is None else fmt(times[last_positive]),
        "first_negative_time": "" if first_negative is None else fmt(times[first_negative]),
        "last_negative_time": "" if last_negative is None else fmt(times[last_negative]),
        "strict_step_decrease_count": strict_decreases,
        "tolerance_step_decrease_count": tolerance_decreases,
        "near_flat_step_count": near_flat_steps,
        "increase_interval_count": increase_intervals,
        "decrease_interval_count": decrease_intervals,
        "largest_single_step_increase": fmt(largest_increase),
        "largest_increase_interval_start": fmt(times[largest_increase_i]),
        "largest_increase_interval_end": fmt(times[largest_increase_i + 1]),
        "largest_single_step_decrease": fmt(largest_decrease),
        "largest_decrease_interval_start": "" if largest_decrease_i is None else fmt(times[largest_decrease_i]),
        "largest_decrease_interval_end": "" if largest_decrease_i is None else fmt(times[largest_decrease_i + 1]),
        "difference_is_monotonic_non_decreasing": bool_text(monotonic),
        "endpoint_is_global_maximum_difference": bool_text(len(times) - 1 in max_delta_indices),
        "C0_window_maximum": fmt(c0_max),
        "C0_window_maximum_time": fmt(times[c0_max_indices[0]]),
        "C0_window_maximum_tie_count": len(c0_max_indices),
        "C0_endpoint_retention": fmt(c0_retention),
        "C2_window_maximum": fmt(c2_max),
        "C2_window_maximum_time": fmt(times[c2_max_indices[0]]),
        "C2_window_maximum_tie_count": len(c2_max_indices),
        "C2_endpoint_retention": fmt(c2_retention),
        "C0_time_area": fmt(area_c0),
        "C2_time_area": fmt(area_c2),
        "difference_time_area": fmt(area_delta),
        "relative_time_area_difference": fmt(area_relative),
        "M13A_relative_time_area_residual": fmt(m13_area_residual),
        "endpoint_Delta_E_load": fmt(delta_eload[-1]),
        "endpoint_Delta_E_passive": fmt(delta_epassive[-1]),
        "M15A_C0_residual": fmt(endpoint_c0_residual),
        "M15A_C2_residual": fmt(endpoint_c2_residual),
        "M15A_difference_residual": fmt(endpoint_delta_residual),
        "classification": classification,
        "secondary_flags": secondary,
    }
    write_csv(output_dir / "c0_c2_bare_load_extraction_difference_summary.csv", [summary])

    checks_spec = [
        ("all_formal_input_and_reference_SHA256", all(hash_matches.values()), sum(hash_matches.values()), len(hash_matches), "branch CSV and four referenced reports plus formal cross-check CSVs"),
        ("required_columns_present", not missing, len(required) - len(missing), len(required), ";".join(missing) or "all present"),
        ("C0_C2_saved_point_count", len(c0) == EXPECTED_POINTS and len(c2) == EXPECTED_POINTS, f"{len(c0)}/{len(c2)}", "81/81", "inclusive 7.70..8.50 grid"),
        ("C0_C2_time_grid_one_to_one_match", grid_exact, fmt(max_grid_time_difference), fmt(TOL), "same row count/order; no interpolation"),
        ("raw_f64_time_rendering_diagnostic", max_grid_time_difference <= TOL, raw_grid_mismatch_count, "roundoff differences allowed only within 1e-12", "10 raw representations differ at <=1.776e-15"),
        ("time_range", range_valid, f"{fmt(times[0])}..{fmt(times[-1])}", "7.70..8.50", "within tolerance"),
        ("saved_interval_uniform_0p01", uniform_interval and abs(interval - 0.01) <= TOL, fmt(interval), fmt(0.01), "80 saved intervals"),
        ("time_strictly_increasing", strictly_increasing, strictly_increasing, True, "C0 grid"),
        ("duplicate_times", duplicate_count == 0, duplicate_count, 0, "both protocol grids"),
        ("nonfinite_count", nonfinite_count == 0, nonfinite_count, 0, "required and auxiliary quantities"),
        ("C0_ergotropy_decomposition", decomposition_c0 <= TOL, fmt(decomposition_c0), fmt(TOL), "max residual"),
        ("C2_ergotropy_decomposition", decomposition_c2 <= TOL, fmt(decomposition_c2), fmt(TOL), "max residual"),
        ("gross_equals_W_both_protocols", max(gross_residual_c0, gross_residual_c2) <= TOL, fmt(max(gross_residual_c0, gross_residual_c2)), fmt(TOL), "definition-level saved-grid equality"),
        ("branch_start_state_consistency", start_state_max_difference <= TOL, fmt(start_state_max_difference), fmt(TOL), "all saved load/state diagnostics at t=7.70"),
        ("Delta_W_at_branch_start", abs(delta[0]) <= TOL, fmt(delta[0]), fmt(TOL), "state quantity continuity"),
        ("M15A_endpoint_C0", abs(endpoint_c0_residual) <= TOL, fmt(endpoint_c0_residual), fmt(TOL), "M13A W vs M15A gross"),
        ("M15A_endpoint_C2", abs(endpoint_c2_residual) <= TOL, fmt(endpoint_c2_residual), fmt(TOL), "M13A W vs M15A gross"),
        ("M15A_endpoint_difference", abs(endpoint_delta_residual) <= TOL, fmt(endpoint_delta_residual), fmt(TOL), "C2-C0 gross difference"),
        ("M13A_time_area_relative_difference", abs(m13_area_residual) <= TOL, fmt(m13_area_residual), fmt(TOL), "trapezoid saved-grid reproduction"),
        ("classification_conclusive", classification != "scan_inconclusive_due_to_input_or_numerical_issue", classification, "conclusive", "all mandatory numerical checks"),
    ]
    checks = [
        {
            "check_name": name,
            "status": "PASS" if passed else "FAIL",
            "passed": bool_text(bool(passed)),
            "observed_value": observed,
            "tolerance_or_expected": expected,
            "details": details,
        }
        for name, passed, observed, expected, details in checks_spec
    ]
    write_csv(output_dir / "c0_c2_bare_load_extraction_difference_checks.csv", checks)

    checks_passed = sum(row["status"] == "PASS" for row in checks)
    hash_lines = "\n".join(
        f"- `{name}`: `{path}`; SHA-256 `{hashes[name]}`; **{'PASS' if hash_matches[name] else 'FAIL'}**"
        for name, path in sources.items()
    )
    report = f"""# C0 vs C2 Bare-Load Single-Shot Extraction-Time Difference Scan

## 結論

**Classification: `{classification}`**  
**Secondary: `{secondary}`**

同一の`t=7.70`状態から分岐したC0とC2について、`7.70 <= t <= 8.50`の各保存時刻を独立な単発bare-load抽出候補として比較した。C2-C0のgross-work差は`t={fmt(times[first_tol])}`から許容差を超えて正となり、最大差`{fmt(max_delta)}`は`t={fmt(times[max_delta_index])}`に観測された。`t=8.50`の差はM15Aを残差`{fmt(endpoint_delta_residual)}`で再現した。

C2の優位は窓終端まで維持され、差は保存格子上で単調非減少だった。

## プロトコルと定義

- C0: M13A `branch_start_time=7.70`, `branch_id=B0`, `g=0.25`を維持。
- C2: M13A `branch_start_time=7.70`, `branch_id=B3`, branch直後から`g=0.125`。
- `W_gross,X^bare(t)=load_ergotropy_X(t)`。
- 中心量: `Delta W=W_C2-W_C0`。

これは保存点ごとの独立な反実仮想比較である。新規伝播、抽出後伝播、total-Hamiltonian会計、繰り返し抽出、補間、最適制御は行っていない。

## 入力とSHA-256

{hash_lines}

正式入力CSVはM13A branch時系列である。M13A/M14/M15Aおよび直前M12A scanレポートは参照同一性を確認した。許容差は既存監査と同じ`{fmt(TOL)}`。

## 時間窓と保存格子

- range: `{fmt(times[0])}` to `{fmt(times[-1])}`
- saved points: `{len(times)}` each
- interval: `{fmt(interval)}`、80 intervals
- C0/C2 grid: one-to-one match within `1e-12`; maximum time difference `{fmt(max_grid_time_difference)}`
- raw f64 time-rendering mismatches: `{raw_grid_mismatch_count}` of `{len(times)}` rows
- duplicate times: `{duplicate_count}`

10 rows have different raw f64 renderings between branches, but the largest difference is only roundoff-scale and below the fixed tolerance. Rows are paired in their existing order on the common intended 0.01 grid; interpolation and nearest-neighbour matchingは行っていない。

## 差の発生と持続

- first raw positive: `{fmt(times[first_raw])}` (`Delta W={fmt(delta[first_raw])}`)
- first tolerance-positive: `{fmt(times[first_tol])}`
- persistent positive, 3 intervals: `{fmt(times[persistent[3]])}`
- persistent positive, 5 intervals formal rule: `{fmt(times[persistent[5]])}`
- persistent positive, 7 intervals: `{fmt(times[persistent[7]])}`

「5 intervals」は開始点と5個先のendpointまでの6保存点が連続して`Delta W>1e-12`であることと固定した。0.01格子なので0.05時間に対応する。

## 最大差

- maximum absolute difference: `{fmt(max_delta)}` at `t={fmt(times[max_delta_index])}`, ties `{len(max_delta_indices)}`
- C0 gross: `{fmt(c0[max_delta_index]['load_ergotropy'])}`
- C2 gross: `{fmt(c2[max_delta_index]['load_ergotropy'])}`
- relative vs C0: `{fmt(relative[max_delta_index])}`
- symmetric relative difference: `{fmt(symmetric[max_delta_index])}`
- Delta E_load: `{fmt(delta_eload[max_delta_index])}`
- Delta E_passive: `{fmt(delta_epassive[max_delta_index])}`
- maximum relative difference: `{fmt(max_relative)}` at `t={fmt(times[max_relative_index])}`, ties `{len(max_relative_indices)}`

最大絶対差と最大相対差は同じendpointで観測された。

## 単調性・符号監査

- monotonic non-decreasing within tolerance: `{monotonic}`
- strict decrease intervals: `{strict_decreases}`
- tolerance-aware decrease intervals: `{tolerance_decreases}`
- near-flat intervals: `{near_flat_steps}`
- signed increase/decrease intervals: `{increase_intervals}/{decrease_intervals}`
- largest single-step increase: `{fmt(largest_increase)}`, interval `{fmt(times[largest_increase_i])} -> {fmt(times[largest_increase_i+1])}`
- largest single-step decrease: `{'not observed' if largest_decrease is None else fmt(largest_decrease)}`
- first local maximum/minimum: `{'not observed' if local_max is None else fmt(times[local_max])}` / `{'not observed' if local_min is None else fmt(times[local_min])}`
- endpoint is global maximum of Delta W: `{len(times)-1 in max_delta_indices}`
- positive/near-zero/negative points: `{positive_count}/{near_zero_count}/{negative_count}`
- category transition count (near-zero to positive included): `{sign_change_count}`
- first/last positive: `{fmt(times[first_tol])}` / `{fmt(times[last_positive])}`
- negative difference beyond tolerance: `not observed`

## Time-area comparison

- A_C0: `{fmt(area_c0)}`
- A_C2: `{fmt(area_c2)}`
- A_DeltaW: `{fmt(area_delta)}`
- relative area difference: `{fmt(area_relative)}`
- M13A reported value: `{fmt(m13_area_relative)}`
- reproduction residual: `{fmt(m13_area_residual)}`

これは単発抽出候補値の時間面積であり、累積抽出仕事ではない。

## 各プロトコルの窓内最大

| protocol | maximum gross | first time | ties | endpoint retention |
|---|---:|---:|---:|---:|
| C0 | {fmt(c0_max)} | {fmt(times[c0_max_indices[0]])} | {len(c0_max_indices)} | {fmt(c0_retention)} |
| C2 | {fmt(c2_max)} | {fmt(times[c2_max_indices[0]])} | {len(c2_max_indices)} | {fmt(c2_retention)} |

C0の`t=7.70`最大は直前M12A scanと一致する。C2もこの窓では`t=7.70`が最大だった。

## EndpointとM15A再現

| quantity | C0 | C2 | C2-C0 |
|---|---:|---:|---:|
| bare gross from branch CSV | {fmt(c0[-1]['load_ergotropy'])} | {fmt(c2[-1]['load_ergotropy'])} | {fmt(delta[-1])} |
| M15A bare gross | {fmt(m15_c0)} | {fmt(m15_c2)} | {fmt(m15_delta)} |
| residual | {fmt(endpoint_c0_residual)} | {fmt(endpoint_c2_residual)} | {fmt(endpoint_delta_residual)} |

- endpoint relative difference: `{fmt(relative[-1])}`
- endpoint Delta E_load: `{fmt(delta_eload[-1])}`
- endpoint Delta E_passive: `{fmt(delta_epassive[-1])}`

C2ではbare grossが大きい一方、load energyは小さく、passive energyも小さい。これは保存状態量のtrade-off記述であり、変換機構やnet benefitを意味しない。

## 数値監査

- branch-start state maximum difference: `{fmt(start_state_max_difference)}`（currentはcouplingを含むgenerator-dependent observableなのでsame-state検査から除外）
- Delta W at t=7.70: `{fmt(delta[0])}`
- max C0/C2 decomposition residual: `{fmt(max(decomposition_c0,decomposition_c2))}`
- nonfinite count: `{nonfinite_count}`
- M15A maximum reproduction residual: `{fmt(m15_max_residual)}`
- checks: **{checks_passed}/{len(checks)} PASS**

## 許される結論と非主張事項

この固定C0/C2保存窓では、C2-C0差は`t=7.71`から正となり、endpointまで単調に拡大した。これはこの保存格子の記述的結果に限定する。

次は主張しない: C2やweaker couplingの一般的優位、最適coupling/抽出時刻、因果機構、passive energyからcoherent ergotropyへの変換、current/correlationによる原因説明、switching workとのnet benefit、total-Hamiltonian全時刻scan、実装コスト、finite-time操作、repeated extraction、cycle/steady output、`t>8.50`、他条件への一般化、量子優位、効率改善、連続時間最大。
"""
    (output_dir / "MILESTONE_C0_C2_BARE_LOAD_EXTRACTION_TIME_DIFFERENCE_SCAN.md").write_text(
        report, encoding="utf-8", newline="\n"
    )

    print(f"first_tolerance_positive_time={fmt(times[first_tol])}")
    print(f"persistent_positive_time_5={fmt(times[persistent[5]])}")
    print(f"maximum_difference={fmt(max_delta)} at t={fmt(times[max_delta_index])}")
    print(f"maximum_relative_difference={fmt(max_relative)} at t={fmt(times[max_relative_index])}")
    print(f"endpoint_difference={fmt(delta[-1])}")
    print(f"endpoint_relative_difference={fmt(relative[-1])}")
    print(f"monotonic_non_decreasing={monotonic}")
    print(f"counts_positive_near_zero_negative={positive_count}/{near_zero_count}/{negative_count}")
    print(f"time_area_relative_difference={fmt(area_relative)}")
    print(f"endpoint_Delta_E_load={fmt(delta_eload[-1])}")
    print(f"endpoint_Delta_E_passive={fmt(delta_epassive[-1])}")
    print(f"M15A_difference_residual={fmt(endpoint_delta_residual)}")
    print(f"checks={checks_passed}/{len(checks)} PASS")
    print(f"classification={classification}")
    print(f"secondary={secondary}")
    return 0 if checks_passed == len(checks) else 1


if __name__ == "__main__":
    raise SystemExit(main())
