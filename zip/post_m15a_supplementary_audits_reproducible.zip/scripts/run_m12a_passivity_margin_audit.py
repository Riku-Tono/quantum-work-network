#!/usr/bin/env python3
"""Audit saved-time load-population passivity for the formal M12A CSV.

This script is deliberately read-only with respect to the M12A input.  It does
not propagate, interpolate, smooth, fit, or otherwise alter the trajectory.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import math
from pathlib import Path


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = (
    PACKAGE_ROOT
    / "reference"
    / "m12a"
    / "matched_n7_local_ergotropy_decomposition_timeseries.csv"
)
EXPECTED_SHA256 = "5AE060355A3657A440C930DEB08348DC78620A1E948E8648D7C30C53F74EA702"

# Fixed before inspecting the margin results.  This is the existing M12A
# population-sum, ergotropy-decomposition, and trajectory-reproduction audit
# tolerance (reported as 9.9999999999999998e-13 in the formal checks CSV).
EPS_POP = 1.0e-12
EPS_W_POP = 1.0e-12
EPS_DECOMPOSITION = 1.0e-12
EPS_NORMALIZATION = 1.0e-12

COLUMNS = {
    "time": "time",
    "p0": "load_population_0",
    "p1": "load_population_1",
    "p2": "load_population_2",
    "W_pop": "load_diagonal_ergotropy",
    "W_coh": "load_coherence_ergotropy",
    "W": "load_ergotropy",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def f(value: float) -> str:
    return f"{value:.16e}"


def b(value: bool) -> str:
    return str(value).lower()


def direct_diagonal_ergotropy(p0: float, p1: float, p2: float) -> float:
    """Ergotropy of diag(p0,p1,p2) for H_L=diag(0,1,2).

    The actual energy is p1+2*p2.  The passive energy assigns the populations
    in descending order to energies in ascending order.  This is a direct
    population-only cross-check, independent of the saved W_pop column.
    """

    actual_energy = p1 + 2.0 * p2
    descending = sorted((p0, p1, p2), reverse=True)
    passive_energy = descending[1] + 2.0 * descending[2]
    raw = actual_energy - passive_energy
    return 0.0 if raw == 0.0 else raw


def write_csv(path: Path, fieldnames: list[str], rows: list[dict[str, object]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    input_path = args.input.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    input_hash = sha256(input_path)
    identity_confirmed = input_hash == EXPECTED_SHA256

    with input_path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        headers = reader.fieldnames or []
        missing = [source for source in COLUMNS.values() if source not in headers]
        if missing:
            raise ValueError(f"missing required columns: {missing}")
        source_rows = list(reader)

    rows: list[dict[str, object]] = []
    numeric_rows: list[dict[str, float | bool]] = []
    nonfinite_count = 0
    for source in source_rows:
        values = {name: float(source[column]) for name, column in COLUMNS.items()}
        finite = all(math.isfinite(value) for value in values.values())
        if not finite:
            nonfinite_count += 1
            continue

        time = values["time"]
        p0, p1, p2 = values["p0"], values["p1"], values["p2"]
        w_pop, w_coh, w_total = values["W_pop"], values["W_coh"], values["W"]
        m01 = p0 - p1
        m12 = p1 - p2
        m_passive = min(m01, m12)
        strict = m01 < 0.0 or m12 < 0.0
        tolerance_violation = m01 < -EPS_POP or m12 < -EPS_POP
        near_boundary = abs(m01) <= EPS_POP or abs(m12) <= EPS_POP
        w_recomputed = direct_diagonal_ergotropy(p0, p1, p2)
        w_difference = w_pop - w_recomputed
        decomposition_residual = w_total - (w_pop + w_coh)
        normalization_residual = p0 + p1 + p2 - 1.0

        numeric_rows.append(
            {
                **values,
                "m01": m01,
                "m12": m12,
                "m_passive": m_passive,
                "strict": strict,
                "tolerance_violation": tolerance_violation,
                "near_boundary": near_boundary,
                "w_recomputed": w_recomputed,
                "w_difference": w_difference,
                "decomposition_residual": decomposition_residual,
                "normalization_residual": normalization_residual,
            }
        )
        rows.append(
            {
                "time": f(time),
                "p0": f(p0),
                "p1": f(p1),
                "p2": f(p2),
                "margin_p0_p1": f(m01),
                "margin_p1_p2": f(m12),
                "minimum_passivity_margin": f(m_passive),
                "strict_order_violation": b(strict),
                "tolerance_order_violation": b(tolerance_violation),
                "near_passivity_boundary": b(near_boundary),
                "W_pop_saved": f(w_pop),
                "W_pop_recomputed": f(w_recomputed),
                "W_pop_difference": f(w_difference),
                "W": f(w_total),
                "W_coh": f(w_coh),
                "decomposition_residual": f(decomposition_residual),
                "population_normalization_residual": f(normalization_residual),
            }
        )

    if not numeric_rows:
        raise ValueError("no finite rows available for audit")

    def minimum_with_ties(key: str) -> tuple[float, float, int]:
        minimum = min(float(row[key]) for row in numeric_rows)
        ties = [row for row in numeric_rows if float(row[key]) == minimum]
        return minimum, float(ties[0]["time"]), len(ties)

    min01, time01, ties01 = minimum_with_ties("m01")
    min12, time12, ties12 = minimum_with_ties("m12")
    min_passive, time_passive, ties_passive = minimum_with_ties("m_passive")

    p0_lt_p1 = sum(float(row["m01"]) < 0.0 for row in numeric_rows)
    p1_lt_p2 = sum(float(row["m12"]) < 0.0 for row in numeric_rows)
    strict_count = sum(bool(row["strict"]) for row in numeric_rows)
    tolerance_count = sum(bool(row["tolerance_violation"]) for row in numeric_rows)
    near_count = sum(bool(row["near_boundary"]) for row in numeric_rows)
    w_strict_nonzero = sum(float(row["W_pop"]) != 0.0 for row in numeric_rows)
    w_beyond_tolerance = sum(abs(float(row["W_pop"])) > EPS_W_POP for row in numeric_rows)
    w_within_tolerance = len(numeric_rows) - w_beyond_tolerance
    max_w_pop = max(abs(float(row["W_pop"])) for row in numeric_rows)
    max_w_recomputed = max(abs(float(row["w_recomputed"])) for row in numeric_rows)
    max_w_difference = max(abs(float(row["w_difference"])) for row in numeric_rows)
    max_decomposition = max(abs(float(row["decomposition_residual"])) for row in numeric_rows)
    max_normalization = max(abs(float(row["normalization_residual"])) for row in numeric_rows)

    invalid = (
        not identity_confirmed
        or nonfinite_count > 0
        or max_normalization > EPS_NORMALIZATION
        or len(numeric_rows) != len(source_rows)
    )
    if invalid:
        classification = "audit_inconclusive_due_to_missing_or_invalid_data"
    elif tolerance_count > 0:
        classification = "saved_time_passivity_violation_observed"
    elif near_count > 0 or min_passive <= EPS_POP:
        classification = "passive_at_all_saved_times_near_boundary"
    elif (
        min_passive > EPS_POP
        and max_w_pop <= EPS_W_POP
        and max_w_recomputed <= EPS_W_POP
        and max_decomposition <= EPS_DECOMPOSITION
    ):
        classification = "passive_at_all_saved_times_with_positive_margin"
    else:
        classification = "audit_inconclusive_due_to_missing_or_invalid_data"

    timeseries_fields = list(rows[0].keys())
    write_csv(output_dir / "m12a_passivity_margin_timeseries.csv", timeseries_fields, rows)

    summary = {
        "input_file": str(input_path),
        "input_sha256": input_hash,
        "expected_sha256": EXPECTED_SHA256,
        "input_identity_confirmed": b(identity_confirmed),
        "saved_point_count": len(source_rows),
        "epsilon_pop": f(EPS_POP),
        "epsilon_W_pop": f(EPS_W_POP),
        "epsilon_decomposition": f(EPS_DECOMPOSITION),
        "epsilon_normalization": f(EPS_NORMALIZATION),
        "minimum_p0_minus_p1": f(min01),
        "time_of_minimum_p0_minus_p1": f(time01),
        "minimum_p0_minus_p1_tie_count": ties01,
        "minimum_p1_minus_p2": f(min12),
        "time_of_minimum_p1_minus_p2": f(time12),
        "minimum_p1_minus_p2_tie_count": ties12,
        "minimum_passivity_margin": f(min_passive),
        "time_of_minimum_passivity_margin": f(time_passive),
        "minimum_passivity_margin_tie_count": ties_passive,
        "p0_less_than_p1_count": p0_lt_p1,
        "p1_less_than_p2_count": p1_lt_p2,
        "strict_violation_count": strict_count,
        "tolerance_violation_count": tolerance_count,
        "near_boundary_count": near_count,
        "strictly_nonzero_W_pop_count": w_strict_nonzero,
        "numerically_nonzero_W_pop_count": w_beyond_tolerance,
        "numerically_zero_W_pop_count": w_within_tolerance,
        "max_abs_W_pop": f(max_w_pop),
        "max_abs_W_pop_recomputed": f(max_w_recomputed),
        "max_abs_saved_vs_recomputed_W_pop": f(max_w_difference),
        "max_abs_decomposition_residual": f(max_decomposition),
        "max_abs_population_normalization_residual": f(max_normalization),
        "nonfinite_count": nonfinite_count,
        "classification": classification,
    }
    write_csv(output_dir / "m12a_passivity_margin_summary.csv", list(summary), [summary])

    checks_spec = [
        ("formal_input_sha256_matches_prior_audits", identity_confirmed, input_hash, EXPECTED_SHA256, "Known M12B/M12C immutable-input hash"),
        ("required_columns_present", not missing, len(COLUMNS) - len(missing), len(COLUMNS), ";".join(missing) or "all semantic columns mapped"),
        ("saved_points_1001", len(source_rows) == 1001, len(source_rows), 1001, "formal M12A saved grid"),
        ("all_required_values_finite", nonfinite_count == 0, nonfinite_count, 0, "seven required numeric columns"),
        ("population_normalization", max_normalization <= EPS_NORMALIZATION, f(max_normalization), f(EPS_NORMALIZATION), "max |p0+p1+p2-1|"),
        ("strict_order_violation_absent", strict_count == 0, strict_count, 0, "raw-sign audit"),
        ("tolerance_order_violation_absent", tolerance_count == 0, tolerance_count, 0, "m01,m12 >= -epsilon_pop"),
        ("near_boundary_classification_consistent", (near_count > 0) == (classification == "passive_at_all_saved_times_near_boundary"), near_count, ">0 iff near-boundary classification", "fixed classification rule"),
        ("saved_W_pop_within_tolerance", max_w_pop <= EPS_W_POP, f(max_w_pop), f(EPS_W_POP), "max |W_pop_saved|"),
        ("recomputed_W_pop_within_tolerance", max_w_recomputed <= EPS_W_POP, f(max_w_recomputed), f(EPS_W_POP), "direct diagonal-state ergotropy"),
        ("saved_vs_recomputed_W_pop", max_w_difference <= EPS_W_POP, f(max_w_difference), f(EPS_W_POP), "max absolute difference"),
        ("ergotropy_decomposition", max_decomposition <= EPS_DECOMPOSITION, f(max_decomposition), f(EPS_DECOMPOSITION), "max |W-(W_pop+W_coh)|"),
        ("classification_not_inconclusive", not classification.startswith("audit_inconclusive"), classification, "conclusive", "input and numerical quality valid"),
    ]
    checks = [
        {
            "check_name": name,
            "status": "PASS" if passed else "FAIL",
            "passed": b(passed),
            "observed_value": observed,
            "tolerance_or_expected": expected,
            "details": details,
        }
        for name, passed, observed, expected, details in checks_spec
    ]
    write_csv(output_dir / "m12a_passivity_margin_checks.csv", list(checks[0]), checks)

    column_rows = "\n".join(
        f"| `{semantic}` | `{source}` |" for semantic, source in COLUMNS.items()
    )
    checks_passed = sum(row["status"] == "PASS" for row in checks)
    report = f"""# Milestone 12A: Load Population Passivity Margin Audit

## 結論

**Classification: `{classification}`**

M12Aの正式軌道の全保存時刻で、loadのエネルギー基底populationはpassive orderingを満たした。最小passivity marginは `{f(min_passive)}`（最初の時刻 `t={f(time_passive)}`、同率 {ties_passive} 点）であり、保存済み `W_pop=0` と整合した。したがって、M12Aの全保存点において、対角load状態はpassiveであり、population ergotropyは数値許容差内で0だった。

最小marginは `epsilon_pop={f(EPS_POP)}` より大きくない。これは違反ではなく、保存点にpassivity境界上の点があるため、positive-margin分類ではなくnear-boundary分類となる。

## 目的と範囲

保存済みM12A時系列だけを用い、各保存時刻の `p0 >= p1 >= p2`、保存済み `W_pop`、および `W=W_pop+W_coh` を独立に照合した。新しい時間発展、再伝播、再matching、補間、smoothing、fittingは行っていない。

## 正式入力と同一性

- 入力: `{input_path}`
- 保存点数: {len(source_rows)}
- SHA-256（今回）: `{input_hash}`
- 既知の正式SHA-256: `{EXPECTED_SHA256}`
- 同一性確認: **{'PASS' if identity_confirmed else 'FAIL'}**

既知hashは、同じ正式M12A CSVを後続のM12B/M12Cがimmutable inputとして監査した値である。

## 列名対応

| 意味 | 正式CSV列 |
|---|---|
{column_rows}

ここで `W_pop=load_diagonal_ergotropy`、`W_coh=load_coherence_ergotropy`、`W=load_ergotropy` である。

## 数学的判定

- `m01=p0-p1`
- `m12=p1-p2`
- `minimum_passivity_margin=min(m01,m12)`
- strict violation: `m01<0` または `m12<0`
- tolerance-aware violation: `m01<-epsilon_pop` または `m12<-epsilon_pop`
- near-boundary: `|m01|<=epsilon_pop` または `|m12|<=epsilon_pop`

`H_L=diag(0,1,2)` とした。対角状態の直接再計算は、実エネルギー `p1+2*p2` から、populationを降順に並べて低いエネルギーへ割り当てたpassive energyを引いた。この再計算は保存済み `W_pop` 列を使わない。

## 数値許容差

結果を見る前に、既存M12A checksのpopulation sum、ergotropy decomposition、M11M common-trajectory reproductionに使われた `1e-12` を採用した。

- `epsilon_pop = {f(EPS_POP)}`
- `epsilon_W_pop = {f(EPS_W_POP)}`
- `epsilon_decomposition = {f(EPS_DECOMPOSITION)}`
- `epsilon_normalization = {f(EPS_NORMALIZATION)}`

## 最小マージンと順序監査

| 項目 | 最小値 | 最初の時刻 | 同率点数 |
|---|---:|---:|---:|
| `p0-p1` | {f(min01)} | {f(time01)} | {ties01} |
| `p1-p2` | {f(min12)} | {f(time12)} | {ties12} |
| `min(p0-p1,p1-p2)` | {f(min_passive)} | {f(time_passive)} | {ties_passive} |

- `p0<p1` 点数: {p0_lt_p1}
- `p1<p2` 点数: {p1_lt_p2}
- strict order violation点数: {strict_count}
- tolerance-aware violation点数: {tolerance_count}
- near-boundary点数: {near_count}

## `W_pop`との独立照合

- 保存済み `W_pop` strictly nonzero点数: {w_strict_nonzero}
- 保存済み `W_pop` numerically nonzero beyond tolerance点数: {w_beyond_tolerance}
- 保存済み `W_pop` numerically zero within tolerance点数: {w_within_tolerance}
- `max |W_pop_saved| = {f(max_w_pop)}`
- `max |W_pop_recomputed| = {f(max_w_recomputed)}`
- `max |W_pop_saved-W_pop_recomputed| = {f(max_w_difference)}`

population順序、保存済み `W_pop`、populationだけからの直接再計算は相互に整合した。

## 分解恒等式と数値品質

- `max |W-(W_pop+W_coh)| = {f(max_decomposition)}`
- `max |p0+p1+p2-1| = {f(max_normalization)}`
- 非有限値点数: {nonfinite_count}
- checks: **{checks_passed}/{len(checks)} PASS**

## 明示的な非主張事項

この監査は解析的定理の証明ではない。次は主張しない。

- 保存点間を含む連続時間全体で必ずpassiveであること
- このモデルで原理的に常に `W_pop=0` であること
- 他の `N, Omega, gamma`、drive、初期状態への一般化
- 励起数保存性だけからpopulation順序が保証されること
- 抽出可能仕事が一般に本質的にcoherence由来だという機構
- `W_pop` と `W_coh` が独立した保存エネルギーであること
- 量子優位、普遍法則、または一般的な熱力学的結論
"""
    (output_dir / "MILESTONE_12A_PASSIVITY_MARGIN_AUDIT.md").write_text(report, encoding="utf-8", newline="\n")

    print(f"input_sha256={input_hash}")
    print(f"saved_points={len(source_rows)}")
    print(f"checks={checks_passed}/{len(checks)} PASS")
    print(f"minimum_passivity_margin={f(min_passive)} at t={f(time_passive)} ties={ties_passive}")
    print(f"classification={classification}")
    return 0 if checks_passed == len(checks) else 1


if __name__ == "__main__":
    raise SystemExit(main())
