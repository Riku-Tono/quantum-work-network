# Post-M15A supplementary audits reproducible package

M15A完了後に実施した次の3件を、保存済み正式成果物だけから再現する軽量パッケージです。
新しいtrajectory伝播、Rust build、ネット接続、外部Pythonパッケージは必要ありません。

1. M12A Load Population Passivity Margin Audit
2. M12A Bare-Load Single-Shot Extraction-Time Scan
3. C0 vs C2 Bare-Load Extraction-Time Difference Scan (`t=7.70..8.50`)

これらは新しいMilestone 12Aではありません。M15A後に、既存M12A・M13A・M14・M15A成果物を
追加解析した補足監査です。

## 必要環境

- Python 3.9以降
- 標準ライブラリのみ
- 数十MB未満の一時領域

## 一括再現

展開したフォルダ直下で次を実行してください。

```powershell
python verify_reproduction.py
```

このコマンドは以下を行います。

1. パッケージ全ファイルのSHA-256を検査。
2. 一時ディレクトリで3監査を個別に再実行。
3. 安定CSVを正式成果物とexact SHA-256比較。
4. 絶対パスを記録するM12A summaryは`input_file`列だけを除外して全列比較。
5. 3報告書の正式classification、チェック数、主要値を確認。
6. 一時生成物を削除し、同梱referenceには書き込まない。

成功時は終了コード0と次の最終行を返します。

```text
[PASS] all three supplementary audits reproduced
```

## 入力の由来

- `reference/m12a/`: 提供された`milestone_12a_reproducible.zip`内の正式M12A時系列。
- `reference/m13a/`: C0/B0とC2/B3を含む正式short-branch時系列、報告書、time-area表。
- `reference/m14/`: Plan B switching-accounting報告書。参照同一性確認用。
- `reference/m15a/`: endpoint extraction報告書、gross-work表、比較表。
- `reference/expected/`: 3監査の正式成果物。再実行結果の照合先。

3番目の監査の主データはM13A branch時系列です。M14・M15A成果物は、protocol provenanceと
`t=8.50` endpoint再現を検査するために同梱しています。

## 範囲

- すべて保存格子上の再解析です。
- bare-load単発抽出候補であり、各時刻で実際の抽出・抽出後伝播を行うものではありません。
- C0/C2比較は固定した`7.70..8.50`窓だけです。
- 機構、最適coupling、net benefit、一般的優位を証明しません。

元のM12A完全trajectoryをt=0から再計算する場合は、別途公開済みの
`milestone_12a_reproducible.zip`を使用してください。本パッケージはその大きなRust/vendorセットを
重複収録しません。
