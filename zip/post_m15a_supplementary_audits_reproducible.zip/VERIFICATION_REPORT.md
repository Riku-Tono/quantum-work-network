# Verification report

Date: 2026-07-19 (Asia/Tokyo)

## Supplied M12A reproduction ZIP

Input archive: `milestone_12a_reproducible.zip`

- Archive SHA-256: `29FA0C27D9D0B282FD539144247A975A39C91F3C4883840E568BA651E1AD2147`
- Packaged input/source/reference SHA checks: `2186/2186 PASS`
- Rust library tests: `86 passed, 0 failed`
- Portable finalizer outputs: `7/7` exact SHA-256 matches
- Overwrite guards: PASS
- Offline Cargo build: PASS
- Short benchmark: 31.486 s
- Estimated complete trajectory run on this machine: about 92.0 min

The supplied bundle's normal quick verification completed successfully. The optional `--full`
trajectory regeneration was not run because it is a separate approximately 92-minute computation;
the user reported that complete reproduction had already been checked repeatedly.

## Three supplementary audits

All three audits were rerun in fresh temporary output directories from the packaged references.

1. M12A Load Population Passivity Margin Audit
   - input SHA-256: `5AE060355A3657A440C930DEB08348DC78620A1E948E8648D7C30C53F74EA702`
   - checks: `13/13 PASS`
   - classification: `passive_at_all_saved_times_near_boundary`
2. M12A Bare-Load Single-Shot Extraction-Time Scan
   - checks: `16/16 PASS`
   - classification: `bare_load_extraction_time_scan_completed`
   - saved-grid maximum: `3.3852501212993710e-03` at `t=7.70`
3. C0 vs C2 Bare-Load Extraction-Time Difference Scan
   - checks: `20/20 PASS`
   - classification: `C2_advantage_persistent_on_saved_window`
   - endpoint difference: `1.8826856275459521e-04` at `t=8.50`
   - M15A difference reproduction residual: `-9.1072982488782372e-18`

Stable generated CSVs matched the formal references exactly by SHA-256. The passivity summary was
identical after excluding only its machine-specific absolute `input_file` field. Generated Markdown
reports were checked for their formal classifications, check counts, and key numerical values.
