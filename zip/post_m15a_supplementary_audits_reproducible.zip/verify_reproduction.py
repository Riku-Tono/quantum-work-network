#!/usr/bin/env python3
"""One-command verification for the three post-M15A supplementary audits."""

from __future__ import annotations

import argparse
import csv
import hashlib
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "manifests" / "package_sha256.csv"
SCRIPTS = ROOT / "scripts"
EXPECTED = ROOT / "reference" / "expected"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def packaged_files() -> list[Path]:
    files = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT)
        if relative == MANIFEST.relative_to(ROOT):
            continue
        if "__pycache__" in relative.parts or relative.parts[0] == "runs":
            continue
        files.append(path)
    return sorted(files, key=lambda item: item.relative_to(ROOT).as_posix())


def write_manifest() -> None:
    MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    with MANIFEST.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["path", "sha256"], lineterminator="\n")
        writer.writeheader()
        for path in packaged_files():
            writer.writerow({
                "path": path.relative_to(ROOT).as_posix(),
                "sha256": sha256(path),
            })
    print(f"[WRITE] {MANIFEST} ({len(packaged_files())} files)")


def verify_manifest() -> None:
    if not MANIFEST.is_file():
        raise SystemExit(f"missing manifest: {MANIFEST}")
    with MANIFEST.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    expected_paths = {row["path"] for row in rows}
    actual_paths = {path.relative_to(ROOT).as_posix() for path in packaged_files()}
    if expected_paths != actual_paths:
        missing = sorted(expected_paths - actual_paths)
        extra = sorted(actual_paths - expected_paths)
        raise SystemExit(f"package file set mismatch; missing={missing}, extra={extra}")
    failures = []
    for row in rows:
        actual = sha256(ROOT / row["path"])
        if actual != row["sha256"]:
            failures.append((row["path"], row["sha256"], actual))
    if failures:
        raise SystemExit(f"package SHA-256 mismatch: {failures}")
    print(f"[PASS] package SHA-256: {len(rows)}/{len(rows)}")


def run_script(name: str, output_dir: Path) -> None:
    command = [
        sys.executable,
        str(SCRIPTS / name),
        "--output-dir",
        str(output_dir),
    ]
    print(f"[RUN] {' '.join(command)}")
    subprocess.run(command, cwd=ROOT, check=True)


def compare_exact(actual_dir: Path, expected_dir: Path, names: list[str]) -> None:
    failures = []
    for name in names:
        actual_hash = sha256(actual_dir / name)
        expected_hash = sha256(expected_dir / name)
        if actual_hash != expected_hash:
            failures.append((name, expected_hash, actual_hash))
    if failures:
        raise SystemExit(f"reproduced output SHA-256 mismatch: {failures}")
    print(f"[PASS] exact reproduced outputs: {len(names)}/{len(names)}")


def compare_csv_ignoring(actual: Path, expected: Path, ignored: set[str]) -> None:
    def rows(path: Path) -> list[dict[str, str]]:
        with path.open(newline="", encoding="utf-8") as handle:
            return [
                {key: value for key, value in row.items() if key not in ignored}
                for row in csv.DictReader(handle)
            ]

    actual_rows = rows(actual)
    expected_rows = rows(expected)
    if actual_rows != expected_rows:
        raise SystemExit(f"semantic CSV mismatch: {actual.name}")
    print(f"[PASS] semantic CSV reproduction: {actual.name}")


def require_report_snippets(report: Path, snippets: list[str]) -> None:
    text = report.read_text(encoding="utf-8")
    missing = [snippet for snippet in snippets if snippet not in text]
    if missing:
        raise SystemExit(f"report validation failed for {report.name}; missing={missing}")
    print(f"[PASS] report verdict and key values: {report.name}")


def verify_three_audits() -> None:
    with tempfile.TemporaryDirectory(prefix="post_m15a_audits_") as temp:
        run_root = Path(temp)
        passivity = run_root / "01_passivity"
        m12a_scan = run_root / "02_m12a_scan"
        c0_c2 = run_root / "03_c0_c2_scan"

        run_script("run_m12a_passivity_margin_audit.py", passivity)
        run_script("run_m12a_bare_load_extraction_time_scan.py", m12a_scan)
        run_script("run_c0_c2_bare_load_extraction_difference_scan.py", c0_c2)

        compare_exact(
            passivity,
            EXPECTED / "passivity",
            ["m12a_passivity_margin_timeseries.csv", "m12a_passivity_margin_checks.csv"],
        )
        compare_csv_ignoring(
            passivity / "m12a_passivity_margin_summary.csv",
            EXPECTED / "passivity" / "m12a_passivity_margin_summary.csv",
            {"input_file"},
        )
        require_report_snippets(
            passivity / "MILESTONE_12A_PASSIVITY_MARGIN_AUDIT.md",
            ["passive_at_all_saved_times_near_boundary", "checks: **13/13 PASS**", "strict order violation点数: 0"],
        )

        compare_exact(
            m12a_scan,
            EXPECTED / "m12a_scan",
            [
                "m12a_bare_load_extraction_time_scan.csv",
                "m12a_bare_load_extraction_key_times.csv",
                "m12a_bare_load_extraction_window_summary.csv",
                "m12a_bare_load_extraction_deadline_summary.csv",
                "m12a_bare_load_extraction_time_scan_checks.csv",
            ],
        )
        require_report_snippets(
            m12a_scan / "MILESTONE_12A_BARE_LOAD_EXTRACTION_TIME_SCAN.md",
            ["bare_load_extraction_time_scan_completed", "checks: **16/16 PASS**", "7.7000000000000002e+00"],
        )

        compare_exact(
            c0_c2,
            EXPECTED / "c0_c2_scan",
            [
                "c0_c2_bare_load_extraction_difference_timeseries.csv",
                "c0_c2_bare_load_extraction_difference_events.csv",
                "c0_c2_bare_load_extraction_difference_summary.csv",
                "c0_c2_bare_load_extraction_difference_checks.csv",
            ],
        )
        require_report_snippets(
            c0_c2 / "MILESTONE_C0_C2_BARE_LOAD_EXTRACTION_TIME_DIFFERENCE_SCAN.md",
            ["C2_advantage_persistent_on_saved_window", "checks: **20/20 PASS**", "1.8826856275459521e-04"],
        )

        with (passivity / "m12a_passivity_margin_summary.csv").open(newline="", encoding="utf-8") as handle:
            p = next(csv.DictReader(handle))
        with (m12a_scan / "m12a_bare_load_extraction_time_scan_checks.csv").open(newline="", encoding="utf-8") as handle:
            scan_checks = list(csv.DictReader(handle))
        with (c0_c2 / "c0_c2_bare_load_extraction_difference_summary.csv").open(newline="", encoding="utf-8") as handle:
            c = next(csv.DictReader(handle))
        print(f"[RESULT] passivity={p['classification']}")
        print(f"[RESULT] M12A scan checks={sum(row['status'] == 'PASS' for row in scan_checks)}/{len(scan_checks)} PASS")
        print(f"[RESULT] C0/C2={c['classification']}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write-manifest", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.write_manifest:
        write_manifest()
        return 0
    print("Post-M15A supplementary audit reproduction")
    verify_manifest()
    verify_three_audits()
    print("[PASS] all three supplementary audits reproduced")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
