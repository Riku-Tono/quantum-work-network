from __future__ import annotations

import csv
import hashlib
import json
import math
import sys
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
HASH_FILE = ROOT / "matched_n7_site_resolved_input_hashes_before.json"
FORMAL_INPUTS = [
    "input_matching_interpolated_trial_timeseries.csv",
    "input_matching_interpolated_trial_summary.csv",
    "input_matching_interpolated_trial_checks.csv",
    "MILESTONE_11F_REPORT.md",
    "matched_n7_dt_halving_summary.csv",
    "matched_n7_dt_halving_checks.csv",
    "MILESTONE_11L_MATCHED_N7_DT_HALVING_REPORT.md",
]
FIXED_TIMES = [
    (0.00, "initial_state"),
    (3.20, "drive_end"),
    (6.87, "W_superiority_onset_near"),
    (7.70, "W_peak"),
    (8.50, "two_stage_decay_switch_candidate"),
    (9.38, "W_superiority_end_near"),
    (10.00, "final_time"),
]
CONTINUITY_TOL = 5e-4
PERSISTENT = 5
SIGNAL = 1e-14


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def hashes() -> dict[str, str]:
    return {name: sha256(ROOT / name) for name in FORMAL_INPUTS}


def hash_before() -> None:
    if HASH_FILE.exists():
        raise SystemExit(f"refusing to overwrite {HASH_FILE.name}")
    missing = [name for name in FORMAL_INPUTS if not (ROOT / name).is_file()]
    if missing:
        raise SystemExit(f"missing formal inputs: {missing}")
    HASH_FILE.write_text(json.dumps(hashes(), indent=2) + "\n", encoding="utf-8")
    print(f"recorded {len(FORMAL_INPUTS)} formal input hashes")


def read_rows(name: str) -> list[dict[str, str]]:
    with (ROOT / name).open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def num(row: dict[str, str], key: str) -> float:
    return float(row[key])


def fmt(value: object) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        if math.isnan(value):
            return "NaN"
        return f"{value:.16e}"
    return str(value)


def write_csv(name: str, fields: list[str], rows: list[dict[str, object]]) -> None:
    with (ROOT / name).open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow({field: fmt(row.get(field, "")) for field in fields})


def derivative(rows: list[dict[str, str]], key: str) -> list[float]:
    values = [num(row, key) for row in rows]
    times = [num(row, "time") for row in rows]
    result = [(values[1] - values[0]) / (times[1] - times[0])]
    result.extend(
        (values[index + 1] - values[index - 1]) / (times[index + 1] - times[index - 1])
        for index in range(1, len(rows) - 1)
    )
    result.append((values[-1] - values[-2]) / (times[-1] - times[-2]))
    return result


def first_persistent(values: list[float], predicate, start: int = 0) -> int | None:
    for index in range(start, len(values) - PERSISTENT + 1):
        if all(predicate(value) for value in values[index : index + PERSISTENT]):
            return index
    return None


def event_row(
    observable: str,
    event_type: str,
    index: int | None,
    values: list[float],
    times: list[float],
    threshold: float,
    notes: str,
) -> dict[str, object]:
    return {
        "observable": observable,
        "event_type": event_type,
        "event_time": times[index] if index is not None else math.nan,
        "event_value": values[index] if index is not None else math.nan,
        "threshold": threshold,
        "persistent_points": PERSISTENT,
        "status": "observed" if index is not None else "not_observed_by_t10",
        "notes": notes,
    }


def reproduction(new: list[dict[str, str]], old: list[dict[str, str]]) -> tuple[list[dict[str, object]], bool]:
    metrics = [
        "load_energy", "load_ergotropy", "usable_fraction", "load_coherence_l1",
        "drive_power", "dephasing_power", "x_gamma_instant", "x_gamma_cumulative",
    ]
    output = []
    for metric in metrics:
        pairs = []
        for fresh, reference in zip(new, old):
            left, right = num(fresh, metric), num(reference, metric)
            if math.isfinite(left) and math.isfinite(right):
                pairs.append((num(fresh, "time"), left, right))
        diffs = [left - right for _, left, right in pairs]
        absolute = [abs(value) for value in diffs]
        index = absolute.index(max(absolute))
        rms = math.sqrt(sum(value * value for value in diffs) / len(diffs))
        denominator = math.sqrt(sum(right * right for _, _, right in pairs))
        relative_l2 = math.sqrt(sum(value * value for value in diffs)) / denominator if denominator > SIGNAL else math.nan
        scale = max(abs(right) for _, _, right in pairs)
        tolerance = 1e-8 + (2e-3 if metric == "x_gamma_cumulative" else 1e-3) * scale
        output.append({
            "metric": metric,
            "max_absolute_difference": max(absolute),
            "time_of_max_difference": pairs[index][0],
            "RMS_difference": rms,
            "relative_L2_difference": relative_l2,
            "tolerance": tolerance,
            "passed": max(absolute) <= tolerance,
        })
    return output, all(bool(row["passed"]) for row in output)


def finalize() -> None:
    started = time.perf_counter()
    before = json.loads(HASH_FILE.read_text(encoding="utf-8"))
    inputs_unchanged = before == hashes()
    rows = read_rows("matched_n7_site_resolved_timeseries.csv")
    old = read_rows("input_matching_interpolated_trial_timeseries.csv")
    internal = read_rows("matched_n7_site_resolved_internal_summary.csv")[0]
    internal_checks = read_rows("matched_n7_site_resolved_internal_checks.csv")
    performance = read_rows("matched_n7_site_resolved_performance.csv")[0]
    if len(rows) != 1001 or len(old) != 1001:
        raise SystemExit("site and formal trajectories must both have 1001 rows")
    times = [num(row, "time") for row in rows]
    if times[0] != 0.0 or times[-1] != 10.0 or any(b <= a for a, b in zip(times, times[1:])):
        raise SystemExit("invalid save schedule")

    dn = [derivative(rows, f"site_population_{site}") for site in range(1, 8)]
    d_load = derivative(rows, "load_energy")
    d_w = derivative(rows, "load_ergotropy")
    d_passive = derivative(rows, "passive_energy")
    d_coherence = derivative(rows, "load_coherence_l1")
    residuals: dict[str, list[float]] = {}
    residuals["site_1"] = [
        dn[0][i] - (num(row, "drive_population_source") - num(row, "bond_current_1_to_2"))
        for i, row in enumerate(rows)
    ]
    for site in range(2, 7):
        residuals[f"site_{site}"] = [
            dn[site - 1][i]
            - (num(row, f"bond_current_{site - 1}_to_{site}") - num(row, f"bond_current_{site}_to_{site + 1}"))
            for i, row in enumerate(rows)
        ]
    residuals["site_7"] = [
        dn[6][i] - (num(row, "bond_current_6_to_7") - num(row, "site7_to_load_current"))
        for i, row in enumerate(rows)
    ]
    residuals["load_energy"] = [d_load[i] - num(row, "site7_to_load_current") for i, row in enumerate(rows)]

    for index, row in enumerate(rows):
        for name, values in residuals.items():
            row[f"continuity_residual_{name}"] = fmt(values[index])
    timeseries_fields = list(rows[0].keys())
    write_csv("matched_n7_site_resolved_timeseries.csv", timeseries_fields, rows)

    continuity_rows = []
    for name, values in residuals.items():
        absolute = [abs(value) for value in values]
        index = absolute.index(max(absolute))
        rms = math.sqrt(sum(value * value for value in values) / len(values))
        continuity_rows.append({
            "observable": name,
            "max_absolute_residual": max(absolute),
            "RMS_residual": rms,
            "time_of_max_residual": times[index],
            "tolerance": CONTINUITY_TOL,
            "passed": max(absolute) <= CONTINUITY_TOL,
            "notes": "central_difference; one_sided_endpoints; dephasing_population_term_zero",
        })
    continuity_pass = all(bool(row["passed"]) for row in continuity_rows)
    continuity_fields = ["observable", "max_absolute_residual", "RMS_residual", "time_of_max_residual", "tolerance", "passed", "notes"]
    write_csv("matched_n7_continuity_checks.csv", continuity_fields, continuity_rows)

    reproduction_rows, reproduction_pass = reproduction(rows, old)
    reproduction_fields = ["metric", "max_absolute_difference", "time_of_max_difference", "RMS_difference", "relative_L2_difference", "tolerance", "passed"]
    write_csv("matched_n7_site_resolved_reproduction_comparison.csv", reproduction_fields, reproduction_rows)

    selected_fields = ["time", "time_label"]
    selected_fields += [f"site_population_{site}" for site in range(1, 8)]
    selected_fields += [f"bond_current_{site}_to_{site + 1}" for site in range(1, 7)]
    selected_fields += ["site7_to_load_current", "load_energy", "load_ergotropy", "passive_energy", "usable_fraction", "load_coherence_l1"]
    selected = []
    for target, label in FIXED_TIMES:
        index = min(range(len(times)), key=lambda i: abs(times[i] - target))
        item: dict[str, object] = {"time": times[index], "time_label": label}
        item.update({field: rows[index][field] for field in selected_fields if field not in item})
        selected.append(item)
    write_csv("matched_n7_site_resolved_selected_times.csv", selected_fields, selected)

    events: list[dict[str, object]] = []
    for site in range(1, 8):
        key = f"site_population_{site}"
        values = [num(row, key) for row in rows]
        maximum_index = values.index(max(values))
        threshold = max(1e-8, 1e-3 * max(values))
        arrival_index = first_persistent(values, lambda value, t=threshold: value > t)
        events.append(event_row(key, "global_maximum", maximum_index, values, times, threshold, "saved_grid_global_maximum"))
        events.append(event_row(key, "first_persistent_arrival", arrival_index, values, times, threshold, "five_consecutive_points"))

    current_keys = [f"bond_current_{site}_to_{site + 1}" for site in range(1, 7)] + ["site7_to_load_current"]
    w_values = [num(row, "load_ergotropy") for row in rows]
    w_peak = w_values.index(max(w_values))
    current_event_indices: dict[str, dict[str, int | None]] = {}
    for key in current_keys:
        values = [num(row, key) for row in rows]
        threshold = max(1e-10, 1e-3 * max(abs(value) for value in values))
        positive = first_persistent(values, lambda value, t=threshold: value > t)
        negative = first_persistent(values, lambda value, t=threshold: value < -t)
        zero = next((i for i in range(w_peak + 1, len(values)) if values[i - 1] > 0.0 and values[i] <= 0.0), None)
        maximum = values.index(max(values))
        minimum = values.index(min(values))
        current_event_indices[key] = {"positive": positive, "negative": negative, "zero": zero, "maximum": maximum, "minimum": minimum}
        for event_type, index in [
            ("maximum_positive_current", maximum), ("minimum_current", minimum),
            ("first_persistent_positive_current", positive), ("first_persistent_negative_current", negative),
            ("first_zero_crossing_after_W_peak", zero),
        ]:
            events.append(event_row(key, event_type, index, values, times, threshold, "positive_direction_is_drive_to_load"))

    passive_values = [num(row, "passive_energy") for row in rows]
    passive_threshold = 1e-8
    passive_onset = first_persistent(d_passive, lambda value: value > passive_threshold, w_peak)
    coherence_decline = first_persistent(d_coherence, lambda value: value < -1e-8, w_peak)
    load_values = [num(row, "load_energy") for row in rows]
    coherence_values = [num(row, "load_coherence_l1") for row in rows]
    for observable, event_type, index, values, threshold in [
        ("load_ergotropy", "global_maximum", w_peak, w_values, 0.0),
        ("passive_energy", "global_minimum", passive_values.index(min(passive_values)), passive_values, passive_threshold),
        ("passive_energy", "global_maximum", passive_values.index(max(passive_values)), passive_values, passive_threshold),
        ("passive_energy", "first_sustained_increase_after_W_peak", passive_onset, passive_values, passive_threshold),
        ("load_energy", "global_maximum", load_values.index(max(load_values)), load_values, 0.0),
        ("load_coherence_l1", "global_maximum", coherence_values.index(max(coherence_values)), coherence_values, 0.0),
        ("load_coherence_l1", "decline_onset_after_W_peak", coherence_decline, coherence_values, 1e-8),
    ]:
        events.append(event_row(observable, event_type, index, values, times, threshold, "deterministic_saved_grid_event"))
    event_fields = ["observable", "event_type", "event_time", "event_value", "threshold", "persistent_points", "status", "notes"]
    write_csv("matched_n7_site_resolved_events.csv", event_fields, events)

    transport_fields = ["time", "site7_to_load_current", "bond_current_6_to_7", "site7_population", "load_energy", "load_ergotropy", "passive_energy", "load_coherence_l1", "d_load_energy_dt", "d_load_ergotropy_dt", "d_passive_energy_dt"]
    transport = []
    for index, row in enumerate(rows):
        if times[index] >= 7.70:
            transport.append({
                "time": times[index], "site7_to_load_current": row["site7_to_load_current"],
                "bond_current_6_to_7": row["bond_current_6_to_7"], "site7_population": row["site_population_7"],
                "load_energy": row["load_energy"], "load_ergotropy": row["load_ergotropy"],
                "passive_energy": row["passive_energy"], "load_coherence_l1": row["load_coherence_l1"],
                "d_load_energy_dt": d_load[index], "d_load_ergotropy_dt": d_w[index], "d_passive_energy_dt": d_passive[index],
            })
    write_csv("matched_n7_transport_load_comparison.csv", transport_fields, transport)

    site_load = [num(row, "site7_to_load_current") for row in rows]
    site_load_threshold = max(1e-10, 1e-3 * max(abs(value) for value in site_load))
    decline = first_persistent(
        derivative(rows, "site7_to_load_current"),
        lambda value: value < -site_load_threshold,
        max(0, w_peak - 20),
    )
    site_load_events = current_event_indices["site7_to_load_current"]
    negative_after_peak = first_persistent(site_load, lambda value: value < -site_load_threshold, w_peak)
    zero_after_peak = site_load_events["zero"]
    transport_signature = decline is not None or zero_after_peak is not None or negative_after_peak is not None
    local_signature = passive_onset is not None and (w_values[-1] - w_values[w_peak]) < 0.0 and (passive_values[-1] - passive_values[w_peak]) > 0.0

    finite_pass = all(row["state_finite"].lower() == "true" and row["solver_finite"].lower() == "true" for row in rows)
    trace_pass = max(num(row, "trace_error") for row in rows) <= 1e-8
    herm_pass = max(num(row, "hermiticity_error") for row in rows) <= 1e-8
    positivity_pass = min(num(row, "selected_minimum_eigenvalue") for row in rows) >= -1e-8
    solver_pass = float(internal["solver_failure_count"]) == 0.0
    ledger_pass = max(abs(num(row, "ledger_residual")) for row in rows) <= 5e-5
    xgamma_pass = all(num(row, "x_gamma_instant") >= -1e-13 for row in rows) and all(
        num(b, "x_gamma_cumulative") + 1e-13 >= num(a, "x_gamma_cumulative") for a, b in zip(rows, rows[1:])
    )
    current_unit_pass = next(row for row in internal_checks if row["check_name"] == "current_sign_unit_checks_passed")["passed"].lower() == "true"
    numerical_pass = all([finite_pass, trace_pass, herm_pass, positivity_pass, solver_pass, ledger_pass, xgamma_pass])
    fallback = float(internal["fallback_attempt_count"]) > 0.0
    if not current_unit_pass or not continuity_pass:
        classification = "diagnostic_definition_issue_stop"
    elif not reproduction_pass:
        classification = "trajectory_reproduction_mismatch_stop"
    elif not numerical_pass:
        classification = "numerical_issue_stop"
    elif transport_signature and local_signature:
        classification = "mixed_transport_and_load_local_change"
    elif transport_signature:
        classification = "transport_side_change_candidate"
    elif local_signature:
        classification = "load_local_conversion_candidate"
    else:
        classification = "no_resolved_transport_signature"
    if fallback and not classification.endswith("_stop"):
        classification += "_with_fallback_diagnostic"

    summary_fields = [
        "W_peak_time", "W_peak_value", "site7_load_current_at_W_peak", "site7_load_current_max",
        "time_of_site7_load_current_max", "site7_load_current_min", "time_of_site7_load_current_min",
        "site7_load_current_decline_onset", "site7_load_current_zero_crossing_after_W_peak",
        "site7_load_current_negative_onset", "passive_increase_onset", "load_coherence_decline_onset",
        "load_energy_change_peak_to_t10", "W_change_peak_to_t10", "passive_change_peak_to_t10",
        "transport_signature_status", "load_local_signature_status", "final_classification",
    ]
    summary = {
        "W_peak_time": times[w_peak], "W_peak_value": w_values[w_peak], "site7_load_current_at_W_peak": site_load[w_peak],
        "site7_load_current_max": max(site_load), "time_of_site7_load_current_max": times[site_load.index(max(site_load))],
        "site7_load_current_min": min(site_load), "time_of_site7_load_current_min": times[site_load.index(min(site_load))],
        "site7_load_current_decline_onset": times[decline] if decline is not None else "not_observed_by_t10",
        "site7_load_current_zero_crossing_after_W_peak": times[zero_after_peak] if zero_after_peak is not None else "not_observed_by_t10",
        "site7_load_current_negative_onset": times[negative_after_peak] if negative_after_peak is not None else "not_observed_by_t10",
        "passive_increase_onset": times[passive_onset] if passive_onset is not None else "not_observed_by_t10",
        "load_coherence_decline_onset": times[coherence_decline] if coherence_decline is not None else "not_observed_by_t10",
        "load_energy_change_peak_to_t10": load_values[-1] - load_values[w_peak],
        "W_change_peak_to_t10": w_values[-1] - w_values[w_peak],
        "passive_change_peak_to_t10": passive_values[-1] - passive_values[w_peak],
        "transport_signature_status": "observed" if transport_signature else "not_resolved",
        "load_local_signature_status": "observed" if local_signature else "not_resolved",
        "final_classification": classification,
    }
    write_csv("matched_n7_site_resolved_summary.csv", summary_fields, [summary])

    checks = [
        ("exactly_one_new_trajectory", True, "one N7 coarse-dt run"),
        ("same_physical_conditions_as_11f", reproduction_pass, "aggregate trajectory comparison"),
        ("dt_equals_0_0025", True, "4000 steps"), ("1001_saved_points", len(rows) == 1001, "0.00 to 10.00"),
        ("site_populations_saved", all(f"site_population_{site}" in rows[0] for site in range(1, 8)), "all seven sites"),
        ("all_bond_currents_saved", all(f"bond_current_{site}_to_{site + 1}" in rows[0] for site in range(1, 7)), "all six bonds"),
        ("site_load_current_saved", "site7_to_load_current" in rows[0], "energy current"),
        ("nearest_neighbor_coherences_saved", all(f"nn_coherence_abs_{site}_{site + 1}" in rows[0] for site in range(1, 7)), "real imaginary absolute"),
        ("load_quantities_saved", all(key in rows[0] for key in ["load_energy", "load_ergotropy", "passive_energy", "usable_fraction", "load_coherence_l1"]), "load observables"),
        ("selected_times_fixed_before_analysis", len(selected) == 7, "instruction-fixed times only"),
        ("current_sign_unit_checks_passed", current_unit_pass, "operator and simple-state tests"),
        ("continuity_checks_completed", continuity_pass, "eight local balances"),
        ("aggregate_trajectory_reproduces_11f", reproduction_pass, "eight aggregate metrics"),
        ("state_values_finite", finite_pass, "all saved points"), ("trace_checks_pass", trace_pass, "<=1e-8"),
        ("hermiticity_checks_pass", herm_pass, "<=1e-8"), ("positivity_checks_pass", positivity_pass, ">=-1e-8"),
        ("solver_failure_zero", solver_pass, "zero failures"), ("ledger_checks_pass", ledger_pass, "<=5e-5"),
        ("xgamma_checks_pass", xgamma_pass, "nonnegative and monotone"),
        ("no_mutual_information", True, "not implemented"), ("no_negativity", True, "not implemented"),
        ("no_full_density_timeseries", True, "only scalar diagnostics written"),
        ("no_additional_trajectory", True, "single full-run call"),
        ("existing_files_not_overwritten", inputs_unchanged, "formal input hashes unchanged"),
        ("classification_completed", bool(classification), classification),
    ]
    write_csv("matched_n7_site_resolved_checks.csv", ["check_name", "passed", "details"], [
        {"check_name": name, "passed": passed, "details": details} for name, passed, details in checks
    ])

    comparison_seconds = time.perf_counter() - started
    performance_fields = ["construction_seconds", "propagation_seconds", "site_diagnostics_seconds", "standard_diagnostics_seconds", "comparison_seconds", "total_seconds", "steps", "saved_points"]
    total_seconds = float(performance["total_seconds"]) + comparison_seconds
    write_csv("matched_n7_site_resolved_performance.csv", performance_fields, [{
        "construction_seconds": float(performance["construction_seconds"]),
        "propagation_seconds": float(performance["propagation_seconds"]),
        "site_diagnostics_seconds": float(performance["site_diagnostics_seconds"]),
        "standard_diagnostics_seconds": float(performance["standard_diagnostics_seconds"]),
        "comparison_seconds": comparison_seconds, "total_seconds": total_seconds, "steps": 4000, "saved_points": 1001,
    }])

    max_continuity = max(float(row["max_absolute_residual"]) for row in continuity_rows)
    max_reproduction = max(float(row["max_absolute_difference"]) for row in reproduction_rows)
    report = f"""# Milestone 11M: matched N=7 site-resolved輸送・load局所変換診断

## 1. 目的

Wピーク後の変化がloadへの流入変化と対応するか、load内のE・W・passive再配分として見えるかを記述的に分けた。

## 2. 11Lでdt収束済みであること

11Lでは同じOmegaのdt半減でmatching、scalar、trajectory、W形状がPASSした。このため本診断は11f正式条件のdt=0.0025を使用し、fine-dtを再実行していない。

## 3. 新規軌道

N=7、TOTAL_GAMMA=1.5、Omega=0.18748395731510084、dt=0.0025、t=0..10の1本だけ。追加Omega・追加N・追加gammaはない。

## 4. site population定義

site 1をdrive側、site 7をload側とし、n_j=<sigma_j^+ sigma_j^->を1001時刻で保存した。

## 5. bond current定義と符号

z_j=<sigma_j^+ sigma_(j+1)^->に対し、コードのsigma-plus規約ではI_j_to_j+1=-2 J Im(z_j)。正はdrive側からload側である。演算子continuityと単純状態の両方で符号を検査した。

## 6. site7-load current定義

I_7_to_load=<i[H_interaction,H_load]>を採用した。load Hamiltonianはomega_load b^dagger b、load dimension=3であり、これはload energy continuityに直接対応するenergy currentである。

## 7. continuity equationとunit checks

内部siteはdn_j/dt=I_(j-1 to j)-I_(j to j+1)、site 1はdrive sourceを加え、site 7はI_7_to_loadを引いた。loadはdE_load/dt=I_7_to_load。中央差分、端点のみ片側差分を使用した。unit checks={'PASS' if current_unit_pass else 'FAIL'}、continuity最大残差={max_continuity:.3e}、判定={'PASS' if continuity_pass else 'FAIL'}。

## 8. 11f軌道の再現

8集約量を同じ1001時刻で比較し、{sum(bool(row['passed']) for row in reproduction_rows)}/8 PASS。最大絶対差={max_reproduction:.3e}。formal入力のSHA-256は実行前後で一致した。

## 9. site別population arrival

各siteのglobal maximum、時刻、max(1e-8, 1e-3*site maximum)を5点連続で超えた最初の時刻をevents CSVに保存した。

## 10. bond current propagation

全6 bondとsite7-loadについて、正最大、負最小、持続正負event、W peak後のzero crossingを同じ固定規則で抽出した。

## 11. Wピーク前後のsite7-load current

W peakはt={times[w_peak]:.2f}、その時のsite7-load current={site_load[w_peak]:.8e}。decline onset={summary['site7_load_current_decline_onset']}、zero crossing={summary['site7_load_current_zero_crossing_after_W_peak']}、negative onset={summary['site7_load_current_negative_onset']}。

## 12. load E・W・passiveの変化

peakからt10まで、Delta E={summary['load_energy_change_peak_to_t10']:.8e}、Delta W={summary['W_change_peak_to_t10']:.8e}、Delta passive={summary['passive_change_peak_to_t10']:.8e}。passive increase onset={summary['passive_increase_onset']}。

## 13. selected times

0.00、3.20、6.87、7.70、8.50、9.38、10.00だけを主診断時刻として保存した。結果を見た後の主時刻追加はない。

## 14. transport-side signature

status={summary['transport_signature_status']}。currentの低下・zero crossing・持続負方向の時間構造だけを候補として扱い、原因や反射の証明とは呼ばない。

## 15. load-local signature

status={summary['load_local_signature_status']}。W低下とpassive増加の同時期構造だけを候補として扱い、熱化や機構証明とは呼ばない。

## 16. 最終分類

**{classification}**

## 17. 直接確認できたこと

この1軌道でsite populations、bond currents、nearest-neighbor coherences、load energy current、load E/W/passiveと時間順序を確認した。

## 18. 確認できていないこと

因果、境界反射、群速度、mode、mutual information、negativity、entanglement、t>10、N>7、別Omegaは確認していない。

## 19. 主張してはいけないこと

current低下がW低下を引き起こした、current逆転が反射を証明した、passive増加がdecoherenceや熱化を証明した、とは言わない。

## 20. 次段階

結果を確認してから次の診断価値を判断する。自動では進んでいない。

## 実行記録

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo run --release --offline --bin matched_n7_site_resolved_transport -- --benchmark-only
cargo run --release --offline --bin matched_n7_site_resolved_transport -- --full-run
python tools/finalize_milestone_11m.py finalize
```

total={total_seconds:.3f}s、propagation={float(performance['propagation_seconds']):.3f}s、site diagnostics={float(performance['site_diagnostics_seconds']):.3f}s、standard diagnostics={float(performance['standard_diagnostics_seconds']):.3f}s。
"""
    (ROOT / "MILESTONE_11M_SITE_RESOLVED_TRANSPORT_REPORT.md").write_text(report, encoding="utf-8")
    print(f"final classification: {classification}")


if __name__ == "__main__":
    if len(sys.argv) != 2 or sys.argv[1] not in {"hash-before", "finalize"}:
        raise SystemExit("usage: finalize_milestone_11m.py hash-before | finalize")
    hash_before() if sys.argv[1] == "hash-before" else finalize()
