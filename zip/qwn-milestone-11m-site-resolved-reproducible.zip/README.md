# Milestone 11M: matched N=7 site-resolved transport diagnostic

This package reproduces the minimal site-resolved diagnosis of the already matched and dt-checked `N=7` trajectory. It separates observed transport-side timing from observed load-local E/W/passive timing without claiming a causal mechanism.

## Fixed condition

```text
N = 7; TOTAL_GAMMA = 1.5; gamma_site = 1.5 / 7
Omega = 0.18748395731510084; dt = 0.0025
t = 0..10; 4000 fixed-step RK4 steps; 1001 saved points
```

The run reuses formal 11f/11L inputs read-only. It executes exactly one new site-resolved trajectory; it does not rematch Omega, change noise, add N, run t>10, or calculate mutual information, negativity, or full density-matrix time series.

## Recorded result

```text
mixed_transport_and_load_local_change_with_fallback_diagnostic
```

| Event or change | Recorded value |
| --- | ---: |
| W peak | `t=7.70`, `W=3.3852501212993710e-03` |
| site7-to-load current decline onset | `t=7.50` |
| zero crossing after W peak | `t=8.15` |
| persistent negative onset | `t=8.16` |
| passive increase onset | `t=7.70` |
| delta load energy, peak to t=10 | `-1.8634507496082930e-04` |
| delta W, peak to t=10 | `-1.0587822145716654e-03` |
| delta passive, peak to t=10 | `+8.7243713961083613e-04` |

Both a transport-side current change and a load-local redistribution were observed on this trajectory. This does not show that the current change caused W loss, that negative current proves a reflection, or that passive increase proves thermalization or decoherence.

## Quick verification

Requirements: Python 3.10+; no third-party packages.

```bash
python scripts/verify.py --reference
```

This checks formal-input hashes, 1001 saved points, the eight aggregate reproduction metrics, continuity, all stored checks, and the timing summary.

## Full reproduction

Requirements: Rust stable and Cargo. A fresh machine normally needs network access once to download the lockfile-pinned dependencies.

```bash
python scripts/prepare_run.py
cd run
python tools/finalize_milestone_11m.py hash-before
cargo run --release --manifest-path ../Cargo.toml --bin matched_n7_site_resolved_transport -- --benchmark-only
cargo run --release --manifest-path ../Cargo.toml --bin matched_n7_site_resolved_transport -- --full-run
python tools/finalize_milestone_11m.py finalize
cd ..
python scripts/verify.py --generated run
```

The original full run took about 3763 seconds. The new run remains isolated in gitignored `run/`.

## Layout

- `src/`, `Cargo.toml`, `Cargo.lock`: exact model and locked dependencies.
- `reference/formal-inputs/`: read-only 11f and 11L formal inputs.
- `reference/site-resolved-results/`: original 11M time series, event table, comparisons, checks, continuity table, and report.
- `tools/finalize_milestone_11m.py`: original finalizer.
- `scripts/prepare_run.py`: stages only the declared formal inputs into an empty run directory.

## License note

`Cargo.toml` declares MIT for the Rust package. Confirm the intended copyright holder and add a repository-level `LICENSE` before public release.
