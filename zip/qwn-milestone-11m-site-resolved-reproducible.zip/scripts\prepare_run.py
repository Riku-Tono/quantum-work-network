#!/usr/bin/env python3
from __future__ import annotations

import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "run"


def main() -> None:
    if RUN.exists() and any(RUN.iterdir()):
        raise SystemExit("run/ already contains files; use a fresh extraction for another full run")
    RUN.mkdir(exist_ok=True)
    for source in (ROOT / "reference" / "formal-inputs").iterdir():
        if source.is_file():
            shutil.copy2(source, RUN / source.name)
    (RUN / "tools").mkdir(exist_ok=True)
    shutil.copy2(ROOT / "tools" / "finalize_milestone_11m.py", RUN / "tools" / "finalize_milestone_11m.py")
    print("prepared isolated run/ with 7 formal inputs and the finalizer")


if __name__ == "__main__":
    main()
