# Milestone 11M: matched N=7 site-resolved輸送・load局所変換診断

## 1. 目的

Wピーク後の変化がloadへの流入変化と対応するか、load内のE・W・passive再配分として見えるかを記述的に分けた。

## 2. 11Lでdt収束済みであること

11Lでは同じOmegaのdt半減でmatching、scalar、trajectory、W形状がPASSした。このため本診断は11f正式条件のdt=0.0025を使用し、fine-dtを再実行していない。

## 3. 新規軌道

N=7、TOTAL_GAMMA=1.5、Omega=0.18748395731510084、dt=0.0025、t=0..10の1本だけ。追加Omega・追加N・追加gammaはない。

## 4. site population定義

site 1をdrive側、site 7をload側とし、n_j=<sigma_j^+ sigma_j^->を1001時刻で保存した。

## 5. bond current定義と符号

z_j=<sigma_j^+ sigma_(j+1)^->に対し、コードのsigma-plus規約ではI_j_to_j+1=-2 J Im(z_j)。正はdrive側からload側である。演算子continuityと単純状態の両方で符号を検査した。

## 6. site7-load current定義

I_7_to_load=<i[H_interaction,H_load]>を採用した。load Hamiltonianはomega_load b^dagger b、load dimension=3であり、これはload energy continuityに直接対応するenergy currentである。

## 7. continuity equationとunit checks

内部siteはdn_j/dt=I_(j-1 to j)-I_(j to j+1)、site 1はdrive sourceを加え、site 7はI_7_to_loadを引いた。loadはdE_load/dt=I_7_to_load。中央差分、端点のみ片側差分を使用した。unit checks=PASS、continuity最大残差=1.373e-05、判定=PASS。

## 8. 11f軌道の再現

8集約量を同じ1001時刻で比較し、8/8 PASS。最大絶対差=0.000e+00。formal入力のSHA-256は実行前後で一致した。

## 9. site別population arrival

各siteのglobal maximum、時刻、max(1e-8, 1e-3*site maximum)を5点連続で超えた最初の時刻をevents CSVに保存した。

## 10. bond current propagation

全6 bondとsite7-loadについて、正最大、負最小、持続正負event、W peak後のzero crossingを同じ固定規則で抽出した。

## 11. Wピーク前後のsite7-load current

W peakはt=7.70、その時のsite7-load current=8.76973969e-04。decline onset=7.5、zero crossing=8.15、negative onset=8.16。

## 12. load E・W・passiveの変化

peakからt10まで、Delta E=-1.86345075e-04、Delta W=-1.05878221e-03、Delta passive=8.72437140e-04。passive increase onset=7.7。

## 13. selected times

0.00、3.20、6.87、7.70、8.50、9.38、10.00だけを主診断時刻として保存した。結果を見た後の主時刻追加はない。

## 14. transport-side signature

status=observed。currentの低下・zero crossing・持続負方向の時間構造だけを候補として扱い、原因や反射の証明とは呼ばない。

## 15. load-local signature

status=observed。W低下とpassive増加の同時期構造だけを候補として扱い、熱化や機構証明とは呼ばない。

## 16. 最終分類

**mixed_transport_and_load_local_change_with_fallback_diagnostic**

## 17. 直接確認できたこと

この1軌道でsite populations、bond currents、nearest-neighbor coherences、load energy current、load E/W/passiveと時間順序を確認した。

## 18. 確認できていないこと

因果、境界反射、群速度、mode、mutual information、negativity、entanglement、t>10、N>7、別Omegaは確認していない。

## 19. 主張してはいけないこと

current低下がW低下を引き起こした、current逆転が反射を証明した、passive増加がdecoherenceや熱化を証明した、とは言わない。

## 20. 次段階

結果を確認してから次の診断価値を判断する。自動では進んでいない。

## 実行記録

```text
cargo fmt --all -- --check
cargo test --release --offline
cargo run --release --offline --bin matched_n7_site_resolved_transport -- --benchmark-only
cargo run --release --offline --bin matched_n7_site_resolved_transport -- --full-run
python tools/finalize_milestone_11m.py finalize
```

total=3762.695s、propagation=2027.550s、site diagnostics=1291.209s、standard diagnostics=431.901s。
