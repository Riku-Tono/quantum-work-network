#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CLASSIFICATION = "mixed_transport_and_load_local_change_with_fallback_diagnostic"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def passed(value: str) -> bool:
    return value.lower() == "true"


def check(result: Path, label: str) -> None:
    summary = rows(result / "matched_n7_site_resolved_summary.csv")[0]
    timeseries = rows(result / "matched_n7_site_resolved_timeseries.csv")
    checks = rows(result / "matched_n7_site_resolved_checks.csv")
    reproduction = rows(result / "matched_n7_site_resolved_reproduction_comparison.csv")
    continuity = rows(result / "matched_n7_continuity_checks.csv")
    if len(timeseries) != 1001:
        raise SystemExit(f"FAIL {label}: expected 1001 time rows")
    if summary["final_classification"] != CLASSIFICATION:
        raise SystemExit(f"FAIL {label}: classification differs")
    if any(not passed(row["passed"]) for row in checks):
        raise SystemExit(f"FAIL {label}: an overall check failed")
    if len(reproduction) != 8 or any(not passed(row["passed"]) for row in reproduction):
        raise SystemExit(f"FAIL {label}: aggregate reproduction differs")
    if any(float(row["max_absolute_residual"]) > 5e-4 for row in continuity):
        raise SystemExit(f"FAIL {label}: continuity tolerance exceeded")
    if summary["site7_load_current_negative_onset"] != "8.1600000000000001e+00":
        raise SystemExit(f"FAIL {label}: negative-current onset differs")
    if summary["passive_increase_onset"] != "7.7000000000000002e+00":
        raise SystemExit(f"FAIL {label}: passive onset differs")
    print(f"PASS {label}: 1001 points, 8 reproduction metrics, continuity, and event timing")


def main() -> None:
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--reference", action="store_true")
    group.add_argument("--generated", metavar="RUN_DIRECTORY")
    args = parser.parse_args()
    if args.reference:
        hashes = json.loads((ROOT / "reference" / "site-resolved-results" / "matched_n7_site_resolved_input_hashes_before.json").read_text(encoding="utf-8"))
        for name, expected in hashes.items():
            actual = sha256(ROOT / "reference" / "formal-inputs" / name)
            if actual != expected:
                raise SystemExit(f"FAIL reference input hash: {name}")
        check(ROOT / "reference" / "site-resolved-results", "stored reference")
        print("PASS all formal-input SHA-256 values")
    else:
        run = Path(args.generated).resolve()
        hashes = json.loads((run / "matched_n7_site_resolved_input_hashes_before.json").read_text(encoding="utf-8"))
        for name, expected in hashes.items():
            if sha256(run / name) != expected:
                raise SystemExit(f"FAIL generated input hash: {name}")
        check(run, "generated run")


if __name__ == "__main__":
    main()
